﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller
{
    /*
     * 
     * 
     * 
     * @author Akin Kula
     * @author Jonas Frei
     */ 
    public class SpyLogic
    {

        /*
        * 
        * 
        * 
        * @autor Akin Kula
        * @author Jonas Frei
        */
        public static Operation CheckSpy(State currentState, Character currentCharacter, List<Character> npclist)
        {




            Character nearestUnknownSpy = GetNearestUnknownSpy(currentState, currentCharacter, npclist);
                 
            //check range
            if (nearestUnknownSpy!=null && Point.GetDistance(currentCharacter.coordinates, nearestUnknownSpy.coordinates) < 2.0)// !=null von jonas
            {
                //make spy action


                if (currentCharacter.getAp() > 0)
                {
                    Operation operation = new Operation(currentCharacter.getGuid(), OperationEnum.SPY_ACTION, nearestUnknownSpy.coordinates);
                    return operation;
                }
                else
                    return null;//return MovementLogic.MoveCharacter(currentState, currentCharacter, nearestUnknownSpy.coordinates);

            }
           
            if (nearestUnknownSpy == null)            
                return null;            
            else            
                return MovementLogic.MoveCharacter(currentState, currentCharacter, nearestUnknownSpy.coordinates);                     
        }


        /*
         * 
         * 
         * 
         * @autor Akin Kula
         * @author Jonas Frei
         */
        public static Character GetNearestUnknownSpy(State currentState, Character currentCharacter, List<Character> npclist)
        {
            List<Character> unknownCharacter = npclist;

            int nearest = int.MaxValue;
            Character nearestCharacter = null;

            ASearchMap aSearchMap = new ASearchMap(currentState.map);


            for (int i = 0; i < unknownCharacter.Count(); i++)
            {
                Point c = unknownCharacter.ElementAt(i).coordinates;

                List<Point> path = aSearchMap.CalcShortestPath(currentCharacter.coordinates, c);
                if (path != null && path.Count() <= nearest)
                {
                    nearest = path.Count();
                    nearestCharacter = unknownCharacter.ElementAt(i);
                }
            }
            return nearestCharacter;
        }

    }
}
