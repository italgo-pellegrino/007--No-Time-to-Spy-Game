﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller.operationsWithoutMovement
{
    public class CommandLineInterface
    {

        public string address = "localhost";
        public int port = 7007;
        public static int verbosity = 0; //0 -> basic ausgabe 1 -> alles auch json nachrichten
        public string name = "team003";
        public int difficulty = 0;


        public static int delay = -1;



        class Option
        {
            public String name;
            public String alias;
            public Boolean optional;
            public List<String> inputParam;



            public Option(String name, String alias, Boolean optional, List<String> inputParam)
            {
                this.name = name;
                this.alias = alias;
                this.optional = optional;
                this.inputParam = inputParam;
            }


            public bool EqualsArg(String arg)
            {
                return name.Equals(arg) || alias.Equals(arg);
            }


            public override string ToString()
            {
                string a = name + "\t" + alias + "\t";
                if (inputParam.Count() != 0)
                {

                    foreach (string arg in inputParam)
                    {
                        a += "<" + arg + ">";
                        a += " ";
                    }
                }
                return a;
            }

            public override int GetHashCode()
            {
                int hashCode = -1752726994;
                hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(name);
                hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(alias);
                hashCode = hashCode * -1521134295 + optional.GetHashCode();
                return hashCode;
            }
        }


        public CommandLineInterface() { 
            
        }


        public bool Parse(String[] args) {

            //input parameter lists
            List<String> optionAddressParameterList = new List<String>();
            optionAddressParameterList.Add("ip");

            List<String> optionXParameterList = new List<String>();
            optionXParameterList.Add("key");
            optionXParameterList.Add("value");

            List<String> optionHelpParameterList = new List<String>();

            List<String> optionPortParameterList = new List<String>();
            optionPortParameterList.Add("port");

            List<String> optionVerbosityParameterList = new List<String>();
            optionVerbosityParameterList.Add("int");

            List<String> optionNameParameterList = new List<String>();
            optionNameParameterList.Add("String");

            List<String> optionDifficultyParameterList = new List<String>();
            optionDifficultyParameterList.Add("int");






            Option optionAddress = new Option("--address", "-a", false, optionAddressParameterList);
            Option optionX = new Option("--x", "-x", false, optionXParameterList);
            Option optionHelp = new Option("--help", "-h", true, optionHelpParameterList);
            Option optionPort = new Option("--port", "-p", true, optionPortParameterList);
            Option optionVerbosity = new Option("--verbosity", "-v", true, optionVerbosityParameterList);
            Option optionName = new Option("--name", "-n", true, optionNameParameterList);
            Option optionDifficulty = new Option("--difficulty", "-d", true, optionDifficultyParameterList);

            List<Option> commands = new List<Option>();
            commands.Add(optionAddress);
            commands.Add(optionX);
            commands.Add(optionHelp);
            commands.Add(optionPort);
            commands.Add(optionVerbosity);
            commands.Add(optionName);
            commands.Add(optionDifficulty);


            bool isOptionAddress = false;
            bool isOptionXKey = false;
            bool isOptionXValue = false;
            bool isOptionPort = false;
            bool isOptionVerbosity = false;
            bool isOptionName = false;
            bool isOptionDifficulty = false;


            string key_temp = "";


            Hashtable settings = new Hashtable();

            foreach (String arg in args)
            {
                try
                {

                    if (isOptionAddress)
                    {
                        address = arg;
                        isOptionAddress = false;
                    }
                    else if (isOptionPort)
                    {
                        port = int.Parse(arg);
                        isOptionPort = false;
                    }
                    else if (isOptionVerbosity)
                    {
                        verbosity = int.Parse(arg);
                        isOptionVerbosity = false;
                    }
                    else if (isOptionName)
                    {
                        name = arg;
                        isOptionName = false;
                    }
                    else if (isOptionXKey)
                    {
                        key_temp = arg;
                        isOptionXKey = false;
                        isOptionXValue = true;
                    }
                    else if (isOptionXValue)
                    {

                        settings.Add(key_temp, arg);
                        isOptionXValue = false;
                    }
                    else if (isOptionDifficulty)
                    {

                        difficulty = int.Parse(arg);
                        isOptionDifficulty = false;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("something went wrong");
                    return false;
                }





                if (optionHelp.EqualsArg(arg))
                {

                    Console.WriteLine("Help\r\n=======================================");
                    commands.ForEach(c =>
                    {
                        Console.WriteLine(c);
                    });
                    Console.WriteLine("\r\n");
                    return true;
                }
                else if (optionAddress.EqualsArg(arg))
                {
                    isOptionAddress = true;
                }
                else if (optionPort.EqualsArg(arg))
                {
                    isOptionPort = true;
                }
                else if (optionVerbosity.EqualsArg(arg))
                {
                    isOptionVerbosity = true;
                }
                else if (optionName.EqualsArg(arg))
                {
                    isOptionName = true;
                }
                else if (optionX.EqualsArg(arg))
                {
                    isOptionXKey = true;
                }
                else if (optionDifficulty.EqualsArg(arg))
                {
                    isOptionDifficulty = true;
                }
            }


            if (settings.Contains("delay")) {
                try
                {
                    delay = int.Parse((string)settings["delay"]);

                }
                catch (Exception e) {
                    if(CommandLineInterface.verbosity>=1)
                        Debug.WriteLine(e);
                    return false;
                }
                
            }



            if (isOptionAddress || isOptionPort || isOptionXKey || isOptionXValue || isOptionPort
                || isOptionVerbosity || isOptionName || isOptionDifficulty)
                return false;



            return true;
        }

    }
}
