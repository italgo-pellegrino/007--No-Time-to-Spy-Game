﻿using System;

namespace ConsoleApp1.Controller
{

    /* @author akin kula*/

    public class AStarPoint : IComparable
    {
        public int x, y;

        public double GCost; // how far from starting point
        public double HCost; // how far from end point
        public double FCost; // gCost + hCost


        public AStarPoint parent; //parent pointer

        public AStarPoint(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int CompareTo(object obj)
        {
            AStarPoint a = (AStarPoint)obj;
            if (FCost == a.FCost)
                return 0;
            else if (FCost < a.FCost)
                return -1;
            else
                return 1;
        }

        public override bool Equals(Object obj)
        {
            //Check for null and compare run-time types.
            if ((obj == null) || !this.GetType().Equals(obj.GetType()))
            {
                return false;
            }
            else
            {
                AStarPoint p = (AStarPoint)obj;
                return (x == p.x) && (y == p.y);
            }
        }

        public override int GetHashCode()
        {
            return (x << 2) ^ y;
        }

        /*
        public static Vector3Int point_to_vector3int(Point p)
        {
            return new Vector3Int(p.x, p.y, 0);
        }
        */
    }
}