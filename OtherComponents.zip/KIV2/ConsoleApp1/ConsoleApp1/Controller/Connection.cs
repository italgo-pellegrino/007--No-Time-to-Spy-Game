using System;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using ConsoleApp1.model.networking;
using System.Diagnostics;
using ConsoleApp1.Controller;
using WebSocketSharp;
using System.Threading;
using System.Runtime.CompilerServices;
using ConsoleApp1.Controller.operationsWithoutMovement;

public class Connection
{
    static WebSocket websocket;
    public static GameHandler gameHandler = new GameHandler();

    // Start is called before the first frame update
    void Start()
   {
   }

  // Update is called once per frame
  void Update()
  {
              
  }
    
  public static void SendWebSocketMessage(HelloMessage message)
  {
    if (websocket.ReadyState == WebSocketState.Open)
    {
      // Sending bytes
      websocket.Send(new byte[] { 10, 20, 30 });
            // Sending plain text
            string json = JsonConvert.SerializeObject(message);
            if(CommandLineInterface.verbosity >= 1)
                Debug.WriteLine(json);
            json = parseDate(json);
            websocket.Send(json);          
    }
  }
    
    public static void SendWebSocketMessage(ReconnectMessage message)
    {
        if (websocket.ReadyState == WebSocketState.Open)
        {
            // Sending bytes
            websocket.Send(new byte[] { 10, 20, 30 });
            // Sending plain text

            string json = JsonConvert.SerializeObject(message);           
            json = parseDate(json);
            websocket.Send(json);
        }
    }
 
    public static void SendWebSocketMessage(ItemChoiceMessage message)
    {
        if (websocket.ReadyState == WebSocketState.Open)
        {
            // Sending bytes
            websocket.Send(new byte[] { 10, 20, 30 });
            // Sending plain text           
            string json = JsonConvert.SerializeObject(message);
            json = parseDate(json);
            if (CommandLineInterface.verbosity >= 1)
                Debug.WriteLine("\n"+json+"\n");
            websocket.Send(json);          
        }
    }
    
     public static void SendWebSocketMessage(EquipmentChoiceMessage message)
     {
         if (websocket.ReadyState == WebSocketState.Open)
         {
             // Sending bytes
             websocket.Send(new byte[] { 10, 20, 30 });
            // Sending plain text
            string json = JsonConvert.SerializeObject(message);          
            //Debug.Log(message.equipment.Values);

            json = parseDate(json);
            if (CommandLineInterface.verbosity >= 1)
                Debug.WriteLine(json);
            websocket.Send(json);
        }
     } 
   
    public static void SendWebSocketMessage(GameOperationMessage message)
    {
        if (websocket.ReadyState == WebSocketState.Open)
        {
            // Sending bytes
            websocket.Send(new byte[] { 10, 20, 30 });
            // Sending plain text

            string json = JsonConvert.SerializeObject(message);
            json = parseDate(json);
            if (CommandLineInterface.verbosity >= 1)
                Debug.WriteLine(json);
            websocket.Send(json);
        }
    }

    public static void SendWebSocketMessage(GameLeaveMessage message)
    {
        if (websocket.ReadyState == WebSocketState.Open)
        {
            // Sending bytes
            websocket.Send(new byte[] { 10, 20, 30 });
            // Sending plain text

            string json = JsonConvert.SerializeObject(message);
            json = parseDate(json);
            websocket.Send(JsonConvert.SerializeObject(message));
        }
    }
    
    public static void SendWebSocketMessage(RequestMetaInformationMessage message)
        {
            if (websocket.ReadyState == WebSocketState.Open)
            {
                // Sending bytes
                websocket.Send(new byte[] { 10, 20, 30 });
                // Sending plain text
                websocket.Send(JsonConvert.SerializeObject(message));
            }
        }

    //we dont do no replays boii   
    /* 
        async void SendWebSocketMessage(RequestReplay message)
        {
            if (websocket.State == WebSocketState.Open)
            {
                // Sending bytes
                await websocket.Send(new byte[] { 10, 20, 30 });
                // Sending plain text
                await websocket.SendText(JsonConvert.SerializeObject(message));
            }
        }
     */
    public static void connectToServer(string ip,int port)
    {

        websocket = new WebSocket("ws://" + ip + ":" + port + "/websockets/game");
        

            websocket.OnOpen += (sender, e) =>
            {
                Debug.WriteLine("Connection open! " + e);

            };

            websocket.OnError += (sender, e) =>
            {
                Debug.WriteLine("Error! " + e);
            };

            websocket.OnClose += (sender, e) =>
            {
                Debug.WriteLine("Connection closed! " + e);

            };
            websocket.OnMessage += (sender, e) =>
            {
                try
                {

                    // Reading a plain text message
                    var messageString = System.Text.Encoding.UTF8.GetString(e.RawData);
                    if (CommandLineInterface.verbosity >= 1)
                        Debug.WriteLine(messageString);

                    var mS = messageString;
                    var dateTimeConverter = new IsoDateTimeConverter { DateTimeFormat = "dd.MM.yyyy HH:mm:ss" };
                    MessageContainer messageJson = JsonConvert.DeserializeObject<MessageContainer>(mS, dateTimeConverter);



                    switch (messageJson.type)
                    {
                        case MessageTypeEnum.HELLO:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.HELLO_REPLY:
                            HelloReplyMessage helloReplyJson = JsonConvert.DeserializeObject<HelloReplyMessage>(mS, dateTimeConverter);
                            HelloReplyMessage helloReplyMessage = new HelloReplyMessage(helloReplyJson.clientId, helloReplyJson.creationDate, helloReplyJson.sessionId, helloReplyJson.level, helloReplyJson.settings, helloReplyJson.characterSettings);
                            gameHandler.onHelloReply(helloReplyMessage);
                            break;
                        case MessageTypeEnum.RECONNECT:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.GAME_STARTED:
                            GameStartedMessage gameStartedJson = JsonConvert.DeserializeObject<GameStartedMessage>(mS, dateTimeConverter);
                            GameStartedMessage gameStartedMessage = new GameStartedMessage(gameStartedJson.clientId, gameStartedJson.creationDate, gameStartedJson.playerOneId, gameStartedJson.playerTwoId, gameStartedJson.playerOneName, gameStartedJson.playerTwoName, gameStartedJson.sessionId);
                            gameHandler.onGameStarted(gameStartedMessage);
                            break;
                        case MessageTypeEnum.REQUEST_ITEM_CHOICE:
                            RequestItemChoiceMessage requestItemChoiceJson = JsonConvert.DeserializeObject<RequestItemChoiceMessage>(mS, dateTimeConverter);
                            RequestItemChoiceMessage requestItemChoiceMessage = new RequestItemChoiceMessage(requestItemChoiceJson.clientId, requestItemChoiceJson.creationDate, requestItemChoiceJson.offeredCharacterIds, requestItemChoiceJson.offeredGadgets);
                            gameHandler.onRequestItemChoice(requestItemChoiceMessage);
                            break;
                        case MessageTypeEnum.ITEM_CHOICE:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.REQUEST_EQUIPMENT_CHOICE:
                            RequestEquipmentChoiceMessage requestEquipmentChoiceJson = JsonConvert.DeserializeObject<RequestEquipmentChoiceMessage>(mS, dateTimeConverter);
                            RequestEquipmentChoiceMessage requestEquipmentChoiceMessage = new RequestEquipmentChoiceMessage(requestEquipmentChoiceJson.clientId, requestEquipmentChoiceJson.creationDate, requestEquipmentChoiceJson.chosenCharacterIds, requestEquipmentChoiceJson.chosenGadgets);
                            gameHandler.onRequestEquipmentChoice(requestEquipmentChoiceMessage);
                            break;
                        case MessageTypeEnum.EQUIPMENT_CHOICE:
                            Debug.WriteLine("Wrong Message");

                            break;
                        case MessageTypeEnum.GAME_STATUS:
                            GameStatusMessage gameStatusJson = JsonConvert.DeserializeObject<GameStatusMessage>(mS, dateTimeConverter);
                            GameStatusMessage gameStatusMessage = new GameStatusMessage(gameStatusJson.clientId, gameStatusJson.creationDate, gameStatusJson.activeCharacterId, statusOperations(mS, gameStatusJson), gameStatusJson.state, gameStatusJson.isGameOver);
                            //Debug.Log(JsonConvert.SerializeObject(gameStatusMessage));
                            gameHandler.onGameStatus(gameStatusMessage);
                            break;
                        case MessageTypeEnum.REQUEST_GAME_OPERATION:
                            RequestGameOperationMessage requestGameOperationJson = JsonConvert.DeserializeObject<RequestGameOperationMessage>(mS, dateTimeConverter);
                            RequestGameOperationMessage requestGameOperationMessage = new RequestGameOperationMessage(requestGameOperationJson.clientId, requestGameOperationJson.creationDate, requestGameOperationJson.characterId);
                            gameHandler.onRequestGameOperation(requestGameOperationMessage);
                            break;
                        case MessageTypeEnum.GAME_OPERATION:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.STATISTICS:
                            StatisticsMessage statisticsJson = JsonConvert.DeserializeObject<StatisticsMessage>(mS, dateTimeConverter);
                            gameHandler.onStatistics(statisticsJson);
                            break;
                        case MessageTypeEnum.GAME_LEAVE:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.GAME_LEFT:
                            GameLeftMessage gameLeftJson = JsonConvert.DeserializeObject<GameLeftMessage>(mS, dateTimeConverter);
                            GameLeftMessage gameLeftMessage = new GameLeftMessage(gameLeftJson.clientId, gameLeftJson.creationDate, gameLeftJson.leftUserId);
                            gameHandler.onGameLeft(gameLeftMessage);
                            break;
                        case MessageTypeEnum.REQUEST_GAME_PAUSE:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.GAME_PAUSE:
                            GamePauseMessage gamePauseJson = JsonConvert.DeserializeObject<GamePauseMessage>(mS, dateTimeConverter);
                            GamePauseMessage gamePauseMessage = new GamePauseMessage(gamePauseJson.clientId, gamePauseJson.creationDate, gamePauseJson.gamePaused, gamePauseJson.serverEnforced);
                            gameHandler.onGamePauseMessage(gamePauseMessage);
                            break;
                        case MessageTypeEnum.REQUEST_META_INFORMATION:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.META_INFORMATION:
                            MetaInformationMessage metaInfoJson = JsonConvert.DeserializeObject<MetaInformationMessage>(mS, dateTimeConverter);
                            gameHandler.onMetaInformation(metaInfoJson);
                            break;
                        case MessageTypeEnum.STRIKE:
                            StrikeMessage strikeJson = JsonConvert.DeserializeObject<StrikeMessage>(mS, dateTimeConverter);
                            StrikeMessage strikeMessage = new StrikeMessage(strikeJson.clientId, strikeJson.creationDate, strikeJson.strikeNr, strikeJson.strikeMax, strikeJson.reason);
                            gameHandler.onStrike(strikeMessage);
                            break;
                        case MessageTypeEnum.ERROR:
                            ErrorMessage errorJson = JsonConvert.DeserializeObject<ErrorMessage>(mS, dateTimeConverter);
                            ErrorMessage errorMessage = new ErrorMessage(errorJson.clientId, errorJson.creationDate, errorJson.reason);
                            gameHandler.onError(errorMessage);
                            break;
                        case MessageTypeEnum.REQUEST_REPLAY:
                            Debug.WriteLine("Wrong Message");
                            break;
                        case MessageTypeEnum.REPLAY:
                            // ReplayMessage message = JsonConvert.DeserializeObject<ReplayMessage>(mS);
                            // ReplayMessage testMessage = new ReplayMessage(message.sessionId,message.level,message.settings,message.characterSettings);
                            // GameHandler.readObject(testMessage);
                            break;
                        default:
                            Console.WriteLine("Default");
                            break;
                    }
                }
                catch (Exception a)
                {
                    Debug.WriteLine(a.ToString());
                }
            };
            try
            {
                websocket.Connect();
            }
            catch (Exception a) {
                Debug.WriteLine(a);
            }
        




        
    }
    public static bool isWebSocketOpen()
    {
        return websocket.ReadyState == WebSocketState.Open;
    }

    private static string parseDate(string json)
    {
        json = json.Remove(json.IndexOf("Date"), 26);
        json = json.Replace("creation", "creationDate" + "\"" + ":" + "\"" + DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss"));

        return json;
    }

    private static List<BaseOperation> statusOperations(string json, GameStatusMessage status)
    {
        List<BaseOperation> op_list = new List<BaseOperation>();
        JObject jObject = JObject.Parse(json);
        JArray array = jObject.GetValue("operations").ToObject<JArray>();
        for (int i = 0; i < status.operations.Count; i++)
        {
            BaseOperation element = status.operations[i];
            JToken token = array[i];
            switch (element.type)
            {
                case OperationEnum.CAT_ACTION:
                case OperationEnum.JANITOR_ACTION:
                case OperationEnum.RETIRE:
                case OperationEnum.SPY_ACTION:
                    op_list.Add(token.ToObject<Operation>());
                    break;
                case OperationEnum.EXFILTRATION:
                    op_list.Add(token.ToObject<Exfiltration>());
                    break;
                case OperationEnum.GADGET_ACTION:
                    op_list.Add(token.ToObject<GadgetAction>());
                    break;
                case OperationEnum.GAMBLE_ACTION:
                    op_list.Add(token.ToObject<GambleAction>());
                    break;
                case OperationEnum.MOVEMENT:
                    op_list.Add(token.ToObject<Movement>());
                    break;
                case OperationEnum.PROPERTY_ACTION:
                    op_list.Add(token.ToObject<PropertyAction>());
                    break;
            }
        }
        return op_list;
    }

    private async void OnApplicationQuit()
    {
        websocket.Close();
    }
}
