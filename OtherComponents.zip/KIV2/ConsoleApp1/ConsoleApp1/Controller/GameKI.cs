﻿using ConsoleApp1.model;
using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller
{
    /*
     * Klasse welche den optimalen Spielzug berechnet und 
     * die dafür notwendigen Informationen über den Spielverlauf speichert
     * und verwaltet.
     * 
     * 
     * @author Jonas Frei
     */
    public class GameKI
    {
        GameHandler gameHandler;

        

        public HashSet<Guid> npcList = new HashSet<Guid>();     //alle lebenden npcs und unidentifizierten Gegener
        public HashSet<Guid> enemy = new HashSet<Guid>();       //alle bekannten lebenden gegner 
        public HashSet<Guid> fraction = new HashSet<Guid>();    //alle lebenden character der eigenen fraktion

        public HashSet<Guid> usedNpcList = new HashSet<Guid>(); //alle lebenden npc die bereits informationen preisgegeben haben (und auf keinen fall gegner sind)       
        public Dictionary<Guid, double> unsuccessfullUsedNpcList = new Dictionary<Guid, double>();//alle npc die deim spionieren keine informationen preisgegeben haben aber noch nicht zu gegnern erklährt wurden
                                                                                                  //wenn die anzahl einen gewissen wert überschreitet(wahrscheinlichkeiten auf 150% wird der character den gegnern zugeordnet)
        //public HashSet<Guid> confirmedNpcs = new HashSet<Guid>(); kann für spätere verbesserungen noch hinzugefügt werden (nur für observation praktisch)

        public HashSet<int> usedSafes;                          //alle genutzten safes





        /*
         * Constuktor
         * 
         * @param Hashset<Guid> of npcs
         * @param Hashset<Guid> own fraction
         * @param gamehandler
         * 
         * @author Jonas Frei
         */
        public GameKI(HashSet<Guid> npc, HashSet<Guid> ownFraction, GameHandler handler)
        {          
            npcList = new HashSet<Guid>();      //beim konsruktoraufruf/spielstart alle spielbaren character die nicht 
            enemy = new HashSet<Guid>();        //am anfang logischerweise leer
            usedNpcList = new HashSet<Guid>();  //am anfang logischerweise leer
            fraction = new HashSet<Guid>();
            unsuccessfullUsedNpcList = new Dictionary<Guid, double>();//wenn die anzahl einen gewissen wert überschreitet(wahrscheinlichkeiten auf 100%? wird der character den gegnern zugeordnet)
            usedSafes = new HashSet<int>();


            gameHandler = handler;
            fraction = ownFraction;
            npcList = npc;
        }



        /*
         * die methode bestimmt den optimalen spielzug
         * falls kein spielzug möglich ist wird ist der Operationtyp retire
         * 
         * 
         * Entscheidungsaufbau:
         * 1. Kann der katze das halsband gebracht werden
         * 2. Kann Leben regeneriert oder ein cocktail aufgenommen werden
         * 3. Kann Spioniert / ein Tresor geöffnet werden
         * 4. Gibt es in mp reichweite potenzielle ziele die ausspioniert werden können 
         *    -> falls nein wird geprüft ob ap ausgegeben werden können
         * 5. Kann zu einem spionageziel gelaufen werden
         * 
         * 6. wenn immer noch keine aktion gefunden wurde versuche eine Ap aktion zu finden (unabhängig der reichweite)
         * 7. Falls kein Ziel gefunden wurde: Retire
         * 
         * 
         * 
         * 
         * abhängigkeiten zu Variablen vom Gamehandler: matchconfig/settings)
         * 
         * @param state
         * @param activ character
         * 
         * @return best operation
         * 
         * @autor Jonas Frei
         */
        public Operation MyTurn(State state, Guid activeCharacterId)
        {

            Operation operation = null;
            Character selectedCharacter = state.guidToCharacter(activeCharacterId);

            //wenn der aktive character im nebel sitzt kann er nichts tun ->retire
            if (!state.map.getField(selectedCharacter.coordinates).isFoggy)
            {


                //prüfen ob der katze das halsband gebracht werden kann (besste aktion)
                operation = MovementLogic.CheckNecklace(state, selectedCharacter);



                //wenn der katze das halsband nicht gebracht werden kann: prüfen ob vor der bewegung noch sinvolle aktionen ausgeführt werden können
                //operations without movement bestimmen
                Operation bestOperationWithoutMovement = null;


                HashSet<Character> allCharacters = new HashSet<Character>(state.characters);//liste aller charactere inklusive hausmeister und katze

                //auf existent der katze und des hausmeister prüfen und gegebenenfalls als character hinzufügen
                if (state.catCoordinates != null)
                {
                    Character cat = new Character(Guid.NewGuid(), "cat", new HashSet<PropertyEnum>());
                    cat.coordinates = state.catCoordinates;
                    allCharacters.Add(cat);
                }
                if (state.janitorCoordinates != null)
                {
                    Character janitor = new Character(Guid.NewGuid(), "Hausmeister", new HashSet<PropertyEnum>());
                    janitor.coordinates = state.janitorCoordinates;
                    allCharacters.Add(janitor);
                }

                //nur wenn ap vorhanden sind ins eine bestOperationWithoutMovement überhaubt möglich
                if (selectedCharacter.ap > 0)
                {
                    bestOperationWithoutMovement = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting(selectedCharacter, state.map, gameHandler.settings,
                                                                                            state.guidToCharacter(enemy),
                                                                                            state.guidToCharacter(npcList),
                                                                                            state.guidToCharacter(usedNpcList),
                                                                                            state.guidToCharacter(fraction),
                                                                                            allCharacters);
                }


                if (bestOperationWithoutMovement != null && operation == null)// = der katze kann die kette nicht gebracht werden
                {
                    //Fall 1:bestOperationWithoutMovement bietet heilung/cocktailaufnahme an und der character ist verletzt: ->heilen/cocktail aufnehmen 
                    if (bestOperationWithoutMovement.type.Equals(OperationEnum.GADGET_ACTION) && selectedCharacter.getHp() < 100)
                    {
                        GadgetAction gadgetAction = (GadgetAction)bestOperationWithoutMovement;


                        //sowohl cocktail aufnehmen als auch cocktail trinken wir hiermit abgedeckt
                        if (gadgetAction.gadget.Equals(GadgetEnum.COCKTAIL))
                        {
                            //Cocktail aufnehmen/trinken als aktion hinzufügen
                            operation = bestOperationWithoutMovement;
                        }

                    }

                    if (operation == null)
                    {
                        //Fall 2: es gibt keine potenziellen ziele zum ausspionieren in reichweite (d.h kein tresor, unused character )
                        //safes der liste der potenziellen Ziele hinzufügen
                        HashSet<Point> possibleTargets = new HashSet<Point>(state.map.getFieldsOfState(FieldStateEnum.SAFE));

                        //npcs die keine informationen preisgegeben haben der liste der potenziellen ziele hinzufügen
                        foreach (Guid character in npcList)
                        {
                            if (!usedNpcList.Contains(character))
                                possibleTargets.Add(state.guidToCharacter(character).getCoordinates());
                        }


                        //prüfen ob diese erreichbar sind
                        bool possibleTargetIsInRange = false;
                        foreach (Point target in possibleTargets)
                        {
                            try
                            {
                                state.map.validateIsInRange(selectedCharacter.coordinates, target, selectedCharacter.getMp() + 1);
                                possibleTargetIsInRange = true;
                                //wenn eines der ziele erreichbar ist muss nicht weiter geprüft werden ob noch mehr in reichweite ist
                                break;

                            }
                            catch (Exception)
                            {
                            }
                        }

                        //wenn die ki die aktionspunkte nicht zum spionieren in ein possibletarget investieren möchte(weil keine wichtigeren ziele in der nähe sind):
                        if (!possibleTargetIsInRange)
                        {
                            operation = bestOperationWithoutMovement;
                        }
                    }
                }




                //wenn der katze das halsband nicht gebracht werden konnte und keine zwischenaktion (operationWithoutMovement): versuchen einen safe zu öffnen 
                if (operation == null)
                {
                    operation = MovementLogic.CheckSafe(state, selectedCharacter, usedSafes, state.guidToCharacter(fraction).ToList());
                    if (operation != null && operation.type.Equals(OperationEnum.RETIRE))
                    {
                        //fängt den fall ab das ein character direkt vor dem safe steht und entsprchend nicht character ausspionieren gehen mollte/sich dafon entfernt
                        operation = null;

                    }
                    else
                    {
                        //add safe to used safes if the ki open a safe
                        if (operation != null)
                        {
                            Point safe = operation.target;
                            int safeindex = state.map.getField(safe).safeIndex;
                            usedSafes.Add(safeindex);
                        }



                        // wenn kein safe geöffnet/dorthin gelaufen werden kann: (+ nur wenn man nicht schon direkt vor dem safe steht) spionieren: 
                        if (operation == null)
                        {
                            HashSet<Guid> npcsWithInformations = new HashSet<Guid>();
                            foreach (Guid character in npcList)
                            {
                                if (!usedNpcList.Contains(character))
                                    npcsWithInformations.Add(character);
                            }
                            operation = SpyLogic.CheckSpy(state, selectedCharacter, state.guidToCharacter(npcsWithInformations).ToList());
                        }

                    }
                }



                //wenn nicht spioniert werden kann OperationWithoutMovement (der obere aufruf von operation without movement schliest viele aktionen aus. mit dem erneuten aufruf werden auch diese betrachtet)
                if (operation == null)
                {
                    operation = bestOperationWithoutMovement;
                }

            }



            //falls keine aktion gefunden wurde
            if (operation == null)
            {
                operation = new Operation(activeCharacterId, OperationEnum.RETIRE, null);
            }



            //dem betrachter der Ki informationen über die Gefundene Aktion mitteilen 
            Console.Out.WriteLine("\n\n");
            Console.Out.WriteLine("Character " + selectedCharacter.name + "  plant eine " + operation.type + " Aktion.\n");
            if (operation.type.Equals(OperationEnum.SPY_ACTION))
            {
                bool targetIsCharacter = state.map.fieldHasCharacter(operation.target, state.characters);
                if (targetIsCharacter)
                    Console.Out.WriteLine("Das Ziel war ein Character (" + gameHandler.getFieldMap().getCharacterOnField(operation.target, state.characters).getName() + ")");
                else
                    Console.Out.WriteLine("Das Ziel war ein Tresor");
            }



            //abfangen von fehlern:
            operation = catchApBpMistakes(operation, selectedCharacter);            
            return operation;
        }



        /*
         * detects enemy behaviour
         * 
         * 
         * Aufbau:
         * 1. Prüfen ob es sich um eine Gamestatusmessage der eigenen Frakion handelt
         * 2. je nach Fall wird dann versucht aus den gegebenen informationen zu erkennen
         *    ob es sich um einen Gegner handelt
         *    
         *    
         *          
         * Abhängigkeiten von variablen des Gamehandlers: fieldmap
         * 
         * @param GameStatusMessage 
         * 
         * @author Jonas Frei
         */
        public void enemyDetection(GameStatusMessage message)
        {

            if (fraction.Contains(message.activeCharacterId))
            {
                //----enemydetection from the owfracton-----//
                foreach (BaseOperation operation in message.operations)
                {

                    //get targetCharacter(if possible)
                    Guid targetId;
                    bool targetIsCharacter = message.state.map.fieldHasCharacter(operation.target, message.state.characters);


    
                    //verarbeiten der unterschiedlichen aktionsarten

                    if (operation.type.Equals(OperationEnum.SPY_ACTION))
                    {
                        if (operation.successful)
                        {
                            //zu used characters hinzufügen
                            if (targetIsCharacter)
                            {
                                targetId = gameHandler.getFieldMap().getCharacterOnField(operation.target, message.state.characters).getGuid();
                                usedNpcList.Add(targetId);
                            }
                        }
                        else
                        {
                            //zu unsuccesfullusedNpc hinzufügen falls noch nicht dabei 
                            if (targetIsCharacter)
                            {
                                targetId = gameHandler.getFieldMap().getCharacterOnField(operation.target, message.state.characters).getGuid();
                                try
                                {
                                    unsuccessfullUsedNpcList.Add(targetId, 0);
                                }
                                catch (Exception) { }

                                //warscheinlichkeit das observation hätte klappen müssen erhöhen
                                unsuccessfullUsedNpcList[targetId] = unsuccessfullUsedNpcList[targetId] + gameHandler.settings.spySuccessChance;

                                //wenn es unwahrscheinlich ist das der character kein Feind ist: zur feindesliste hinzufügen
                                if (unsuccessfullUsedNpcList[targetId] > 1.5)
                                {
                                    enemy.Add(targetId);
                                    npcList.Remove(targetId);
                                }
                            }
                        }
                    }
                    else if (operation.type.Equals(OperationEnum.GADGET_ACTION))
                    {
                        //herausfinden welches gadget benutzt wurde                      

                        GadgetAction gadgetAction = (GadgetAction)operation;
                        if (gadgetAction.gadget == null)
                        {
                            //fehler vom server abfangen
                        }
                        else if (gadgetAction.gadget.Equals(GadgetEnum.NUGGET))
                        {
                            //analyse der reaktion wenn das eigene team zuletzt ein Nugget übergeben hat
                            if (targetIsCharacter && operation.successful)
                            {
                                //neuen character der eigenen fraktion hinzufügen und aus den anderen listen entfernen
                                targetId = gameHandler.getFieldMap().getCharacterOnField(operation.target, message.state.characters).getGuid();
                                fraction.Add(targetId);     //da nur npc die bereits informationen preisgegeben ein nugget erhalten haben können kann das ziel der eigenen fraktion hinzugefügt werden
                                npcList.Remove(targetId);
                                usedNpcList.Remove(targetId);
                            }

                        }
                        else if (gadgetAction.gadget.Equals(GadgetEnum.MIRROR_OF_WILDERNESS))
                        {
                            //kommt nicht vor da das risiko xp zu verlieren zu hoch ist
                        }
                        else if (gadgetAction.gadget.Equals(GadgetEnum.CHICKEN_FEED))
                        {
                            /*kommt nicht vor da in der aktuellen implementierun ehr schädlich
                             * falls die implentierung geändert wird/ doch ein nutzen vermutet wird kann 
                             * hier ensprechend auf einen erfolg geprüft werden
                             * 
                             */
                        }


                    }
                }
            }
            else
            {
            //*****************enemydetection with enemy behaviour*******************//


                foreach (BaseOperation operation in message.operations)
                {
                    //art des Ziels herausfinden
                    bool targetIsCharacter = message.state.map.fieldHasCharacter(operation.target, message.state.characters);


                    //falls das ziel ein character war:
                    if (targetIsCharacter)
                    {
                        Guid targetId = gameHandler.getFieldMap().getCharacterOnField(operation.target, message.state.characters).getGuid();


                        //ausspionieren bemerken:
                        if (operation.type.Equals(OperationEnum.SPY_ACTION) && fraction.Contains(targetId))
                        {
                            enemy.Add(message.activeCharacterId);
                            npcList.Remove(message.activeCharacterId);
                        }


                        //gegner übergibt der eigenen fraktion das nugget
                        if (operation.type.Equals(OperationEnum.GADGET_ACTION) && fraction.Contains(targetId))
                        {
                            GadgetAction gadgetAction = (GadgetAction)operation;
                            if (gadgetAction.gadget.Equals(GadgetEnum.NUGGET))
                            {
                                enemy.Add(message.activeCharacterId);
                                npcList.Remove(message.activeCharacterId);
                            }
                        }


                    }
                }
            }
        }



        /*
         * This method deltetes the dead characters in the GaneKi datastructure 
         * 
         * @param hashset of the characters that are alive
         * 
         * @author Jonas Frei
         */
        public void deleteKilledCharacters(HashSet<Character> newCharacterList)//todo alles falsch es werden die lebenden gelöscht
        {
            //translate characterHashset to guid
            HashSet<Guid> newGuidList = new HashSet<Guid>();
            foreach (Character character in newCharacterList)
            {
                newGuidList.Add(character.characterId);
            }


            List<Guid> deadCharacters;
            //findet die toten character in der Liste
            deadCharacters = new List<Guid>();
            foreach (Guid npc in npcList)
            {
                if (!newGuidList.Contains(npc))
                {
                    deadCharacters.Add(npc);
                }
            }
            //löscht die Character der Liste
            foreach (Guid dead in deadCharacters)
            {
                npcList.Remove(dead);
            }



            deadCharacters = new List<Guid>();
            foreach (Guid usedNpc in usedNpcList)
            {
                if (!newGuidList.Contains(usedNpc))
                {
                    deadCharacters.Add(usedNpc);
                }
            }
            foreach (Guid dead in deadCharacters)
            {
                usedNpcList.Remove(dead);
            }



            deadCharacters = new List<Guid>();
            foreach (Guid enemy in enemy)
            {
                if (!newGuidList.Contains(enemy))
                {
                    deadCharacters.Add(enemy);
                }
            }
            foreach (Guid dead in deadCharacters)
            {
                enemy.Remove(dead);
            }



            deadCharacters = new List<Guid>();
            foreach (Guid memberOfFraction in fraction)
            {
                if (!newGuidList.Contains(memberOfFraction))
                {
                    deadCharacters.Add(memberOfFraction);
                }
            }
            foreach (Guid dead in deadCharacters)
            {
                fraction.Remove(dead);
            }



            deadCharacters = new List<Guid>();
            foreach (Guid unsuccesfull in unsuccessfullUsedNpcList.Keys)
            {
                if (!newGuidList.Contains(unsuccesfull))
                {
                    deadCharacters.Add(unsuccesfull);
                }
            }
            foreach (Guid dead in deadCharacters)
            {
                unsuccessfullUsedNpcList.Remove(dead);
            }
        }



        /*
         * Sichert die Ki gegen fehlerhafte Ap/Bp fehler ab. sollte aber eigentlich nie passieren...
         * 
         * @param operation die geplante Operation
         * 
         * @author Jonas Frei
         */ 
        public static Operation catchApBpMistakes(Operation operation, Character selectedCharacter)
        {
            if (operation.type.Equals(OperationEnum.GADGET_ACTION) && selectedCharacter.ap < 1)
            {
                Console.Out.WriteLine("FEHLER abgefangen: Gadgetaction ohne AP");
                operation = new Operation(selectedCharacter.characterId, OperationEnum.RETIRE, null);
            }

            if (operation.type.Equals(OperationEnum.SPY_ACTION) && selectedCharacter.ap < 1)
            {
                Console.Out.WriteLine("FEHLER abgefangen: Spyaction ohne AP");
                operation = new Operation(selectedCharacter.characterId, OperationEnum.RETIRE, null);
            }

            if (operation.type.Equals(OperationEnum.PROPERTY_ACTION) && selectedCharacter.ap < 1)
            {
                Console.Out.WriteLine("FEHLER abgefangen: Propertyaction ohne AP");
                operation = new Operation(selectedCharacter.characterId, OperationEnum.RETIRE, null);
            }

            if (operation.type.Equals(OperationEnum.MOVEMENT) && selectedCharacter.mp < 1)
            {
                Console.Out.WriteLine("FEHLER abgefangen: Propertyaction ohne AP");
                operation = new Operation(selectedCharacter.characterId, OperationEnum.RETIRE, null);
            }

            return operation;
        }

    }
}

