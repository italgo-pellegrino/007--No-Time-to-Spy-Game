//HashSet
using ConsoleApp1.Controller;
using ConsoleApp1.Controller.operationsWithoutMovement;
using ConsoleApp1.model;
using ConsoleApp1.model.networking;
using System;
//Guid
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;


/*Der Gamehandler Verarbeitet die Netzwerknachrichten, und repräsentiert den aktuellen Spielzustand
 * 
 * @author Akin  Kula
 * @author Jonas Frei
 */
public class GameHandler
{
    public Guid playerId;
    private HashSet<Guid> fraction = new HashSet<Guid>();
    public Guid sessionId;
    public Scenario level;
    public Matchconfig settings;
    public CharacterInformation[] characterSettings;
    /**
        Dieses Array enthält alle (redundanten) Informationen zu den Charakteren,
        Erhalt bei HelloReply Nachricht,
        wichtig zur Abfrage des Geschlechts
    **/

    public Point mapSize;
    private bool userIsPlayerOne, userIsPlayerTwo;

    //zeigt an, welcher Character momentan am Zug ist, s. RequestGameOperationMessage - muss geupdated werden
    public Guid activeCharacterGuid;

    private int currentRound;
    /**
    s. State - Objekt: Liste aller Charaktere auf dem Spielfeld, muss durch GameStatus Nachrichten geupdatet werden
    **/
    public HashSet<Character> characters = new HashSet<Character>();
    /** 
        Geheimnisse, die ein Client/Spieler kennt
    **/
    public HashSet<int> mySafeCombinations { get; set; }
    //FieldMap des Spiels, das den globalen Zustand des Spiels enthält, gemaß Standard
    //Zum Aufbauen der Map sollte man sich an dieses Attribut richten!!! -> buildMap Methode umschreiben !!!
    public FieldMap map;
    private Point catCoordinates, janitorCoordinates;

    public bool isPaused;
    public bool isMyTurn;

    public State state;



    public AuswahlphaseKI auswahlphaseKI;
    public GameKI gameKi;


    public GameHandler()
    {
        auswahlphaseKI = null;
    }

    


    //RECEIVERS
    /**
     * onHelloReply
     */
    public void onHelloReply(HelloReplyMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Hello Reply...");
        this.playerId = message.clientId;
        this.sessionId = message.sessionId;
        this.level = message.level;
        this.mapSize = new Point(this.level.getScenario().GetLength(0), this.level.getScenario().GetLength(1));
        this.settings = message.settings;
        this.characterSettings = message.characterSettings;
        setCharacterList();
    }
    public Scenario getLevel()
    {
        return level;
    }

    public void setCharacterList()
    {
        foreach (CharacterInformation info in characterSettings)
        {
            var properties = new HashSet<PropertyEnum>(info.features);
            Character ch = new Character(info.characterId, info.name, properties);
            characters.Add(ch);
        }
    }

    /**
     * onGameStarted
     */
    public void onGameStarted(GameStartedMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Game Started...");
        
        userIsPlayerOne = playerId.Equals(message.playerOneId);
        userIsPlayerTwo = playerId.Equals(message.playerTwoId);
        if (CommandLineInterface.verbosity >= 1)
        {
            Debug.WriteLine("playerOneId" + message.playerOneId);
            Debug.WriteLine("playerTwoId" + message.playerTwoId);
            Debug.WriteLine("playerId" + playerId);
        }
            

        if (userIsPlayerOne)
            playerId = message.playerOneId;
        else
            playerId = message.playerTwoId;

        playerId = message.clientId;
    }

    /**
     * WAHLPHASE & AUSRUSTUNGSPHASE hier
     * gadget assigning to chars will be done there
     */
    /**
        Verweis wird im Editor eingestellt
    **/
    

    /**
     * WAHLPHASE & AUSRUSTUNGSPHASE hier
     * gadget assigning to chars will be done there
     */
    public void onRequestItemChoice(RequestItemChoiceMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Request Item Choice...");
        List<Guid> characters = message.offeredCharacterIds;
        List<GadgetEnum> gadgets = message.offeredGadgets;

        Guid[] charactersArray = characters.ToArray();
        GadgetEnum[] gadgetsArray = gadgets.ToArray();


        //Beim ersten mal
        if (auswahlphaseKI == null) {
            auswahlphaseKI = new AuswahlphaseKI(new Config(
                    playerId, sessionId, level, settings, characterSettings
                ));

        }

        ItemChoiceMessage itemChoiceMessage = auswahlphaseKI.WahlphaseKI(characters, gadgets);

        itemChoiceMessage.clientId = playerId;




        sendItemChoiceMessage(itemChoiceMessage);
    }

    /*
    private void chooseItem(Guid[] chars, GadgetEnum[] gadgets, bool choosingChar)
    {
        System.Random r = new System.Random();
        if (choosingChar)
        {
            sendItemChoiceMessage(new ItemChoiceMessage(playerId, DateTime.Now,
                chars[r.Next(0, chars.Length)], null));
        }
        else
        {
            sendItemChoiceMessage(new ItemChoiceMessage(playerId, DateTime.Now,
                null, gadgets[r.Next(0, gadgets.Length)]));
        }

    }
    */


    public void sendItemChoiceMessage(ItemChoiceMessage itemChoice)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Sending item choice...");
        Connection.SendWebSocketMessage(itemChoice);
    }

    public void onRequestEquipmentChoice(RequestEquipmentChoiceMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Request Equipment Choice...");
        List<Guid> characters = message.chosenCharacterIds;
        List<GadgetEnum> gadgets = message.chosenGadgets;

        Guid[] charactersArray = characters.ToArray();
        addToFraction(charactersArray);
        GadgetEnum[] gadgetsArray = gadgets.ToArray();

        //add npc to npc list

        HashSet<Guid> npcSet = new HashSet<Guid>();
        foreach (CharacterInformation c in characterSettings) {
            if (!fraction.Contains(c.getCharacterId())) {
                npcSet.Add(c.getCharacterId());
            }
        }


        gameKi = new GameKI(npcSet, fraction, this);


        EquipmentChoiceMessage equipmentChoiceMessage = auswahlphaseKI.AusrüstungsphaseKi(characters, gadgets);
        sendEquipmentChoiceMessage(equipmentChoiceMessage);
    }

    public void sendEquipmentChoiceMessage(EquipmentChoiceMessage equipmentChoice)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Sending equipment choice...");
        Connection.SendWebSocketMessage(equipmentChoice);
    }

    //=================================================================================


    public Guid getPlayer()
    {
        return playerId;
    }

    /**
     * onGameStatus
     * 
     */
    public void onGameStatus(GameStatusMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Game Status..");
        if (message.activeCharacterId != null)
        {
            setActiveCharacter((Guid)message.activeCharacterId);
        }



        updateState(message);

        //do ki things

        gameKi.enemyDetection(message);

        gameKi.deleteKilledCharacters(message.state.characters);
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("onGameStatusMessage DONE");

    }

    public void setActiveCharacter(Guid guid)
    {
        activeCharacterGuid = guid;
    }

    /** 
     * Getter für activeCharacter, um Informationen auszulesen,
     * Enuerator iteriert durch die Datenstruktur
     */
    public Character getActiveCharacter()
    {
        HashSet<Character>.Enumerator enu = characters.GetEnumerator();
        while (enu.MoveNext())
        {
            Character ch = enu.Current;
            if (ch.getGuid().Equals(activeCharacterGuid)) return ch;
        }
        //NULL zeigt einen Fehler an!
        return null;
    }

    public Character getCharacterById(Guid charId)
    {
        HashSet<Character>.Enumerator enu = characters.GetEnumerator();
        while (enu.MoveNext())
        {
            Character ch = enu.Current;
            if (ch.getGuid().Equals(charId)) return ch;
        }
        //NULL zeigt einen Fehler an!
        return null;
    }

    public Character getCharacterByName(string charName)
    {
        HashSet<Character>.Enumerator enu = characters.GetEnumerator();
        while (enu.MoveNext())
        {
            Character ch = enu.Current;
            if (ch.getName().Equals(charName)) return ch;
        }
        //NULL zeigt einen Fehler an!
        return null;
    }

    public Character getCharacterByIndex(int charIndex)
    {
        int count = 0;
        HashSet<Character>.Enumerator enu = characters.GetEnumerator();
        while (enu.MoveNext())
        {
            if (count == charIndex)
            {
                return enu.Current;
            }
            count++;
        }
        //NULL zeigt einen Fehler an!
        return null;
    }

    public bool isActiveCharacter(Character c)
    {
        return c.getGuid().Equals(activeCharacterGuid);
    }

    /**
    Diese Liste verwaltet alle UUIDs der Charaktere in der eigenen Fraktion,
    Auffüllung geschieht durch die Nachrichten in der Wahl - und Ausrüstungsphase,
    bei Übergabe des Nuggets ??? - Standard
**/
    

    public HashSet<Guid> getFraction()
    {
        return fraction;
    }

    public void addToFraction(Guid newchar)
    {
        fraction.Add(newchar);
    }


    public void addToFraction(Guid[] newchars)
    {
        foreach (Guid g in newchars)
        {
            fraction.Add(g);
        }
    }

    public void updateState(GameStatusMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine(message.state.ToString());
        state = message.state;
        currentRound = state.currentRound;
        map = state.map;
        mySafeCombinations = state.mySafeCombinations;
        characters = state.characters;
        catCoordinates = state.catCoordinates;
        if (state.janitorCoordinates != null)
        {
            janitorCoordinates = state.janitorCoordinates;
        }

        if (!activeCharacterGuid.Equals(Guid.Empty))
        {
            Character c = getActiveCharacter();
        }
    }

    //Getter FieldMap
    public FieldMap getFieldMap()
    {
        return map;
    }

    /**
     * onRequestGameOperation
     */
    public void onRequestGameOperation(RequestGameOperationMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Game Operation Request...");
        isMyTurn = true; // set this to false after sending a game operation message
        setActiveCharacter(message.characterId);
        Character active_char = getActiveCharacter();

        Operation operation = gameKi.MyTurn(state, active_char.getGuid());

        //wait if delay
        if (CommandLineInterface.delay != -1) {
            if (CommandLineInterface.verbosity >= 1)
                Debug.WriteLine("Delay: " + CommandLineInterface.delay + " ms");
            Thread.Sleep(CommandLineInterface.delay);
        }

        sendGameOperationMessage(operation);

    }

    /**
     * statistics
     */
    public void onStatistics(StatisticsMessage message)
    {
        Debug.WriteLine("Game over");
        if (message.winner.Equals(playerId))
        {
            Debug.WriteLine("You won");
        }
        else {
            Debug.WriteLine("You lost");
        }
    }

    /**
     * onGameLeft
     */
    public void onGameLeft(GameLeftMessage message)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Game Left...");
        if (message.leftUserId.Equals(playerId))
        {
            // show main menu scene
        }
        else
        {
            // show winner canvas
        }
    }

    
    /**
     * onGamePause
     */
    public void onGamePauseMessage(GamePauseMessage gamePauseMessage)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Processing Game Pause...");
        this.isPaused = gamePauseMessage.gamePaused;

        // in case server forces the pause
        // OR
        if (gamePauseMessage.serverEnforced)
        {
            
        }
        else
        {
           
        }
       
    }

    /**
     * 
     */
    public void onMetaInformation(MetaInformationMessage message)
    {
        //WTF is this??
    }


    /**
     * onStrike
     */
    public void onStrike(StrikeMessage message)
    {
        Debug.WriteLine("Processing strike message: " + message.reason + ", " + message.debugMessage);
        /*
        if (message.strikeNr >= message.strikeMax)
        {
            sendGameLeaveMessage();
        }
        */
    }

    /**
     * onError
     */
    public void onError(ErrorMessage message)
    {
        Debug.WriteLine("Processing error message: " + message.reason + ", " + message.debugMessage);
    }




    // SENDERS
    /**
     * sendHello
     */
    public void sendHelloMessage(string name, RoleEnum role)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Saying hello to server...");
        HelloMessage message = new HelloMessage(Guid.NewGuid(), DateTime.Now, name, role);
        Connection.SendWebSocketMessage(message);
    }

    /**
     * sendReconnect
     */
    public void sendReconnectMessage()
    {
        Debug.WriteLine("Reconnecting...");
        ReconnectMessage message = new ReconnectMessage(playerId, sessionId, DateTime.Now);
        Connection.SendWebSocketMessage(message);
    }

    /**
     *   Diese Methode wird aufgerufen, wenn das Spiel verlassen wird und dafür eine Nachricht gesendent werden soll
     */
    public void sendGameLeaveMessage()
    {

        Debug.WriteLine("Sending leave request...");
        GameLeaveMessage message = new GameLeaveMessage(playerId);
        Connection.SendWebSocketMessage(message);
    }

    /**
     * should send pause request to server
     * but only activates receive pause method (in gamescreen script) rn
     */
    public void sendPauseRequest()
    {
       //für ki unwichtig
    }

    /**
     * RequestMetaInfo
     */
    public void sendMetaInfoRequest(string[] keys)
    {
        Debug.WriteLine("Gettin them meta infoo...");
        RequestMetaInformationMessage message = new RequestMetaInformationMessage(playerId, keys);
        Connection.SendWebSocketMessage(message);
    }

    /**
        Diese Methode gibt das Gender des Charakteren zurück
        @param Charakter: 

        return GenderEnum

        Bemerkung: Geschlecht ist ein optionales Feld!!!!!!!!
    **/
    public GenderEnum GetGender(Character ch)
    {
        Guid uuid = ch.getGuid();
        CharacterInformation info = null;
        for (int i = 0; i < characterSettings.Length; i++)
        {
            if (characterSettings[i].getCharacterId().Equals(uuid)) info = characterSettings[i];
        }
        if (info != null)
        {
            GenderEnum gender = info.GetGender();
            return gender;
        }
        return GenderEnum.None;
    }

    /**
        Diese Methode überprüft, ob der Client das Geheimnis zum Tresor kennt oder nicht
        @param safeIndex: Index des Safes

        return true, falls der Client das Geheimnis zu diesem Tresor kennt, somst false
    **/
    private bool isTresorSecretKnown(int safeIndex)
    {
        if (mySafeCombinations != null)
        {
            HashSet<int>.Enumerator enu = mySafeCombinations.GetEnumerator();
            while (enu.MoveNext())
            {
                int secret = enu.Current;
                if (secret == safeIndex) return true;
            }
        }
        return false;
    }

    /**
        Diese Methode erfrägt, ob der Charakter der eigenen Fraktion angehört
        @param ch: Charakter auf der Spielfeld

        return true, falls der Charakter der eigenen Fraktion angehört sonst false
    **/
    private bool IsOwnFractionMember(Character ch)
    {
        Guid uuid = ch.getGuid();
        return fraction.Contains(uuid);
    }



    /**
        Diese Methode überprüft, ob auf einem gegebenen Feld ein Charakter existiert
        @param pos: Position des Feldes
        return Character, falls einer auf diesem Feld existiert, sonst null
    **/
    private Character ExistsCharacter(Point pos)
    {
        System.Collections.Generic.HashSet<Character>.Enumerator enu = characters.GetEnumerator();
        while (enu.MoveNext())
        {
            Character ch = enu.Current;
            if (ch.getCoordinates().Equals(pos)) return ch;
        }
        //null, falls auf dieser Position kein Charakter existiert
        return null;
    }


    /**
        Diese Methode git das Feld an der gegeben Position zurück
        @param pos: Position im Spielfeld

        return Field
    **/
    private Field GetFieldOnPos(Point pos)
    {
        Field[,] gameField = map.getMap();
        return gameField[pos.y, pos.x];
    }

    /**
        Diese Methode errechnet die Entfernung gemäß Definiton aus dem Lastenheft,
        da diese Methode eine Hilfsmethode ist, ist sie static
        Bemerkung: Diese Methode geht von einem "kontinuierlichen" Spieleld aus

        //Diese Methode gilt nur solang das Spielfeld rechteckig ist
    **/
    public static int calculateDistance(Point a, Point b)
    {
        int a_x, a_y, b_x, b_y;
        a_x = a.x;
        a_y = a.y;
        b_x = b.x;
        b_y = b.y;

        int x_distance = Math.Abs((a_x - b_x));
        int y_distance = Math.Abs((a_y - b_y));

        return Math.Max(x_distance, y_distance);

    }

    /**
        Diese Methode validiert den Zug des active Charakters, der vom Spieler angeregt wird.
        Sie wird aufgerufen, wenn ein Spieler eine Gadget Aktion oder Ähnliches ausführen möchte
        @param gadget: Gadget, das ausgewählt wurde (View: DropDown)
        @param target: Ziel, auf das das Gadget zielt (View: Clicked Position)
        Bemerkung: Zu target gehören die LOGISCHEN Koordinaten gemäß Standard!!!! (sprich: die y Koordinate muss invertiert werden!!!!)
        !!!!Parameter müssen valide sein: target muss sich im Spielfeld befinden, falls nicht: So muss hier eine extra Validierung erfolgen !!!!

        @return true, falls Spielzug valide ist, sonst false

        Diese Methode wird von der View aufgerufen, bei true sollte die Canvas geblockt werden

        Ergänzung am 08.05.2020: Abfrage nach Katze und Hausmeister Koordinaten + weitere Entscheidungen des Standards in Ausnahmefällen + Nugget Aktion + Jetpack konkretisiert
        Ergänzung am 14.05.2020: User Input, welcher sinnlos ist, wird verhindert!!
    **/
    

    /**
        Diese Methode frägt ab, ob an einer übergebenen Position sich die Katze oder der Hausmeister befindet
        @param target: Zielfeld

        return true, falls sich der Hausmeister oder die Katze auf dem Feld target befindet, sonst false
    **/
    public bool ExistsJanitorOrCatOnPos(Point target)
    {
        return target.Equals(catCoordinates) || target.Equals(janitorCoordinates);
    }

    /**
        Diese Methode überprüft, ob die Katze auf dem angegebenen Feld existiert
    **/
    public bool ExistsCatOnPos(Point target)
    {
        return target.Equals(catCoordinates);
    }


    //Ergänzung zur WebSocket-Verbindung

    /**
        Diese Methode sendet eine GameOperationMessage über die Connection Klasse an den Server
    **/
    public void sendGameOperationMessage(Operation operation)
    {
        if (CommandLineInterface.verbosity >= 1)
            Debug.WriteLine("Sending game operation message...");
        GameOperationMessage message = new GameOperationMessage(playerId, DateTime.Now, operation);
        Connection.SendWebSocketMessage(message);
        isMyTurn = false;
       
    }

    

}