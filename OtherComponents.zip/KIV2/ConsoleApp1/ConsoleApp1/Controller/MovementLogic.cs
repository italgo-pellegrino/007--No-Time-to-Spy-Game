﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Net.Security;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller
{
    /*
     *
     * 
     * 
     * @author Akin Kula
     * @author Jonas Frei
     */ 
    public class MovementLogic
    {

        


        /*
         * Move the character within it's mp range
         * returns null if no mp or if no way to move to the point
         * 
         * 
         */
        public static Operation MoveCharacter(State currentState, Character character, Point to) {
            return MoveCharacter(currentState, character, to, true);
        }






        /* 
         * returns the next step to the target       
         * 
         * @author Jonas Frei
         */ 
        public static Operation MoveCharacter(State currentState, Character character, Point to, bool singleOperation)
        {
            if (character.coordinates.Equals(to))
                return null;

            if (character.mp == 0) //check if enough points          
                return null;


            Point from = character.coordinates;
                                  
            //check if legal move
            ASearchMap asearchmap = new ASearchMap(currentState.map);
            List<Point> moves = asearchmap.CalcShortestPath(to, from);


            //neckt alle fälle ab in denen der punkt nicht erreichbar ist
            if (moves == null || moves.Count == 0)
                return null;
              
            Movement movement = new Movement(from, character.characterId, OperationEnum.MOVEMENT, moves.ElementAt(1));         
            return movement;
        }




        public static List<Point> getAllSafePoints(State curentState, HashSet<int> usedSafes)
        {

            //get all safe points exluded the ones I already opened
            List<Point> safeList = new List<Point>();
            for (int x = 0; x < curentState.map.map.GetLength(1); x++)
            {
                for (int y = 0; y < curentState.map.map.GetLength(0); y++)
                {
                    if (curentState.map.map[y, x].getFieldStateEnum().Equals(FieldStateEnum.SAFE) && !usedSafes.Contains(curentState.map.map[y, x].safeIndex))
                    {
                        safeList.Add(new Point(x, y));
                    }
                }
            }
            return safeList;
        }


        public static List<Point> getAllSafePointsAvailable(State curentState, HashSet<int> usedSafes)
        {
            //get all safe coordinates where the ki has the key to
            List<Point> safeList = getAllSafePoints(curentState, usedSafes);
            List<Point> newSafeList = new List<Point>();
            safeList.ForEach(a => {
                //check if you have the key for it
                int x = a.x;
                int y = a.y;

                int safeIndex = curentState.map.map[y, x].getSafeIndex();

                if (curentState.mySafeCombinations.Contains(safeIndex))
                {
                    newSafeList.Add(a);
                }
            });
            return newSafeList;

        }

        public static List<Point> getShortestPathFromPaths(Point from, List<Point> path, State curentState)
        {
            int shortest = int.MaxValue;
            List<Point> shortestPath = null;
            ASearchMap asearchmap = new ASearchMap(curentState.map);


            if (path == null)
            {
                return null;
            }

            for (int i = 0; i < path.Count(); i++)
            {
                List<Point> p = asearchmap.CalcShortestPath(from, path.ElementAt(i));

                //if no path return null (no way to safe found)
                if (p == null)
                    return null;

                if (p.Count() <= shortest)
                {
                    shortest = p.Count();
                    shortestPath = p;
                }
            }

            return shortestPath;
        }



        /*
         * moves the character to cat (with jetpack if possible)
         * 
         * @Author Jonas Frei
         */ 
        public static Operation MoveToCat(State currentState, Character currentCharacter)
        {           
            // prüfen ob der Character ein Jetpack hat, falls Ja finde einen gültigen landeplatz neben der Katze
            if (currentCharacter.HasGadget(GadgetEnum.JETPACK) && currentCharacter.hasGadget(GadgetEnum.JETPACK).getUsages() > 0 &&currentCharacter.ap>0)
            {               
               HashSet<Point> pointsNextToCat = currentState.map.getAccessibleNeighbours(currentState.catCoordinates);

                if (pointsNextToCat != null && pointsNextToCat.Count != 0)
                {
                    foreach (Point target in pointsNextToCat)
                    {
                        if( !target.Equals(currentState.janitorCoordinates)  &&  !target.Equals(currentState.catCoordinates) && !currentState.isCharacerOnPoint(target))
                           return new GadgetAction(GadgetEnum.JETPACK,currentCharacter.characterId, OperationEnum.GADGET_ACTION, target);  

                    }
                }

                             
            }
            //sonst laufen
            return MoveCharacter(currentState, currentCharacter, currentState.catCoordinates);
        }






        /*
         * moves the character to Halsband (with jetpack if possible)
         * 
         * @Author Jonas Frei
         */
        public static Operation MoveTohalsband(State currentState, Character currentCharacter,Point Halsbandkoordinaten)
        {
            // prüfen ob der Character ein Jetpack hat, falls Ja finde einen gültigen landeplatz neben dem halsband
            if (currentCharacter.HasGadget(GadgetEnum.JETPACK) && currentCharacter.hasGadget(GadgetEnum.JETPACK).getUsages() > 0 && currentCharacter.ap > 0)//TODO eigentlich erst den direktanflug prüfen
            {
                HashSet<Point> pointsNextToHalsband = currentState.map.getAccessibleNeighbours(Halsbandkoordinaten);

                if (pointsNextToHalsband != null && pointsNextToHalsband.Count != 0)
                {
                    foreach (Point target in pointsNextToHalsband)
                    {
                        if (!target.Equals(currentState.janitorCoordinates) && !target.Equals(currentState.catCoordinates) && !currentState.isCharacerOnPoint(target))
                            return new GadgetAction(GadgetEnum.JETPACK, currentCharacter.characterId, OperationEnum.GADGET_ACTION, target);

                    }
                }

            }
            //sonst laufen
            return MoveCharacter(currentState, currentCharacter, Halsbandkoordinaten);
        }




        /*
         * checks and return a possible Necklace action
         * 
         * @author Jonas Frei
         */
        public static Operation CheckNecklace(State currentState, Character currentCharacter)
        {

            if (currentCharacter.HasGadget(GadgetEnum.DIAMOND_COLLAR))
            {
                //wenn das halsband der katze nicht übergeben werden kann -> zur katze bewegen (nur bis zum feld vor der katze)
                return MoveToCat(currentState, currentCharacter);

            }
            else
            {
                HashSet<Point> fieldsWithDIAMOND_COLLAR = currentState.map.getFieldsWithGadgetOfType(GadgetEnum.DIAMOND_COLLAR);
                //wenn das halsband auf dem boden liegt
                if (fieldsWithDIAMOND_COLLAR != null && fieldsWithDIAMOND_COLLAR.Count != 0)
                {
                    Point fieldWithDIAMOND_COLLAR = fieldsWithDIAMOND_COLLAR.First();

                    if (!currentState.map.getField(fieldWithDIAMOND_COLLAR).Equals(FieldStateEnum.FREE) &&
                        !currentState.map.getField(fieldWithDIAMOND_COLLAR).Equals(FieldStateEnum.BAR_SEAT)
                        )
                        return null;

                    return MoveTohalsband(currentState, currentCharacter, fieldWithDIAMOND_COLLAR);

                }               
                    
            }
            return null;
        }



        /*
         * 
         * 
         * 
         * @author Akin Kula
         * @author Jonas Frei
         */ 
        public static Operation CheckSafe(State curentState, Character currentCharacter, HashSet<int> usedSafes, List<Character> fraction)
        {

            //check if you have safe combinations

            if (curentState.mySafeCombinations != null && curentState.mySafeCombinations.Count() != 0)
            {

                //get the most near character to nearest safe

                int shortest = int.MaxValue;
                Character nearestCharacter = null;

                foreach (Character character in fraction)
                {
                    List<Point> safeCoordinates = getAllSafePointsAvailable(curentState, usedSafes);

                    Point coord = character.coordinates;
                    List<Point> path = getShortestPathFromPaths(coord, safeCoordinates, curentState);


                    if (path == null)
                        continue;

                    if (path.Count <= shortest)
                    {
                        shortest = path.Count;
                        nearestCharacter = character;
                    }
                }


                if (nearestCharacter==null || !(nearestCharacter.Equals(currentCharacter)))// nearestCharacter==null von Jonas (13.7)
                    return null;


                //then move this character to the safe

                List<Point> safePoints = getAllSafePointsAvailable(curentState, usedSafes);
                List<Point> pathToNearestSafe = getShortestPathFromPaths(nearestCharacter.coordinates, safePoints, curentState);


                if(pathToNearestSafe == null)
                {
                    return null;
                }

                Point safePoint = pathToNearestSafe.First();// (geändert von jonas) :pathToNearestSafe.Last()
                Console.WriteLine(safePoint.x + ": " + safePoint.y);
                if (Point.GetDistance(currentCharacter.coordinates, safePoint) < 2.0)
                {
                    if (currentCharacter.getAp() == 0)
                        return new Operation(currentCharacter.getGuid(), OperationEnum.RETIRE, null);
                    Operation operation = new Operation(currentCharacter.getGuid(), OperationEnum.SPY_ACTION, safePoint);
                    return operation;
                }



                Point nextStep = pathToNearestSafe.ElementAt<Point>(1); //get the second -> first one is start point
                return MoveCharacter(curentState, nearestCharacter, nextStep);
            }
            return null;
        }
    }
}
