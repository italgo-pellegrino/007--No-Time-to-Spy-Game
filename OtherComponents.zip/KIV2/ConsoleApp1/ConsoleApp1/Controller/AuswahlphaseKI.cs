﻿using ConsoleApp1.model;
using ConsoleApp1.model.networking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller
{
    public class AuswahlphaseKI
    {
       

        private Config config;

        private  List<GadgetEnum> gadgetsWithoutProbability;
        private  List<GadgetEnum> gadgetsWithProbability;

        private  int offerNr;


        /*
         * Konstruktor
         * 
         * @param config
         * 
         * 
         * @author Jonas Frei
         */ 
        public AuswahlphaseKI(Config pConfig)
        {
            config = pConfig;
            offerNr = 0;
           
            gadgetsWithoutProbability = new List<GadgetEnum>();//for characters with Constant_Clammy_Clothes
            gadgetsWithProbability = new List<GadgetEnum>();//für character ohne Constant_Clammy_Clothes


            gadgetsWithoutProbability.Add(GadgetEnum.MOLEDIE);
            gadgetsWithoutProbability.Add(GadgetEnum.POISON_PILLS);
            gadgetsWithoutProbability.Add(GadgetEnum.ROCKET_PEN);
            gadgetsWithoutProbability.Add(GadgetEnum.GAS_GLOSS);
            gadgetsWithoutProbability.Add(GadgetEnum.MOTHBALL_POUCH);
            gadgetsWithoutProbability.Add(GadgetEnum.FOG_TIN);
            gadgetsWithoutProbability.Add(GadgetEnum.JETPACK);
            gadgetsWithoutProbability.Add(GadgetEnum.CHICKEN_FEED);
            gadgetsWithoutProbability.Add(GadgetEnum.NUGGET);
            gadgetsWithoutProbability.Add(GadgetEnum.ANTI_PLAGUE_MASK);//new


            gadgetsWithProbability.Add(GadgetEnum.MAGNETIC_WATCH);
            gadgetsWithProbability.Add(GadgetEnum.LASER_COMPACT);
            gadgetsWithProbability.Add(GadgetEnum.GRAPPLE);
            gadgetsWithProbability.Add(GadgetEnum.WIRETAP_WITH_EARPLUGS);
            gadgetsWithProbability.Add(GadgetEnum.MIRROR_OF_WILDERNESS);
            gadgetsWithProbability.Add(GadgetEnum.POCKET_LITTER);
            gadgetsWithProbability.Add(GadgetEnum.BOWLER_BLADE);
        }



        /*
        Characterbewertung

        Flinkheit:               NIMBLENESS,                +1
        Schwerfälligkeit:       SLUGGISHNESS,               -1
        Behäbigkeit:             PONDEROUSNESS,             -1
        Behändigkeit:           SPRYNESS,                   +1
        Agilität                AGILITY,                    +1
        Gl¨uckspilz:            LUCKY_DEVIL,                +0  
        Pechvogel:              JINX,                        0
        Klamme Klamotten        CLAMMY_CLOTHES,             -1
        Konstant Klamme Klamotten:CONSTANT_CLAMMY_CLOTHES,  -5
        Robuster Magen:         ROBUST_STOMACH,             +2
        Z¨ahigkeit:             TOUGHNESS,                  +2
        BABYSITTER,                                         +1.5
        HONEY_TRAP,
        BANG_AND_BURN,                                      +0.5
        FLAPS_AND_SEALS,                                    +1
        TRADECRAFT,                                         +5
        OBSERVATION                                         +1
        */



        /*
         * bestimmt den Nutzen eines Characters anhand seiner Eigenschaften
         * 
         * @param id des characters der bewertet werden soll
         * 
         * @return wert des characters 
         * 
         * @author Jonas Frei
         */ 
        private int characterRanking(Guid offeredCharacterId)
        {

            //eigenschaften bestimmen
            PropertyEnum[] propertys = new PropertyEnum[1];
            for (int i = 0; i < config.characterInformation.Length; i++)
            {
                if (config.characterInformation[i].getCharacterId().Equals(offeredCharacterId))
                {
                    propertys = config.characterInformation[i].features.ToArray();
                }
            }


            //Eigenschaften bewerten
            int raiting = 0;

            for (int i = 0; i < propertys.Length; i++)
            {
                if (propertys[i].Equals(PropertyEnum.NIMBLENESS))           { raiting += 1; }
                else if (propertys[i].Equals(PropertyEnum.SLUGGISHNESS))    { raiting += -1; }
                else if (propertys[i].Equals(PropertyEnum.PONDEROUSNESS))   { raiting += -1; }
                else if (propertys[i].Equals(PropertyEnum.SPRYNESS))        { raiting += 1; }
                else if (propertys[i].Equals(PropertyEnum.AGILITY))         { raiting += 1; }
                else if (propertys[i].Equals(PropertyEnum.LUCKY_DEVIL))     { raiting += 0; }
                else if (propertys[i].Equals(PropertyEnum.JINX))            { raiting += 0; }
                else if (propertys[i].Equals(PropertyEnum.CLAMMY_CLOTHES))  { raiting += -1; }
                else if (propertys[i].Equals(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) { raiting += -5; }
                else if (propertys[i].Equals(PropertyEnum.ROBUST_STOMACH))  { raiting += 2; }
                else if (propertys[i].Equals(PropertyEnum.TOUGHNESS))       { raiting += 2; }
                else if (propertys[i].Equals(PropertyEnum.BABYSITTER))      { raiting += 2; }
                else if (propertys[i].Equals(PropertyEnum.HONEY_TRAP))      { raiting += 2; }
                else if (propertys[i].Equals(PropertyEnum.BANG_AND_BURN))   { raiting += 0; }
                else if (propertys[i].Equals(PropertyEnum.FLAPS_AND_SEALS)) { raiting += 1; }
                else if (propertys[i].Equals(PropertyEnum.TRADECRAFT))      { raiting += 5; }
                else if (propertys[i].Equals(PropertyEnum.OBSERVATION))     { raiting += 3; }

            }
           // Console.Out.WriteLine("CharacterRaiting: " + offeredCharacterId.ToString() + "  " + raiting + "\n\n\n");
            return raiting;
        }





        /**
         * Gadget Bewertung:
         * Jedem gadget wird ein Wert zugewiesen(Abhängig von der Matchkonfiguration)
         * 
         * der zurückgegeben wird wenn ein entsprechendes gadget pbergeben wird
         * 
         * @author Jonas Frei
        */
        private double gadgetRaiting(GadgetEnum gadget)
        {
            if (gadget.Equals(GadgetEnum.HAIRDRYER))                { return 1; }
            else if (gadget.Equals(GadgetEnum.MOLEDIE))              { return 1  +(Math.Sqrt(config.settings.moledieRange+1)); }
            else if (gadget.Equals(GadgetEnum.TECHNICOLOUR_PRISM))   { return 0; }
            else if(gadget.Equals(GadgetEnum.BOWLER_BLADE))         { if (config.settings.bowlerBladeDamage < 100) return (Math.Sqrt(config.settings.bowlerBladeRange + 1) + 1) * config.settings.bowlerBladeHitChance;
                                                                     else                                         return (Math.Sqrt(config.settings.bowlerBladeRange + 1) + 2) * config.settings.bowlerBladeHitChance; }//+sqrt(reichweite+1)+)*trefferwahrscheinlichkeit
            else if(gadget.Equals(GadgetEnum.MAGNETIC_WATCH))       { return 2; }
            else if(gadget.Equals(GadgetEnum.POISON_PILLS))         { return 4; }
            else if(gadget.Equals(GadgetEnum.LASER_COMPACT))        { return 2 * config.settings.laserCompactHitChance; }
            else if(gadget.Equals(GadgetEnum.ROCKET_PEN))           { if (config.settings.rocketPenDamage < 100) return 2; else return 4;     }//4if tötlich sonst 2
            else if(gadget.Equals(GadgetEnum.GAS_GLOSS))            { if (config.settings.gasGlossDamage < 100) return 2; else return 3;      }//3if tötlich sonst 2
            else if(gadget.Equals(GadgetEnum.MOTHBALL_POUCH))       { if (config.settings.mothballPouchDamage < 100) return 3; else return 4; }//4if tötlich sonst 3      
            else if(gadget.Equals(GadgetEnum.FOG_TIN))              { return 2; }
            else  if (gadget.Equals(GadgetEnum.GRAPPLE))            { return 1  +(Math.Sqrt(config.settings.grappleRange + 2) * config.settings.grappleHitChance); }
            else if(gadget.Equals(GadgetEnum.JETPACK))              { return 2; }
            else if(gadget.Equals(GadgetEnum.WIRETAP_WITH_EARPLUGS)){ return 1 + 3 * config.settings.wiretapWithEarplugsFailChance; }
            else if(gadget.Equals(GadgetEnum.CHICKEN_FEED))         { return 0; } //1.5 wenn die myturn implementierung chickenfeed zulässt
            else if(gadget.Equals(GadgetEnum.NUGGET))               { return 2; }
            else if(gadget.Equals(GadgetEnum.MIRROR_OF_WILDERNESS)) { return 0; }
            else if(gadget.Equals(GadgetEnum.POCKET_LITTER))        { return 2; }
            else if(gadget.Equals(GadgetEnum.ANTI_PLAGUE_MASK))     { return 1; }
            else return -100;
        }





        /*
         * Aus den übergebenen CharacterIds und Gadgets wird das besste Item ausgewählt.
         * 
         * Aufbau:
         * 1. den Bessten agenten finden. Die bewertung des Agenten erfolgt mit der funktion characterRanking(id)
         * 
         * 2.Bestes Gadget finden. Die Bewertung der Gadgets erfolgt mit der Funktion gadgetRaiting
         * 
         * 3.Auswertung: Je nach dem ob das Gadget oder der Character besser ist,
         *               wird eine Entsprechende EqipmentChoice message zurückgeheben.
         * 
         * @author Jonas Frei
         */
        public ItemChoiceMessage WahlphaseKI(List<Guid> offeredCharacterIds, List<GadgetEnum> offeredGadgets)
        {
            //CHARACTERrAITING
            int max_characterRaiting = -100;
            Guid? max_characterId = null;
            if (offeredCharacterIds != null)
            {
                foreach (Guid characterId in offeredCharacterIds)
                {
                    int ranking = characterRanking(characterId);
                    if (ranking > max_characterRaiting)
                    {
                        max_characterId = characterId;
                        max_characterRaiting = ranking;
                    }
                }
            }


            //Bewertung Gadget
            double max_GadgetRaiting = -100;
            GadgetEnum? max_Gadget = null;
            if (offeredGadgets != null)
            {
                foreach (GadgetEnum gadget in offeredGadgets)
                {
                    double raiting = gadgetRaiting(gadget);
                    if (raiting > max_GadgetRaiting)
                    {
                        max_GadgetRaiting = raiting;
                        max_Gadget = gadget;
                    }
                }
            }


            //Auswertung
            Guid? chosenCharacter = null;
            GadgetEnum? chosenGadget = null;
            if (max_characterRaiting <= max_GadgetRaiting)
            {
                chosenGadget = max_Gadget;
            }
            else
            {
                chosenCharacter = max_characterId;
            }

            ItemChoiceMessage itemChoice = new ItemChoiceMessage(Guid.Empty, MessageTypeEnum.ITEM_CHOICE, DateTime.Now, chosenCharacter, chosenGadget);
            offerNr++;
            return itemChoice;
        }



        /*
         * Die Funktion Teilt die übergebnen Gadgets den übergebenen Agenten zu
         * 
         * Aufbau:
         * 1. //Suchen der zugehöhrigen Agenten zu den Ids
         * 
         * 
         * 2. zu jedem Gadget prüfen ob es einen Perfekt passenden agenten gibt
         *      - falls ja: zuordnen
         *      - sonst   : Zufällig zuordnen
         * 
         * 3. rückgabe: EquipmentChoiceMessage
         * 
         *@author Jonas Frei
         */
        public EquipmentChoiceMessage AusrüstungsphaseKi(List<Guid> chosenCharacterIds, List<GadgetEnum> chosenGadgets)
        {

            //Suchen der zugehöhrigen Agenten zu den Ids
            List<CharacterInformation> chosenCharactersList = new List<CharacterInformation>();
            for (int i = 0; i < config.characterInformation.Length; i++)
            {
                if (chosenCharacterIds.Contains(config.characterInformation[i].getCharacterId()))
                {
                    chosenCharactersList.Add(config.characterInformation[i]);
                }
            }


            //Zuteilung der Characteren zu den Agenten -Vorbereitung-
            CharacterInformation[] chosenCharacters = chosenCharactersList.ToArray();
            Dictionary<Guid, HashSet<GadgetEnum>> equipment = new Dictionary<Guid, HashSet<GadgetEnum>>();
            foreach(Guid Id in chosenCharacterIds)
            {
                equipment.Add(Id, new HashSet<GadgetEnum>());
            }

            //Zuteilung der Characteren zu den Agenten
            int fairDistribution = 0;
            int index = 0;
            bool isUsed = false;//wichtig falls es zu einem gadget keinen passenden Character gibt
            foreach (GadgetEnum gadget in chosenGadgets)
            {
                isUsed = false;//new Gadget
                for (int i = 0; i < chosenCharacters.Length; i++)
                {
                    index = (fairDistribution + i) % chosenCharacters.Length;
                    if ((gadgetsWithoutProbability.Contains(gadget)     //gadgets die besser zu constant clammy clothes passen
                        && chosenCharacters[index].features.Contains(PropertyEnum.CONSTANT_CLAMMY_CLOTHES))
                        ||
                        (gadgetsWithProbability.Contains(gadget)        //gadgets bei denen man glück braucht
                        && !chosenCharacters[index].features.Contains(PropertyEnum.CONSTANT_CLAMMY_CLOTHES))                      
                        ||
                        (gadget.Equals(GadgetEnum.TECHNICOLOUR_PRISM)    //der Prisma passt am besten zu pech
                        && chosenCharacters[index].features.Contains(PropertyEnum.JINX))
                        ||
                        (gadget.Equals(GadgetEnum.HAIRDRYER)            //passt am bessten zu agenten die getrocknet werden können
                        && !chosenCharacters[index].features.Contains(PropertyEnum.CONSTANT_CLAMMY_CLOTHES))
                        && chosenCharacters[index].features.Contains(PropertyEnum.CLAMMY_CLOTHES))
                    {
                        //Gadget passt zum Agenten:
                        Console.Out.WriteLine("Gadget passt genau zu Agent:\n" +chosenCharacters[index].name +"       Gadget: " +gadget.ToString()+"\n\n");
                        equipment[chosenCharacters[index].characterId].Add(gadget);//gadget zur rückgabedatenstruktur hinzufügen
                        isUsed = true;
                        break;
                    }
                }
                fairDistribution++;//startindex verschieben für gleichmässige verteilung
                //fairDistribution++;
                //falls das Gadget nicht zugeordnet werden konnte
                if (!isUsed)
                {
                    equipment[chosenCharacters[index].characterId].Add(gadget);
                    Console.Out.WriteLine("GADGET ZUFÄLLIG ZUGETEILT:\n" + chosenCharacters[index].name + "       Gadget: " + gadget.ToString() + "\n\n");
                }
            }

            return new EquipmentChoiceMessage(config.playerId, equipment);
        }
    }
}       
 