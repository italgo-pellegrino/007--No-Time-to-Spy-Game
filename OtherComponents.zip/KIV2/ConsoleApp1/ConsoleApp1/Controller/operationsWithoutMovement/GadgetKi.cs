﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller
{

    /*
     * Statische Klasse welche die Methoden für Operationen mit Gadgets für die 
     * Ki beinhalten
     * 
     * 
     * @author Jonas Frei
     */
    public static class GadgetKi
    {
        //defines whitch gadgetAction is the best
        private static readonly GadgetEnum[] gadgetRankList =
            {
            GadgetEnum.COCKTAIL,
            GadgetEnum.FOG_TIN,
            GadgetEnum.HAIRDRYER,
            GadgetEnum.WIRETAP_WITH_EARPLUGS,
            GadgetEnum.NUGGET,
            GadgetEnum.CHICKEN_FEED,
            GadgetEnum.POISON_PILLS,
            GadgetEnum.ROCKET_PEN,
            GadgetEnum.MOTHBALL_POUCH,
            GadgetEnum.GAS_GLOSS,
            GadgetEnum.MOLEDIE,
            GadgetEnum.BOWLER_BLADE,
            GadgetEnum.MIRROR_OF_WILDERNESS,
            GadgetEnum.GRAPPLE,
            GadgetEnum.LASER_COMPACT,
            GadgetEnum.TECHNICOLOUR_PRISM,
            };


        //defines whitch gadget is the best for the grapple
        private static readonly GadgetEnum[] grapableGadgetRankList =
           {
          GadgetEnum.DIAMOND_COLLAR,
          GadgetEnum.COCKTAIL,
          GadgetEnum.ROCKET_PEN,
          GadgetEnum.POISON_PILLS,
          GadgetEnum.MAGNETIC_WATCH,
          GadgetEnum.BOWLER_BLADE,
          GadgetEnum.GAS_GLOSS,
          GadgetEnum.MOTHBALL_POUCH,
          GadgetEnum.JETPACK,
          GadgetEnum.ANTI_PLAGUE_MASK,
          GadgetEnum.HAIRDRYER,
          GadgetEnum.WIRETAP_WITH_EARPLUGS,
          GadgetEnum.NUGGET,
          //GadgetEnum.CHICKEN_FEED,          //platz für chickenfeed falls es wieder relevant wird
          GadgetEnum.POCKET_LITTER,
          GadgetEnum.FOG_TIN,
          GadgetEnum.GRAPPLE,
          GadgetEnum.MIRROR_OF_WILDERNESS,
          GadgetEnum.LASER_COMPACT,
          GadgetEnum.TECHNICOLOUR_PRISM,
          GadgetEnum.CHICKEN_FEED, //neuer platz für chickenfeed da es in der aktuellen implementierun von myturn nutzlos ist
            };




        /**
         * returns the best possible GadgetAction 
         * 
         
          * @param activ character
         * @param fieldMap
         * @param matchconfig
         * @param enemys
         * @param npcs
         * @param usedNpc (npc die bereits informationen preisgegeben haben)
         * @param eigene Fraktion
         * @param all Characters (enthällt auch den hausmeister und die Katze wenn sie im spiel sind)
         * 
         * 
         * @return Best Gadget Action /null if no gadgetaction is possible
         * 
         * @author Jonas Frei
         **/
        public static Tuple<GadgetEnum, Point> getBestGadgetAction(Character character, FieldMap fieldMap, Matchconfig matchconfig, HashSet<Character> enemy, HashSet<Character> npc, HashSet<Character> usedNpc, HashSet<Character> friends, HashSet<Character> allCharacters)
        {

            Tuple<GadgetEnum, Point> bestAction = null;
            Dictionary<Gadget, Point> possibeActions = couldUseGadget(character, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);

            foreach (GadgetEnum gadgetName in gadgetRankList)
            {
                foreach (Gadget gadget in character.gadgets)
                {
                    if (gadget.gadget.Equals(gadgetName) && possibeActions.ContainsKey(gadget))//nur weil man ein gadget hat heist das nicht das man es benutzen kann
                    {
                        bestAction = new Tuple<GadgetEnum, Point>(gadget.gadget, possibeActions[gadget]);
                        return bestAction;
                    }
                }
            }
            return bestAction;
        }




        /*
         * this method returns the best grapable gadget
         * 
         * @param activ Character
         * @param range
         * @param fieldMap
         * 
         * @return the pont of the best grapable gadget / null if not possible
         * 
         * @author Jonas Frei
         */
        public static Tuple<GadgetEnum, Point> bestGrapableGadget(Character selectedCharacter, int range, FieldMap fieldMap)
        {

            Tuple<GadgetEnum, Point> bestGrapableGadget = null;
            //erreichbare gadgets bestimmen
            Dictionary<GadgetEnum, Point> grappableGadgets = getGrapableGadgets(selectedCharacter, range, fieldMap);

            //prüft nach der in grapableGadgetRankList gegenenen Reinfolge die Liste der erreichbaren Gadgets
            foreach (GadgetEnum gadget in grapableGadgetRankList)
            {
                if (gadget.Equals(GadgetEnum.COCKTAIL) && selectedCharacter.HasGadget(GadgetEnum.COCKTAIL))
                {
                    continue; //nur maximal ein cocktail im inventar
                }
                else if (grappableGadgets.ContainsKey(gadget))
                {
                    bestGrapableGadget = new Tuple<GadgetEnum, Point>(gadget, grappableGadgets[gadget]);
                    break;//wenn das beste gadget gefunden wurde kann de siche nach alternativen abgebrochen werden
                }
            }

            return bestGrapableGadget;
        }




        /*
         * gibt die erreichbaren Gadgets zurück
         * 
         * @param activ character
         * @param range
         * @param fieldmap
         * 
         * @return erreichbare gadgets
         * 
         * @author Jonas Frei
         */
        public static Dictionary<GadgetEnum, Point> getGrapableGadgets(Character selectedCharacter, int range, FieldMap fieldMap)
        {
            //alle felder mit gadgets im radius bestimmen
            Dictionary<GadgetEnum, Point> grapableGadgets = new Dictionary<GadgetEnum, Point>();
            List<Point> fieldsWithGadgets;


            //sonderfall Kein Grapple vorhanden:
            if (range == 0)
            {
                fieldsWithGadgets = new List<Point>(fieldMap.getNeighboursWithGadgetOfType(selectedCharacter.coordinates, GadgetEnum.COCKTAIL));//nur cocktails können über distanz 1 aufgenommen werden wenn kein grapple vorhanden

                if (fieldsWithGadgets != null && fieldsWithGadgets.Count > 0)
                {
                    grapableGadgets.Add(fieldMap.getField(fieldsWithGadgets[0]).gadget.gadget, fieldsWithGadgets[0]);//es kan nur ein cocktail (einziges erreichbares gadget) hinzugefügt werden
                }

                return grapableGadgets;

            }



            //fälle mit grapple
            if (range == 1)
            {//wenn  grapple mit range 1 benutzt wird reichen die nachbarfelder
                fieldsWithGadgets = new List<Point>(fieldMap.getNeighboursWithGadget(selectedCharacter.coordinates));
            }
            else
            {//wenn der grapple auf hohe distanz benutzt wird
                fieldsWithGadgets = new List<Point>(fieldMap.getFieldsWithGadgets());
            }




                //prüfen ob diese felder auch in reichweite/erreichbar sind
                foreach (Point target in fieldsWithGadgets)
                {
                    try
                    {
                        fieldMap.validateIsInRange(selectedCharacter.getCoordinates(), target, range);
                        fieldMap.validateIsInSight(selectedCharacter.getCoordinates(), target);
                    }
                    catch (Exception)
                    {
                        continue;
                    }


                    //da mehrere cocktails auf dem spielfeld sind -> nur hinzufügen wenn das gadget noch nicht in der liste ist
                    GadgetEnum gadgetAtTarget = fieldMap.getField(target).gadget.gadget;

                    if ( !grapableGadgets.ContainsKey(gadgetAtTarget))
                        grapableGadgets.Add(fieldMap.getField(target).gadget.gadget, target);

                }
                
            
            return grapableGadgets;
        }


        /** 
        * Method to get all the possibilities to use a gadget for the npc character.
        * some parts from the code are from the server
        *
        * @param selectetCharacter           The selectetCharacter character.
        * @param fieldMap                    The board of the game.
        * @param allCharacters               A set of all Characters on the FieldMap.
        * @param matchconfig                 The preloaded Matchconfig.
        *  
         * @param enemys
         * @param npcs
         * @param usedNpc (npc die bereits informationen preisgegeben haben)
         * @param eigene Fraktion
         * @param all Characters (enthällt auch den hausmeister und die Katze wenn sie im spiel sind)
         * 
        * 
        * @return The hashset with the possible targets for every gadget of the selectetCharacter.
        */
        public static Dictionary<Gadget, Point> couldUseGadget(Character selectetCharacter, FieldMap fieldMap, Matchconfig matchconfig, HashSet<Character> enemy, HashSet<Character> npc, HashSet<Character> usedNpc, HashSet<Character> friends, HashSet<Character> allCharacters)
        {
            HashSet<Gadget> gadgets = selectetCharacter.gadgets;
            Dictionary<Gadget, Point> usableGadgets = new Dictionary<Gadget, Point>();


            if (gadgets.Count > 0)
            {
                foreach (Gadget gadget in gadgets)
                {

                    if (gadget.gadget.Equals(GadgetEnum.HAIRDRYER))
                    {
                        if (selectetCharacter.hasProperty(PropertyEnum.CLAMMY_CLOTHES) && !selectetCharacter.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES))
                        {
                            usableGadgets.Add(gadget, selectetCharacter.getCoordinates());
                        }

                    }


                    else if (gadget.gadget.Equals(GadgetEnum.MOLEDIE))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            if (enemy.Count > 0)
                            {
                                foreach (Character target in enemy)
                                {
                                    if (!target.characterId.Equals(selectetCharacter.characterId))
                                    {
                                        try
                                        {
                                            fieldMap.validateIsInRange(selectetCharacter.getCoordinates(), target.getCoordinates(), matchconfig.moledieRange);
                                            fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                        }
                                        catch (Exception)
                                        {
                                            continue;
                                        }
                                        usableGadgets.Add(gadget, target.getCoordinates());
                                        break;
                                    }
                                }
                            }
                            else if (npc.Count > 0 && (selectetCharacter.properties.Contains(PropertyEnum.FLAPS_AND_SEALS) || selectetCharacter.properties.Contains(PropertyEnum.TRADECRAFT) || selectetCharacter.properties.Contains(PropertyEnum.OBSERVATION)))
                            {//in diesem fall ist der moledie besonders hinderlich. ->möglichst schnell loswerden
                                foreach (Character target in npc)
                                {
                                    if (!target.characterId.Equals(selectetCharacter.characterId))
                                    {
                                        try
                                        {
                                            fieldMap.validateIsInRange(selectetCharacter.getCoordinates(), target.getCoordinates(), matchconfig.moledieRange);
                                            fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                        }
                                        catch (Exception)
                                        {
                                            continue;
                                        }
                                        usableGadgets.Add(gadget, target.getCoordinates());
                                        break;
                                    }
                                }
                            }

                        }

                    }


                    else if (gadget.gadget.Equals(GadgetEnum.TECHNICOLOUR_PRISM))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            HashSet<Point> tables = fieldMap.getNeighboursOfState(selectetCharacter.getCoordinates(), FieldStateEnum.ROULETTE_TABLE);
                            if (!(tables.Count() == 0))
                            {
                                foreach (Point table in tables)
                                {
                                    if (!fieldMap.getField(table).isDestroyed)//nur wenn der roulettetisch noch existiert
                                    {

                                        try
                                        {
                                            fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), table);
                                        }
                                        catch (Exception)
                                        {
                                            continue;
                                        }
                                        usableGadgets.Add(gadget, table);
                                        break;
                                    }
                                }
                            }
                        }
                    }



                    else if (gadget.gadget.Equals(GadgetEnum.BOWLER_BLADE))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            foreach (Character target in enemy)
                            {
                                if (!target.characterId.Equals(selectetCharacter.characterId))
                                {
                                    try
                                    {
                                        fieldMap.validateIsInRange(selectetCharacter.getCoordinates(), target.getCoordinates(), matchconfig.bowlerBladeRange);
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                        fieldMap.validateIsNotBlocked(selectetCharacter.getCoordinates(), target.getCoordinates(), allCharacters);//all characters beinhaltet auch katze und hausmeister
                                    }
                                    catch (Exception)
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, target.getCoordinates());
                                    break;//sobald ein ziel gefunden wurde wird abgebrochen
                                }
                            }
                        }
                    }



                    else if (gadget.gadget.Equals(GadgetEnum.POISON_PILLS))
                    {
                        if (gadget.getUsages() > 0)//getNeighboursWithGadgetOfType gibt felder zurück auf denen ein cocktail steht
                        {
                            List<Character> neighbourCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), enemy));

                            foreach (Character c in neighbourCharacters)
                            {
                                if (c.HasGadget(GadgetEnum.COCKTAIL))
                                {
                                    try
                                    {
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), c.getCoordinates());
                                    }
                                    catch (Exception)
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, c.getCoordinates());
                                    break;
                                }
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.LASER_COMPACT))
                    {
                        if (gadget.getUsages() > 0)
                        {

                            List<Character> charactersWithCocktail = new List<Character>();
                            foreach (Character c in enemy)
                            {
                                if (c.HasGadget(GadgetEnum.COCKTAIL))
                                {
                                    charactersWithCocktail.Add(c);
                                }
                            }

                            if (charactersWithCocktail.Count >= 1)
                            {
                                foreach (Character target in charactersWithCocktail)
                                {
                                    if (!target.getGuid().Equals(selectetCharacter.getGuid()))
                                    {
                                        try
                                        {
                                            fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                        }
                                        catch (Exception)
                                        {
                                            continue;
                                        }
                                        usableGadgets.Add(gadget, target.getCoordinates());
                                        break;
                                    }
                                }
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.ROCKET_PEN))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            foreach (Character target in enemy)
                            {
                                if (!target.getGuid().Equals(selectetCharacter.getGuid()))
                                {


                                    //verhindern das eigene spieler vom Flächenschaden getroffen werden
                                    List<Character> friendlyneighbourCharacters = new List<Character>(fieldMap.getNeighbourCharacters(target.getCoordinates(), friends));
                                    if (friendlyneighbourCharacters.Count != 0) continue;


                                    try
                                    {
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                    }
                                    catch (Exception)
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, target.getCoordinates());
                                    break;
                                }
                            }
                        }
                    }



                    else if (gadget.gadget.Equals(GadgetEnum.GAS_GLOSS))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            List<Character> neighbourEnemyCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), enemy));
                            if (neighbourEnemyCharacters.Count >= 1)
                            {
                                foreach (Character c in neighbourEnemyCharacters)
                                {
                                    try
                                    {
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), c.getCoordinates());
                                    }
                                    catch
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, c.getCoordinates());
                                    break;
                                }
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.MOTHBALL_POUCH))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            List<Point> fireplaces = new List<Point>(fieldMap.getFieldsOfState(FieldStateEnum.FIREPLACE));
                            foreach (Point target in fireplaces)
                            {
                                if (!fieldMap.getField(target).isDestroyed)
                                {

                                    //verhindern das eigene spieler vom Flächenschaden getroffen werden+ gegner dabei sind
                                    List<Character> friendlyneighbourCharacters = new List<Character>(fieldMap.getNeighbourCharacters(target, friends));
                                    if (friendlyneighbourCharacters.Count != 0)
                                        continue;

                                    //prüfen ob überhaubt gegner anwesend sind die getroffen werden können
                                    List<Character> enemyneighbourCharacters = new List<Character>(fieldMap.getNeighbourCharacters(target, enemy));
                                    if (enemyneighbourCharacters.Count == 0)
                                        continue;



                                    try
                                    {
                                        fieldMap.validateIsInRange(selectetCharacter.getCoordinates(), target, matchconfig.mothballPouchRange);
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target);
                                    }
                                    catch (Exception)
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, target);
                                    break;
                                }
                            }
                        }
                    }



                    else if (gadget.gadget.Equals(GadgetEnum.FOG_TIN))
                    {
                        if ((gadget.getUsages() > 0) && selectetCharacter.hp < 100)
                        {
                            foreach (Character target in enemy)
                            {
                                if (!target.Equals(selectetCharacter))
                                {


                                    //verhindern das eigene spieler vom Flächenschaden getroffen werden
                                    List<Character> friendlyneighbourCharacters = new List<Character>(fieldMap.getNeighbourCharacters(target.getCoordinates(), friends));
                                    if (friendlyneighbourCharacters.Count != 0) continue;


                                    try
                                    {
                                        fieldMap.validateIsInRange(selectetCharacter.getCoordinates(), target.getCoordinates(), matchconfig.fogTinRange);
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                    }
                                    catch (Exception)
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, target.getCoordinates());
                                    break;
                                }
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.GRAPPLE))
                    {
                        Tuple<GadgetEnum, Point> bestgrapable = bestGrapableGadget(selectetCharacter, matchconfig.grappleRange, fieldMap);

                        if (bestgrapable != null && bestgrapable.Item2 != null)
                            usableGadgets.Add(gadget, bestgrapable.Item2);

                        //sichtlinie wird schon in bestGrapable gadgets geprüft
                    }




                    else if (gadget.gadget.Equals(GadgetEnum.COCKTAIL))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            if (selectetCharacter.getHp() < 100)
                            {
                                usableGadgets.Add(gadget, selectetCharacter.getCoordinates());
                            }
                            else
                            {
                                List<Character> neighbourCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), enemy));
                                if (neighbourCharacters.Count >= 1)
                                {
                                    foreach (Character target in neighbourCharacters)
                                    {
                                        if (!target.hasProperty(PropertyEnum.CLAMMY_CLOTHES) && !target.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES))
                                        {
                                            try
                                            {
                                                fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), target.getCoordinates());
                                            }
                                            catch (Exception)
                                            {
                                                continue;
                                            }

                                            Random zufall = new Random();
                                            double randomD = zufall.NextDouble();

                                            if (randomD < 0.3)//30% wahrscheinlichkeit den cocktail zu verschütten
                                                usableGadgets.Add(gadget, neighbourCharacters[0].getCoordinates());
                                            break;
                                        }
                                    }

                                }
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.CHICKEN_FEED))
                    {
                        /*
                        if (gadget.getUsages() > 0)
                        {
                            List<Character> neighbourNpcCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), npc));
                            if (neighbourNpcCharacters.Count >= 1)
                            {
                                foreach (Character c in neighbourNpcCharacters)
                                {
                                    try
                                    {
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), c.getCoordinates());
                                    }
                                    catch
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, c.getCoordinates());
                                    break;
                                }
                            }
                        }
                        */
                    }

                    else if (gadget.gadget.Equals(GadgetEnum.NUGGET))
                    {
                        List<Character> NeighbourNpcCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), usedNpc));
                        if (NeighbourNpcCharacters.Count >= 1)
                        {
                            foreach (Character c in NeighbourNpcCharacters)
                            {
                                try
                                {
                                    fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), c.getCoordinates());
                                }
                                catch
                                {
                                    continue;
                                }
                                usableGadgets.Add(gadget, c.getCoordinates());
                                break;
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.WIRETAP_WITH_EARPLUGS))
                    {
                        if (gadget.getUsages() > 0)
                        {
                            List<Character> neighbourEnemyCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), enemy));//todo enemy oder npc
                            if (neighbourEnemyCharacters.Count >= 1)
                            {
                                foreach (Character c in neighbourEnemyCharacters)
                                {
                                    try
                                    {
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), c.getCoordinates());
                                    }
                                    catch
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, c.getCoordinates());
                                    break;
                                }
                            }
                        }
                    }


                    else if (gadget.gadget.Equals(GadgetEnum.MIRROR_OF_WILDERNESS))
                    {
                        /*wurde aus der implentierung ausgeschlossen da in der aktuellen version die gefahren (ip verlust) den nutzen übersteigt
                        if (gadget.getUsages() > 0)
                        {
                            List<Character> neighbourEnemyCharacters = new List<Character>(fieldMap.getNeighbourCharacters(selectetCharacter.getCoordinates(), enemy));
                            if (neighbourEnemyCharacters.Count >= 1)
                            {
                                foreach (Character c in neighbourEnemyCharacters)
                                {
                                    try
                                    {
                                        fieldMap.validateIsInSight(selectetCharacter.getCoordinates(), c.getCoordinates());
                                    }
                                    catch
                                    {
                                        continue;
                                    }
                                    usableGadgets.Add(gadget, c.getCoordinates());
                                    break;
                                }
                            }
                        }
                        */
                    }

                }                
            }

            return usableGadgets;
        }
    }
}
