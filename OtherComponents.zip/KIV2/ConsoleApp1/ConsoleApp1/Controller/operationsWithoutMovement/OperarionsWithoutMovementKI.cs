﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ConsoleApp1.Controller
{      
    /*
     *Die Klasse enthält eine statische Hilfsmethode welche die beste Aktion berechnet die ohne bewegung möglich ist
     * 
     *@author Jonas Frei 
     * */

    public static class OperarionsWithoutMovementKI
    {
        /*
         * 
         * statische hilfsmethode welche die beste Aktion zurückgibt die ohne Bewegung möglich ist
         * 
         * @param activ character
         * @param fieldMap
         * @param matchconfig
         * @param enemys
         * @param npcs
         * @param usedNpc (npc die bereits informationen preisgegeben haben)
         * @param eigene Fraktion
         * @param all Characters (enthällt auch den hausmeister und die Katze wenn sie im spiel sind)
         * 
         * 
         * @return operation / null wenn keine Operation möglich ist
         * 
         * @author Jonas Frei
         */
        public static Operation OperarionsWithoutMovementRaiting(Character selectedCharacter, FieldMap fieldMap, Matchconfig matchconfig, HashSet<Character> enemy, HashSet<Character> npc, HashSet<Character> usedNpc,HashSet<Character> friends, HashSet<Character> allCharacters)
        {

            Operation bestChoice = null;
           
            Tuple<GadgetEnum, Point> bestGrapableGadget = GadgetKi.bestGrapableGadget(selectedCharacter, 0, fieldMap);//0 da da ohne grappel die reichweite o ist (nachbartische mit cocktail werden berücksichtigt)
            Tuple<PropertyEnum, Point> observation = PropertyOperationKI.tryObservation(selectedCharacter, npc, fieldMap);
            Tuple<GadgetEnum, Point> bestGadgetAction = GadgetKi.getBestGadgetAction(selectedCharacter, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);



            //Allerwichtigste Aktion: Diamanthalsband 2. wichtigste cocktail

            if (bestGrapableGadget != null && bestGrapableGadget.Item1.Equals(GadgetEnum.DIAMOND_COLLAR))
            {//abdekcung des falls das das diamanthalsband aufgenommen werden kann:
                bestChoice = new GadgetAction(bestGrapableGadget.Item1, selectedCharacter.characterId, OperationEnum.GADGET_ACTION, bestGrapableGadget.Item2);
            }
            else if (bestGadgetAction != null && bestGadgetAction.Item1.Equals(GadgetEnum.COCKTAIL) && bestGadgetAction.Item2.Equals(selectedCharacter.coordinates))
            {//leben regenerieren wird bevorzugt wenn es möglich ist
                bestChoice = new GadgetAction(bestGadgetAction.Item1, selectedCharacter.characterId, OperationEnum.GADGET_ACTION, bestGadgetAction.Item2);//TODO es reicht offensichtlich das gadgetEnum zurückzugeben ->methoden davor können optimiert werden 
            }



            else if (bestGrapableGadget != null)
            {//abdekcung aller fälle bei denen etwas aufgenommen werden kann:
                //(beginnend mit dem 2. wichtigstem aufsammelbaren gadget: dem cocktail)
                bestChoice = new GadgetAction(bestGrapableGadget.Item1, selectedCharacter.characterId, OperationEnum.GADGET_ACTION, bestGrapableGadget.Item2);               
            }
            else
            {
               
                if (enemy.Count==0 && observation != null)
                {//observation bevorzugen wenn es keine gegner gibt und observation möglich ist
                    bestChoice = new PropertyAction(PropertyEnum.OBSERVATION, selectedCharacter.characterId, OperationEnum.PROPERTY_ACTION, observation.Item2);
                }
                else if (bestGadgetAction != null)
                {//wenn es gegner gibt kann nur gadgetAction den gegnern schaden
                    bestChoice = new GadgetAction(bestGadgetAction.Item1, selectedCharacter.characterId, OperationEnum.GADGET_ACTION, bestGadgetAction.Item2);//TODO es reicht offensichtlich das gadgetEnum zurückzugeben ->methoden davor können optimiert werden 
                }
                else if(observation != null)
                {//restliche fallabdeckung observation (fälle in denen es schon aufgedeckte gegner gibt aber observation die einzige mögliche aktion gibt)
                    bestChoice = new PropertyAction(PropertyEnum.OBSERVATION, selectedCharacter.characterId, OperationEnum.PROPERTY_ACTION, observation.Item2);
                }

            }

            return bestChoice;
        }
       

    }
}

