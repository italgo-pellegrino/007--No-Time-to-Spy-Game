﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller
{

    /*
     * Die Klasse  enthält methoden welche Prüfen ob Eigenschaften der Character Aktionen ermöglichen,
     * und geben diese möglichkeiten, zur weiteren Bewertung, zurück.
     * 
     * 
     * 
     * @author Jonas Frei
     */ 
    public class PropertyOperationKI
    {


        /*
         * Methode die prüft ob observation möglich ist und eine mögliche Operation zurückgibt 
         * 
         * @param selected character
         * @param npcs
         * @param fieldmap
         * 
         * @return Tuple<observation, Ziel> / null falls observation nicht möglich ist 
         * 
         * @author Jonas Frei
         */
        public static Tuple<PropertyEnum, Point> tryObservation(Character selectedCharacter,HashSet<Character> npc, FieldMap fieldMap)
        {
            if (selectedCharacter.properties.Contains(PropertyEnum.OBSERVATION) && !selectedCharacter.HasGadget(GadgetEnum.MOLEDIE)){

                foreach(Character character in npc)               
                {
                    try
                    {   //alle npc in sicht können ausspioniert werden
                        fieldMap.validateIsInSight(character.coordinates, selectedCharacter.coordinates);
                        return new Tuple<PropertyEnum, Point>(PropertyEnum.OBSERVATION,character.coordinates);
                    }
                    catch { }
                                     
                }
            }

            return null;
        }


    }
}
