﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


/**

    @author Akin Kula

    */



namespace ConsoleApp1.Controller



{
    public class ASearchMap
    {
        public FieldMap map;
        public List<AStarPoint> opened_tiles;
        public List<AStarPoint> closed_tiles;

        public ASearchMap(FieldMap map)
        {
            this.map = map;
        }





        public List<Point> CalcShortestPath(Point from_, Point to_)
        {
            AStarPoint from = new AStarPoint(from_.x, from_.y);
            AStarPoint to = new AStarPoint(to_.x, to_.y);


            this.opened_tiles = new List<AStarPoint>();
            this.closed_tiles = new List<AStarPoint>();

            //add the start node to opened
            this.opened_tiles.Add(from);

            while (true)
            {
                AStarPoint current_node = opened_tiles.Min(); // get current min with the lowest fcost
                if (current_node == null)
                {
                    //no path available
                    return null;
                }
                opened_tiles.Remove(current_node); // remove from opened list
                closed_tiles.Add(current_node); //add to closed list
                if (current_node.Equals(to))
                {
                    //path has been founded
                    List<AStarPoint> path = new List<AStarPoint>();
                    while (true)
                    {
                        path.Add(current_node);
                        current_node = current_node.parent;
                        if (current_node == null)
                        {
                            //convert AStarPoint to Point
                            List<Point> pathReal = new List<Point>();
                            for (int i = 0; i < path.Count(); i++)
                            {
                                AStarPoint astarpoint = path.ElementAt<AStarPoint>(i);
                                Point realPoint = new Point(astarpoint.x, astarpoint.y);
                                pathReal.Add(realPoint);
                            }
                            return pathReal;
                        }
                    }
                }

                //foreach neighbour of the current node
                List<AStarPoint> neighbors = GetPointsNeighbours(current_node);
                for (int i = 0; i < neighbors.Count(); i++)
                {
                    //check if not traversable (blocked) or is already in closed
                    AStarPoint neighbour = neighbors.ElementAt(i);
                    if (!CheckIfPointIsTraversable(neighbour, to) || closed_tiles.Contains(neighbour))
                    {
                        continue; //skip to next neighbour
                    }

                    //if path to this neihbour is shorter or neihbour not in opened list
                    if (!opened_tiles.Contains(neighbour))
                    {
                        //calc fcost of neighbour

                        double hcost = getDistance(neighbour, to);
                        double gcost = getDistance(neighbour, from);
                        double fcost = gcost + hcost;
                        neighbour.HCost = hcost;
                        neighbour.GCost = gcost;
                        neighbour.FCost = fcost;
                        neighbour.parent = current_node;
                        //set parent of this node to get back later! (calc the shortest route)
                        if (!opened_tiles.Contains(neighbour))
                        {
                            opened_tiles.Add(neighbour);
                        }

                    }

                }




            }

        }

        public bool CheckIfPointIsTraversable(AStarPoint a, AStarPoint to)
        {

            //check if outside map

            if (a.Equals(to))
                return true;


            if (!Enumerable.Range(0, map.map.GetLength(0)).Contains(a.y) || !Enumerable.Range(0, map.map.GetLength(1)).Contains(a.x))
                return false;



            FieldStateEnum state = map.map[a.y, a.x].getFieldStateEnum();
            Gadget gadget = map.map[a.y, a.x].GetGadget();
            bool isDestroyed = map.map[a.y, a.x].getIsDestroyed();
            bool isFoggy = map.map[a.y, a.x].isFoggy;

            bool check = state.Equals(FieldStateEnum.FREE) | state.Equals(FieldStateEnum.BAR_SEAT);

            return check;
        }


        public List<AStarPoint> GetPointsNeighbours(AStarPoint a)
        {

            List<AStarPoint> neighbours = new List<AStarPoint>();

            int[] xDirs = { 0, 1, 1, 1, 0, -1, -1, -1 };
            int[] yDirs = { 1, 1, 0, -1, -1, -1, 0, 1 };

            for (int i = 0; i < 8; i++)
            {


                AStarPoint b = new AStarPoint(a.x + xDirs[i], a.y + yDirs[i]);
                neighbours.Add(b);
            }

            return neighbours;
        }



        public Double getDistance(AStarPoint a, AStarPoint b)
        {
            Double ax = Math.Abs(a.x - b.x);
            Double ay = Math.Abs(a.y - b.y);
            Double ad = Math.Sqrt(Math.Pow(ax, 2) + Math.Pow(ay, 2));
            return ad;
        }






        public Boolean isBlocked()
        {
            return true;
        }
        public Boolean isFree()
        {
            return true;
        }


        public FieldMap copyField(FieldMap currentMap)
        {
            FieldMap copiedFieldMap = new FieldMap(new Field[currentMap.map.GetLength(0), currentMap.map.GetLength(1)]);//copy the current map;

            for (int x = 0; x < currentMap.map.GetLength(0); x++)
            {
                for (int y = 0; y < currentMap.map.GetLength(1); y++)
                {
                    copiedFieldMap.map[x, y] = currentMap.map[x, y];
                }
            }
            return copiedFieldMap;
        }
    }
}