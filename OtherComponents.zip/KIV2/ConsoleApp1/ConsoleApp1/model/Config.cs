﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.model
{
    /*
     * datensammlung aller character und eigenschaftsbezogenen Informationen 
     * für die Wahlphase
     * 
     * @author Jonas Frei
     */ 
    public class Config
    {
        public Guid playerId;
        public Guid sessionId;
        public Scenario level;
        public Matchconfig settings;
        public CharacterInformation[] characterInformation;



        /*@author Jonas Frei*/
        public Config()
        {
        }

        /*@author Jonas Frei*/
        public Config(Guid playerId, Guid sessionId, Scenario level, Matchconfig settings, CharacterInformation[] characterInformation)
        {
            this.playerId           = playerId;
            this.sessionId          = sessionId;
            this.level              = level;
            this.settings           = settings;
            this.characterInformation= characterInformation;
        }

    }       
}
