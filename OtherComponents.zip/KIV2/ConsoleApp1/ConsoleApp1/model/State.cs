﻿using System;
using System.Collections.Generic;

public class State
{
	public int currentRound;
	public FieldMap map;
	public HashSet<int> mySafeCombinations;
	public HashSet<Character> characters;
	public Point catCoordinates;
	public Point janitorCoordinates;

	public State(int currentRound, FieldMap map, HashSet<int> mySafeCombinations, HashSet<Character> characters,
		Point catCoordinates, Point janitorCoordinates)
	{
		this.currentRound = currentRound;
		this.map = map;
		this.mySafeCombinations = mySafeCombinations;
		this.characters = characters;
		this.catCoordinates = catCoordinates;
		this.janitorCoordinates = janitorCoordinates;
	}



    /*
     * translate a HashSet of Guid to a HashSet of Character
     * 
     * @param HashSet of Guid
     * 
     * @return HashSet of Character
     * 
     * @author Jonas Frei
     */
    public HashSet<Character> guidToCharacter(HashSet<Guid> guidList)
    {
        HashSet<Character> result = new HashSet<Character>();
        foreach (Character character in characters)
        {
            if (guidList.Contains(character.characterId))
            {
                result.Add(character);
            }
        }
        return result;
    }


    /*
     * translate a Guid to a Character
     * 
     * @param character Guid
     * 
     * @return Character
     * 
     * @author Jonas Frei
     */
    public Character guidToCharacter(Guid characterGuid)
    {
        Character result = null;
        foreach (Character character in characters)
        {
            if (characterGuid==character.characterId)
            {
                result=character;
                break;
            }
        }
        return result;
    }



    /*
     * 
     * 
     * 
     * @author jonas frei
     */
    public bool isCharacerOnPoint(Point point)
    {
        if (characters != null && point != null)
        {
            foreach (Character c in characters)
            {
                if (c.coordinates.Equals(point))
                    return true;

            }         
        }
        return false;

    }

}
