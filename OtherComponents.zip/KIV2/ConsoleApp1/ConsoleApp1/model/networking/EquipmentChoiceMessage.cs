﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.model.networking
{
    public class EquipmentChoiceMessage : MessageContainer
    {
       public Dictionary<Guid, HashSet<GadgetEnum>> equipment;

        public EquipmentChoiceMessage(Guid playerId, Dictionary<Guid, HashSet<GadgetEnum>> pEquipment) : base(playerId, MessageTypeEnum.EQUIPMENT_CHOICE, DateTime.Now)
        {
            equipment = pEquipment;
        }
    }
}
