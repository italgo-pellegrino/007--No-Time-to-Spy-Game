﻿using System;
using System.Runtime.Serialization;

[Serializable]
internal class TargetOutOfSightException : Exception
{
    public TargetOutOfSightException()
    {
    }

    public TargetOutOfSightException(string message) : base(message)
    {
    }

    public TargetOutOfSightException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected TargetOutOfSightException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}