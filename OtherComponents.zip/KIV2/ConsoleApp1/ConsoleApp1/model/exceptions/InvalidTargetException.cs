﻿using System;
using System.Runtime.Serialization;

[Serializable]
internal class InvalidTargetException : Exception
{
    private object p;

    public InvalidTargetException()
    {
    }

    public InvalidTargetException(object p)
    {
        this.p = p;
    }

    public InvalidTargetException(string message) : base(message)
    {
    }

    public InvalidTargetException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected InvalidTargetException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}