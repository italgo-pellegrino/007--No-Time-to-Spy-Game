﻿using System;
using System.Runtime.Serialization;

namespace ConsoleApp1.Controller
{
    [Serializable]
    internal class TargetOutOfRangeException : Exception
    {
        public TargetOutOfRangeException()
        {
        }

        public TargetOutOfRangeException(string message) : base(message)
        {
        }

        public TargetOutOfRangeException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected TargetOutOfRangeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}