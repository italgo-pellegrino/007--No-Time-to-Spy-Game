﻿using System;
using System.Runtime.Serialization;

[Serializable]
internal class TargetBlockedException : Exception
{
    private object p;

    public TargetBlockedException()
    {
    }

    public TargetBlockedException(object p)
    {
        this.p = p;
    }

    public TargetBlockedException(string message) : base(message)
    {
    }

    public TargetBlockedException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected TargetBlockedException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}