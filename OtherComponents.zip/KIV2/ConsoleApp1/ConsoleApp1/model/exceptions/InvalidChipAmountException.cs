﻿using System;
using System.Runtime.Serialization;

[Serializable]
internal class InvalidChipAmountException : Exception
{
    private object p;

    public InvalidChipAmountException()
    {
    }

    public InvalidChipAmountException(object p)
    {
        this.p = p;
    }

    public InvalidChipAmountException(string message) : base(message)
    {
    }

    public InvalidChipAmountException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected InvalidChipAmountException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}