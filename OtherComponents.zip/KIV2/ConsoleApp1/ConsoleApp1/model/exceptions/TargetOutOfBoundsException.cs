﻿using System;
using System.Runtime.Serialization;

[Serializable]
internal class TargetOutOfBoundsException : Exception
{
    public TargetOutOfBoundsException()
    {
    }

    public TargetOutOfBoundsException(string message) : base(message)
    {
    }

    public TargetOutOfBoundsException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected TargetOutOfBoundsException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}