﻿using System;
using System.Runtime.Serialization;

[Serializable]
internal class InvalidActionPointsException : Exception
{
    public InvalidActionPointsException()
    {
    }

    public InvalidActionPointsException(string message) : base(message)
    {
    }

    public InvalidActionPointsException(string message, Exception innerException) : base(message, innerException)
    {
    }

    protected InvalidActionPointsException(SerializationInfo info, StreamingContext context) : base(info, context)
    {
    }
}