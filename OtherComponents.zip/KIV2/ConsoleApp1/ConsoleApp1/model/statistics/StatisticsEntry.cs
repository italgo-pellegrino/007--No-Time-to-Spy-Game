﻿public class StatisticsEntry
{
    public string title;
    public string description;
    public string valuePlayer1;
    public string valuePlayer2;

    public StatisticsEntry(string title, string description, string valuePlayer1, string valuePlayer2)
    {
        this.title = title;
        this.description = description;
        this.valuePlayer1 = valuePlayer1;
        this.valuePlayer2 = valuePlayer2;
    }
}
