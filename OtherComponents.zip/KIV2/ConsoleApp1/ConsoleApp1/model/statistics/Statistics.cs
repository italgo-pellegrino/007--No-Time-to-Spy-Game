﻿public class Statistics
{
    public StatisticsEntry[] entries;
    public Statistics(StatisticsEntry[] entries)
    {
        this.entries = entries;
    }
}
