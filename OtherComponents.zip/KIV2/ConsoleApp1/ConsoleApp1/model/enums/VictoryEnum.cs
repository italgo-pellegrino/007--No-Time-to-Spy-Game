﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

[JsonConverter(typeof(StringEnumConverter))]
public enum VictoryEnum
{
    VICTORY_BY_IP,
    VICTORY_BY_COLLAR,
    VICTORY_BY_DRINKING,
    VICTORY_BY_SPILLING,
    VICTORY_BY_HP,
    VICTORY_BY_RANDOMNESS,
    VICTORY_BY_LEAVE,
    VICTORY_BY_KICK
}
