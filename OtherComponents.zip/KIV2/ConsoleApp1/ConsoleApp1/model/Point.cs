

using System;

public class Point {
    public int x,y;

    public Point(int x, int y){
        this.x = x;
        this.y = y;
    }


    public override bool Equals(Object obj)
    {
        //Check for null and compare run-time types.
        if ((obj == null) || !this.GetType().Equals(obj.GetType()))
        {
            return false;
        }
        else
        {
            Point p = (Point)obj;
            return (x == p.x) && (y == p.y);
        }
    }

    public override string ToString()
    {
        return "x: " + x + " y: " + y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    public static Double GetDistance(Point a, Point b)
    {
        Double ax = Math.Abs(a.x - b.x);
        Double ay = Math.Abs(a.y - b.y);
        Double ad = Math.Sqrt(Math.Pow(ax, 2) + Math.Pow(ay, 2));
        return ad;
    }

    
}