﻿
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;

public class FieldMap
{
    public Field[,] map;

    public Field[,] getMap()
    {
        return map;
    }
    public FieldMap(Field[,] map)
    {
        this.map = map;
    }



    /**
    * Method to validate if the given point exists on the map.
    *
    * @param point The coordinates of the target field.
    * @throws TargetOutOfBoundsException If the given coordinates are out of bounds.
    */
    public void validatePoint(Point point)
    {
        try
        {
            Field field = map[point.y, point.x];
        }
        catch (Exception exception)
        {
            throw new TargetOutOfBoundsException("The target field " + point.ToString() + " is out of bounds!");
        }
    }


    /**
     * Method to validate if the target field has a character.
     *
     * @param point      The coordinates of the target field.
     * @param characters The characters currently active in the game.
     * @throws InvalidTargetException If there is no character on the target field.
     */
    public void validateFieldHasCharacter(Point point, HashSet<Character> characters)
    {
        if (!fieldHasCharacter(point, characters))
        {
            throw new InvalidTargetException("There is no character on the target field " + point.ToString() + "!");
        }
    }


    /**
     * Method to validate if the target field has no character.
     *
     * @param point      The coordinates of the target field.
     * @param characters The characters currently active in the game.
     * @throws InvalidTargetException If there is a character on the target field.
     */
    public void validateFieldHasNoCharacter(Point point, HashSet<Character> characters)
    {
        if (fieldHasCharacter(point, characters))
        {
            throw new InvalidTargetException("There is a character on the target field " + point.ToString() + "!");
        }
    }



    /**
     * Method to validate if the target field is a neighbour.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @throws InvalidTargetException If the target field is not a neighbour.
     */
    public void validateIsNeighbour(Point start, Point target)
    {
        if (!isNeighbour(start, target))
        {
            throw new InvalidTargetException("The target field " + target.ToString() + " is not a neighbour of " + start.ToString() + "!");
        }
    }

    /**
     * Method to validate if the target field is a neighbour of the given state.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @param state  The state the target field should have.
     * @throws InvalidTargetException If the target field is not a neighbour or has the wrong state.
     */
    public void validateIsNeighbourOfState(Point start, Point target, FieldStateEnum state)
    {
        validateIsNeighbour(start, target);
        getField(target).validateIsState(state);
    }

    /**
     * Method to validate if the target field is a neighbour with a gadget of the given type.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @param gadget The type of gadget the target field should have.
     * @throws InvalidTargetException If the target field is not a neighbour, has no gadget or has the wrong gadget.
     */
    public void validateIsNeighbourWithGadgetOfType(Point start, Point target, GadgetEnum gadget)
    {
        validateIsNeighbour(start, target);
        getField(target).validateHasGadgetOfType(gadget);
    }

    /**
     * Method to validate if the target field is in sight.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @throws TargetOutOfSightException If the target field is not in sight.
     * @throws InvalidTargetException    If the target is the character itself.
     */
    public void validateIsInSight(Point start, Point target)
    {
        if (target.Equals(start))
        {
            throw new InvalidTargetException("The target field " + target.ToString() + "is the player character itself !");
        }
        if (!isInSight(start, target))
        {
            throw new TargetOutOfSightException("The target field " + target.ToString() + " is not in sight of " + start.ToString() + "!");
        }
    }



    /**
     * Method to validate if the target field is in range.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @param range  The range of the gadget.
     * @throws TargetOutOfRangeException If the target field is not in range.
     * @throws InvalidTargetException    If the target is the character itself.
     */
    public void validateIsInRange(Point start, Point target, int range)
    {
        if (target.Equals(start))
        {
            throw new InvalidTargetException("The target field " + target.ToString() + "is the player character itself !");
        }
        if (!isInRange(start, target, range))
        {
            throw new TargetOutOfRangeException("The target field " + target.ToString() + " is not in range of " + start.ToString() + "! Expected a range of " + range + " but got " + getRange(start, target) + ".");
        }
    }

    /**
     * Method to validate if the target field is blocked.
     *
     * @param start      The coordinates of the start field.
     * @param target     The coordinates of the target field.
     * @param characters All the characters currently active in the game.
     * @throws TargetBlockedException If the target field is blocked.
     * @throws InvalidTargetException If the target is the character itself.
     */
    public void validateIsNotBlocked(Point start, Point target, HashSet<Character> characters)
    {
        if (target.Equals(start))
        {
            throw new InvalidTargetException("The target field " + target.ToString() + "is the player character itself !");
        }
        if (isBlocked(start, target, characters))
        {
            throw new TargetBlockedException("The target field " + target.ToString() + " is blocked with a character!");
        }
    }

    /**
     * Method to get the field of the given coordinates.
     *
     * @param point The coordinates of the field.
     * @return The field of the given coordinates.
     */
    public Field getField(Point point)
    {
        return map[point.getY(), point.getX()];
    }

    /**
     * Method to check if a character is on the given field.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return true if there is a character on the given field, false if not.
     */
    public Boolean fieldHasCharacter(Point point, HashSet<Character> characters)
    {
        foreach (Character character in characters)
        {
            if (character.getCoordinates().Equals(point))
                return true;
        }
        return false;
    }

    /**
     * Method to get the character on the field with the given coordinates.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return The character which is on the given field, null if there is none.
     */
    public Character getCharacterOnField(Point point, HashSet<Character> characters)
    {
        foreach (Character character in characters)
        {
            if (character.getCoordinates().Equals(point))
            {
                return character;
            }
        }
        return null;
    }

    /**
     * Method to get the neighbour field on top left side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getTopLeftNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX() - 1, point.getY() - 1);
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on top side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getTopNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX(), point.getY() - 1);
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on top right side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getTopRightNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX() + 1, point.getY() - 1);
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on left side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getRightNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX() + 1, point.getY());
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on bottom right side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getBottomRightNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX() + 1, point.getY() + 1);
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on bottom side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getBottomNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX(), point.getY() + 1);
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on bottom left side.
     *
     * @param point The coordinates of the field, null if the neighbour is out of bounds.
     * @return The neighbour field.
     */
    public Point getBottomLeftNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX() - 1, point.getY() + 1);
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on left side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getLeftNeighbour(Point point)
    {
        Point neighbour = new Point(point.getX() - 1, point.getY());
        try
        {
            validatePoint(neighbour);
        }
        catch (TargetOutOfBoundsException exception)
        {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbours of a given field.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbours of the given field if they are valid.
     */
    public HashSet<Point> getNeighbours(Point point)
    {
        HashSet<Point> neighbours = new HashSet<Point>();//ehemals  new HashSet<>();
        if (getTopLeftNeighbour(point) != null)
        {
            neighbours.Add(getTopLeftNeighbour(point));
        }
        if (getTopNeighbour(point) != null)
        {
            neighbours.Add(getTopNeighbour(point));
        }
        if (getTopRightNeighbour(point) != null)
        {
            neighbours.Add(getTopRightNeighbour(point));
        }
        if (getRightNeighbour(point) != null)
        {
            neighbours.Add(getRightNeighbour(point));
        }
        if (getBottomRightNeighbour(point) != null)
        {
            neighbours.Add(getBottomRightNeighbour(point));
        }
        if (getBottomNeighbour(point) != null)
        {
            neighbours.Add(getBottomNeighbour(point));
        }
        if (getBottomLeftNeighbour(point) != null)
        {
            neighbours.Add(getBottomLeftNeighbour(point));
        }
        if (getLeftNeighbour(point) != null)
        {
            neighbours.Add(getLeftNeighbour(point));
        }
        return neighbours;
    }

    /**
     * Method to check if the target field is a neighbour of the given field.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @return true if the target field is a neighbour, false if not.
     */
    public Boolean isNeighbour(Point start, Point target)
    {
        foreach (Point point in getNeighbours(start))
        {
            if (point.Equals(target))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to check if adjacent fields to the character have a character on them.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return true if there is at least one neighbour field with a character, false if not.
     */
    public Boolean neighbourHasCharacter(Point point, HashSet<Character> characters)
    {
        foreach (Point neighbours in getNeighbours(point))
        {
            if (fieldHasCharacter(neighbours, characters))
            {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to get the every character on neighbour fields.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return The character which is on the given field, null if there is none.
     */
    public HashSet<Character> getNeighbourCharacters(Point point, HashSet<Character> characters)
    {
        HashSet<Character> neighbourCharacters = new HashSet<Character>();
        foreach (Point neighbours in getNeighbours(point))
        {
            if (fieldHasCharacter(neighbours, characters))
            {
                neighbourCharacters.Add(getCharacterOnField(neighbours, characters));
            }
        }
        return neighbourCharacters;
    }

    /**
     * Method to count neighbour characters.
     *
     * @param point      The coordinates of the field.
     * @param characters The character currently active in the game.
     * @return The count of neighbour characters.
     */
    public int getNeighbourCharacterCount(Point point, HashSet<Character> characters)
    {
        return getNeighbourCharacters(point, characters).Count;
    }

    /**
     * Method check if there are neighbour characters with the property babysitter.
     *
     * @param character         The target character.
     * @param characters        Every character on the map.
     * @param charactersPlayer1 Every character of player one on the map.
     * @param charactersPlayer2 Every character of player two on the map.
     * @return True if there is at least one neighbour character with the property babysitter, false if not.
     */

    /*Server methode
    public Boolean checkBabysitter(Character character, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2)
    {
        if (neighbourHasCharacter(character.getCoordinates(), characters))
        {
            for (Character neighbour : getNeighbourCharacters(character.getCoordinates(), characters))
            {
                if (neighbour.hasProperty(PropertyEnum.BABYSITTER))
                {
                    // Check if same faction
                    if ((character.isMemberOfFaction(charactersPlayer1) && neighbour.isMemberOfFaction(charactersPlayer1))
                            || (character.isMemberOfFaction(charactersPlayer2) && neighbour.isMemberOfFaction(charactersPlayer2)))
                    {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    /*



    /**
     * Method to get all neighbours with the property babysitter.
     *
     * @param character         The target character.
     * @param characters        Every character on the map.
     * @param charactersPlayer1 Every character of player one on the map.
     * @param charactersPlayer2 Every character of player two on the map.
     * @return Set of neighbour characters with the property babysitter.
     */

    /*Server funktion
    public SortedSet<Character> getBabysitters(Character character, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2)
    {
        Set<Character> babysitters = new HashSet<>();
        for (Character neighbour : getNeighbourCharacters(character.getCoordinates(), characters))
        {
            if (neighbour.hasProperty(PropertyEnum.BABYSITTER))
            {
                // Check if same faction
                if ((character.isMemberOfFaction(charactersPlayer1) && neighbour.isMemberOfFaction(charactersPlayer1))
                        || (character.isMemberOfFaction(charactersPlayer2) && neighbour.isMemberOfFaction(charactersPlayer2)))
                {
                    babysitters.add(neighbour);
                }
            }
        }
        return babysitters;
    }
    /*


    /**
     * Method to get the neighbours of the given field which have the given state.
     *
     * @param point The coordinates of the field.
     * @param state The state of the neighbour fields.
     * @return The coordinates of the neighbour fields which have the given state, null if there are none.
     */
    public HashSet<Point> getNeighboursOfState(Point point, FieldStateEnum state)
    {
        HashSet<Point> neighbours = new HashSet<Point>();
        foreach (Point neighbour in getNeighbours(point))
        {
            if (getField(neighbour).isState(state))
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to check if any neighbour of the given field is of the given state.
     *
     * @param point The coordinates of the field.
     * @param state The state of the field.
     * @return true if at least one neighbour field is of the given state, false if not.
     */
    public Boolean hasNeighboursOfState(Point point, FieldStateEnum state)
    {
        return !(getNeighboursOfState(point, state).Count == 0);//.isEmpty()
    }

    /**
     * Method to get a random free neighbour point with no gadget and character on it.
     *
     * @param point      The coordinates of the field.
     * @param characters All characters on the map.
     * @return A random neighbour point.
     */
    /*Unnötig
   public Point getRandomFreeNeighbour(Point point, Set<Character> characters)
   {
       // All free neighbour fields
       Set<Point> freeNeighbours = getNeighboursOfState(point, FieldStateEnum.FREE);
       // Remove fields with a gadget on it
       freeNeighbours.removeIf(neighbour->getField(neighbour).hasGadget());
       // Remove fields with a character on it
       freeNeighbours.removeIf(neighbour->fieldHasCharacter(neighbour, characters));

       if (freeNeighbours.isEmpty())
       {
           return null;
       }

       return getRandomPoint(freeNeighbours);
   }
   */


    /**
     * Method to get all the neighbours of the given field which have a gadget.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which have a gadget, null if there are none.
     */
    public HashSet<Point> getNeighboursWithGadget(Point point)
    {
        HashSet<Point> neighbours = new HashSet<Point>();// ehemals new HashSet<>();
        foreach (Point neighbour in getNeighbours(point))
        {
            if (getField(neighbour).hasGadget())
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which have the given gadget.
     *
     * @param point      The coordinates of the field.
     * @param gadgetType The type of the gadget.
     * @return The coordinates of the neighbour fields which have the given gadget, null if there are none.
     */
    public HashSet<Point> getNeighboursWithGadgetOfType(Point point, GadgetEnum gadgetType)
    {
        HashSet<Point> neighbours = new HashSet<Point>();
        foreach (Point neighbour in getNeighboursWithGadget(point))
        {
            if (getField(neighbour).hasGadgetOfType(gadgetType))
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which are destroyed.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which are destroyed, null if there are none.
     */
    public HashSet<Point> getDestroyedNeighbours(Point point)
    {
        HashSet<Point> neighbours = new HashSet<Point>();//ehemals  new HashSet<>();
        foreach (Point neighbour in getNeighbours(point))
        {
            if (getField(neighbour).isDestroyed)
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which are inverted.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which are inverted, null if there are none.
     */
    public HashSet<Point> getInvertedNeighbours(Point point)
    {
        HashSet<Point> neighbours = new HashSet<Point>();
        foreach (Point neighbour in getNeighbours(point))
        {
            if (getField(neighbour).isInverted)
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }



    /**
     * Method to get all the neighbours of the given field which have the given safe index.
     *
     * @param point     The coordinates of the field.
     * @param safeIndex The index of the safe.
     * @return The coordinates of the neighbour fields which have the given safe index, null if there are none.
     */
    /*Server methode
   public SortedSet<Point> getNeighboursWithSafeIndex(Point point, int safeIndex)
   {
       Set<Point> neighbours = new HashSet<>();
       foreach (Point neighbourPoint in getNeighbours(point))
       {
           if (getField(neighbourPoint).hasSafeIndex(safeIndex))
           {
               neighbours.add(neighbourPoint);
           }
       }
       return neighbours;
   }
   /*


   /**
    * Method to get all the neighbours of the given field which can are foggy.
    *
    * @param point The coordinates of the field.
    * @return The coordinates of the neighbour fields which are foggy, null if there are none.
    */
    public HashSet<Point> getFoggyNeighbours(Point point)
    {
        HashSet<Point> neighbours = new HashSet<Point>(); // ehemals new HashSet<>();
        foreach (Point neighbour in getNeighbours(point))
        {
            if (getField(neighbour).isFoggy)
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which can be moved on to.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbours fields which are accessible, null if there are none.
     */
    public HashSet<Point> getAccessibleNeighbours(Point point)
    {
        HashSet<Point> neighbours = new HashSet<Point>();
        foreach (Point neighbour in getNeighbours(point))
        {
            if (getField(neighbour).isAccessible())
            {
                neighbours.Add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get every field of the given coordinates.
     *
     * @param points The coordinates of the fields.
     * @return The fields of the given coordinates.
     */
    public HashSet<Field> getFields(HashSet<Point> points)
    {
        HashSet<Field> fields = new HashSet<Field>();

        foreach (Point point in points)
        {
            fields.Add(getField(point));
        }
        return fields;
    }

    /**
     * Method to get the coordinates of every field of the map.
     *
     * @return The coordinates of the fields of the map.
     */
    public HashSet<Point> getPointsOfMap()
    {
        int x = 0;
        int y = 0;
        HashSet<Point> points = new HashSet<Point>();

        for (int i = y; i < map.GetLength(0); i++)               //for (int i = y; i < map.Length; i++)//TODO get length(dimension)//TODO Length vermutlich überall falsch verwendent : length gibt alle dimensionen zurück (in der datei nur hier)
        {
            for (int j = x; j < map.GetLength(1); j++)           //for (int j = x; j < map[y].Length; j++)//TODO get length(dimension)
            {
                try
                {
                    Point point = new Point(j, i);
                    validatePoint(point);
                    points.Add(point);
                }
                catch (TargetOutOfBoundsException exception)
                {
                    // don't add invalid points to the set
                }
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which are of the given state.
     *
     * @param state The state of the field.
     * @return The the coordinates of fields which are of the given state, null if there are none.
     */
    public HashSet<Point> getFieldsOfState(FieldStateEnum state)
    {
        HashSet<Point> points = new HashSet<Point>(); 

        foreach (Point point in getPointsOfMap())
        {
            if (getField(point).isState(state))
            {
                points.Add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which have a gadget.
     *
     * @return The the coordinates of fields of the map which have a gadget, null if there are none.
     */
    public HashSet<Point> getFieldsWithGadgets()
    {
        HashSet<Point> points = new HashSet<Point>(); 

        foreach (Point point in getPointsOfMap())
        {
            if (getField(point).hasGadget())
            {
                points.Add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which has the gadget of the given type.
     *
     * @param gadget The type of the gadget.
     * @return The coordinates of the field of the map which has the gadget of the given type, null if there is none.
     */
    public HashSet<Point> getFieldsWithGadgetOfType(GadgetEnum gadget)
    {
        HashSet<Point> points = new HashSet<Point>();

        foreach (Point point in getFieldsWithGadgets())
        {
            if (getField(point).hasGadgetOfType(gadget))
            {
                points.Add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which are destroyed.
     *
     * @return The coordinates of the fields of the map which are destroyed, null if there are none.
     */
    public HashSet<Point> getDestroyedFields()
    {
        HashSet<Point> points = new HashSet<Point>(); //ehemalsnew HashSet<>()

        foreach (Point point in getPointsOfMap())
        {
            if (getField(point).isDestroyed)
            {
                points.Add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which are inverted.
     *
     * @return The coordinates of thefields of the map which are inverted, null if there are none.
     */
    public HashSet<Point> getInvertedFields()
    {
        HashSet<Point> points = new HashSet<Point>();
        foreach (Point point in getPointsOfMap())
        {
            if (getField(point).isInverted)
            {
                points.Add(point);
            }
        }
        return points;
    }


    /**
     * Method to get all the fields of the map which are foggy.
     *
     * @return The coordinates of the fields of the map which are foggy, null if there are none.
     */
    public HashSet<Point> getFoggyFields()
    {
        HashSet<Point> points = new HashSet<Point>();

        foreach (Point point in getPointsOfMap())
        {
            if (getField(point).isFoggy)
            {
                points.Add(point);
            }
        }
        return points;
    }

    /**
     * Method to get all the field of the map which are free and have no character.
     *
     * @param characters The characters currently active in the game.
     * @return The coordinates of the fields of the map which are free and have no character.
     */
    public HashSet<Point> getFreeFields(HashSet<Character> characters)
    {
        HashSet<Point> points = new HashSet<Point>();

        foreach (Point point in getFieldsOfState(FieldStateEnum.FREE))
        {
            if (!fieldHasCharacter(point, characters))
            {
                points.Add(point);
            }
        }
        return points;
    }

    /**
     * Method to check if a field on the map got updated.
     *
     * @return true if a field on the map got updated, false if not.
     */
    public Boolean isMapUpdated()
    {
        foreach (Point point in getPointsOfMap())
        {
            if (getField(point).isUpdated)
            {
                return true;
            }
        }
        return false;
    }

    
    /**
     * Method to get the coordinates of the fields in between two points.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @return The coordinates of the fields in between the given points.
     */
    public HashSet<Point> getPointsInBetween(Point start, Point target)
    {
        HashSet<Point> points = new HashSet<Point>();

        // The coordinates of the start field and target field
        int x = start.getX();
        int y = start.getY();
        int xTarget = target.getX();
        int yTarget = target.getY();

        // The x and y ranges to the target field
        int xRange = Math.Abs(xTarget - x);
        int yRange = Math.Abs(yTarget - y);

        // The number of fields to check
        int n = xRange + yRange - 1;

        // The x and y direction from the start to the target field
        int xDirection = xTarget > x ? 1 : -1;
        int yDirection = yTarget > y ? 1 : -1;

        // The offset to the target point
        int offset = xRange - yRange;

        // For intermediate points which are not in the middle of the grid, it suffices to multiply by 2
        xRange *= 2;
        yRange *= 2;

        while (n > 0)
        {
            // Go in x direction
            if (offset > 0)
            {
                x += xDirection;
                offset -= yRange;
            }

            // Go in y direction
            else if (offset < 0)
            {
                y += yDirection;
                offset += xRange;
            }

            // Go diagonal, get both fields which are tangent to the line//vermuteter Fehler
            else
            {
                //points.Add(new Point(x + xDirection, y));//nachträglich entfernt da die implentierung des gekauften servers falsch war
                //points.Add(new Point(x, y + yDirection));////nachträglich entfernt da die implentierung des gekauften servers falsch war
                x += xDirection;
                y += yDirection;
                offset += xRange - yRange;
                n--;
            }
            if (n > 0)
            {
                points.Add(new Point(x, y));
            }
            n--;
        }
        return points;
    }

    /**
     * Method get the shortest range between two points.
     *
     * @param start  Coordinates of the character.
     * @param target Coordinates of the target.
     * @return true if target is in range, false if not.
     */
    public int getRange(Point start, Point target)
    {
        return Math.Max(Math.Abs(start.getX() - target.getX()), Math.Abs(start.getY() - target.getY()));
    }

    /**
     * Method to check if a target is in range of the character.
     *
     * @param start  Coordinates of the character.
     * @param target Coordinates of the target.
     * @param range  Range of the character.
     * @return true if target is in range, false if not.
     */
    public Boolean isInRange(Point start, Point target, int range)
    {
        return (getRange(start, target) <= range);
    }

    /**
     * Method to check if a target is in sight of the character.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @return true if the target field is in sight, false if not.
     */
    public Boolean isInSight(Point start, Point target)
    {
        foreach (Point point in getPointsInBetween(start, target))
        {
            if (getField(point).isState(FieldStateEnum.WALL) || getField(point).isState(FieldStateEnum.FIREPLACE) || getField(point).isFoggy)
            {
                return false;
            }
        }
        return true;
    }

    /**
     * Method to check if a target is blocked by a character.
     *
     * @param start      The coordinates of the start field.
     * @param target     The coordinates of the target field.
     * @param characters All the characters currently active in the game.
     * @return true if the target field is blocked, false if not.
     */
    public Boolean isBlocked(Point start, Point target, HashSet<Character> characters)
    {
        foreach (Point point in getPointsInBetween(start, target))
        {
            if (fieldHasCharacter(point, characters))
            {
                return true;
            }
        }
        return false;
    }





    /**
	[,] muss geändert werden in [][] weil [,] ein rechteckförmiges Arraygebilde voraussetzt 
	**/
}
