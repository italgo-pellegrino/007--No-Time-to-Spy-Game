﻿using System;

public class Field
{
	public FieldStateEnum state;
	public Gadget gadget;

	public bool isDestroyed;
	public bool isInverted;
	public int chipAmount;

	public int safeIndex;

	public bool isFoggy;
	public bool isUpdated;
	public Field()
	{
	}

	public FieldStateEnum getState()
	{
		return state;
	}
	public int GetChipAmount(){
		return chipAmount;
	}

	public FieldStateEnum getFieldStateEnum(){
		return state;
	}

	public bool getIsDestroyed(){
		return isDestroyed;
	}

	public Gadget GetGadget(){
		return gadget;
	}

    public Gadget getGadget()
    {
        return gadget;
    }

    public int getSafeIndex(){
		return safeIndex;
	}


    /**
    * Method to validate if the field is of the given state.
    *
    * @param state The type of state.
    * @throws InvalidTargetException If the field is not of the given state.
    */
    public void validateIsState(FieldStateEnum state)
    {
        if (!isState(state)) {
            throw new InvalidTargetException("The target field has the wrong state! Expected " + state.ToString() + ", but got " + this.state.ToString() + ".");
}
    }

    /**
     * Method to validate if the field is not of the given state.
     *
     * @param state The type of state.
     * @throws InvalidTargetException If the field is of the given state.
     */
    public void validateIsNotState(FieldStateEnum state)
{
        if (isState(state)) {
        throw new InvalidTargetException("The target field has the wrong state! Expected anything but " + state.ToString() + ", but got " + this.state.ToString() + ".");
    }
}

/**
 * Method to validate if the field is accessible.
 *
 * @throws InvalidTargetException If the field is not accessible.
 */
public void validateIsAccessible()
{
        if (!isAccessible()) {
        throw new InvalidTargetException("The target field is not accessible! Expected " + FieldStateEnum.FREE.ToString() + " or " + FieldStateEnum.BAR_SEAT.ToString() + ", but got " + state.ToString() + ".");
    }
}

/**
 * Method to validate if the field has any gadget.
 *
 * @throws InvalidTargetException If there is no gadget on the field.
 */
public void validateHasGadget() 
{
        if (!hasGadget()) {
        throw new InvalidTargetException("There is no gadget on the target field!");
    }
}

/**
 * Method to validate if the field has the given gadget.
 *
 * @param gadgetEnum The type of gadget.
 * @throws InvalidTargetException If there is no gadget on the field or the given gadget is not on the field.
 */
public void validateHasGadgetOfType(GadgetEnum gadgetEnum)
{
    validateHasGadget();
        if (!hasGadgetOfType(gadgetEnum)) {
        throw new InvalidTargetException("The target field has the wrong gadget! Expected " + gadget.gadget.ToString() + ", but got " + gadgetEnum.ToString() + ".");
    }
}

/**
 * Method to validate if the target field is not destroyed.
 *
 * @throws InvalidTargetException If the target field is destroyed.
 */
public void validateIsNotDestroyed()
{
        if (isDestroyed) {
        throw new InvalidTargetException("The target field is destroyed!");
    }
}

/**
 * Method to validate if there are enough chips on the field for a character's bet.
 *
 * @param bet The amount of chips the character wants to bet.
 * @throws InvalidTargetException     If the field is not a roulette table.
 * @throws InvalidChipAmountException If there are not enough chips on the field.
 */
public void validateHasChipAmount(int bet)
        {
        validateIsState(FieldStateEnum.ROULETTE_TABLE);
        if ((bet > chipAmount)) {
            throw new InvalidChipAmountException("The target field has not enough chips needed for that bet! Expected at least " + bet + ", but got " + chipAmount + ".");
        }
    }

    /**
     * Method to validate if the field is foggy or not.
     *
     * @throws InvalidActionPointsException If the field is foggy.
     */
    public void validateIsNotFoggy()
{
        if (isFoggy) {
        throw new InvalidActionPointsException("The field is foggy! The character standing on the field can't use any action points!");
    }
}

/**
 * Method to check if the field is of the given type.
 *
 * @param state The state of the field.
 * @return true if the given field is of the given type, false if not.
 */
public Boolean isState(FieldStateEnum state)
{
    return this.state.Equals(state);
}

/**
 * Method to check if the field is a valid field to move on to.
 *
 * @return true if the field is accessible, false if it is not.
 */
public Boolean isAccessible()
{
    return (isState(FieldStateEnum.FREE) || isState(FieldStateEnum.BAR_SEAT));
}



/**
 * Method to update the state of a game field.
 *
 * @param state The new state the field will be updated to.
 */
public void updateFieldState(FieldStateEnum state)
    {
        this.state = state;
        isUpdated=true;
    }




    /**
    * Method to check if a gadget is on the field.
    *
    * @return true if the field has a gadget, false if not.
    */
    public Boolean hasGadget()
    {
        return (gadget != null);
    }

    /**
     * Method to check if the given gadget is on the field.
     *
     * @param gadgetEnum The type of the gadget.
     * @return true if the field has the given gadget, false if not.
     */
    public Boolean hasGadgetOfType(GadgetEnum gadgetEnum)
    {
        if (!hasGadget())
        {
            return false;
        }
        return gadget.gadget.Equals(gadgetEnum);
    }




    /**
     * Method to get the cocktail of the field.
     *
     * @return The cocktail.
     */
    public Cocktail getCocktail()
    {
        if (gadget.gadget.Equals(GadgetEnum.COCKTAIL))
        {
            return (Cocktail)gadget;
        }
        return null;
    }

    /**
    * Method to add an amount of chips to the field if it is an roulette table.
    *
    * @param chipAmount The amount of chips to add or remove.
    */
    public void updateChips(int chipAmount)
    {
        this.chipAmount += chipAmount;
        isUpdated=true;
    }

    /**
     * Method to check if the field has the given safeIndex.
     *
     * @param safeIndex The safe index.
     * @return true if the field has the given safeIndex, false if not.
     */
    public Boolean hasSafeIndex(int safeIndex)
    {
        return this.safeIndex == safeIndex;
    }




}
