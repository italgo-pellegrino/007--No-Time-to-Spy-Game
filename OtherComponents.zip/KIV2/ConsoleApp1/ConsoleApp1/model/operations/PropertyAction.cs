﻿using System;

public class PropertyAction : Operation
{/* modified */
	public PropertyEnum usedProperty;

	public bool isEnemy;

	/**
		Konstruktor zum Senden, daher isEnemy = false, da der Client nicht von vornherein entscheiden kann, ob der Gegner ein Feind ist
	**/
	public PropertyAction(PropertyEnum usedProperty, Guid characterId, OperationEnum type, Point target) : base(characterId, type, target)
	{
		this.usedProperty = usedProperty;
		this.isEnemy = false;
	}

	public PropertyAction()
	{
		//Default Konstruktor
	}
}
