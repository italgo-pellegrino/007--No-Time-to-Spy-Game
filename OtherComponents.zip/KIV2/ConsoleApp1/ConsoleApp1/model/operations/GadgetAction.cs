﻿using System;

public class GadgetAction : Operation
{ /* modified */

	public GadgetEnum gadget;

	//successful ist hier false, da dies der Default Wert ist vom bool Wert, der Client kann nicht bestimmen, ob die Aktion erfolgreich sein wird!!
	public GadgetAction(GadgetEnum gadget, Guid characterId, OperationEnum type, Point target) : base(characterId, type, target)
	{
		this.gadget = gadget;
	}

	public GadgetAction(){
		//Default Konstruktor
	}
}
