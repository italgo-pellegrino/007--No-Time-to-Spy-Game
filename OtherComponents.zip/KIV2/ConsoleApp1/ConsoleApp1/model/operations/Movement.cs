﻿using System;


public class Movement : Operation
{/* modified */
	public Point from;
	// Zielfeld: Operation.target
	public Movement(Point from, Guid characterId, OperationEnum type, Point target) : base(characterId, type, target)
	{
		this.from = from;
	}
}
