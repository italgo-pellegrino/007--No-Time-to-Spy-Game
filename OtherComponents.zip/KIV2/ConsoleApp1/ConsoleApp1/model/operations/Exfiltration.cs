﻿

public class Exfiltration : Operation
{
	public Point from;
	public Exfiltration() : base()
	{
	}
}
