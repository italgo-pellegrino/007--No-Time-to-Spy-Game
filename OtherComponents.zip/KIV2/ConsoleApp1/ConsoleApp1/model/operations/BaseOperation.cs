﻿

public class BaseOperation
{/* modified */
	public OperationEnum type;
	public bool successful;
	public Point target;
	public BaseOperation(OperationEnum type, bool successful, Point target)
	{
		this.type = type;
		this.successful = successful;
		this.target = target;
	}

	public BaseOperation(){
		//Default Konstruktor
	}
}
