﻿using System;

public class GambleAction: Operation
{/* modified */
	public int stake;
	public GambleAction(int stake, Guid characterId, OperationEnum type, Point target) : base(characterId, type, target)
	{
		this.stake = stake;
	}
}
