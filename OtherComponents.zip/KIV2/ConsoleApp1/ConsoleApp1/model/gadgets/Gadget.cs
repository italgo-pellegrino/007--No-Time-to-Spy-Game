﻿public class Gadget
{
	public GadgetEnum gadget;
	public int usages;

	public Gadget(GadgetEnum gadget, int usages)
	{
		this.gadget = gadget;
		this.usages = usages;
	}

    public int getUsages() { return usages; }

	public bool use()
	{
		if (usages <= 0)
		{
			return false;
		}
		usages--;
		return true;
	}
}
