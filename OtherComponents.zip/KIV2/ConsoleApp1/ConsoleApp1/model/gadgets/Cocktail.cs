﻿public class Cocktail : Gadget
{
	public bool isPoisoned;
	public Cocktail(int usages, bool isPoisoned) : base(GadgetEnum.COCKTAIL, usages)
	{
		this.isPoisoned = isPoisoned;
	}

	public void poison()
	{
		this.isPoisoned = true;
	}
}
