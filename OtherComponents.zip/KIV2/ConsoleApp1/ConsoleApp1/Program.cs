﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.Controller;
using System.Text.RegularExpressions;
using ConsoleApp1.Controller.operationsWithoutMovement;
using System.Diagnostics;
using System.Threading;
using ConsoleApp1.Controller.operationsWithoutMovement;

namespace KI
{

    /*@author Akin Kula*/


    class DesktopLauncher
    {



        static void Main(string[] args)
        {

            Debug.Listeners.Add(new TextWriterTraceListener(Console.Out));
            Debug.AutoFlush = true;
            Debug.Indent();


            CommandLineInterface commandLineInterface = new CommandLineInterface();

            commandLineInterface.Parse(args);



            string address = commandLineInterface.address;
            int port = commandLineInterface.port;
            int verbosity = CommandLineInterface.verbosity;
            string name = commandLineInterface.name;
            int difficulty = commandLineInterface.difficulty;


            


            //connect to server



            if (address.Equals(""))
            {
                Console.WriteLine("No address given");
                return;
            }


            if (name.Equals(""))
            {
                Console.WriteLine("No name given");
                return;
            }



            //check ip address
            if (!Regex.Match(address, "^[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}$").Success
            && !address.Equals("localhost"))
            {
                Console.WriteLine("Invalid ip address");
                return;
            }
            else
            {
                string[] split = address.Split(new Char[] { '.' });
                foreach (string s in split)
                {
                    int ip;
                    Int32.TryParse(s, out ip);
                    if (!(ip >= 0 && ip <= 255))
                    {

                        Console.WriteLine("Invalid ip address (x.x.x.x)!");
                    }
                }
            }

            if (!(port >= 0 && port <= 65535))
            {
                Console.WriteLine("invalid port (between 0 and 65535)! \n");
            }

            //TODO: create websocket and link to connection class

            Console.WriteLine("Try to connect to " + address + ":" + port);
            Connection.connectToServer(address, port);



            //send hello message
            //Console.WriteLine("send hello message");
           Connection.gameHandler.sendHelloMessage(name, RoleEnum.AI);


            while (true) { 
            }

            
        }
    }
}
