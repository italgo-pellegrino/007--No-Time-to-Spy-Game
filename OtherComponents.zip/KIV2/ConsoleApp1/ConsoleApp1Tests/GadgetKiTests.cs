﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;

namespace ConsoleApp1.Controller.Tests
{
    [TestClass()]
    public class GadgetKiTests
    {
        [TestMethod()]
        public void getBestGadgetActionTest()
        {
            //Ohne Möglichkeiten


            //mit auswahl
        }






        [TestMethod()]
        public void couldUseGadgetTest()
        {

            HashSet<Character> enemy = new HashSet<Character>();
            HashSet<Character> npc = new HashSet<Character>();
            HashSet<Character> friends = new HashSet<Character>();
            HashSet<Character> allCharacters = new HashSet<Character>();


            Field emty_ = new Field();
            emty_.state = FieldStateEnum.FREE;

            Field item1 = new Field();
            item1.state = FieldStateEnum.FREE;

            Field player = new Field();
            player.state = FieldStateEnum.FREE;

            Field[,] map =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,emty_, emty_ },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            FieldMap fieldMap = new FieldMap(map);


            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);


            Character selectedCharacter = new Character(new Guid(), "player", new Point(0, 1),100,100,100,100,100, new HashSet<PropertyEnum>(),new HashSet<Gadget>());
            selectedCharacter.coordinates = new Point(0, 1);

            HashSet<Gadget> gadgets;
            HashSet<PropertyEnum> propertys;


            Dictionary<Gadget, Point> ergebnis;





            //test: ohne möglichkeiten
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig,enemy, npc, friends, allCharacters);
            Assert.AreEqual(0,ergebnis.Count);


            //test Hairdryer
            Gadget hairdryer = new Gadget(GadgetEnum.HAIRDRYER,1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(hairdryer);
            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.CLAMMY_CLOTHES);
            
            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys,gadgets);

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(0, 1), ergebnis[hairdryer]);



            //*******Test moledie**************
            Gadget moledie = new Gadget(GadgetEnum.MOLEDIE, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(moledie);
            propertys = new HashSet<PropertyEnum>();
            
            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //moledie without target
            enemy = new HashSet<Character>();
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //moledie with target
            enemy = new HashSet<Character>();
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(2,2 ), 100, 100, 100, 100, 100, propertys, gadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(2, 2), ergebnis[moledie]);

            //*****Prisma*******(niedrige priorität...)
            //Ohne tisch in reichweite

            //mit tisch in reichweite

            //mit umgestossenen tisch in reichweite



            //***BowlerBlade*****                    
            Gadget bowler = new Gadget(GadgetEnum.BOWLER_BLADE, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(bowler);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //ohne target
            enemy = new HashSet<Character>();
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
            Assert.AreEqual(0, ergebnis.Count);


            //Freie Sicht:
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(2,1), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(2, 1), ergebnis[bowler]);


            //mit ziel aber verdeckt durch character(einzige besonderheit..)

            allCharacters = new HashSet<Character>();
            allCharacters.Add(new Character(Guid.NewGuid(), "cat", new Point(1, 1), 100, 100, 100, 100, 100, propertys, gadgets));
            allCharacters.Add(selectedCharacter);

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
            Assert.AreEqual(0, ergebnis.Count);

            //(true da es auch bei allen anderen funktioniert...)
            //mit wand dazwischen
            //treffbar (mit tisch dazwischen)



            //*********Poison Pill************
            Gadget poison = new Gadget(GadgetEnum.POISON_PILLS, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(poison);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);
            enemy = new HashSet<Character>();

            //gegener ohne cocktail in reichweite
            HashSet<Gadget> enemyGadgets = new HashSet<Gadget>();
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(1, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //gegener mit cocktail in reichweite

            enemyGadgets.Add(new Gadget(GadgetEnum.COCKTAIL, 1));
            
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(1, 1), ergebnis[poison]);


            //kein gegner in reichweite(2 felder weiter)
            enemy = new HashSet<Character>();
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(2, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);



            //*******rocket Pen***************
            Gadget pen = new Gadget(GadgetEnum.ROCKET_PEN, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(pen);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //ohne gegener
            friends = new HashSet<Character>();
            enemy = new HashSet<Character>();

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);

            //mit gegner (ohne gefahr für andere)
            friends.Add(new Character(Guid.NewGuid(), "friend", new Point(0, 0), 100, 100, 100, 100, 100, propertys, gadgets));
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(3, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(3, 1), ergebnis[pen]);


            //rakete würde friens treffen
            friends.Add(new Character(Guid.NewGuid(), "friend2", new Point(3,2 ), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);



            //******gas gloss*********
            Gadget gas = new Gadget(GadgetEnum.GAS_GLOSS, 2);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(gas);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);
            enemy = new HashSet<Character>();

            //gegner ausserhalb der reichweite
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(2, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            friends = new HashSet<Character>();
           
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //gegner in reichweite
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(1, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(1, 1), ergebnis[gas]);




            //*********mothball pounch********
            Gadget moth = new Gadget(GadgetEnum.MOTHBALL_POUCH, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(moth);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);
            enemy = new HashSet<Character>();

            Field ofen = new Field();
            ofen.state = FieldStateEnum.FIREPLACE;
            
            Field[,] map3 =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,ofen ,emty_,  },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map3);

            friends = new HashSet<Character>();

            //gegner ohne ofen
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(0, 0), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //gegner am ofen
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(1, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(2, 1), ergebnis[moth]);


            //gegner am ofen mit freunden in reichweite
            friends.Add(new Character(Guid.NewGuid(), "friend", new Point(3, 0), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);






            fieldMap = new FieldMap(map);//Leere fieldmap wiederherstellen


            //***********fog tin**********
            Gadget fog_Tin = new Gadget(GadgetEnum.FOG_TIN, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(fog_Tin);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //ohne gegener
            friends = new HashSet<Character>();
            enemy = new HashSet<Character>();

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);

            selectedCharacter.setHp(99);

            //mit gegner der zu weit weg ist (ohne gefahr für andere)//TODO: theoretisch reicht auch ein nachbarfeld des gegners...

            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(3, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //gegner in reichweite ohne freunden zu schaden
            enemy.Add(new Character(Guid.NewGuid(), "enemy2", new Point(2, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(2, 1), ergebnis[fog_Tin]);

            //Character hat volles leben
            selectedCharacter.setHp(100);
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
            
            Assert.AreEqual(0, ergebnis.Count);

            //rakete würde friends treffen
            selectedCharacter.setHp(10);
            friends.Add(new Character(Guid.NewGuid(), "friend2", new Point(2, 0), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);




            //********grapple*********
            Gadget grapple = new Gadget(GadgetEnum.GRAPPLE, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(grapple);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //ohne erreichbare gadgets
            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //mit erreichbaren gadgets
            item1.gadget = new Gadget(GadgetEnum.DIAMOND_COLLAR, 3);
            Field[,] map2 =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,item1  ,emty_ ,emty_,  },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map2);

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(1, 1), ergebnis[grapple]);


            Field[,] emtymap =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,emty_, emty_ },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
             fieldMap = new FieldMap(emtymap);



            //**********cocktail***********
            Gadget cocktail = new Gadget(GadgetEnum.COCKTAIL, 2);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(cocktail);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);
            enemy = new HashSet<Character>();

            //genug leben+ kein trockener gegner
            //genug leben mit nassem gegner in reichweite
            HashSet<PropertyEnum> enemyPropertys = new HashSet<PropertyEnum>();
            enemyPropertys.Add(PropertyEnum.CLAMMY_CLOTHES);
            enemy.Add(new Character(Guid.NewGuid(), "enemy2", new Point(1, 1), 100, 100, 100, 100, 100, enemyPropertys, enemyGadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //genug leben mit Konstant nassem gegner in reichweite
            enemyPropertys.Remove(PropertyEnum.CLAMMY_CLOTHES);
            enemyPropertys.Add(PropertyEnum.CONSTANT_CLAMMY_CLOTHES);

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //nicht genug leben
            enemyPropertys.Remove(PropertyEnum.CONSTANT_CLAMMY_CLOTHES);
            selectedCharacter.setHp(99);

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(0, 1), ergebnis[cocktail]);

            //genug leben mit trockenem gegner in reichweite
            selectedCharacter.setHp(100);

            
            for (int i = 0; i < 1000; i++)
            {
                ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);
                if (ergebnis.Count == 1)
                    break;
            }
            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(1, 1), ergebnis[cocktail]);


            //genug leben mit trockenem gegner ausserhalb der reichweite



            //********Chicken Feed****************
            Gadget chicken = new Gadget(GadgetEnum.CHICKEN_FEED, 4);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(chicken);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //ohne npc in reichweite ZURÜCKÄNDERN
            npc = new HashSet<Character>();
            npc.Add(new Character(Guid.NewGuid(), "npc", new Point(0, 2), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);


            //mit npc in reichweite
            npc.Add(new Character(Guid.NewGuid(), "npc", new Point(1, 1), 100, 100, 100, 100, 100, propertys, gadgets));
            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(1, 1), ergebnis[chicken]);



            //**********Nugget***************
            Gadget nugget = new Gadget(GadgetEnum.NUGGET, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(chicken);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);


            //ohne npc in reichweite
            npc = new HashSet<Character>();
            npc.Add(new Character(Guid.NewGuid(), "npc", new Point(3, 2), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //mit npc in reichweite
            npc.Add(new Character(Guid.NewGuid(), "npc", new Point(0, 2), 100, 100, 100, 100, 100, propertys, gadgets));
            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(0, 2), ergebnis[nugget]);



            //*********WIRETAP_WITH_EARPLUGS***************
            Gadget wiretab = new Gadget(GadgetEnum.WIRETAP_WITH_EARPLUGS, 2);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(wiretab);
            propertys = new HashSet<PropertyEnum>();

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);
            enemy = new HashSet<Character>();

            //gegner ausserhalb der reichweite
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(2, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));
            friends = new HashSet<Character>();

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(0, ergebnis.Count);


            //gegner in reichweite
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(1, 1), 100, 100, 100, 100, 100, propertys, enemyGadgets));

            ergebnis = GadgetKi.couldUseGadget(selectedCharacter, fieldMap, matchconfig, enemy, npc, friends, allCharacters);

            Assert.AreEqual(1, ergebnis.Count);
            Assert.AreEqual(new Point(1, 1), ergebnis[wiretab]);



        }




        [TestMethod()]
        public void getGrapableGadgetsTest()
        {
            Field emty_ = new Field();
            emty_.state = FieldStateEnum.FREE;

            Field item1 = new Field();
            item1.state = FieldStateEnum.FREE;



            Field player = new Field();
            player.state = FieldStateEnum.FREE;

            Field[,] map =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,emty_, emty_ },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            FieldMap fieldMap = new FieldMap(map);





            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);

            Character selectedCharacter = new Character(new Guid(), "player", new HashSet<PropertyEnum>());
            selectedCharacter.coordinates = new Point(0, 1);


            //Ohne gadgets auf dem spielfeld
            Dictionary<GadgetEnum, Point> grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 1, fieldMap);
            Assert.AreEqual(0, grapablegGadgets.Count);



            //ein gadgets auf dem spielfeld ausserhalb der reichweite
            item1.gadget = new Gadget(GadgetEnum.DIAMOND_COLLAR, 3);
            Field[,] map2 =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,emty_, item1 },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map2);

            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 1, fieldMap);
            Assert.AreEqual(0, grapablegGadgets.Count);



            //2 gadgets auf dem spielfeld  1 in reichweite
            Field item2 = new Field();
            item2.gadget = new Gadget(GadgetEnum.BOWLER_BLADE, 3);

            item1.gadget = new Gadget(GadgetEnum.DIAMOND_COLLAR, 3);
            Field[,] map3 =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,item1   ,emty_, emty_ },
                               { emty_  ,emty_   ,emty_ ,item2 },
                             };
            fieldMap = new FieldMap(map3);
            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 1, fieldMap);

            Assert.AreEqual(1, grapablegGadgets.Count);
            Point p = grapablegGadgets[GadgetEnum.DIAMOND_COLLAR];
            Assert.AreEqual(1, p.getX());
            Assert.AreEqual(1, p.getY());




            //1 gadgets auf dem spielfeld  0 in reichweite(reichweite 2)
            item2 = new Field();
            item2.gadget = new Gadget(GadgetEnum.BOWLER_BLADE, 3);

            item1.gadget = new Gadget(GadgetEnum.DIAMOND_COLLAR, 3);
            Field[,] map4 =  {  { emty_ ,emty_ ,emty_, emty_ },
                               { player ,emty_ ,emty_, item2 }, 
                               { emty_  ,emty_ ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map4);
            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 2, fieldMap);

            Assert.AreEqual(0, grapablegGadgets.Count);
            //1 gadgets auf dem spielfeld  1 in reichweite(reichweite 3)
            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 3, fieldMap);
            Assert.AreEqual(1, grapablegGadgets.Count);



            //2 gadgets auf dem spielfeld  0 in reichweite(reichweite 4), 2 blockiert
            item2 = new Field();
            item2.gadget = new Gadget(GadgetEnum.BOWLER_BLADE, 3);
            Field wall = new Field();
            wall.state = FieldStateEnum.WALL;
            item1.gadget = new Gadget(GadgetEnum.DIAMOND_COLLAR, 3);
            Field[,] map5 =  {  { emty_ ,emty_ ,emty_, item1 },
                               { player ,emty_ ,wall, item2 },
                               { emty_  ,emty_ ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map5);
            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 4, fieldMap);
            Assert.AreEqual(0, grapablegGadgets.Count);



            //2 gadgets auf dem spielfeld  1 in reichweite(reichweite 1), 1 blockiert
            item2 = new Field();
            item2.gadget = new Gadget(GadgetEnum.BOWLER_BLADE, 3);
            wall = new Field();
            wall.state = FieldStateEnum.WALL;
            item1.gadget = new Gadget(GadgetEnum.DIAMOND_COLLAR, 3);
            Field[,] map6 =  {  { wall ,item1 ,emty_, wall },
                               { player ,wall ,wall, item2 },
                               { emty_  ,emty_ ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map6);
            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 4, fieldMap);
            Assert.AreEqual(0, grapablegGadgets.Count);



            //1 gadgets auf dem spielfeld  1 in reichweite(reichweite 4),
            
            wall = new Field();
            wall.state = FieldStateEnum.WALL;
            Field tisch = new Field();
            tisch.state = FieldStateEnum.BAR_TABLE;

            Field stuhl = new Field();
            stuhl.state = FieldStateEnum.BAR_SEAT;

            tisch.gadget = new Gadget(GadgetEnum.COCKTAIL, 3);

            Field[,] map7 =  {  { wall ,item1 ,emty_, wall },
                               { player ,stuhl ,tisch, wall },
                               { emty_  ,emty_ ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map7);
            grapablegGadgets = GadgetKi.getGrapableGadgets(selectedCharacter, 4, fieldMap);
            Assert.AreEqual(1, grapablegGadgets.Count);

        }





        [TestMethod()]
        public void bestGrapableGadgetTest()
        {
            Field emty_ = new Field();
            emty_.state = FieldStateEnum.FREE;

            Field item1 = new Field();
            item1.state = FieldStateEnum.FREE;



            Field player = new Field();
            player.state = FieldStateEnum.FREE;

            Field[,] map =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,emty_, emty_ },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            FieldMap fieldMap = new FieldMap(map);





            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);

            Character selectedCharacter = new Character(new Guid(), "player", new HashSet<PropertyEnum>());
            selectedCharacter.coordinates = new Point(0, 1);


            //Ohne gadgets auf dem spielfeld
            Tuple<GadgetEnum, Point> best = GadgetKi.bestGrapableGadget(selectedCharacter, 1, fieldMap);
            Assert.IsNull(best);



            //mehrere Gadgets
            Field item2 = new Field();
            item2.gadget = new Gadget(GadgetEnum.BOWLER_BLADE, 3);
            Field wall = new Field();
            wall.state = FieldStateEnum.WALL;         
            item1.gadget = new Gadget(GadgetEnum.COCKTAIL, 3);
            Field[,] map6 =  {  { emty_ ,item1 ,emty_, wall },
                               { player ,emty_ ,emty_, item2 },
                               { emty_  ,emty_ ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map6);
            best = GadgetKi.bestGrapableGadget(selectedCharacter, 6, fieldMap);
            Assert.AreEqual(GadgetEnum.COCKTAIL,best.Item1);
        }


    }
}