﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller.Tests
{
    /*@Jonas Frei*/
    [TestClass()]
    public class PropertyOperationKITests
    {
        /*@Jonas Frei*/
        [TestMethod()]
        public void tryObservationTest()
        {
            Field emty_ = new Field();
            emty_.state = FieldStateEnum.FREE;

            Field player = new Field();
            player.state = FieldStateEnum.FREE;

            

            Field [,] map =  { { emty_, emty_ ,emty_, emty_ },
                               { player ,emty_ ,emty_, emty_ }, 
                               { emty_ ,emty_ ,emty_, emty_ }, 
                             };
            FieldMap fieldMap = new FieldMap(map);





            Character selectedCharacter = new Character(new Guid(), "player", new HashSet<PropertyEnum>());
            selectedCharacter.coordinates = new Point(1, 1);

            //Kein observation und niemand dA
            HashSet<Character> npcHashSet = new HashSet<Character>();
           Tuple<PropertyEnum,Point> observation= PropertyOperationKI.tryObservation(selectedCharacter,new HashSet<Character>(),fieldMap);
            Assert.IsNull(observation);//Kein observation und niemand dA

            
            // observation und niemand dA
            HashSet<PropertyEnum> propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.OBSERVATION);
            selectedCharacter = new Character(new Guid(), "player",propertys );
            selectedCharacter.coordinates = new Point(1, 1);
            npcHashSet = new HashSet<Character>();
            observation = PropertyOperationKI.tryObservation(selectedCharacter, new HashSet<Character>(), fieldMap);

            Assert.IsNull(observation);



            //observation mit einem gegener nicht notwendig da der methode nur npcs bekannt sind



            //observation mit einem npc in reichweite
            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.OBSERVATION);
            selectedCharacter = new Character(new Guid(), "player", propertys);
            selectedCharacter.coordinates = new Point(1, 1);

            npcHashSet = new HashSet<Character>();
            Point npc1_Point = new Point(1,2);
            Character npc1 = new Character(new Guid(), "npc1",new HashSet<PropertyEnum>());
            npc1.coordinates = npc1_Point;
            npcHashSet.Add(npc1);

            observation = PropertyOperationKI.tryObservation(selectedCharacter, npcHashSet, fieldMap);

            Assert.IsNotNull(observation);
            Assert.AreEqual(npc1_Point, observation.Item2);




            //observation mit einem npc in  Reichweite
            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.OBSERVATION);
            selectedCharacter = new Character(new Guid(), "player", propertys);
            selectedCharacter.coordinates = new Point(1, 1);

            npcHashSet = new HashSet<Character>();
            npc1_Point = new Point(1, 3);
            npc1 = new Character(new Guid(), "npc1", new HashSet<PropertyEnum>());
            npc1.coordinates = npc1_Point;
            npcHashSet.Add(npc1);

            observation = PropertyOperationKI.tryObservation(selectedCharacter, npcHashSet, fieldMap);

            Assert.IsNotNull(observation);
            Assert.AreEqual(new Point(1,3),observation.Item2);



            //observation mit einem npc auserhalb und einem in  Reichweite

            //neue map:
            Field wall = new Field();
            wall.state = FieldStateEnum.WALL;

            Field[,] map2 =  { { emty_, emty_ ,emty_, emty_ },
                               { emty_, player ,wall, emty_ },
                               { emty_ ,emty_ ,wall, emty_ },
                             };
             fieldMap = new FieldMap(map2);



            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.OBSERVATION);
            selectedCharacter = new Character(new Guid(), "player", propertys);
            selectedCharacter.coordinates = new Point(1, 1);

            npcHashSet = new HashSet<Character>();

            npc1_Point = new Point(3, 1);
            npc1 = new Character(new Guid(), "npc1", new HashSet<PropertyEnum>());
            npc1.coordinates = npc1_Point;
            npcHashSet.Add(npc1);

            Point npc2_Point = new Point(1, 0);
            Character npc2 = new Character(new Guid(), "npc2", new HashSet<PropertyEnum>());
            npc2.coordinates = npc2_Point;
            npcHashSet.Add(npc2);

            observation = PropertyOperationKI.tryObservation(selectedCharacter, npcHashSet, fieldMap);

            Assert.IsNotNull(observation);
            Assert.AreEqual(npc2_Point, observation.Item2);


        }

    }
}