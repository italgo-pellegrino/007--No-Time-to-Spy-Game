﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller.operationsWithoutMovement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Controller.operationsWithoutMovement.Tests
{
    [TestClass()]
    public class CommandLineInterfaceTests
    {

        [TestMethod()]
        public void ParseTest()
        {
            CommandLineInterface cmd = new CommandLineInterface();
            string[] args = { "-h" };
            bool test = cmd.Parse(args);
            Assert.IsTrue(test);


            //check if address and no address given
            CommandLineInterface cmd2 = new CommandLineInterface();
            string[] args2 = { "--address" };
            bool test2 = cmd2.Parse(args2);
            Assert.IsFalse(test2);

            //check if address and valid address given
            CommandLineInterface cmd3 = new CommandLineInterface();
            string[] args3 = { "--address" , "127.152.15.23"};
            bool test3 = cmd3.Parse(args3);
            Assert.IsTrue(test3);
            Assert.AreEqual("127.152.15.23", cmd3.address);

            //check if port and no port given
            CommandLineInterface cmd4 = new CommandLineInterface();
            string[] args4 = { "--port" };
            bool test4 = cmd4.Parse(args4);
            Assert.IsFalse(test4);

            //check if port and valid port given
            CommandLineInterface cmd5 = new CommandLineInterface();
            string[] args5 = { "--port", "7213"};
            bool test5 = cmd5.Parse(args5);
            Assert.IsTrue(test5);
            Assert.AreEqual(7213, cmd5.port);


            //check if difficulty and no difficulty given
            CommandLineInterface cmd6 = new CommandLineInterface();
            string[] args6 = { "--difficulty" };
            bool test6 = cmd6.Parse(args6);
            Assert.IsFalse(test6);


            //check if difficulty and difficulty given
            CommandLineInterface cmd7 = new CommandLineInterface();
            string[] args7 = { "--difficulty" , "2"};
            bool test7 = cmd7.Parse(args7);
            Assert.IsTrue(test7);
            Assert.AreEqual(2, cmd7.difficulty);

        }
    }
}