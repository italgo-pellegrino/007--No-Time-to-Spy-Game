﻿using System;
using System.Collections.Generic;
using ConsoleApp1.Controller;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace ConsoleApp1Tests.Controller
{
    [TestClass]
    public class ASearchMapTests
    {
        [TestMethod]
        public void TestMethod1()
        {

            string fieldJson = @"{
                'scenario': [
                ['FREE', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL'],
                ['WALL', 'FIREPLACE', 'WALL', 'BAR_TABLE', 'BAR_SEAT', 'FREE', 'WALL'],
                ['WALL', 'FREE', 'FREE', 'FREE', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'BAR_TABLE', 'FREE', 'ROULETTE_TABLE', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'BAR_SEAT', 'FREE', 'WALL', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'FREE', 'FREE', 'FREE', 'FREE', 'SAFE', 'WALL'],
                ['WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL']
                ]
                }";

            Scenario scenario = JsonConvert.DeserializeObject<Scenario>(fieldJson);

            FieldStateEnum[,] map = scenario.getScenario();


            //convert FieldStateEnum[,] into Field[,]

            Field[,] fieldTiles = new Field[map.GetLength(0), map.GetLength(1)];
            for(int y = 0;  y < map.GetLength(0); y++)
            {
                for (int x = 0;  x < map.GetLength(1); x++)
                {
                    Field f = new Field();
                    f.state = map[y, x];
                    fieldTiles[y,x] = f;
                }
            }

            FieldMap fieldMap = new FieldMap(fieldTiles);

            ASearchMap asearchmap = new ASearchMap(fieldMap);

            //(x,y) test from (1,5) -> (4,5)
            List<Point> points = asearchmap.CalcShortestPath(new Point(1, 5), new Point(4, 5));
            Assert.IsNotNull(points);
            Console.WriteLine("Found Path");
            points.ForEach(Console.WriteLine);

            //(x,y) test from (1,5) -> (4,5)
            points = asearchmap.CalcShortestPath(new Point(1, 5), new Point(5, 1));
            Assert.IsNotNull(points);
            Console.WriteLine("Found Path");
            points.ForEach(Console.WriteLine);

            //(x,y) test from (1,5) -> (4,5)
            points = asearchmap.CalcShortestPath(new Point(1, 5), new Point(0, 0));
            Assert.IsNull(points);
            Console.WriteLine("no Path");

            //(x,y) test from (4,5) -> (5,5) (safe test)
            points = asearchmap.CalcShortestPath(new Point(4, 5), new Point(5, 5));
            points.ForEach(a => { Console.WriteLine(a); });
            Assert.IsNotNull(points);
            Console.WriteLine("no Path");
        }

    }
}
