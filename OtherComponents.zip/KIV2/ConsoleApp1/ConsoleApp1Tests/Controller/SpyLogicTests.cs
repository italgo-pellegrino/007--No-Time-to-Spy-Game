﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ConsoleApp1.Controller.Tests
{
    [TestClass()]
    public class SpyLogicTests
    {

        public State state;
        public Character character1;

        public Character activeCharacter;

        [TestInitialize]
        public void TestInitialize()
        {
            string fieldJson = @"{
                'scenario': [
                ['WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL'],
                ['WALL', 'FIREPLACE', 'WALL', 'BAR_TABLE', 'BAR_SEAT', 'FREE', 'WALL'],
                ['WALL', 'FREE', 'FREE', 'FREE', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'BAR_TABLE', 'FREE', 'ROULETTE_TABLE', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'BAR_SEAT', 'FREE', 'WALL', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'FREE', 'FREE', 'FREE', 'FREE', 'SAFE', 'WALL'],
                ['WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL']
                ]
                }";

            Scenario scenario = JsonConvert.DeserializeObject<Scenario>(fieldJson);

            FieldStateEnum[,] map = scenario.getScenario();


            //convert FieldStateEnum[,] into Field[,]

            Field[,] fieldTiles = new Field[map.GetLength(0), map.GetLength(1)];
            for (int y = 0; y < map.GetLength(0); y++)
            {
                for (int x = 0; x < map.GetLength(1); x++)
                {
                    Field f = new Field();
                    f.state = map[y, x];
                    fieldTiles[y, x] = f;
                }
            }

            FieldMap fieldMap = new FieldMap(fieldTiles);

            HashSet<int> mySafeCombinations = new HashSet<int>();
            HashSet<Character> characters = new HashSet<Character>();
            //GadgetEnum.DIAMOND_COLLAR
            this.character1 = new Character(Guid.NewGuid(), "Test Person 1", new HashSet<PropertyEnum>());
            HashSet<Gadget> gadgets1 = new HashSet<Gadget>();

            character1.gadgets = gadgets1;
            character1.setCoordinates(new Point(5, 1));
            character1.setHp(100);
            character1.setMp(3);

            characters.Add(character1);
            character1.setHp(100);
            character1.setMp(3);



            State state = new State(0, fieldMap, mySafeCombinations, characters, null, null);

            this.state = state;

            this.activeCharacter = character1;




        }



        [TestMethod()]
        public void CheckSpyTest()
        {

            //player = (5, 1)
            //npc = (5,2)

            character1.setAp(1);


            Character currentCharacter = character1;
            List<Character> npclist = new List<Character>();
            Character npcDummy = new Character(Guid.NewGuid(), "npc", new HashSet<PropertyEnum>());
            
            
            //if near enough
            npcDummy.setCoordinates(new Point(5, 2));
            npclist.Add(npcDummy);
            Operation operation = SpyLogic.CheckSpy(state, currentCharacter, npclist);

            Assert.AreEqual(operation.type, OperationEnum.SPY_ACTION);


            //player = (5, 1)
            //npc = (5,4)

            npcDummy.setCoordinates(new Point(5, 4));



            //if too far away to spy -> move
            operation = SpyLogic.CheckSpy(state, currentCharacter, npclist);

            Assert.AreEqual(operation.type, OperationEnum.MOVEMENT);





            //test am 07.07.2020
            //map init
            Field f = new Field();
            f.state = FieldStateEnum.FREE;

            Field c = new Field();
            c.state = FieldStateEnum.BAR_SEAT;

            Field t = new Field();
            t.state = FieldStateEnum.BAR_TABLE;

            Field o = new Field();
            o.state = FieldStateEnum.FIREPLACE;

            Field r = new Field();
            r.state = FieldStateEnum.ROULETTE_TABLE;

            Field w = new Field();
            w.state = FieldStateEnum.WALL;

            Field x = new Field();
            x.state = FieldStateEnum.FREE;
            x.gadget = new Gadget(GadgetEnum.MOLEDIE, 1);

            Field y = new Field();
            y.state = FieldStateEnum.BAR_TABLE;
            y.gadget = new Gadget(GadgetEnum.COCKTAIL, 1);


            Field s1 = new Field();
            s1.state = FieldStateEnum.SAFE;
            s1.safeIndex = 1;

            Field s2 = new Field();
            s2.state = FieldStateEnum.SAFE;
            s2.safeIndex = 2;


            Field[,] map = {    {f, f, f, c, y, f, t, f, f, w,s2, f, f, w, f },
                                {f, f, f, c, f, f, f, f, f, w, w, w, f, w, f },
                                {f, f, f, c, t, f,s1, f, f, f, f, f, f, w, f } };

            state.map.map = map;


            character1.setCoordinates(new Point(0, 0));

            npcDummy.setCoordinates(new Point(1, 0));

            //spy
            operation = SpyLogic.CheckSpy(state, currentCharacter, npclist);

            Assert.AreEqual(OperationEnum.SPY_ACTION, operation.type);

            //scenario von jonas
            character1.setMp(3);

            npcDummy.setCoordinates(new Point(2, 0));

            //spy
            operation = SpyLogic.CheckSpy(state, currentCharacter, npclist);

            Assert.AreEqual(OperationEnum.MOVEMENT, operation.type);

        }

        [TestMethod()]
        public void GetNearestUnknownSpyTest()
        {
            Character currentCharacter = character1;
            List<Character> npclist = new List<Character>();

            //player = (5, 1)
            //npc = (5,2)
            //npc1 = (4,5)


            Character npcDummy = new Character(Guid.NewGuid(), "npc", new HashSet<PropertyEnum>());
            npcDummy.setCoordinates(new Point(4, 5));
            npclist.Add(npcDummy);
            Character nearestUknownSpy = SpyLogic.GetNearestUnknownSpy(state, currentCharacter, npclist);
            Assert.AreEqual(npcDummy, nearestUknownSpy);




            //player = (5, 1)
            //npc1 = (5,2)


            Character npcDummy1 = new Character(Guid.NewGuid(), "npc1", new HashSet<PropertyEnum>());
            npcDummy1.setCoordinates(new Point(5, 2));
            npclist.Add(npcDummy1);
            nearestUknownSpy = SpyLogic.GetNearestUnknownSpy(state, currentCharacter, npclist);
            Assert.AreEqual(npcDummy1, nearestUknownSpy);
        }
    }
}