﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace ConsoleApp1.Controller.Tests
{
    /*@Jonas Frei*/
    [TestClass()]
    public class OperarionsWithoutMovementKITests
    {
        /*@Jonas Frei*/
        [TestMethod()]
        public void OperarionsWithoutMovementRaitingTest()
        {
            HashSet<Character> enemy = new HashSet<Character>();
            HashSet<Character> npc = new HashSet<Character>();
            HashSet<Character> usedNpc = new HashSet<Character>();
            HashSet<Character> friends = new HashSet<Character>();
            HashSet<Character> allCharacters = new HashSet<Character>();


            Field emty_ = new Field();
            emty_.state = FieldStateEnum.FREE;

            Field item1 = new Field();
            item1.state = FieldStateEnum.FREE;

            Field player = new Field();
            player.state = FieldStateEnum.FREE;

            Field[,] map =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,emty_  ,emty_, emty_ },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            FieldMap fieldMap = new FieldMap(map);


            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);


            Character selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, new HashSet<PropertyEnum>(), new HashSet<Gadget>());
            

            HashSet<Gadget> gadgets;
            HashSet<PropertyEnum> propertys;
            propertys = new HashSet<PropertyEnum>();
            gadgets = new HashSet<Gadget>();

            Operation ergebnis;

            //ohne mögliche aktionen

            ergebnis = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting( selectedCharacter,  fieldMap,  matchconfig, enemy,  npc, usedNpc,  friends, allCharacters);
            Assert.IsNull(ergebnis);


            //nur gadgetaufnahme
            Field item = new Field();
            item.state = FieldStateEnum.BAR_TABLE;
            item.gadget =new Gadget( GadgetEnum.COCKTAIL,2);

            Field[,] map2 =  {  { emty_  , emty_ ,emty_, emty_ },
                               { player ,item  ,emty_, emty_ },
                               { emty_  ,emty_  ,emty_, emty_ },
                             };
            fieldMap = new FieldMap(map2);

            ergebnis = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting(selectedCharacter, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);
            Assert.IsNotNull(ergebnis);
            Assert.AreEqual(new Point(1,1),ergebnis.target);
            Assert.AreEqual(OperationEnum.GADGET_ACTION,ergebnis.type);
            


            //gadgetaufnahme und Fön
            Gadget hairdryer = new Gadget(GadgetEnum.HAIRDRYER, 1);
            gadgets = new HashSet<Gadget>();
            gadgets.Add(hairdryer);
            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.CLAMMY_CLOTHES);

            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);

            ergebnis = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting(selectedCharacter, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);

            Assert.IsNotNull(ergebnis);
            Assert.AreEqual(new Point(1, 1), ergebnis.target);
            Assert.AreEqual(OperationEnum.GADGET_ACTION, ergebnis.type);


            //observation und Fön
          
            fieldMap = new FieldMap(map);//=kein gadget auf der map

            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.CLAMMY_CLOTHES);
            propertys.Add(PropertyEnum.OBSERVATION);
            selectedCharacter.properties = propertys;
            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);

            npc = new HashSet<Character>();
            enemy = new HashSet<Character>();
            
            npc.Add(new Character(Guid.NewGuid(), "npc", new Point(0, 0), 100, 100, 100, 100, 100, propertys, gadgets));


            ergebnis = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting(selectedCharacter, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);


            Assert.IsNotNull(ergebnis);
            Assert.AreEqual(new Point(0, 0), ergebnis.target);
            Assert.AreEqual(OperationEnum.PROPERTY_ACTION, ergebnis.type);


            //observation und trinken +fön
            gadgets.Add(new Gadget(GadgetEnum.COCKTAIL, 1));
            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 50, 50, 50, 50, 50, propertys, gadgets);//50 hp
            ergebnis = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting(selectedCharacter, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);

            Assert.IsNotNull(ergebnis);
            Assert.AreEqual(new Point(0, 1), ergebnis.target);
            Assert.AreEqual(OperationEnum.GADGET_ACTION, ergebnis.type);


            //observation obwohl gegener existieren

            propertys = new HashSet<PropertyEnum>();
            propertys.Add(PropertyEnum.OBSERVATION);
            selectedCharacter.properties = propertys;
            selectedCharacter = new Character(new Guid(), "player", new Point(0, 1), 100, 100, 100, 100, 100, propertys, gadgets);

            npc = new HashSet<Character>();
            enemy = new HashSet<Character>();

            npc.Add(new Character(Guid.NewGuid(), "npc", new Point(0, 0), 100, 100, 100, 100, 100, propertys, gadgets));
            enemy.Add(new Character(Guid.NewGuid(), "enemy", new Point(2, 1), 100, 100, 100, 100, 100, propertys, gadgets));

            ergebnis = OperarionsWithoutMovementKI.OperarionsWithoutMovementRaiting(selectedCharacter, fieldMap, matchconfig, enemy, npc, usedNpc, friends, allCharacters);


            Assert.IsNotNull(ergebnis);
            Assert.AreEqual(new Point(0, 0), ergebnis.target);
            Assert.AreEqual(OperationEnum.PROPERTY_ACTION, ergebnis.type);


        }
    }
}