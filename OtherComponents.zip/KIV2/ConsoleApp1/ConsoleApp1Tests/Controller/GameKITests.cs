﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace ConsoleApp1.Controller.Tests
{
    /*@Jonas Frei*/
    [TestClass()]
    public class GameKITests
    {
        /*@author Jonas Frei*/
        [TestMethod()]
        public void enemyDetectionTest()
        {

            GameKI gameKi;

            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);

            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\TestDateiKI.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }

            //characterDescription in character übersetzen
            HashSet<Character> characterList = new HashSet<Character>();
            int counter = 0;
            foreach (CharacterInformation information in characterInformation)
            {
                Character character = new Character(information.characterId, information.name, new HashSet<PropertyEnum>(information.features));
                character.coordinates = new Point(0, counter);//da der getesteten methode vollkommen egal is ob der character in reichweite steht solage keine character ineinander stehen wird einfach hochgezählt
                characterList.Add(character);
                counter++;
            }


            gameHandler.settings = matchconfig;
            gameHandler.characterSettings = characterInformation;
            gameHandler.characters = characterList;
            gameHandler.map = new FieldMap(new Field[0, 0]);


            HashSet<Guid> ownFraction;
            HashSet<Guid> enemy;
            HashSet<Guid> npcList;

            List<BaseOperation> baseOperationList;
            BaseOperation baseOperation;
            GameStatusMessage message;
            State state = new State(-1, new FieldMap(new Field[0, 0]), new HashSet<int>(), characterList, new Point(-1, -1), new Point(-1, -1));//viele variablen des state haben keinen einfluss auf den test weshalb sie bewust mit falschen wrten initialisiert wurden
            //unverändert lassen:gamehandler

            //veränderbar:gameki, npcList, ownFraction, enemy(nachdem GameKi erstellt wurde)





            //Test nr1: eigenes team hat erfolgreich einen npc ausspioniert
            //own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //ausspionierter npc= "00000000-0000-0000-0000-000000000002"
            //activeCharacter war "00000000-0000-0000-0000-000000000000"

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt

            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);




            baseOperationList = new List<BaseOperation>();
            baseOperation = new BaseOperation(OperationEnum.SPY_ACTION, true, new Point(0, 2));
            baseOperationList.Add(baseOperation);


            message = new GameStatusMessage(Guid.NewGuid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), baseOperationList, state, false);
            gameKi.enemyDetection(message);




            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(2, gameKi.enemy.Count);

            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);

            Assert.AreEqual(1, gameKi.usedNpcList.Count);
            Assert.IsTrue(gameKi.usedNpcList.Contains(new Guid("00000000-0000-0000-0000-000000000002")));










            //Test nr2: eigenes team hat erfolglos einen npc ausspioniert
            //own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //ausspionierter npc= "00000000-0000-0000-0000-000000000002"
            //activeCharacter war "00000000-0000-0000-0000-000000000000"

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt

            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);




            baseOperationList = new List<BaseOperation>();
            baseOperation = new BaseOperation(OperationEnum.SPY_ACTION, false, new Point(0, 2));//spionieren war nicht erfolgreich
            baseOperationList.Add(baseOperation);


            message = new GameStatusMessage(Guid.NewGuid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), baseOperationList, state, false);
            gameKi.enemyDetection(message);



            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(2, gameKi.enemy.Count);

            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);
            Assert.AreEqual(matchconfig.spySuccessChance, gameKi.unsuccessfullUsedNpcList[new Guid("00000000-0000-0000-0000-000000000002")]);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);





            //Test nr3: prüfen ob der ausspionierte Character zum gegner wird wenn es sich mit "150% wahrscheinlichkeit" um einen gegner handelt
            gameKi.enemyDetection(message);//"100%"


            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(2, gameKi.enemy.Count);

            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);
            Assert.AreEqual(matchconfig.spySuccessChance * 2, gameKi.unsuccessfullUsedNpcList[new Guid("00000000-0000-0000-0000-000000000002")], 0.1);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);




            gameKi.enemyDetection(message);//149%(wegen ungenauigkeiten bei adition von Kommazahlen)
            gameKi.enemyDetection(message);//200%//not


            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(1, gameKi.npcList.Count);
            Assert.AreEqual(3, gameKi.enemy.Count);
            Assert.IsTrue(enemy.Contains(new Guid("00000000-0000-0000-0000-000000000002")));


            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);
            Assert.AreEqual(matchconfig.spySuccessChance * 4, gameKi.unsuccessfullUsedNpcList[new Guid("00000000-0000-0000-0000-000000000002")], 0.1);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);




            /*chickenfeed wird in der aktuellen implementierung auf grund des Ip verlust nicht gnutzt 

            //test nr4 Chickenfeed auf enemy angewand
            // own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //beschenkter npc= "00000000-0000-0000-0000-000000000003"
            //activeCharacter war "00000000-0000-0000-0000-000000000001"

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt
           

            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);




            baseOperationList = new List<BaseOperation>();
            baseOperation = new GadgetAction(GadgetEnum.CHICKEN_FEED, new Guid("00000000-0000-0000-0000-000000000001"),OperationEnum.GADGET_ACTION, new Point(0, 3));//chickenfeed ist eine gadgetaction
            baseOperationList.Add(baseOperation);

            

            state = new State(-1, new FieldMap(new Field[0, 0]), new HashSet<int>(), characterList, new Point(-1, -1), new Point(-1, -1));//der state hat keinen einfluss auf die test weshalb er bewusst mit falschen werten gefüllt wurde

            message = new GameStatusMessage(Guid.NewGuid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000001"), baseOperationList, state, false);
            gameKi.enemyDetection(message);


            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);

            //Assert.AreEqual(1, gameKi.npcList.Count);
            //Assert.AreEqual(3, gameKi.enemy.Count);
            Assert.IsTrue(enemy.Contains(new Guid("00000000-0000-0000-0000-000000000003")));
            Assert.IsFalse(npcList.Contains(new Guid("00000000-0000-0000-0000-000000000003")));

            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);







            //test nr5: chickenfeed auf npc0003 angewand

            //own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //beschenkter npc= "00000000-0000-0000-0000-000000000003"
            //activeCharacter war "00000000-0000-0000-0000-000000000001"

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt


            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);




            baseOperationList = new List<BaseOperation>();
            baseOperation = new BaseOperation(OperationEnum.GADGET_ACTION, true, new Point(0, 3));//chickenfeed ist eine gadgetaction
            baseOperationList.Add(baseOperation);

            // dem character der chickenfeed ausgeführt hat die selbe anzahl an IP geben wie in ipbevforeOperation gespeichert sind
            foreach (Character character in characterList)
            {
                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.ip = 100;
                }
            }

            state = new State(-1, new FieldMap(new Field[0, 0]), new HashSet<int>(), characterList, new Point(-1, -1), new Point(-1, -1));//der state hat keinen einfluss auf die test weshalb er bewusst mit falschen werten gefüllt wurde

            message = new GameStatusMessage(Guid.NewGuid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000001"), baseOperationList, state, false);
            gameKi.enemyDetection(message);




            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(2, gameKi.enemy.Count);

            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);



            */



            //test nr 6 gegner erkennen weil er der eigenen fraktion nachspioniert hat
            //own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //ausspionierter character der eigenen fraktion= "00000000-0000-0000-0000-000000000001"
            //activeCharacter war "00000000-0000-0000-0000-000000000003"

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt

            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);




            baseOperationList = new List<BaseOperation>();
            baseOperation = new BaseOperation(OperationEnum.SPY_ACTION, false, new Point(0, 1));//spionieren war nicht erfolgreich opfer war der character oo1 des eigenen teams
            baseOperationList.Add(baseOperation);


            message = new GameStatusMessage(Guid.NewGuid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000003"), baseOperationList, state, false);//character
            gameKi.enemyDetection(message);



            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(1, gameKi.npcList.Count);
            Assert.AreEqual(3, gameKi.enemy.Count);

            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);







            //test nr 7 gegner verhört einen spieler der zur fraktion gehöhrt

            //own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //ausspionierter character der eigenen fraktion= "00000000-0000-0000-0000-000000000001"
            //activeCharacter war "00000000-0000-0000-0000-000000000003"

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt

            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);




            baseOperationList = new List<BaseOperation>();
            baseOperation = new BaseOperation(OperationEnum.SPY_ACTION, false, new Point(0, 1));//spionieren war nicht erfolgreich opfer war der character oo1 des eigenen teams
            baseOperationList.Add(baseOperation);


            message = new GameStatusMessage(Guid.NewGuid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000004"), baseOperationList, state, false);//character war 004
            gameKi.enemyDetection(message);


            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(2, gameKi.enemy.Count);

            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);

            Assert.AreEqual(0, gameKi.usedNpcList.Count);









        }



        /*@author Jonas Frei*/
        [TestMethod()]
        public void deleteKilledCharactersTest()
        {
            GameKI gameKi;

            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);

            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\6personen.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }

            //characterDescription in character übersetzen
            HashSet<Character> characterList = new HashSet<Character>();
            HashSet<Character> modifizierteCharacterList = new HashSet<Character>();
            int counter = 0;
            foreach (CharacterInformation information in characterInformation)
            {
                Character character = new Character(information.characterId, information.name, new HashSet<PropertyEnum>(information.features));
                character.coordinates = new Point(0, counter);//da der getesteten methode vollkommen egal is ob der character in reichweite steht solage keine character ineinander stehen wird einfach hochgezählt              
                characterList.Add(character);
                modifizierteCharacterList.Add(character);
                counter++;
            }


            gameHandler.settings = matchconfig;
            gameHandler.characterSettings = characterInformation;
            gameHandler.characters = characterList;
            gameHandler.map = new FieldMap(new Field[0, 0]);


            HashSet<Guid> ownFraction;
            HashSet<Guid> enemy;
            HashSet<Guid> npcList;


            State state = new State(-1, new FieldMap(new Field[0, 0]), new HashSet<int>(), characterList, new Point(-1, -1), new Point(-1, -1));//viele variablen des state haben keinen einfluss auf den test weshalb sie bewust mit falschen wrten initialisiert wurden





            //Test nr1: eigenes team hat erfolgreich einen npc ausspioniert
            //own fraction: "00000000-0000-0000-0000-000000000000" ,"00000000-0000-0000-0000-000000000001"
            //npc:0002, 0003
            //enemy:004,005

            //verstorbene der eigenen fraktion  :000
            //verstorbene npc                   :003 (ist auch in unsuccesfullUsednpc)
            //verstorbene gegner                :004

            ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));

            npcList = new HashSet<Guid>();
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npcList.Add(new Guid("00000000-0000-0000-0000-000000000003"));

            enemy = new HashSet<Guid>();
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            enemy.Add(new Guid("00000000-0000-0000-0000-000000000005"));


            gameKi = new GameKI(npcList, ownFraction, gameHandler);
            gameKi.enemy = enemy;//enemy würde normalerweise durch die zu testende Funktion selbst aufgerufen werden wird für den test jedoch mit vorgegebenen werten befüllt

            //prüfen ob die listen vor dem funktionsaufruf übereinstimmen
            Assert.AreEqual(ownFraction, gameKi.fraction);
            Assert.AreEqual(npcList, gameKi.npcList);
            Assert.AreEqual(enemy, gameKi.enemy);



            //(oben genannter character löschen)
            List<Character> toRemove = new List<Character>();
            foreach (Character character in modifizierteCharacterList)
            {
                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    toRemove.Add(character);
                }
                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    gameKi.unsuccessfullUsedNpcList.Add(character.getGuid(), 0.1);
                    gameKi.usedNpcList.Add(character.getGuid());
                    toRemove.Add(character);
                }
                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    toRemove.Add(character);
                }
            }

            foreach (Character character in toRemove)
            {
                modifizierteCharacterList.Remove(character);
            }


            state.characters = modifizierteCharacterList;

            Assert.AreEqual(2, gameKi.npcList.Count);



            gameKi.deleteKilledCharacters(state.characters);

            Assert.AreEqual(1, gameKi.fraction.Count);
            Assert.AreEqual(1, gameKi.npcList.Count);
            Assert.AreEqual(1, gameKi.enemy.Count);
            Assert.AreEqual(0, gameKi.usedNpcList.Count);
            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);


        }


















        /*@Jonas Frei*/
        [TestMethod()]
        public void MyTurnTest()
        {


            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);

            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\6personen.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }

            //characterDescription in character übersetzen
            HashSet<Character> characterList = new HashSet<Character>();
            HashSet<Character> modifizierteCharacterList = new HashSet<Character>();
            int counter = 0;
            foreach (CharacterInformation information in characterInformation)
            {
                Character character = new Character(information.characterId, information.name, new HashSet<PropertyEnum>(information.features));
                character.gadgets = new HashSet<Gadget>();
                characterList.Add(character);
                modifizierteCharacterList.Add(character);
                counter++;
            }


            //map init
            Field f = new Field();
            f.state = FieldStateEnum.FREE;

            Field c = new Field();
            c.state = FieldStateEnum.BAR_SEAT;

            Field t = new Field();
            t.state = FieldStateEnum.BAR_TABLE;

            Field o = new Field();
            o.state = FieldStateEnum.FIREPLACE;

            Field r = new Field();
            r.state = FieldStateEnum.ROULETTE_TABLE;

            Field w = new Field();
            w.state = FieldStateEnum.WALL;

            Field x = new Field();
            x.state = FieldStateEnum.FREE;
            x.gadget = new Gadget(GadgetEnum.BOWLER_BLADE, 1);

            Field y = new Field();
            y.state = FieldStateEnum.BAR_TABLE;
            y.gadget = new Gadget(GadgetEnum.COCKTAIL, 1);


            Field s1 = new Field();
            s1.state = FieldStateEnum.SAFE;
            s1.safeIndex = 1;


            Field s2 = new Field();
            s2.state = FieldStateEnum.SAFE;
            s2.safeIndex = 2;


            Field[,] map = {    {f, f, f, x, t, f, t, f, f, w,s2, f, f, w, f },
                                {f, f, f, f, c, f, f, f, f, w, w, w, f, w, f },
                                {f, f, f, y, t, f,s1, f, f, f, f, f, f, w, f } };

            //gameHandler init
            gameHandler.settings = matchconfig;
            gameHandler.characterSettings = characterInformation;
            gameHandler.characters = characterList;
            gameHandler.map = new FieldMap(map);









            //GameKI init
            //own fraction 000,001
            //npc 002,003,004,005


            HashSet<Guid> npc = new HashSet<Guid>();
            npc.Add(new Guid("00000000-0000-0000-0000-000000000002"));
            npc.Add(new Guid("00000000-0000-0000-0000-000000000003"));
            npc.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            npc.Add(new Guid("00000000-0000-0000-0000-000000000005"));

            HashSet<Guid> ownFraction = new HashSet<Guid>();
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000000"));
            ownFraction.Add(new Guid("00000000-0000-0000-0000-000000000001"));


            GameKI gameKi = new GameKI(npc, ownFraction, gameHandler);







            List<BaseOperation> operationFromServer;
            GameStatusMessage gameStatusMessage;

            //Testbeginn:*************************************************************
            Operation result = null;

            //spielbeginn: activ character=000 (gamehandler)(001 existiert nur um opfer zu spielen)
            //koordinaten, ap, bp, der charactere anpassen:

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.hp = 100;

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 0);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(0, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(9, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            State state = new State(1, new FieldMap(map), new HashSet<int>(), characterList, new Point(14, 2), null);



            gameHandler.activeCharacterGuid = new Guid("00000000-0000-0000-0000-000000000000");

            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //was passieren sollte:
            // 1 schritt zum nächstbessten npc (zu 002 bei (0,2)(un auszuspionieren))

            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(0, 1), result.target);




            //"server sendet baseoperation"(ooo jetzt bei (0,1))
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 1);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(0, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), new HashSet<int>(), characterList, new Point(14, 2), null);


            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.MOVEMENT, true, new Point(0, 1)));
            gameStatusMessage = new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false);

            gameKi.enemyDetection(gameStatusMessage);

            gameKi.deleteKilledCharacters(characterList);


            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(0, gameKi.usedNpcList.Count);
            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);




            //******************************************************************************
            //npc(002) macht einen schritt schräg nach oben (steht dann auf feld(1,1)) (base operation vom server)


            //"server sendet baseoperation"(ooo jetzt bei (0,1))
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 1);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), new HashSet<int>(), characterList, new Point(14, 2), null);

            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.MOVEMENT, true, new Point(1, 1)));


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000002"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);


            //was passieren sollte:
            //nichts
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(0, gameKi.usedNpcList.Count);
            Assert.AreEqual(0, gameKi.unsuccessfullUsedNpcList.Count);



            //*****************************************************************************************
            // 000 spioniert 002 aus (ist in reichweite)(0/1)(1/1)


            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //was passieren sollte:
            //spionage

            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(1, 1), result.target);



            //Server sendet BaseOperation baseoperation sagt nein_______________________________


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 1);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), new HashSet<int>(), characterList, new Point(14, 2), null);

            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.SPY_ACTION, false, new Point(1, 1)));


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));

            gameKi.deleteKilledCharacters(characterList);


            //was passieren sollte:
            //nichts
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(0, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);



            // //****************************************************************************
            // 000 spioniert erneut 002 aus (ist in reichweite)

            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //was passieren sollte:
            //spionage

            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(1, 1), result.target);




            //baseoperation sagt ja____________________________________________________________________
            HashSet<int> safeCombinations = new HashSet<int>();
            safeCombinations.Add(1);

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);



            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.SPY_ACTION, true, new Point(1, 1)));


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);


            //was passieren sollte:
            //usednpc list um 1 erhöht
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(1, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);





            //ZUSAMMEFASSUNG: geheimnis für Safe1 ist bekannt, 001 ist direkt nebendem safe-> 001 öffnet 000 sollt in richtung des nächsten npc laufen (003 bei (3,1))
            //um zu prüfen ob 000 wirklich nur zum nächsten npc läuft kommt 001 erst dran wenn 000 versucht hat 003 auszuspionieren


            //000 (0,1) geht in richtung 003 (3,1)*************************************************************************

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 1);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), new HashSet<int>(), characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            //was passieren sollte: 000 (0,1) will auf (1/1) um auf feld(2/1) zu gelangen um von dort aus den character 003 auszuspionieren
            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            // Assert.AreEqual(new Point(1, 1), result.target);





            //gamestatus fom server(bestätigt den lauffvorgang von 000 auf (1/1))__________________________________

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(1, 1);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);



            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.MOVEMENT, true, new Point(1, 1)));


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);





            // 003 wirf nebel auf 000(1/1) _________________________________________________________

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(1, 1);

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);



            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.MOVEMENT, true, new Point(4, 1)));//nur um zu testen wie enemydetection auf 2 eingaben reagiert, im state später irrelevant (=3/1)
            GadgetAction gadgetaction = new GadgetAction(GadgetEnum.FOG_TIN, new Guid("00000000-0000-0000-0000-000000000003"), OperationEnum.GADGET_ACTION, new Point(1, 1));
            operationFromServer.Add(gadgetaction);


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000003"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);


            // was passieren sollte: nichts        
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(1, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);






            //000 ist an der reihe und kann wegen dem nebel nichts tun *****************************************
            f.isFoggy = true;//alle freien felder werden neblig aber egal...

            state = new State(1, new FieldMap(map), new HashSet<int>(), characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            f.isFoggy = false;//nebel löst sich wieder nach der retire aktion+++++++++

            //was pasieren sollte: retire
            Assert.AreEqual(OperationEnum.RETIRE, result.type);



            //gamestatus from server(bestätigt das nichts passiert)

            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.RETIRE, true, new Point(4, 1)));//nur um zu testen wie enemydetection auf 2 eingaben reagiert, im state später irrelevant (=3/1)


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000003"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);


            // was passieren sollte: nichts        
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(1, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);



            //nebel hat sich aufgelöst
            //003 wirft klingenhut auf 000 (wird nicht aktiv getestet.)
            //wichtig: nebenan liegt ein klingenhut + 000 hat nur 50 hp)



            //nebel hat sich aufgelöst: 000 hat 1 Bp ,1 aktionspunkte -> geht v0n 1/1 nach 2/1 (keine heilung in reichweite)
            //-> 000 von 1/1 zu 2/1

            foreach (Character character in characterList)
            {
                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(1, 1);
                    character.hp = 50;//schaden durch klingenhut

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //Erwartete Aktion
            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(2, 1), result.target);
            Movement movement = (Movement)result;
            Assert.AreEqual(new Point(1, 1), movement.from);



            //gamestatus fom server

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(2, 1);
                    character.hp = 50;

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);



            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.MOVEMENT, true, new Point(2, 1)));

            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);





            // hat bewegungspunkte und aktionspunkte: cocktail+klingenhut+spionageziel daneben -> nimmt cocktail auf
            //= test ob in notsituation cocktail bevorzugt wird

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //Erwartete Aktion
            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            Assert.AreEqual(new Point(3, 2), result.target);
            GadgetAction gadgetActionResult = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.COCKTAIL, gadgetActionResult.gadget);






            //gamestatus: erfolgreich aufgenommen

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(2, 1);
                    character.hp = 50;
                    character.gadgets.Add(new Gadget(GadgetEnum.COCKTAIL, 1));

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(3, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);


            operationFromServer = new List<BaseOperation>();
            gadgetActionResult = new GadgetAction(GadgetEnum.COCKTAIL, new Guid("00000000-0000-0000-0000-000000000000"), OperationEnum.GADGET_ACTION, new Point(3, 2));
            operationFromServer.Add(gadgetActionResult);

            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);



            //000 ist immer noch in einer notsituation -> bevorzugt cocktail trinken

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //Erwartete Aktion
            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            Assert.AreEqual(new Point(2, 1), result.target);
            gadgetActionResult = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.COCKTAIL, gadgetActionResult.gadget);


            //umgang bewegung von npcs ausreichend getestet -> keine zugehöhrigen gamestatusnachrichten mehr



            //oo3 bewegt sich sich auf 5/1




            //Character hat genau einen bewegungspunkt und aktionspunkt, schaffft es also nicht bis zu 003 zum spionieren -> nimmt cocktail auf

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(2, 1);
                    character.hp = 100;
                    character.gadgets = new HashSet<Gadget>();

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(14, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//oo3 hat sich bewegt
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            // was passieren sollte: 
            //cocktailaufnahme (character schafft es nicht bis zum verhöhr)
            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            Assert.AreEqual(new Point(3, 2), result.target);
            gadgetActionResult = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.COCKTAIL, gadgetActionResult.gadget);


            //gamestatusmessage: (unwichtig wurde in dieser konstelation schon getestet)



            //läuft zum verhöhr:***************************************
            //(ap=0) durch vorherige aktion

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 0;//wurde zuvor verwendet


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(2, 1);
                    character.hp = 100;
                    character.gadgets = new HashSet<Gadget>();

                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(4, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            // was passieren sollte: 000 von 2/1 zu 3/1 um   zu  spionieren       
            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(3, 1), result.target);


            //-> verhöhr nicht erfolgreich:(wurde schon getestet weshalb die baseoperation weggelassen wurde)
            //nachweis das dem server bewusst ist das ein anderer character näher am safe1 ist.



            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);
                    character.hp = 100;


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(4, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(4, 1), result.target);




            //gamestatusmessage: spionieren erfolgreich:
            safeCombinations.Add(1);// wieder die selbe information
            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);

            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new BaseOperation(OperationEnum.SPY_ACTION, true, new Point(4, 1)));


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);


            //was passieren sollte:
            //usednpc list um 1 erhöht
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);




            //!!!!!!!!!!!!!WICHTIG WER IST näher am Tresor!!!!!!!!!!!!!!
            //prüfen ob 001 zum tresor geht (steht näher an s1) (safe bei 7/2)(si ist direktes nachbarfeld von 001 (000 steht deutlich weiter weg))
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);
                    character.hp = 100;


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(4, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));

            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(6, 2), result.target);
            //wenn active character=001
            //möchte bei von 7/2 auf 9/2 laufen um von dort  auf 10/2 eine spyaction machen (hab gestestet wo er hinläuft und as er da will)
            //startpunkt ist (7/2) und er sollte auf safe1 bei 6/2 zugreifen (information ist vorhanden)
            //der einzige mitspieler ist mehr als 2 felder vom tresor entfernt 000 bei(3,1)


            //bug 2: (DER als erstes behoben werden sollte): 001 springt von 7/2 zu 9/2
            //(dazu muss  Assert.AreEqual(OperationEnum.SPY_ACTION, result.type); auskommentiert werden )







            //Test 2 zum safe öffnen:(alles wie oben-> löschen der used safes)

            //Zustand  000 ist bei 0/0 und damit sehr weit weg
            //         001 ist bei 8/2 und muss nur 1 laufen (zu 7/2)

            gameKi.usedSafes = new HashSet<int>();


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 0);
                    character.hp = 100;


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(8, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(4, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));



            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(7, 2), result.target);


            //nächster schritt zum character
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(0, 0);
                    character.hp = 100;


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(4, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(6, 2), result.target);



            // gameStatusMessage:
            // state.mySafeCombinations.Add(2);//neue safekombination bekannt-> wird aber nicht hinzugefügt da erst noch weitere tests gemacht werden 
            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new Operation(new Guid("00000000-0000-0000-0000-000000000004"), OperationEnum.SPY_ACTION, new Point(6, 2)));



            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000004"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);


            // Assert.AreEqual(2,state.mySafeCombinations.Count);siehe neue safekombination
            Assert.IsTrue(gameKi.usedSafes.Contains(1));
            Assert.IsFalse(gameKi.usedSafes.Contains(2));



            //***********prüfen der gegner erkennungsmethoden:*******************************************
            //dazu teleportieren sich die verleibenden npc vor 000
            //000 wird von fremden (003) verhöhrt -> gegner erkannt
            //000 hat nur aktionspunkte

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(4, 2);// zu 001 für weitere tests hinteleportiert
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);



            //gamestatusnachrich des servers das 000 verhöhrt worden ist

            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new Operation(new Guid("00000000-0000-0000-0000-000000000004"), OperationEnum.SPY_ACTION, new Point(3, 1)));

            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000004"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);

            //was passieren sollte: 1. gegner erkannt + gegner aus npc list löschen
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(3, gameKi.npcList.Count);
            Assert.AreEqual(1, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);





            //********************************************************************************************
            //bonustest: wird auf ap geachtet

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 0;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(4, 2);// zu 001 für weitere tests hinteleportiert
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));

            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            Assert.IsTrue(result.type.Equals(OperationEnum.RETIRE) || result.type.Equals(OperationEnum.MOVEMENT));















            //weiter mit normalen tests:::::::::::::::::::::::::::::::::::::::::::::::::::::::



            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.gadgets.Add(new Gadget(GadgetEnum.GAS_GLOSS, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(4, 2);// zu 001 für weitere tests hinteleportiert
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }





            //000 hat bei der letzten aktion (zufälligerweise) den gasglos erhalten und nutzt diesen gegen 004 ,den neuen feind    
            // der cocktail + bowlerblade in der nähe wurde entfernt
            y.gadget = null;
            x.gadget = null;

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            gadgetaction = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.GAS_GLOSS, gadgetaction.gadget);
            Assert.AreEqual(new Point(4, 2), result.target);





            // für weitere tests wird der gegner aus enemy gelöscht und zu npc hinzugefügt
            gameKi.enemy = new HashSet<Guid>();
            npc.Add(new Guid("00000000-0000-0000-0000-000000000004"));

            //004 ist wieder resozialisiert
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);


            //diesmal übergitbt 004 ein nugget:
            operationFromServer = new List<BaseOperation>();
            operationFromServer.Add(new GadgetAction(GadgetEnum.NUGGET, new Guid("00000000-0000-0000-0000-000000000004"), OperationEnum.GADGET_ACTION, new Point(3, 1)));

            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000004"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);

            //was passieren sollte: 1. gegner erkannt + gegner aus npc list löschen
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(3, gameKi.npcList.Count);
            Assert.AreEqual(1, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);




            //004 wird wieder resozialisiert
            // für weitere tests wird der gegner aus enemy gelöscht und zu npc hinzugefügt
            gameKi.enemy = new HashSet<Guid>();
            npc.Add(new Guid("00000000-0000-0000-0000-000000000004"));

            //004 ist wieder resozialisiert
            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);




            //tests mit chickenfeed


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 10;

                    character.gadgets.Add(new Gadget(GadgetEnum.CHICKEN_FEED, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(4, 2);// zu 001 für weitere tests hinteleportiert
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            /*chickenfeed kann nicht ausgelöst werden da immer wenn ein npc vor einem steht dieser so lange verhöhrt wird bis er informationen preisgibt... sollte sich das ändern kann der test wieder eingefügt werden

            //000 probiert chickenfeed erfolglos
            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            gadgetaction = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.CHICKEN_FEED, gadgetaction.gadget);
            Assert.AreEqual(new Point(4, 2), result.target);



            //gamestatus 

            operationFromServer = new List<BaseOperation>();
            gadgetaction = new GadgetAction(GadgetEnum.CHICKEN_FEED, new Guid("00000000-0000-0000-0000-000000000000"), OperationEnum.GADGET_ACTION, new Point(4, 2));
            gadgetaction.successful = false;
            operationFromServer.Add(gadgetaction);



            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);

            //nichts sollte sich geändert haben

            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);








            //wieder chickenfeed akion
            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            //erfolgreiche gamestatusnachricht

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.CHICKEN_FEED, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(4, 2);// zu 001 für weitere tests hinteleportiert
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            operationFromServer = new List<BaseOperation>();
            gadgetaction = new GadgetAction(GadgetEnum.CHICKEN_FEED, new Guid("00000000-0000-0000-0000-000000000000"), OperationEnum.GADGET_ACTION, new Point(4, 2));
            gadgetaction.successful = true;
            operationFromServer.Add(gadgetaction);



            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);

            //nichts sollte sich geändert haben

            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(4, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);


            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            gadgetaction = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.CHICKEN_FEED, gadgetaction.gadget);
            Assert.AreEqual(new Point(4, 2), result.target);


    */



            //gegner töten
            // (= prüfen ob bp beachtet werden)
            //da oben chickenfeed auskommentiert werden musste werden wird der entsprechende zustand künstlich erzeugt


            gameKi.enemy.Add(new Guid("00000000-0000-0000-0000-000000000004"));
            gameKi.npcList.Remove(new Guid("00000000-0000-0000-0000-000000000004"));


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.GAS_GLOSS, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(1, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                {
                    character.coordinates = new Point(4, 2);// zu 001 für weitere tests hinteleportiert
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }




            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            gadgetaction = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.GAS_GLOSS, gadgetaction.gadget);
            Assert.AreEqual(new Point(4, 2), result.target);



            //gamestatus from server:
            //000 hat 004 getötet

            operationFromServer = new List<BaseOperation>();
            gadgetaction = new GadgetAction(GadgetEnum.GAS_GLOSS, new Guid("00000000-0000-0000-0000-000000000000"), OperationEnum.GADGET_ACTION, new Point(4, 2));
            gadgetaction.successful = true;
            operationFromServer.Add(gadgetaction);




            //löschn des gegners aus der characterlist
            Character delete = new Character(new Guid(), "nix", null);
            foreach (Character c_ in characterList)
            {
                if (c_.characterId.Equals(new Guid("00000000-0000-0000-0000-000000000004")))
                    delete = c_;
            }
            characterList.Remove(delete);



            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            gameKi.deleteKilledCharacters(characterList);

            //prüfen ob toter gegner gelöscht wurde

            Assert.AreEqual(2, gameKi.fraction.Count);
            Assert.AreEqual(3, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);



            // nugget an npc
            //used npc (002 wird zu 000 teleportiert )
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);//7,2
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));


            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            gadgetaction = (GadgetAction)result;
            Assert.AreEqual(GadgetEnum.NUGGET, gadgetaction.gadget);
            Assert.AreEqual(new Point(2, 1), result.target);


            //gamestatus from server
            operationFromServer = new List<BaseOperation>();
            gadgetaction = new GadgetAction(GadgetEnum.NUGGET, new Guid("00000000-0000-0000-0000-000000000000"), OperationEnum.GADGET_ACTION, new Point(2, 1));
            gadgetaction.successful = true;
            operationFromServer.Add(gadgetaction);


            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            Assert.AreEqual(3, gameKi.fraction.Count);
            gameKi.deleteKilledCharacters(characterList);


            Assert.AreEqual(3, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(1, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);















            //bonustest: laufen zum spioniern über 3 felder
            //start für 001 bei 6/2

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(7, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }




            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(8, 2), result.target);





            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(8, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(9, 2), result.target);

            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(9, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(10, 2), result.target);



            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(11, 2), result.target);


            //Gamestatus from Server

            operationFromServer = new List<BaseOperation>();
            Operation operation = new Operation(new Guid("00000000-0000-0000-0000-000000000001"), OperationEnum.SPY_ACTION, new Point(11, 2));
            operation.successful = true;
            operationFromServer.Add(operation);



            gameKi.enemyDetection(new GameStatusMessage(new Guid(), DateTime.Now, new Guid("00000000-0000-0000-0000-000000000000"), operationFromServer, state, false));
            Assert.AreEqual(3, gameKi.fraction.Count);
            gameKi.deleteKilledCharacters(characterList);


            Assert.AreEqual(3, gameKi.fraction.Count);
            Assert.AreEqual(2, gameKi.npcList.Count);
            Assert.AreEqual(0, gameKi.enemy.Count);
            Assert.AreEqual(2, gameKi.usedNpcList.Count);
            Assert.AreEqual(1, gameKi.unsuccessfullUsedNpcList.Count);

            safeCombinations.Add(2);//der letzte server kann angesteuert werden

            //bonustest ende


            //'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            //letzter abschnitt: zum letzten tresor, öffnen, katze
            //***************************************************************************************
            //001 bewegt sich zum tresor:


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(10, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(11, 2), result.target);



            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(11, 2);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(12, 1), result.target);



            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(12, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(11, 0), result.target);




            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(11, 0);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }

            //tresor2 öffnen
            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.SPY_ACTION, result.type);
            Assert.AreEqual(new Point(10, 0), result.target);


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(11, 0);
                    character.gadgets.Add(new Gadget(GadgetEnum.DIAMOND_COLLAR, 1));
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(14, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));


            Assert.AreEqual(OperationEnum.RETIRE, result.type);


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(0, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));
            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);
            Assert.AreEqual(new Point(12, 1), result.target);



            //mit jetpack


            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(11, 0);
                    character.gadgets.Add(new Gadget(GadgetEnum.JETPACK, 1));
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }


            //findet Jetpack->fliegt zur katze (bei 0/2)

            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(0, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));
            Assert.AreEqual(OperationEnum.GADGET_ACTION, result.type);
            Assert.AreEqual(new Point(0, 1), result.target);



            //Katze das Halsband überreichen
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 0;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets.Add(new Gadget(GadgetEnum.NUGGET, 1));


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(0, 1);
                    character.gadgets.Add(new Gadget(GadgetEnum.JETPACK, 0));
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(11, 2);
                }

            }



            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(0, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000001"));
            Assert.AreEqual(OperationEnum.MOVEMENT, result.type);

            Assert.AreEqual(new Point(0, 2), result.target);





            //allerletzter test: observation:
            foreach (Character character in characterList)
            {

                character.mp = 1;
                character.ap = 1;


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000000")))
                {
                    character.coordinates = new Point(3, 1);//3,1
                    character.hp = 100;
                    character.ip = 50;

                    character.gadgets = new HashSet<Gadget>();
                    character.properties.Add(PropertyEnum.OBSERVATION);


                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000001")))
                {
                    character.coordinates = new Point(0, 1);
                    character.gadgets.Add(new Gadget(GadgetEnum.JETPACK, 1));
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000002")))
                {
                    character.coordinates = new Point(2, 1);
                }

                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000003")))
                {
                    character.coordinates = new Point(5, 1);//weggeschoben damit 004 platz hat
                }


                if (character.getGuid().Equals(new Guid("00000000-0000-0000-0000-000000000005")))
                {
                    character.coordinates = new Point(7, 1);
                }

            }


            state = new State(1, new FieldMap(map), safeCombinations, characterList, new Point(0, 2), null);
            result = gameKi.MyTurn(state, new Guid("00000000-0000-0000-0000-000000000000"));

            Assert.AreEqual(OperationEnum.PROPERTY_ACTION, result.type);
            Assert.AreEqual(new Point(5, 1), result.target);

        }




        [TestMethod()]
        public void Test()
        {
            GadgetAction gadgetAction = new GadgetAction(GadgetEnum.COCKTAIL, new Guid(), OperationEnum.GADGET_ACTION, new Point(0, 0));
            GadgetAction result = null;
            BaseOperation operation = gadgetAction;

            if (operation.type.Equals(OperationEnum.GADGET_ACTION))
                result = (GadgetAction)operation;

            Assert.IsTrue(result.gadget.Equals(GadgetEnum.COCKTAIL));

        }

        [TestMethod()]
        public void catchApBpMistakesTest()
        {
            Operation operation = new Operation();
        }
    }
}