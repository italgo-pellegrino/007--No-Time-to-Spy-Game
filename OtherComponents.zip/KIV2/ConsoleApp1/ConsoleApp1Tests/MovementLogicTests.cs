﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;



/*
    Note: Pro Move nachricht 1ne position nach vorne

    */

namespace ConsoleApp1.Controller.Tests
{
    [TestClass()]
    public class MovementLogicTests
    {


        public State state;
        public Character character1;
        public Character character2;
        public Character character3;
        public Character character4;

        public Character activeCharacter;

        [TestInitialize]
        public void TestInitialize()
        {
            string fieldJson = @"{
                'scenario': [
                ['WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL'],
                ['WALL', 'FIREPLACE', 'WALL', 'BAR_TABLE', 'BAR_SEAT', 'FREE', 'WALL'],
                ['WALL', 'FREE', 'FREE', 'FREE', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'BAR_TABLE', 'FREE', 'ROULETTE_TABLE', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'BAR_SEAT', 'FREE', 'WALL', 'FREE', 'FREE', 'WALL'],
                ['WALL', 'FREE', 'FREE', 'FREE', 'FREE', 'SAFE', 'WALL'],
                ['WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL', 'WALL']
                ]
                }";

            Scenario scenario = JsonConvert.DeserializeObject<Scenario>(fieldJson);

            FieldStateEnum[,] map = scenario.getScenario();


            //convert FieldStateEnum[,] into Field[,]

            Field[,] fieldTiles = new Field[map.GetLength(0), map.GetLength(1)];
            for (int y = 0; y < map.GetLength(0); y++)
            {
                for (int x = 0; x < map.GetLength(1); x++)
                {
                    Field f = new Field();
                    f.state = map[y, x];
                    fieldTiles[y, x] = f;
                }
            }

            FieldMap fieldMap = new FieldMap(fieldTiles);

            HashSet<int> mySafeCombinations = new HashSet<int>();
            HashSet<Character> characters = new HashSet<Character>();
            //GadgetEnum.DIAMOND_COLLAR
            this.character1 = new Character(Guid.NewGuid(), "Test Person 1", new HashSet<PropertyEnum>());
            HashSet<Gadget> gadgets1 = new HashSet<Gadget>();

            character1.gadgets = gadgets1;
            character1.setCoordinates(new Point(5, 1));
            character1.setHp(100);
            character1.setMp(3);




            this.character2 = new Character(Guid.NewGuid(), "Test Person 2", new HashSet<PropertyEnum>());
            HashSet<Gadget> gadgets2 = new HashSet<Gadget>();
            character2.gadgets = gadgets2;
            character2.setCoordinates(new Point(3, 5));

            characters.Add(character1);
            characters.Add(character2);
            character1.setHp(100);
            character1.setMp(3);



            Point catCoordinates = new Point(1, 5);


            State state = new State(0, fieldMap, mySafeCombinations, characters, catCoordinates, null);

            this.state = state;

            this.activeCharacter = character1;
        }


        [TestMethod()]
        public void CheckIfAlreadyHaveNecklaceTest()
        {


            Boolean haveNecklace = MovementLogic.CheckIfAlreadyHaveNecklace(this.state);
            Assert.IsFalse(haveNecklace);

            Gadget diamond_collar = new Gadget(GadgetEnum.DIAMOND_COLLAR, 0);
            this.character1.gadgets.Add(diamond_collar);
            haveNecklace = MovementLogic.CheckIfAlreadyHaveNecklace(this.state);
            Assert.IsTrue(haveNecklace);
        }

        [TestMethod()]
        public void GetCharacterWithNecklaceTest()
        {
            //if there is no character with necklace
            Character characterWithNecklace = MovementLogic.GetCharacterWithNecklace(this.state);
            Assert.IsNull(characterWithNecklace);


            //if there is one character with necklace
            Gadget diamond_collar = new Gadget(GadgetEnum.DIAMOND_COLLAR, 0);
            this.character1.gadgets.Add(diamond_collar);
            characterWithNecklace = MovementLogic.GetCharacterWithNecklace(this.state);
            Assert.AreEqual(this.character1, characterWithNecklace);
        }

        [TestMethod()]
        public void MoveCharacterTest()
        {
            bool legalMove = MovementLogic.MoveCharacter(this.state, character1, new Point(1, 2)); //from (5, 1)) to (1, 2)
            Assert.IsFalse(legalMove);

            legalMove = MovementLogic.MoveCharacter(this.state, character1, new Point(3, 2)); //from (5, 1)) to (3, 2)
            Assert.IsTrue(legalMove);
        }

        [TestMethod()]
        public void getAllSafePointsTest()
        {
            List<Point> safePoints = MovementLogic.getAllSafePoints(this.state);
            Point safePoint = safePoints.ElementAt<Point>(0);
            Assert.AreEqual(safePoint, new Point(5, 5));
        }

        [TestMethod()]
        public void getAllSafePointsAvailableTest()
        {
            //add tresor
            this.state.map.map[5, 5].safeIndex = 1;

            //check if you can open any safes
            List<Point> safes = MovementLogic.getAllSafePointsAvailable(this.state);
            Assert.AreEqual(0, safes.Count());


            //add safe key to us
            this.state.mySafeCombinations.Add(1);

            safes = MovementLogic.getAllSafePointsAvailable(this.state);
            Assert.AreEqual(1, safes.Count());
        }

        [TestMethod()]
        public void MoveToNecklaceTest()
        {

            //from (5, 1) to (1,5)

            Gadget diamond_collar = new Gadget(GadgetEnum.DIAMOND_COLLAR, 0);
            this.character1.setMp(3);
            this.character1.gadgets.Add(diamond_collar);
            MovementLogic.MoveToNecklace(this.state, character1);
            Console.WriteLine(character1.coordinates);
        }

        [TestMethod()]
        public void getShortestPathFromPathsTest()
        {
            Point from = new Point(2, 2);

            List<Point> points = new List<Point>();
            points.Add(new Point(4, 2));
            points.Add(new Point(2, 4));


            List<Point> shortestPath = MovementLogic.getShortestPathFromPaths(from, points, this.state);
            Assert.AreEqual(3, shortestPath.Count());


            points = new List<Point>();
            points.Add(new Point(4, 2));
            points.Add(new Point(2, 3));
            shortestPath = MovementLogic.getShortestPathFromPaths(from, points, this.state);
            Assert.AreEqual(2, shortestPath.Count());
        }
    }
}