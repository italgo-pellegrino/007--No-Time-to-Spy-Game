﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ConsoleApp1.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleApp1.model;
using Newtonsoft.Json;
using System.IO;
using ConsoleApp1.model.networking;

namespace ConsoleApp1.Controller.Tests
{
    [TestClass()]
    public class AuswahlphaseKITests
    {
        [TestMethod()]
        public void WahlphaseKITest1()
        {
            Config config = new Config();
            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);
            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\KiTest1.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }


            config.settings = matchconfig;
            config.characterInformation = characterInformation;




            AuswahlphaseKI wahlphase = new AuswahlphaseKI(config, gameHandler);
            ItemChoice itemChoice;
            List<Guid> offeredCharacterIds = new List<Guid>();
            List<GadgetEnum> offeredGadgets = new List<GadgetEnum>();

            //offeredCharacterIds=leer
            //offeredGadgets: hairdryer
            offeredGadgets.Add(GadgetEnum.HAIRDRYER);

            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(GadgetEnum.HAIRDRYER, itemChoice.chosenGadget);
            Assert.IsNull(itemChoice.chosenCharacter);

            //offeredCharacterIds=leer
            //offeredGadgets: hairdryer,pocketlitter
            offeredGadgets.Add(GadgetEnum.POCKET_LITTER);
            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(GadgetEnum.POCKET_LITTER, itemChoice.chosenGadget);
            Assert.IsNull(itemChoice.chosenCharacter);


            //offeredCharacterIds=
            //offeredGadgets: hairdryer,pocketlitter
            offeredCharacterIds.Add(new Guid("00000000-0000-0000-0000-00000000000" + 0));
            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(null, itemChoice.chosenGadget);
            Assert.AreEqual(itemChoice.chosenCharacter, new Guid("00000000-0000-0000-0000-00000000000" + 0));

            //offeredCharacterIds=
            //offeredGadgets: hairdryer,pocketlitter
            offeredCharacterIds.Add(new Guid("00000000-0000-0000-0000-00000000000" + 1));
            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(null, itemChoice.chosenGadget);
            Assert.AreEqual(itemChoice.chosenCharacter, new Guid("00000000-0000-0000-0000-00000000000" + 0));



        }






        [TestMethod()]
        public void AusrüstungsphaseKiTest1()
        {
            Config config = new Config();
            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);
            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\KiTest1.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }


            config.settings = matchconfig;
            config.characterInformation = characterInformation;

            AuswahlphaseKI wahlphase = new AuswahlphaseKI(config, gameHandler);
            EquipmentChoiceMessage message;
            List<Guid> chosenCharacters = new List<Guid>();
            List<GadgetEnum> chosenGadgets = new List<GadgetEnum>();


            //Test1
            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 0));
            chosenGadgets.Add(GadgetEnum.MAGNETIC_WATCH);

            message=wahlphase.AusrüstungsphaseKi(chosenCharacters, chosenGadgets);
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.MAGNETIC_WATCH));
            Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.LASER_COMPACT));






            //Test2     :6 objekte 1 character
            chosenGadgets.Add(GadgetEnum.LASER_COMPACT);
            chosenGadgets.Add(GadgetEnum.GRAPPLE);
            chosenGadgets.Add(GadgetEnum.WIRETAP_WITH_EARPLUGS);
            chosenGadgets.Add(GadgetEnum.MIRROR_OF_WILDERNESS);
            chosenGadgets.Add(GadgetEnum.POCKET_LITTER);
            chosenGadgets.Add(GadgetEnum.BOWLER_BLADE);            

            message = wahlphase.AusrüstungsphaseKi(chosenCharacters, chosenGadgets);
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.MAGNETIC_WATCH));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.LASER_COMPACT));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.GRAPPLE));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.WIRETAP_WITH_EARPLUGS));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.MIRROR_OF_WILDERNESS));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.POCKET_LITTER));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.BOWLER_BLADE));



            //Test3     -Test ob bei 2 gleichberechtigten personen alles gleich verteilt wird
            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 1));
            message = wahlphase.AusrüstungsphaseKi(chosenCharacters, chosenGadgets);
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.MAGNETIC_WATCH));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.LASER_COMPACT));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.GRAPPLE));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.WIRETAP_WITH_EARPLUGS));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.MIRROR_OF_WILDERNESS));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.POCKET_LITTER));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.BOWLER_BLADE));





            //Test4   -Test ob bei 2 gleichberechtigten personen alles gleich verteilt wird
            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 2));
            message = wahlphase.AusrüstungsphaseKi(chosenCharacters, chosenGadgets);
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.MAGNETIC_WATCH));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.LASER_COMPACT));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 2)].Contains(GadgetEnum.GRAPPLE));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.WIRETAP_WITH_EARPLUGS));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.MIRROR_OF_WILDERNESS));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 2)].Contains(GadgetEnum.POCKET_LITTER));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 0)].Contains(GadgetEnum.BOWLER_BLADE));

        }






        //Test mit anderen Characteren:
        [TestMethod()]
        public void WahlphaseKITest2()
        {

            Config config = new Config();
            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
            Assert.AreEqual(matchconfig.catIp, 10);
            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\TestDateiKI.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }


            config.settings = matchconfig;
            config.characterInformation = characterInformation;




            AuswahlphaseKI wahlphase = new AuswahlphaseKI(config, gameHandler);
            ItemChoice itemChoice;
            List<Guid> offeredCharacterIds = new List<Guid>();
            List<GadgetEnum> offeredGadgets = new List<GadgetEnum>();




            //GadgetBewertung test

            offeredGadgets.Add(GadgetEnum.GRAPPLE);//4
            offeredGadgets.Add(GadgetEnum.MAGNETIC_WATCH);//2

            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(GadgetEnum.GRAPPLE, itemChoice.chosenGadget);
            Assert.IsNull(itemChoice.chosenCharacter);


            offeredGadgets.Remove(GadgetEnum.GRAPPLE);
            offeredGadgets.Add(GadgetEnum.MIRROR_OF_WILDERNESS);//1

            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(GadgetEnum.MAGNETIC_WATCH, itemChoice.chosenGadget);
            Assert.IsNull(itemChoice.chosenCharacter);






            //CharacterBewertung test

            offeredGadgets.Remove(GadgetEnum.MIRROR_OF_WILDERNESS);
            offeredGadgets.Remove(GadgetEnum.MAGNETIC_WATCH);
            offeredCharacterIds.Add(new Guid("00000000-0000-0000-0000-00000000000" + 0));//alle Eigenschaften
            offeredCharacterIds.Add(new Guid("00000000-0000-0000-0000-00000000000" + 1));//ohne Eigenschaften

            itemChoice = wahlphase.WahlphaseKI(offeredCharacterIds, offeredGadgets);
            Assert.AreEqual(null, itemChoice.chosenGadget);
            Assert.AreEqual(itemChoice.chosenCharacter, new Guid("00000000-0000-0000-0000-00000000000" + 0));

        }






        [TestMethod()]
        public void AusrüstungsphaseKiTest2()
        {
            Config config = new Config();
            GameHandler gameHandler = new GameHandler();

            Matchconfig matchconfig = JsonConvert.DeserializeObject<Matchconfig>(File.ReadAllText(@"configDateien\KiTestNr1.party"));
        
            CharacterDescription[] characterDescription = JsonConvert.DeserializeObject<CharacterDescription[]>(File.ReadAllText(@"configDateien\TestDateiKI.character"));
            CharacterInformation[] characterInformation = new CharacterInformation[characterDescription.Length];

            for (int i = 0; i < characterDescription.Length; i++)
            {
                characterInformation[i] = new CharacterInformation();

                characterInformation[i].characterId = new Guid("00000000-0000-0000-0000-00000000000" + i);//maximal 10 personen(0-9)
                characterInformation[i].description = characterDescription[i].description;
                characterInformation[i].features = characterDescription[i].features;
                characterInformation[i].gender = characterDescription[i].gender;
                characterInformation[i].name = characterDescription[i].name;

                Assert.IsNotNull(characterDescription[i].features);
                Assert.IsNotNull(characterInformation[i].features);

            }


            config.settings = matchconfig;
            config.characterInformation = characterInformation;

            AuswahlphaseKI wahlphase = new AuswahlphaseKI(config, gameHandler);
            EquipmentChoiceMessage message;
            List<Guid> chosenCharacters = new List<Guid>();
            List<GadgetEnum> chosenGadgets = new List<GadgetEnum>();


            chosenGadgets.Add(GadgetEnum.MOLEDIE);
            chosenGadgets.Add(GadgetEnum.POISON_PILLS);
            chosenGadgets.Add(GadgetEnum.ROCKET_PEN);
            chosenGadgets.Add(GadgetEnum.GAS_GLOSS);
            chosenGadgets.Add(GadgetEnum.MOTHBALL_POUCH);
            chosenGadgets.Add(GadgetEnum.FOG_TIN);
            chosenGadgets.Add(GadgetEnum.JETPACK);
            chosenGadgets.Add(GadgetEnum.CHICKEN_FEED);
            chosenGadgets.Add(GadgetEnum.NUGGET);

            chosenGadgets.Add(GadgetEnum.TECHNICOLOUR_PRISM);
            chosenGadgets.Add(GadgetEnum.HAIRDRYER);

            
            chosenGadgets.Add(GadgetEnum.MAGNETIC_WATCH);
            chosenGadgets.Add(GadgetEnum.LASER_COMPACT);
            chosenGadgets.Add(GadgetEnum.GRAPPLE);
            chosenGadgets.Add(GadgetEnum.WIRETAP_WITH_EARPLUGS);
            chosenGadgets.Add(GadgetEnum.MIRROR_OF_WILDERNESS);
            chosenGadgets.Add(GadgetEnum.POCKET_LITTER);
            chosenGadgets.Add(GadgetEnum.BOWLER_BLADE);


            List<GadgetEnum> gadgetsWithoutProbability;
             gadgetsWithoutProbability = new List<GadgetEnum>();
            gadgetsWithoutProbability.Add(GadgetEnum.MOLEDIE);
            gadgetsWithoutProbability.Add(GadgetEnum.POISON_PILLS);
            gadgetsWithoutProbability.Add(GadgetEnum.ROCKET_PEN);
            gadgetsWithoutProbability.Add(GadgetEnum.GAS_GLOSS);
            gadgetsWithoutProbability.Add(GadgetEnum.MOTHBALL_POUCH);
            gadgetsWithoutProbability.Add(GadgetEnum.FOG_TIN);
            gadgetsWithoutProbability.Add(GadgetEnum.JETPACK);
            gadgetsWithoutProbability.Add(GadgetEnum.CHICKEN_FEED);
            gadgetsWithoutProbability.Add(GadgetEnum.NUGGET);



            List<GadgetEnum> gadgetsWithProbability=new List<GadgetEnum>(); ;
            chosenGadgets.Add(GadgetEnum.MAGNETIC_WATCH);
            chosenGadgets.Add(GadgetEnum.LASER_COMPACT);
            chosenGadgets.Add(GadgetEnum.GRAPPLE);
            chosenGadgets.Add(GadgetEnum.WIRETAP_WITH_EARPLUGS);
            chosenGadgets.Add(GadgetEnum.MIRROR_OF_WILDERNESS);
            chosenGadgets.Add(GadgetEnum.POCKET_LITTER);
            chosenGadgets.Add(GadgetEnum.BOWLER_BLADE);




            
            //Agent0: alles
            //agent1: nichts
            //Agent2: clammyClothes
            //agent3: ConstantclammyClothes
            //agent4: pechvogel

            //Test1: 

            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 1));//nichts
            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 3));//constantCC
           


            message = wahlphase.AusrüstungsphaseKi(chosenCharacters, chosenGadgets);
           
            foreach (GadgetEnum gadget in gadgetsWithoutProbability)
            {
                Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(gadget));
            }

            foreach (GadgetEnum gadget in gadgetsWithoutProbability)
            {
                Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(gadget));
            }

            foreach (GadgetEnum gadget in gadgetsWithProbability)
            {
                Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(gadget));
            }

            foreach (GadgetEnum gadget in gadgetsWithProbability)
            {
                Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(gadget));
            }

            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.HAIRDRYER)
                    || message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(GadgetEnum.HAIRDRYER));

            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.TECHNICOLOUR_PRISM)
                    || message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(GadgetEnum.TECHNICOLOUR_PRISM));




            //test2
            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 2));//clammyClothes
            chosenCharacters.Add(new Guid("00000000-0000-0000-0000-00000000000" + 4));//Pechvogel
            message = wahlphase.AusrüstungsphaseKi(chosenCharacters, chosenGadgets);

            foreach (GadgetEnum gadget in gadgetsWithoutProbability)
            {
                Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(gadget));
            }

            foreach (GadgetEnum gadget in gadgetsWithProbability)
            {
                Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(gadget));
            }



            foreach (GadgetEnum gadget in gadgetsWithoutProbability)
            {
                Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(gadget));
            }

            foreach (GadgetEnum gadget in gadgetsWithProbability)
            {
                Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(gadget));
            }


            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 4)].Contains(GadgetEnum.TECHNICOLOUR_PRISM));
            Assert.IsTrue(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 2)].Contains(GadgetEnum.HAIRDRYER));

            Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.HAIRDRYER)
                    || message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(GadgetEnum.HAIRDRYER));

            Assert.IsFalse(message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 1)].Contains(GadgetEnum.TECHNICOLOUR_PRISM)
                    || message.equipment[new Guid("00000000-0000-0000-0000-00000000000" + 3)].Contains(GadgetEnum.TECHNICOLOUR_PRISM));


        
        }
    }

}

