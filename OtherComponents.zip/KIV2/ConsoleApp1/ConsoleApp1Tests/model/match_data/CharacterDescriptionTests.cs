﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Tests für die CharacterDescription
 * 
 * 
 * @author Jonas Frei
 */
namespace Tests
{
    [TestClass()]
    public class CharacterDescriptionTests
    {
        /*@author Jonas Frei*/
        [TestMethod()]
        public void getFeatureStringTest()
        {
            List<PropertyEnum> propertys = new List<PropertyEnum>();
            

            CharacterInformation character = new CharacterInformation("Testcharacter","Testbeschreibung",GenderEnum.DIVERSE,propertys,new Guid());


            //Test leere feature-list
            Assert.AreEqual("",character.getFeatureString("xxxxxxx")) ;

            //test featureList mit 1 element
            propertys.Add(PropertyEnum.NIMBLENESS);
            Assert.AreEqual("Flinkheit",character.getFeatureString("x") );

            //test featureList mit 1 element
            propertys.Add(PropertyEnum.SLUGGISHNESS);
            Assert.AreEqual("Flinkheit Schwerfälligkeit",character.getFeatureString(" ") );

            //Test featureList mit 3 elementen         
            propertys.Add(PropertyEnum.PONDEROUSNESS);
            Assert.AreEqual("Flinkheit, Schwerfälligkeit, Behäbigkeit", character.getFeatureString(", ") );


            //Test featureList mit 3 elementen
            propertys.Add(PropertyEnum.SPRYNESS);
            propertys.Add(PropertyEnum.AGILITY);
            propertys.Add(PropertyEnum.LUCKY_DEVIL);
            propertys.Add(PropertyEnum.JINX);
            propertys.Add(PropertyEnum.CLAMMY_CLOTHES);
            propertys.Add(PropertyEnum.CONSTANT_CLAMMY_CLOTHES);
            propertys.Add(PropertyEnum.ROBUST_STOMACH);
            propertys.Add(PropertyEnum.TOUGHNESS);
            propertys.Add(PropertyEnum.BABYSITTER);
            propertys.Add(PropertyEnum.HONEY_TRAP);
            propertys.Add(PropertyEnum.BANG_AND_BURN);
            propertys.Add(PropertyEnum.FLAPS_AND_SEALS);
            propertys.Add(PropertyEnum.TRADECRAFT);
            propertys.Add(PropertyEnum.OBSERVATION);
           
            Assert.AreEqual("Flinkheit, Schwerfälligkeit, Behäbigkeit, Behändigkeit, Agilität, Glückspilz, Pechvogel, Klamme Klamotten, Konstant Klamme Klamotten, Robuster Magen, Zähigkeit, Babysitter, Honey Trap, Bang and Burn, Flaps and Seals, Tradecraft, Observation", character.getFeatureString(", "));


        }
    }
}
