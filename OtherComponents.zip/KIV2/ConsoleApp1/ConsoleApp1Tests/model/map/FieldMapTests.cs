﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tests
{
    [TestClass()]
    public class FieldMapTests
    {
        [TestMethod()]
        public void getPointsInBetweenTest()
        {
            //Point(X,Y)
            HashSet<Point> ergebnis;
            FieldMap map = new FieldMap(new Field[10, 10]);


            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(1, 1));
            Assert.AreEqual(0, ergebnis.Count);

            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(0, 1));
            Assert.AreEqual(0, ergebnis.Count);

            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(1, 0));
            Assert.AreEqual(0, ergebnis.Count);


            List<Point> loesung;

            loesung = new List<Point>();
            loesung.Add(new Point(1, 1));

            //(nur durch feld (1,1))
            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(2, 2));
            Assert.AreEqual(loesung.Count, ergebnis.Count);

            foreach (Point point in ergebnis)
            {
                Assert.IsTrue(loesung.Contains(point));//Aus unbekannten gründen liefert contains auf Hashmam nicht das richtige ergebnis zurück 
            }



            loesung = new List<Point>();
            loesung.Add(new Point(1, 1));
            loesung.Add(new Point(2, 2));
            loesung.Add(new Point(3, 3));
            loesung.Add(new Point(4, 4));

            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(5, 5));
            containsOnly(loesung,ergebnis);



            loesung = new List<Point>();
            loesung.Add(new Point(1, 0));
            loesung.Add(new Point(2, 0));
            loesung.Add(new Point(3, 0));
            loesung.Add(new Point(4, 0));

            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(5, 0));
            containsOnly(loesung, ergebnis);



            loesung = new List<Point>();
            loesung.Add(new Point(0, 1));
            loesung.Add(new Point(1, 1));
            
            ergebnis = map.getPointsInBetween(new Point(0, 0), new Point(1, 2));
            containsOnly(loesung, ergebnis);



            loesung = new List<Point>();
            loesung.Add(new Point(2, 0));
            loesung.Add(new Point(1, 1));           

            ergebnis = map.getPointsInBetween(new Point(0, 1), new Point(3, 0));
            containsOnly(loesung, ergebnis);


            loesung = new List<Point>();
            loesung.Add(new Point(2, 0));
            loesung.Add(new Point(1, 1));

            ergebnis = map.getPointsInBetween(new Point(3, 0), new Point(0, 1));
            containsOnly(loesung, ergebnis);


            loesung = new List<Point>();
            loesung.Add(new Point(0, 1));
            loesung.Add(new Point(1, 1));

            ergebnis = map.getPointsInBetween(new Point(1, 2),new Point(0, 0) );
            containsOnly(loesung, ergebnis);

        }




        /*
         * @author Akin Kula
         * 
        */

        [TestMethod()]
        public void testSightLine()
        {
            string fieldJson = @"{
                'scenario': [
                    ['WALL', 'WALL',      'WALL', 'WALL',           'WALL',     'WALL', 'WALL'],
                    ['WALL', 'FIREPLACE', 'WALL', 'BAR_TABLE',      'BAR_SEAT', 'FREE', 'WALL'],
                    ['WALL', 'FREE',      'FREE', 'FREE',           'FREE',     'FREE', 'WALL'],
                    ['WALL', 'BAR_TABLE', 'FREE', 'ROULETTE_TABLE', 'FREE',     'FREE', 'WALL'],
                    ['WALL', 'BAR_SEAT',  'FREE', 'WALL',           'FREE',     'FREE', 'WALL'],
                    ['WALL', 'FREE',      'FREE', 'FREE',           'BAR_TABLE',     'BAR_SEAT', 'WALL'],
                    ['WALL', 'SAFE',      'FREE', 'FREE',           'WALL',     'WALL', 'WALL'],
                    ['WALL', 'WALL',      'WALL', 'FREE',           'BAR_SEAT',     'BAR_TABLE', 'WALL'],
                    ['WALL', 'SAFE',      'FREE', 'FREE',           'FREE',     'SAFE', 'WALL'],
                    ['WALL', 'WALL',      'ROULETTE_TABLE', 'FREE',           'FREE',     'SAFE', 'WALL'],
                    ['WALL', 'WALL',      'WALL', 'WALL',           'WALL',     'WALL', 'WALL']
                ]
            }";

            Scenario scenario = JsonConvert.DeserializeObject<Scenario>(fieldJson);

            FieldStateEnum[,] map = scenario.getScenario();


            //convert FieldStateEnum[,] into Field[,]

            Field[,] fieldTiles = new Field[map.GetLength(0), map.GetLength(1)];
            for (int y = 0; y < map.GetLength(0); y++)
            {
                for (int x = 0; x < map.GetLength(1); x++)
                {
                    Field f = new Field();
                    f.state = map[y, x];
                    fieldTiles[y, x] = f;
                }
            }



            FieldMap fieldMap = new FieldMap(fieldTiles);

            HashSet<Point> ergebnis = fieldMap.getPointsInBetween(new Point(2, 3), new Point(2, 8));
            List<Point> loesung = new List<Point>();
            loesung.Add(new Point(2, 4));
            loesung.Add(new Point(2, 5));
            loesung.Add(new Point(2, 6));
            loesung.Add(new Point(2, 7));

            containsOnly(loesung, ergebnis);

        }

        private void containsOnly(List<Point>loesung, HashSet<Point>ergebnis)
        {
            Assert.AreEqual(loesung.Count, ergebnis.Count);

            foreach (Point point in ergebnis)
            {
                Assert.IsTrue(loesung.Contains(point));

            }
        }

    }

    


}