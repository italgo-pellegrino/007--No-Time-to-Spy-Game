package de.uulm.team0015.server.model.DataTypes.ServerOnly;

import de.uulm.team0015.server.model.Enumerations.GenderEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;

import java.util.List;

/**
 * Class for informations of a character needed for character configuration purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class CharacterDescription {
    private String name;
    private String description;
    private GenderEnum gender;
    private List<PropertyEnum> features;

    /**
     * Constructor of the class CharacterDescription.
     *
     * @param name        The name of the character.
     * @param description The description of the character.
     * @param gender      The gender of the character.
     * @param features    The properties of the character.
     */
    public CharacterDescription(String name, String description, GenderEnum gender, List<PropertyEnum> features) {
        this.name = name;
        this.description = description;
        this.gender = gender;
        this.features = features;
    }

    /**
     * Getter for name.
     *
     * @return The name of the character.
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for name.
     *
     * @param name The name of the character.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for description.
     *
     * @return The description of the character.
     */
    public String getDescription() {
        return description;
    }

    /**
     * Setter for description.
     *
     * @param description The description of the character.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Getter for gender.
     *
     * @return The gender of the character.
     */
    public GenderEnum getGender() {
        return gender;
    }

    /**
     * Setter for gender.
     *
     * @param gender The gender of the character.
     */
    public void setGender(GenderEnum gender) {
        this.gender = gender;
    }

    /**
     * Getter for features.
     *
     * @return The list of features of the character.
     */
    public List<PropertyEnum> getFeatures() {
        return features;
    }

    /**
     * Setter for features.
     *
     * @param features The list of features of the character.
     */
    public void setFeatures(List<PropertyEnum> features) {
        this.features = features;
    }

    /**
     * toString method of the class CharacterDescription.
     *
     * @return The values of CharacterDescription as a String.
     */
    @Override
    public String toString() {
        return "name: " + name +
                "\n" +
                "description: " + description +
                "\n" +
                "gender: " + gender +
                "\n" +
                "features: " + features;
    }
}
