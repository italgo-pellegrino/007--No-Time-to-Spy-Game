package de.uulm.team0015.server.controller.NetworkLogic;

import de.uulm.team0015.server.controller.ServerLogger;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

import javax.websocket.RemoteEndpoint;

/**
 * This class represents an Emitter.
 * To write a String use sendMessage(String jsonMessage).
 * If there is a (long) message which needs more time any future messages will be enqueued by using a ReentrantLock.
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 * @see SimpleClient
 */
public class SimpleClientEmitter {
    private final static Logger LOGGER = Logger.getLogger(SimpleClientEmitter.class.getName());
    private RemoteEndpoint.Basic remote;
    private SimpleClient client;
    private ReentrantLock lock = new ReentrantLock();

    /**
     * Constructor of the class SimpleClientEmitter
     *
     * @param client The simpleClient.
     * @param output The output writer.
     */
    public SimpleClientEmitter(SimpleClient client, RemoteEndpoint.Basic remote) {
        ServerLogger.addHandler(LOGGER);

        this.remote = remote;
        this.client = client;
    }

    /**
     * Send a String to the Client at the other side of the output.
     * This method is Thread safe due to the usage of a ReentrantLock.
     *
     * @param jsonMessage The String that will be send.
     */
    public void sendMessage(String jsonMessage) {
        lock.lock();
        try {
            try {
                remote.sendText(jsonMessage);
                LOGGER.fine("Send to: " + client.getSession().getId() + " Message: " + jsonMessage);
            } catch (Exception e) {
                LOGGER.warning(e.toString());
            }
        } finally {
            lock.unlock();
        }

    }


    /**
     * Getter for isDisconnectedByServer from the SimpleClient class.
     *
     * @return if the client is disconnected by the server.
     */
    boolean isDisconnectedByServer() {
        return client.isDisconnectedByServer();
    }

    /**
     * Setter for setDisconnectedByServer from the SimpleClient class.
     *
     * @param disconnectedByServer if the client is disconnected by the server.
     */
    void setDisconnectedByServer(boolean disconnectedByServer) {
        client.setDisconnectedByServer(disconnectedByServer);
    }
}
