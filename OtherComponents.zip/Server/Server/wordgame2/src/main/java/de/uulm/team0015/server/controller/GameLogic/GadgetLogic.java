package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.GamePhaseState;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Gadgets.WireTapWithEarplugs;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;

import java.util.HashSet;
import java.util.Set;

/**
 * Class to handle the game logic actions for the gadgets.
 *
 * @author Alexander Preiß, Marcel Rötzer
 * @version 1.0
 */
public class GadgetLogic {

    /**
     * Method for when a character uses the gadget hairdryer.
     *
     * @param character  Character that uses the Gadget
     * @param target     Coordinates of the target.
     * @param map        Current FieldMap.
     * @param characters Set of all characters currently on the map.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean hairdryer(Character character, Point target, FieldMap map, Set<Character> characters) throws InvalidTargetException {
        if (character.getCoordinates().equals(target)) {
            character.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        } else {
            map.validateIsNeighbour(character.getCoordinates(), target);
            map.validateFieldHasCharacter(target, characters);
            map.getCharacterOnField(target, characters).removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        }
        return true;
    }

    /**
     * Method for when a character uses the gadget moledie.
     *
     * @param character   Character that uses the gadget.
     * @param target      Coordinates of the target.
     * @param map         Current FieldMap.
     * @param characters  Set of all characters on the map.
     * @param matchconfig The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException    If the character targets an invalid field.
     * @throws TargetOutOfSightException If the character targets a field which is out of sight.
     * @throws TargetOutOfRangeException If the character targets a field which is out of range.
     */
    public static boolean moledie(Character character, Point target, FieldMap map, Set<Character> characters, Matchconfig matchconfig) throws InvalidTargetException, TargetOutOfSightException, TargetOutOfRangeException {
        map.validateIsInSight(character.getCoordinates(), target);
        map.validateIsInRange(character.getCoordinates(), target, matchconfig.getMoledieRange());
        map.getField(target).validateIsNotState(FieldStateEnum.WALL);

        if (map.fieldHasCharacter(target, characters)) {
            map.getCharacterOnField(target, characters).addGadget(GadgetEnum.MOLEDIE);
        } else {
            if (map.neighbourHasCharacter(target, characters)) {
                Character.getRandomCharacter(map.getNeighbourCharacters(target, characters)).addGadget(GadgetEnum.MOLEDIE);
            } else {
                Point nearestCharacter = character.getCoordinates();
                int minRange = 1000;
                for (Character character1 : characters) {
                    if (map.getRange(target, character1.getCoordinates()) < minRange && !character.getCoordinates().equals(character1.getCoordinates())) {
                        nearestCharacter = character1.getCoordinates();
                        minRange = map.getRange(target, character1.getCoordinates());
                    }
                }
                map.getCharacterOnField(nearestCharacter, characters).addGadget(GadgetEnum.MOLEDIE);
            }
        }
        return true;
    }

    /**
     * Method for when a character uses the gadget technicolorPrism.
     *
     * @param character Character that uses the gadget.
     * @param target    Coordinates of the target.
     * @param map       Current FieldMap.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean technicolorPrism(Character character, Point target, FieldMap map) throws InvalidTargetException {
        map.validateIsNeighbourOfState(character.getCoordinates(), target, FieldStateEnum.ROULETTE_TABLE);

        map.getField(target).setInverted(!map.getField(target).isInverted());
        return true;
    }

    /**
     * Method for when a character uses the gadget bowlerBlade.
     *
     * @param character         Character that uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws TargetBlockedException    If the character targets a field which is blocked.
     * @throws InvalidTargetException    If the character targets an invalid field.
     * @throws TargetOutOfSightException If the character targets a field which is out of sight.
     * @throws TargetOutOfRangeException If the character targets a field which is out of range.
     */
    public static boolean bowlerBlade(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) throws TargetBlockedException, InvalidTargetException, TargetOutOfSightException, TargetOutOfRangeException {
        map.validateIsInSight(character.getCoordinates(), target);
        map.validateIsNotBlocked(character.getCoordinates(), target, characters);
        map.validateIsInRange(character.getCoordinates(), target, matchconfig.getBowlerBladeRange());
        map.validateFieldHasCharacter(target, characters);

        // If target has honey trap
        if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.HONEY_TRAP)) {
            // Get all other possible targets
            Set<Character> possibleTargets = new HashSet<>();
            for (Character character1 : characters) {
                if (map.isInSight(character.getCoordinates(), character1.getCoordinates())
                        && !map.isBlocked(character.getCoordinates(), character1.getCoordinates(), characters)
                        && map.isInRange(character.getCoordinates(), character1.getCoordinates(), matchconfig.getBowlerBladeRange())
                        && !character1.getCoordinates().equals(map.getCharacterOnField(target, characters).getCoordinates())
                        && !character1.getCoordinates().equals(character.getCoordinates())) {
                    possibleTargets.add(character1);
                }
            }
            // Calculate honey trap success chance
            double chance = matchconfig.getHoneyTrapSuccessChance();
            if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CLAMMY_CLOTHES) || map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                chance = chance / 2;
            }
            // If another target exists
            if (!possibleTargets.isEmpty()) {
                // If honey trap success
                if (Math.random() < chance) {
                    // New target
                    Point randomTarget = Character.getRandomCharacter(possibleTargets).getCoordinates();
                    return bowlerBladeLogic(character, randomTarget, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                }
                // If honey trap failed
                else {
                    // If second chance
                    if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.TRADECRAFT) && !map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.MOLEDIE)) {
                        // Success
                        if (Math.random() < chance) {
                            // new target
                            Point randomTarget = Character.getRandomCharacter(possibleTargets).getCoordinates();
                            return bowlerBladeLogic(character, randomTarget, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                        }
                        // Failed
                        else {
                            // Old target
                            return bowlerBladeLogic(character, target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                        }
                    }
                    // No second chance
                    else {
                        // Old target
                        return bowlerBladeLogic(character, target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                    }
                }
            }
            // If no other target is possible
            else {
                return bowlerBladeLogic(character, target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
            }
        }
        // If target has no honey trap
        else {
            return bowlerBladeLogic(character, target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
        }
    }

    /**
     * Sub method of bowlerBlade to check if target has magneticWatch and to calculate the damage and if the bowlerBlade hits.
     *
     * @param character         Character that uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     */
    private static boolean bowlerBladeLogic(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) {
        // If target has magnetic watch
        if (map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.MAGNETIC_WATCH)) {
            bowlerBladeField(target, map, characters);
            return false;
        }
        // If target has no magnetic watch
        else {
            // Calculate bowler blade hit chance
            double chance = matchconfig.getBowlerBladeHitChance();
            if (character.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || character.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                chance = chance / 2;
            }
            // If hit
            if (Math.random() < chance) {
                return bowlerBladeBabysitter(target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
            }
            // If no hit
            else {
                // If second chance
                if (character.hasProperty(PropertyEnum.TRADECRAFT) && !character.hasGadget(GadgetEnum.MOLEDIE)) {
                    // If success
                    if (Math.random() < chance) {
                        return bowlerBladeBabysitter(target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                    }
                    // If failed
                    else {
                        bowlerBladeField(target, map, characters);
                        return false;
                    }
                }
                // If no second chance
                else {
                    bowlerBladeField(target, map, characters);
                    return false;
                }
            }
        }
    }

    /**
     * Sub method of bowlerBlade to check if target neighbour has babysitter.
     *
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     */
    private static boolean bowlerBladeBabysitter(Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) {
        // If babysitter
        if (map.checkBabysitter(map.getCharacterOnField(target, characters), characters, charactersPlayer1, charactersPlayer2)) {
            // For all babysitters in range
            for (Character babysitter : map.getBabysitters(map.getCharacterOnField(target, characters), characters, charactersPlayer1, charactersPlayer2)) {
                double babysitterSuccessChance = matchconfig.getBabysitterSuccessChance();
                // Check if babysitter has clammy clothes or constant clammy clothes
                if (babysitter.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || babysitter.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                    // Set new chance
                    babysitterSuccessChance = babysitterSuccessChance / 2;
                }
                // First chance
                if (Math.random() < babysitterSuccessChance) {
                    // Success
                    bowlerBladeField(target, map, characters);
                    return false;
                }
                // Check if babysitter has second chance
                else if (babysitter.hasProperty(PropertyEnum.TRADECRAFT) && !babysitter.hasGadget(GadgetEnum.MOLEDIE)) {
                    // second chance
                    if (Math.random() < babysitterSuccessChance) {
                        // success
                        bowlerBladeField(target, map, characters);
                        return false;
                    }
                }
            }
        }
        map.getCharacterOnField(target, characters).takeDamage(matchconfig.getBowlerBladeDamage(), map, characters, charactersPlayer1, charactersPlayer2);
        bowlerBladeField(target, map, characters);
        return true;
    }

    /**
     * Sub method of bowlerBladeLogic to calculate a random field for the bowlerBlade.
     *
     * @param target     Coordinates of the target.
     * @param map        Current FieldMap.
     * @param characters Set of all characters on the map.
     */
    private static void bowlerBladeField(Point target, FieldMap map, Set<Character> characters) {
        // If a free neighbour field exists
        if (map.getRandomFreeNeighbour(target, characters) != null) {
            map.getField(map.getRandomFreeNeighbour(target, characters)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE, 1));
        }
        // If no free neighbour field exists
        else {
            boolean found = false;
            for (Point point : map.getNeighbours(target)) {
                Point neighbour = bowlerBladeNeighbour(point, map, characters);
                if (neighbour != null) {
                    map.getField(neighbour).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE, 1));
                    found = true;
                    break;
                }
            }
            if (!found) {
                map.getCharacterOnField(target, characters).addGadget(GadgetEnum.BOWLER_BLADE);
            }
        }
    }

    /**
     * Sub method of bowlerBladeField to calculate a neighbour of a neighbour.
     *
     * @param point      Coordinates of the field.
     * @param map        Current FieldMap.
     * @param characters Set of all characters on the map.
     * @return A free neighbour point.
     */
    private static Point bowlerBladeNeighbour(Point point, FieldMap map, Set<Character> characters) {
        for (Point neighbour : map.getNeighbours(point)) {
            if (map.getRandomFreeNeighbour(neighbour, characters) != null) {
                return map.getRandomFreeNeighbour(neighbour, characters);
            }
        }
        return null;
    }

    /**
     * Method for when a character uses the gadget poisonPills.
     *
     * @param character  Character that uses the gadget.
     * @param target     Coordinates of the target.
     * @param map        Current FieldMap.
     * @param characters Set of all characters on the map.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets a field with the wrong gadget.
     */
    public static boolean poisonPills(Character character, Point target, FieldMap map, Set<Character> characters) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        try {
            map.validateFieldHasCharacter(target, characters);
            map.getCharacterOnField(target, characters).validateHasGadget(GadgetEnum.COCKTAIL);
        } catch (InvalidGadgetException | InvalidTargetException exception) {
            map.getField(target).validateHasGadgetOfType(GadgetEnum.COCKTAIL);
        }

        if (map.fieldHasCharacter(target, characters)) {
            map.getCharacterOnField(target, characters).getCocktail().poison();
        } else if (map.getField(target).hasGadgetOfType(GadgetEnum.COCKTAIL)) {
            map.getField(target).getCocktail().poison();
        }
        return true;
    }

    /**
     * Method for when a character uses the gadget laserCompact.
     *
     * @param character   Character that uses the gadget.
     * @param target      Coordinates of the target.
     * @param map         Current FieldMap.
     * @param characters  Set of all characters on the map.
     * @param matchconfig The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException    If the character targets a field with the wrong gadget.
     * @throws TargetOutOfSightException If the character targets a field which is out of sight.
     */
    public static boolean laserCompact(Character character, Point target, FieldMap map, Set<Character> characters, Matchconfig matchconfig) throws InvalidTargetException, TargetOutOfSightException {
        map.validateIsInSight(character.getCoordinates(), target);
        try {
            map.validateFieldHasCharacter(target, characters);
            map.getCharacterOnField(target, characters).validateHasGadget(GadgetEnum.COCKTAIL);
        } catch (InvalidGadgetException | InvalidTargetException exception) {
            map.getField(target).validateHasGadgetOfType(GadgetEnum.COCKTAIL);
        }

        // Calculate laser compact success chance
        double chance = matchconfig.getLaserCompactHitChance();
        if (character.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || character.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
            chance = chance / 2;
        }
        // Hit character with cocktail
        if (map.fieldHasCharacter(target, characters) && map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.COCKTAIL)) {
            // If hit
            if (Math.random() < chance) {
                map.getCharacterOnField(target, characters).removeGadget(GadgetEnum.COCKTAIL);
                return true;
            }
            // No hit
            else {
                // If second chance
                if (character.hasProperty(PropertyEnum.TRADECRAFT) && !character.hasGadget(GadgetEnum.MOLEDIE)) {
                    // Hit
                    if (Math.random() < chance) {
                        map.getCharacterOnField(target, characters).removeGadget(GadgetEnum.COCKTAIL);
                        return true;
                    }
                    // No hit
                    else {
                        return false;
                    }
                }
                // If no second chance
                else {
                    return false;
                }
            }
        }
        // Hit cocktail on field
        if (map.getField(target).hasGadgetOfType(GadgetEnum.COCKTAIL)) {
            // If hit
            if (Math.random() < chance) {
                map.getField(target).setGadget(null);
                return true;
            }
            // If no hit
            else {
                // If second chance
                if (character.hasProperty(PropertyEnum.TRADECRAFT) && !character.hasGadget(GadgetEnum.MOLEDIE)) {
                    // If hit
                    if (Math.random() < chance) {
                        map.getField(target).setGadget(null);
                        return true;
                    }
                    // If no hit
                    else {
                        return false;
                    }
                }
                // No second chance
                else {
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * Method for when a character uses the gadget rocketPen.
     *
     * @param character         Character that uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        Set of all characters on the map.
     * @param matchconfig       The match config.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @return True if the gadget was used successfully, false if not.
     * @throws TargetOutOfSightException If the character targets a field which is out of range.
     * @throws InvalidTargetException    If the character targets an invalid field.
     */
    public static boolean rocketPen(Character character, Point target, FieldMap map, Set<Character> characters, Matchconfig matchconfig, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) throws TargetOutOfSightException, InvalidTargetException {
        map.validateIsInSight(character.getCoordinates(), target);

        // Target field
        if (map.fieldHasCharacter(target, characters)) {
            map.getCharacterOnField(target, characters).takeDamage(matchconfig.getRocketPenDamage(), map, characters, charactersPlayer1, charactersPlayer2);
        } else if (map.getField(target).isState(FieldStateEnum.WALL)) {
            map.getField(target).updateFieldState(FieldStateEnum.FREE);
        }
        // Neighbour fields
        for (Point neighbour : map.getNeighbours(target)) {
            if (map.fieldHasCharacter(neighbour, characters)) {
                map.getCharacterOnField(neighbour, characters).takeDamage(matchconfig.getRocketPenDamage(), map, characters, charactersPlayer1, charactersPlayer2);
            } else if (map.getField(neighbour).isState(FieldStateEnum.WALL)) {
                map.getField(neighbour).updateFieldState(FieldStateEnum.FREE);
            }
        }
        return true;
    }

    /**
     * Method for when a character uses the gadget gasGloss.
     *
     * @param character         Character that uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If a character targets a invalid field.
     */
    public static boolean gasGloss(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        map.validateFieldHasCharacter(target, characters);

        // Honey trap
        if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.HONEY_TRAP)) {
            // Calculate honey trap success chance
            double chance = matchconfig.getHoneyTrapSuccessChance();
            if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CLAMMY_CLOTHES) || map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                chance = chance / 2;
            }
            // If another target exists
            if (map.getNeighbourCharacterCount(character.getCoordinates(), characters) > 1) {
                // If honey trap success
                if (Math.random() < chance) {
                    Set<Character> targets = map.getNeighbourCharacters(character.getCoordinates(), characters);
                    targets.remove(map.getCharacterOnField(target, characters));

                    Point randomTarget = Character.getRandomCharacter(targets).getCoordinates();
                    // New target
                    return gasGlossLogic(randomTarget, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                }
                // If honey trap failed
                else {
                    // If second chance
                    if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.TRADECRAFT) && !map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.MOLEDIE)) {
                        // Success
                        if (Math.random() < chance) {
                            Set<Character> targets = map.getNeighbourCharacters(character.getCoordinates(), characters);
                            targets.remove(map.getCharacterOnField(target, characters));
                            // new target
                            Point randomTarget = Character.getRandomCharacter(targets).getCoordinates();
                            return gasGlossLogic(randomTarget, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                        }
                        // Failed
                        else {
                            // Old target
                            return gasGlossLogic(target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                        }
                    }
                    // No second chance
                    else {
                        // Old target
                        return gasGlossLogic(target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                    }
                }
            }
            // No new target
            else {
                return gasGlossLogic(target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
            }
        }
        // No honey trap
        else {
            return gasGlossLogic(target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
        }
    }

    /**
     * Sub method for logic of gasGloss.
     *
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     */
    private static boolean gasGlossLogic(Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) {
        // If babysitter
        if (map.checkBabysitter(map.getCharacterOnField(target, characters), characters, charactersPlayer1, charactersPlayer2)) {
            // For all babysitters in range
            for (Character babysitter : map.getBabysitters(map.getCharacterOnField(target, characters), characters, charactersPlayer1, charactersPlayer2)) {
                double babysitterSuccessChance = matchconfig.getBabysitterSuccessChance();
                // Check if babysitter has clammy clothes or constant clammy clothes
                if (babysitter.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || babysitter.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                    // Set new chance
                    babysitterSuccessChance = babysitterSuccessChance / 2;
                }
                // First chance
                if (Math.random() < babysitterSuccessChance) {
                    // Success
                    return false;
                }
                // Check if babysitter has second chance
                else if (babysitter.hasProperty(PropertyEnum.TRADECRAFT) && !babysitter.hasGadget(GadgetEnum.MOLEDIE)) {
                    // Second chance
                    if (Math.random() < babysitterSuccessChance) {
                        // Success
                        return false;
                    }
                }
            }
        }
        // No babysitter
        map.getCharacterOnField(target, characters).takeDamage(matchconfig.getGasGlossDamage(), map, characters, charactersPlayer1, charactersPlayer2);
        return true;
    }

    /**
     * Method for when a character uses the gadget mothballPouch.
     *
     * @param character         Character who uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        Set of all characters on the map.
     * @param matchconfig       The match config.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException    If the character targets an invalid field.
     * @throws TargetOutOfSightException If the character targets a field which is out of sight.
     * @throws TargetOutOfRangeException If the character targets a field which is out of range.
     */
    public static boolean mothballPouch(Character character, Point target, FieldMap map, Set<Character> characters, Matchconfig matchconfig, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) throws InvalidTargetException, TargetOutOfSightException, TargetOutOfRangeException {
        map.getField(target).validateIsState(FieldStateEnum.FIREPLACE);
        map.validateIsInSight(character.getCoordinates(), target);
        map.validateIsInRange(character.getCoordinates(), target, matchconfig.getMothballPouchRange());

        for (Point neighbour : map.getNeighbours(target)) {
            if (map.fieldHasCharacter(neighbour, characters)) {
                map.getCharacterOnField(neighbour, characters).takeDamage(matchconfig.getMothballPouchDamage(), map, characters, charactersPlayer1, charactersPlayer2);
            }
        }
        return true;
    }

    /**
     * Method for when a character uses the gadget fogTin.
     *
     * @param character   Character who uses the gadget.
     * @param target      Coordinates of the target.
     * @param map         Current FieldMap.
     * @param matchconfig The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException    If the character targets an invalid field.
     * @throws TargetOutOfSightException If the character targets a field which is out of sight.
     * @throws TargetOutOfRangeException If the character targets a field which is out of range.
     */
    public static boolean fogTin(Character character, Point target, FieldMap map, Matchconfig matchconfig) throws InvalidTargetException, TargetOutOfRangeException, TargetOutOfSightException {
        map.validateIsInRange(character.getCoordinates(), target, matchconfig.getFogTinRange());
        map.validateIsInSight(character.getCoordinates(), target);
        map.getField(target).validateIsNotState(FieldStateEnum.WALL);

        map.getField(target).setFoggy(true);
        for (Point neighbours : map.getNeighbours(target)) {
            map.getField(neighbours).setFoggy(true);
        }
        GamePhaseState.foggyFieldCount = 3;
        return true;

    }

    /**
     * Method for when a character uses the gadget grapple.
     *
     * @param character   Character who uses the gadget.
     * @param target      Coordinates of the target.
     * @param map         Current FieldMap.
     * @param matchconfig The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException    If the character targets a field with the wrong gadget.
     * @throws TargetOutOfSightException If the character targets a field which is out of sight.
     * @throws TargetOutOfRangeException If the character targets a field which is out of range.
     */
    public static boolean grapple(Character character, Point target, FieldMap map, Matchconfig matchconfig) throws InvalidTargetException, TargetOutOfRangeException, TargetOutOfSightException {
        map.validateIsInRange(character.getCoordinates(), target, matchconfig.getGrappleRange());
        map.validateIsInSight(character.getCoordinates(), target);
        map.getField(target).validateHasGadget();
        // Calculate grapple success chance
        double hitChance = matchconfig.getGrappleHitChance();
        if (character.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || character.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
            hitChance = hitChance / 2;
        }
        // If hit
        if (Math.random() < hitChance) {
            character.addGadget(map.getField(target).getGadget().getGadgetEnum());
            map.getField(target).setGadget(null);
            return true;
        }
        // If no hit
        else {
            // If second chance
            if (character.hasProperty(PropertyEnum.TRADECRAFT) && !character.hasGadget(GadgetEnum.MOLEDIE)) {
                // If success
                if (Math.random() < hitChance) {
                    character.addGadget(map.getField(target).getGadget().getGadgetEnum());
                    map.getField(target).setGadget(null);
                    return true;
                }
                // If fail
                else {
                    return false;
                }
            }
            // If no second chance
            else {
                return false;
            }
        }
    }

    /**
     * Method for when a character uses the gadget wiretapWithEarplugs.
     *
     * @param character  Character who uses the gadget.
     * @param target     Coordinates of the target.
     * @param map        Current FieldMap.
     * @param characters Set of all characters on the map.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean wiretapWithEarplugs(Character character, Point target, FieldMap map, Set<Character> characters) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        map.validateFieldHasCharacter(target, characters);
        character.getWireTapWithEarplugs().validateIsNotInUse();
        character.getWireTapWithEarplugs().setupWireTapWithEarplugs(map.getCharacterOnField(target, characters));
        GamePhaseState.isWiretapsAlreadyUsed = true;
        return true;
    }

    /**
     * Method to check if a character has an active wiretap on them.
     *
     * @param character  Character who has the wiretap.
     * @param characters Set of all characters currently in the game.
     * @param ipAdd      Ip to add to the character.
     */
    public static void checkHasWireTapWithEarplugs(Character character, Set<Character> characters, int ipAdd) {
        Character wiretapWithEarplugsUser = Character.getCharacterWithGadgetOfType(characters, GadgetEnum.WIRETAP_WITH_EARPLUGS);
        if (wiretapWithEarplugsUser != null) {
            if (wiretapWithEarplugsUser.getWireTapWithEarplugs().isWorking() && wiretapWithEarplugsUser.getWireTapWithEarplugs().getActiveOn().equals(character.getCharacterId())) {
                wiretapWithEarplugsUser.updateIntelligencePoints(ipAdd);
            }
        }
    }

    /**
     * Method to calculate if the gadget wireTapWithEarplugs is active.
     *
     * @param wireTapWithEarplugs The gadget wireTapWithEarplugs.
     * @param matchconfig         The match config.
     * @param characters          Set of all characters currently in the game.
     * @return True if the gadget was used successfully, false if not.
     */
    public static boolean isWireTapWithEarplugsActive(WireTapWithEarplugs wireTapWithEarplugs, Matchconfig matchconfig, Set<Character> characters) {
        if (wireTapWithEarplugs.isWorking()) {
            if (Math.random() < matchconfig.getWiretapWithEarplugsFailChance()) {
                wireTapWithEarplugs.setWorking(false);
                Character wiretapWithEarplugsUser = Character.getCharacterWithGadgetOfType(characters, GadgetEnum.WIRETAP_WITH_EARPLUGS);
                if (wiretapWithEarplugsUser != null) {
                    wiretapWithEarplugsUser.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
                }
                GamePhaseState.isWiretapsAlreadyUsed = false;
            }
        }
        return wireTapWithEarplugs.isWorking();
    }

    /**
     * Method for when a character uses the gadget jetpack.
     *
     * @param character  Character who uses the gadget
     * @param target     Coordinates of the target.
     * @param map        Current FieldMap.
     * @param characters All characters on the map.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets a invalid character.
     */
    public static boolean jetpack(Character character, Point target, FieldMap map, Set<Character> characters) throws InvalidTargetException {
        map.validateFieldHasNoCharacter(target, characters);
        map.getField(target).validateIsState(FieldStateEnum.FREE);
        character.setCoordinates(target);
        return true;
    }

    /**
     * Method for when a character uses the gadget chickenFeed.
     *
     * @param character         Character who uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean chickenFeed(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        map.validateFieldHasCharacter(target, characters);

        if (character.isMemberOfFaction(charactersPlayer1)) {
            if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer2)) {
                chickenFeedChangeIP(character, map.getCharacterOnField(target, characters), characters);
            }
        } else if (character.isMemberOfFaction(charactersPlayer2)) {
            if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer1)) {
                chickenFeedChangeIP(character, map.getCharacterOnField(target, characters), characters);
            }
        }
        return true;
    }

    /**
     * Method needed for the chickenFeed logic.
     *
     * @param character  Character who uses the gadget chickenFeed.
     * @param target     Target character.
     * @param characters Set of all characters currently in the game.
     */
    private static void chickenFeedChangeIP(Character character, Character target, Set<Character> characters) {
        if (character.getIp() > target.getIp()) {
            character.updateIntelligencePoints(-(character.getIp() - target.getIp()));

        } else if (character.getIp() < target.getIp()) {
            int ipGain = target.getIp() - character.getIp();
            character.updateIntelligencePoints(ipGain);
            checkHasWireTapWithEarplugs(character, characters, ipGain);
        }
    }

    /**
     * Method for when a character uses the gadget nugget.
     *
     * @param character         Character who uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        All characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param charactersNPC     The non playable characters.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean nugget(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Set<Character> charactersNPC) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        map.validateFieldHasCharacter(target, characters);

        if (character.isMemberOfFaction(charactersPlayer1)) {
            map.getCharacterOnField(target, characters).validateIsNoMemberOfFaction(charactersPlayer1);
        } else {
            map.getCharacterOnField(target, characters).validateIsNoMemberOfFaction(charactersPlayer2);
        }

        if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer1) || map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer2)) {
            map.getCharacterOnField(target, characters).addGadget(GadgetEnum.NUGGET);
        } else {
            if (character.isMemberOfFaction(charactersPlayer1)) {
                charactersPlayer1.add(map.getCharacterOnField(target, characters));
            } else {
                charactersPlayer2.add(map.getCharacterOnField(target, characters));
            }
            charactersNPC.remove(map.getCharacterOnField(target, characters));
        }
        return true;
    }

    /**
     * Method for when a character uses the gadget mirrorOfWilderness.
     *
     * @param character         Character who uses the gadget.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        Set of all characters on the map.
     * @param charactersPlayer1 Characters from player1
     * @param charactersPlayer2 Characters from player2
     * @param charactersNPC     The non playable characters.
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets a invalid target.
     */
    public static boolean mirrorOfWilderness(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Set<Character> charactersNPC, Matchconfig matchconfig) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        map.validateFieldHasCharacter(target, characters);

        // Target is NPC
        if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersNPC)) {
            return false;
        }
        // Target is in the same faction
        else if ((character.isMemberOfFaction(charactersPlayer1) && map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer1))
                || character.isMemberOfFaction(charactersPlayer2) && map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer2)) {
            int neighbourIp = map.getCharacterOnField(target, characters).getIp();
            map.getCharacterOnField(target, characters).setIp(character.getIp());
            character.setIp(neighbourIp);
            return true;
        }
        // Target is in another faction
        else {
            // Calculate mirror swap success chance
            double hitChance = matchconfig.getMirrorSwapChance();
            if (character.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || character.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                hitChance = hitChance / 2;
            }
            // If success
            if (Math.random() < hitChance) {
                useMirrorOfWilderness(character, target, map, characters);
                return true;
            }
            // If fail
            else {
                // If second chance
                if (character.hasProperty(PropertyEnum.TRADECRAFT) && !character.hasGadget(GadgetEnum.MOLEDIE)) {
                    // If success
                    if (Math.random() < hitChance) {
                        useMirrorOfWilderness(character, target, map, characters);
                        return true;
                    }
                    // If fail
                    else {
                        return false;
                    }
                }
                // If no second chance
                else {
                    return false;
                }
            }
        }
    }

    /**
     * Sub method for mirrorOfWilderness to use it.
     *
     * @param character  Character who uses the gadget.
     * @param target     Coordinates of the target.
     * @param map        Current FieldMap.
     * @param characters Set of all characters on the map.
     */
    private static void useMirrorOfWilderness(Character character, Point target, FieldMap map, Set<Character> characters) {
        int neighbourIp = map.getCharacterOnField(target, characters).getIp();
        map.getCharacterOnField(target, characters).setIp(character.getIp());
        character.setIp(neighbourIp);
        character.useGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        checkHasWireTapWithEarplugs(character, characters, neighbourIp);
    }


    /**
     * Method for when a character uses the diamondCollar.
     *
     * @param character   Character who uses the gadget.
     * @param target      Coordinates of the target.
     * @param map         Current FieldMap.
     * @param characters  Set of all characters on the map.
     * @param cat         The cat.
     * @param matchconfig The match config.
     * @return True if the cat got the diamondCollar.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    /*
     * Nicht konsistent mit dem Lastenheft: 19.07
     * 
    public static boolean diamondCollar(Character character, Point target, FieldMap map, Set<Character> characters, Character cat, Matchconfig matchconfig) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        cat.validateIsCharacter(target);
        character.updateIntelligencePoints(matchconfig.getCatIp());
        cat.addGadget(GadgetEnum.DIAMOND_COLLAR);
        checkHasWireTapWithEarplugs(character, characters, matchconfig.getCatIp());
        return true;
    }
	*/

    /**
     * Method for when a character spills a cocktail. Gets the target of the spill action.
     *
     * @param character         Character who uses the cocktail.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        Set of all characters on the map.
     * @param charactersPlayer1 Characters from player1
     * @param charactersPlayer2 Characters from player2
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean spillCocktail(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) throws InvalidTargetException {
        map.validateIsNeighbour(character.getCoordinates(), target);
        map.validateFieldHasCharacter(target, characters);

        // If target has honey trap
        if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.HONEY_TRAP)) {
            double chance = matchconfig.getHoneyTrapSuccessChance();

            // If target has clammy clothes or constant clammy clothes
            if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CLAMMY_CLOTHES) || map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                chance = chance / 2;
            }

            // If the user has more possible target neighbours
            if (map.getNeighbourCharacterCount(character.getCoordinates(), characters) > 1) {
                // If honey trap success
                if (Math.random() < chance) {
                    // Gadget user get all neighbours
                    Set<Character> possibleNewTargets = map.getNeighbourCharacters(character.getCoordinates(), characters);

                    // Remove the target with honey trap success
                    possibleNewTargets.remove(map.getCharacterOnField(target, characters));

                    // New target
                    Point newTarget = Character.getRandomCharacter(possibleNewTargets).getCoordinates();
                    return spillCocktailLogic(character, newTarget, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                }
                // If the target has tradecraft and the first honey trap chance failed.
                else if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.TRADECRAFT) && !map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.MOLEDIE)) {
                    // Second chance
                    if (Math.random() < chance) {
                        // Gadget user get all neighbours
                        Set<Character> possibleNewTargets = map.getNeighbourCharacters(character.getCoordinates(), characters);

                        // Remove the target with honey trap success
                        possibleNewTargets.remove(map.getCharacterOnField(target, characters));

                        // New target
                        Point newTarget = Character.getRandomCharacter(possibleNewTargets).getCoordinates();
                        return spillCocktailLogic(character, newTarget, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
                    }
                }
            }
        }
        // Old target
        return spillCocktailLogic(character, target, map, characters, charactersPlayer1, charactersPlayer2, matchconfig);
    }

    /**
     * Method for when a character picks up a cocktail.
     *
     * @param character The character who gets the cocktail in his inventory.
     * @param map       Current FieldMap.
     * @param target    The target field.
     * @return True if the action was successful.
     * @throws InvalidTargetException If the character targets an invalid field.
     */
    public static boolean pickupCocktail(Character character, FieldMap map, Point target) throws InvalidTargetException {
        map.validateIsNeighbourOfState(character.getCoordinates(), target, FieldStateEnum.BAR_TABLE);
        map.getField(target).validateHasGadgetOfType(GadgetEnum.COCKTAIL);

        if (map.getField(target).getCocktail().isPoisoned()) {
            character.addGadget(GadgetEnum.COCKTAIL);
            character.getCocktail().poison();
        } else {
            character.addGadget(GadgetEnum.COCKTAIL);
        }
        map.getField(target).setGadget(null);
        return true;
    }

    /**
     * Method for when a character uses the cocktail to drink it.
     *
     * @param character         Character who drinks the cocktail.
     * @param map               Current FieldMap.
     * @param matchconfig       The match config.
     * @param characters        Set of all characters on the map.
     * @param charactersPlayer1 Characters from player1.
     * @param charactersPlayer2 Characters from player2.
     * @return True if the action was successful.
     */
    public static boolean drinkCocktail(Character character, FieldMap map, Matchconfig matchconfig, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) {
        if (character.getCocktail().isPoisoned()) {
            if (character.hasProperty(PropertyEnum.ROBUST_STOMACH)) {
                character.takeDamage(matchconfig.getCocktailHp() / 2, map, characters, charactersPlayer1, charactersPlayer2);

            } else {
                character.takeDamage(matchconfig.getCocktailHp(), map, characters, charactersPlayer1, charactersPlayer2);
            }
        } else {
            if (character.hasProperty(PropertyEnum.ROBUST_STOMACH)) {
                character.getHealed(matchconfig.getCocktailHp() * 2);
            } else {
                character.getHealed(matchconfig.getCocktailHp());
            }
        }
        if (character.isMemberOfFaction(charactersPlayer1)) {
            MainServerLogic.winCondition.addDrankCocktailPlayer1();
        } else if (character.isMemberOfFaction(charactersPlayer2)) {
            MainServerLogic.winCondition.addDrankCocktailPlayer2();
        }
        return true;
    }

    /**
     * Method for when a character uses the cocktail to spill it on someone.
     *
     * @param character         Character who spills the cocktail.
     * @param target            Coordinates of the target.
     * @param map               Current FieldMap.
     * @param characters        Set of all characters on the map.
     * @param charactersPlayer1 Characters from player1
     * @param charactersPlayer2 Characters from player2
     * @param matchconfig       The match config.
     * @return True if the gadget was used successfully, false if not.
     */
    private static boolean spillCocktailLogic(Character character, Point target, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) {
        // Dodge chance
        double chance = matchconfig.getCocktailDodgeChance();
        // If the target has clammy clothes or constant clammy clothes
        if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CLAMMY_CLOTHES) || map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
            // Dodge chance
            chance = chance / 2;
        }
        if (Math.random() < chance) {
            // Success
            return false;
        }
        // If the target has tradecraft
        else if (map.getCharacterOnField(target, characters).hasProperty(PropertyEnum.TRADECRAFT) && !map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.MOLEDIE)) {
            // Second dodge chance
            if (Math.random() < chance) {
                // Success
                return false;
            }
        }
        // Check if the target has a babysitter
        else if (map.checkBabysitter(map.getCharacterOnField(target, characters), characters, charactersPlayer1, charactersPlayer2)) {
            // Check every babysitter
            for (Character babysitter : map.getBabysitters(map.getCharacterOnField(target, characters), characters, charactersPlayer1, charactersPlayer2)) {
                double babysitterSuccessChance = matchconfig.getBabysitterSuccessChance();
                // Check if babysitter has clammy clothes or constant clammy clothes
                if (babysitter.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || babysitter.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                    // Set new chance
                    babysitterSuccessChance = babysitterSuccessChance / 2;
                }
                // First chance
                if (Math.random() < babysitterSuccessChance) {
                    // success
                    return false;
                }
                // Check if babysitter has second chance
                else if (babysitter.hasProperty(PropertyEnum.TRADECRAFT) && !babysitter.hasGadget(GadgetEnum.MOLEDIE)) {
                    // Second chance
                    if (Math.random() < babysitterSuccessChance) {
                        // Success
                        return false;
                    }
                }
            }
        }
        // Target gets clammy clothes
        map.getCharacterOnField(target, characters).addProperty(PropertyEnum.CLAMMY_CLOTHES);
        if (character.isMemberOfFaction(charactersPlayer1)) {
            MainServerLogic.winCondition.addSpilledCocktailPlayer1();
        } else if (character.isMemberOfFaction(charactersPlayer2)) {
            MainServerLogic.winCondition.addSpilledCocktailPlayer2();
        }
        return true;
    }
}
