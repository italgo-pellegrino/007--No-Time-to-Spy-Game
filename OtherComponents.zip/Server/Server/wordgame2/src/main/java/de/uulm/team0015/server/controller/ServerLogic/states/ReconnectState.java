package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.ReconnectTimerTask;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Messages.Receive.EquipmentChoiceMessage;
import de.uulm.team0015.server.model.Messages.Receive.GameOperationMessage;
import de.uulm.team0015.server.model.Messages.Receive.ItemChoiceMessage;
import de.uulm.team0015.server.model.Messages.Receive.ReconnectMessage;
import de.uulm.team0015.server.model.Messages.Send.GamePauseMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStartedMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.Timer;
import java.util.logging.Logger;

/**
 * ReconnectState used to handle the disconnection of one or both players.
 *
 * @author Tom Weisser
 * @version 1.0
 * @see ServerState
 */
public class ReconnectState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(ReconnectState.class.getName());
    private final ServerState previous;
    private final ServerStateEnum previousStateEnum;
    Timer timerPlayer1, timerPlayer2;

    /**
     * Constructor of ReconnectState, will start a timer for the disconnected player.
     *
     * @param previous           ServerState, the server has been in before entering the ReconnectState.
     * @param disconnectedPlayer SimpleClientManager of the disconnected player.
     */
    public ReconnectState(ServerState previous, SimpleClientManager disconnectedPlayer) {
        super();
        ServerLogger.addHandler(LOGGER);
        previousStateEnum = ServerState.activeState;
        ServerState.activeState = ServerStateEnum.RECONNECT_STATE;
        this.previous = previous;
        mainServerLogic.serverState = this;

        LOGGER.warning("A player has been disconnected, entering ReconnectState.");

        // call onPlayerDisconnect to start timer
        onPlayerDisconnect(disconnectedPlayer);

        // Create GamePauseMessage
        GamePauseMessage gamePauseMessage = GamePauseMessage.createGamePauseMessage(true,
                true,
                null,
                "A player has been disconnected, server enforced pause.");
        // Broadcast GamePauseMessage
        mainServerLogic.broadcast(gamePauseMessage);
    }

    /**
     * Method, that handles the receiving of a ReconnectMessage.
     * Will re-register a client, when valid.
     *
     * @param manager          SimpleClientManager of the client that sent the ReconnectMessage.
     * @param reconnectMessage The message that was received.
     */
    @Override
    public void onReconnectMessage(SimpleClientManager manager, ReconnectMessage reconnectMessage) {
        // Check if SessionId is correct
        if (reconnectMessage.sessionId.equals(mainServerLogic.sessionID)) {
            LOGGER.fine("Received ReconnectMessage with valid SessionId");
            // Check if player1 is disconnected and playerId = player1Id, IF true stop timers set manager as player1
            if (mainServerLogic.player1.isDisconnected() && mainServerLogic.clientIdPlayer1.equals(reconnectMessage.clientId)) {
                String p1reconnect = "Player1 reconnected to the server.";
                LOGGER.warning(p1reconnect);
                ServerShell.print(p1reconnect);
                stopPlayer1Timer();
                // Set clientInformation from old manager
                manager.setClientInformation(mainServerLogic.player1.clientInformation);
                mainServerLogic.player1 = manager;
                reenterGame(manager);
            } else if (mainServerLogic.player2.isDisconnected() && mainServerLogic.clientIdPlayer2.equals(reconnectMessage.clientId)) {
                // Check if player2 is disconnected and playerId = player2Id, IF true stop timers and set manager as player2
                String p2reconnect = "Player2 reconnected to the server.";
                LOGGER.warning(p2reconnect);
                ServerShell.print(p2reconnect);
                stopPlayer2Timer();
                // Set clientInformation from old manager
                manager.setClientInformation(mainServerLogic.player2.clientInformation);
                mainServerLogic.player2 = manager;
                reenterGame(manager);
            } else {
                manager.disconnect();
            }
            // Check if player1 and player2 are connected, IF yes return to last state.
            if (!mainServerLogic.player1.isDisconnected() && !mainServerLogic.player2.isDisconnected()) {
                String bothReconnected = "Both players are connected again. Stopping server enforced pause.";
                LOGGER.warning(bothReconnected);
                ServerShell.print(bothReconnected);

                // Create GamePauseMessage
                GamePauseMessage gamePauseMessage = GamePauseMessage.createGamePauseMessage(false,
                        true,
                        null,
                        "Both players are connected again.");
                // Broadcast GamePauseMessage
                mainServerLogic.broadcast(gamePauseMessage);

                previous.onReturn();
            }
        } else {
            String falseMessage = "Received ReconnectMessage with wrong SessionId.";
            LOGGER.fine(falseMessage);
            onFalseMessage(manager, ErrorTypeEnum.SESSION_DOES_NOT_EXIST, falseMessage);
        }
    }

    /**
     * Method to handle a RequestPauseMessage by a player during the ReconnectState.
     * ReconnectState can only be unpaused by the server therefore striking client.
     *
     * @param manager SimpleClientManager of the player that tried to pause the game.
     * @param pause   Boolean indicating if the player wants to resume or pause
     */
    @Override
    public void onPlayerPause(SimpleClientManager manager, boolean pause) {
        if (MainServerLogic.strictness) {
            String problem = "Received RequestPauseMessage by player during server enforced pause. Only the server can unpause the game.";
            LOGGER.info(problem);
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
        } else {
            String problem = "Received RequestPauseMessage by player during server enforced pause. Message might have been delayed";
            LOGGER.info(problem);
            strikeClient(manager, problem);
        }
    }

    /**
     * Method to register the disconnection of a client, during the ReconnectState.
     * Allows for parallel disconnections, will start a separate Timer for each player.
     *
     * @param manager SimpleClientManager of the disconnected player client.
     */
    @Override
    public void onPlayerDisconnect(SimpleClientManager manager) {
        long reconnectLimit = mainServerLogic.initialMatchconfig.getReconnectLimit() * 1000;
        if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
            String p1disconnect = "Player1 has been disconnected, waiting " + mainServerLogic.initialMatchconfig.getReconnectLimit() + " seconds for him to reconnect.";
            LOGGER.warning(p1disconnect);
            ServerShell.print(p1disconnect);
            timerPlayer1 = new Timer();
            timerPlayer1.schedule(new ReconnectTimerTask(this, manager), reconnectLimit);
        } else if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer2)) {
            String p2disconnect = "Player2 has been disconnected, waiting " + mainServerLogic.initialMatchconfig.getReconnectLimit() + " seconds for him to reconnect.";
            LOGGER.warning(p2disconnect);
            ServerShell.print(p2disconnect);
            timerPlayer2 = new Timer();
            timerPlayer2.schedule(new ReconnectTimerTask(this, manager), reconnectLimit);
        } else {
            LOGGER.severe("Indicating player disconnect of unregistered player. This should not happen.");
        }
    }

    /**
     * Method to handle delayed ItemChoiceMessage.
     *
     * @param manager           SimpleClientManager of the spectator that sent the ItemChoiceMessage.
     * @param itemChoiceMessage The message that was received.
     */
    @Override
    public void onItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        if (previousStateEnum == ServerStateEnum.DECISION_PHASE_STATE) {
            if (MainServerLogic.strictness) {
                String problem = "Received ItemChoiceMessage by player during server enforced pause.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Received ItemChoiceMessage by player during server enforced pause. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        } else {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent ItemChoiceMessage in wrong state.");
        }
    }

    /**
     * Method to handle delayed EquipmentChoiceMessage.
     *
     * @param manager                SimpleClientManager of the client that sent the EquipmentChoiceMessage.
     * @param equipmentChoiceMessage The message that was received.
     */
    @Override
    public void onEquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        if (previousStateEnum == ServerStateEnum.EQUIPMENT_PHASE_STATE) {
            if (MainServerLogic.strictness) {
                String problem = "Received EquipmentChoiceMessage by player during server enforced pause.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Received EquipmentChoiceMessage by player during server enforced pause. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        } else {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent EquipmentChoiceMessage in wrong state.");
        }
    }

    /**
     * Method to handle delayed GameOperationMessage.
     *
     * @param manager              SimpleClientManager that sent the GameOperationMessage
     * @param gameOperationMessage The message that was received
     */
    @Override
    public void onGameOperationMessage(SimpleClientManager manager, GameOperationMessage gameOperationMessage) {
        if (previousStateEnum == ServerStateEnum.GAME_PHASE_STATE) {
            if (MainServerLogic.strictness) {
                String problem = "Received GameOperationMessage by player during server enforced pause.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Received GameOperationMessage by player during server enforced pause. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        } else {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent GameOperationMessage in wrong state.");
        }
    }

    /**
     * Method to handle the successful reconnection of a client.
     * Will retransmit GameStartedMessage, last GameStatusMessage and, if a player pause is in progress a GamePauseMessage.
     *
     * @param manager SimpleClientManager that is reconnecting as a player
     */
    private void reenterGame(SimpleClientManager manager) {
        LOGGER.finer("Player reentered the game.");
        // Send GameStartedMessage again.
        GameStartedMessage gameStartedMessage = GameStartedMessage.createGameStartedMessage(mainServerLogic.clientIdPlayer1,
                mainServerLogic.clientIdPlayer2,
                mainServerLogic.player1.clientInformation.getName(),
                mainServerLogic.player2.clientInformation.getName(),
                mainServerLogic.sessionID,
                null,
                "Sending GameStartedMessage after successful reconnect.");
        manager.sendMessage(gameStartedMessage);
        // Send last GameStatusMessage if previous is GamePhaseState or previous is GamePauseState after GamePhaseState
        if (previousStateEnum == ServerStateEnum.GAME_PHASE_STATE || (previousStateEnum == ServerStateEnum.GAME_PAUSE_STATE && ((GamePauseState) previous).getPreviousStateEnum() == ServerStateEnum.GAME_PHASE_STATE)) {
            LOGGER.fine("Retransmitting last GameStatusMessage.");
            assert previous instanceof GamePhaseState;
            GamePhaseState gamePhaseState = (GamePhaseState) previous;
            if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
                manager.sendMessage(gamePhaseState.getLastGameStatusMessagePlayer1());
            } else if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer2)) {
                manager.sendMessage(gamePhaseState.getLastGameStatusMessagePlayer2());
            }
        }
        // If previous is GamePauseState send GamePauseMessage
        if (previousStateEnum == ServerStateEnum.GAME_PAUSE_STATE) {
            LOGGER.fine("Retransmitting Player GamePauseMessage.");
            GamePauseMessage gamePauseMessage = GamePauseMessage.createGamePauseMessage(true,
                    false,
                    manager.clientInformation.getClientId(),
                    "Player has disconnected and reconnected during GamePauseState. Resending GamePauseMessage.");
            manager.sendMessage(gamePauseMessage);
        }
    }

    /**
     * Method used to stop all running timers.
     */
    private void killAllTimers() {
        stopPlayer1Timer();
        stopPlayer2Timer();
    }

    /**
     * Method used to stop the timer of player 1.
     */
    private void stopPlayer1Timer() {
        try {
            timerPlayer1.cancel();
            timerPlayer1.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("Reconnect timer of player 1 has already been closed");
        }
    }

    /**
     * Method used to stop the timer of player 2.
     */
    private void stopPlayer2Timer() {
        try {
            timerPlayer2.cancel();
            timerPlayer2.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("Reconnect timer of player 2 has already been closed");
        }
    }

    /**
     * Synchronized method that will be called by a timer, when a player fails to reconnect.
     * Will call onGameLeave() with respective client
     *
     * @param manager SimpleClientManager of the client, that failed to reconnect.
     * @see ServerState
     */
    public synchronized void onReconnectFailure(SimpleClientManager manager) {
        if (activeState == ServerStateEnum.RECONNECT_STATE) {
            if (manager.clientInformation.getClientId().equals(mainServerLogic.player1.clientInformation.getClientId())) {
                LOGGER.warning("Player 1 has failed to reconnect. Game Over.");
            } else {
                LOGGER.warning("Player 2 has failed to reconnect. Game Over.");
            }
            // Stop all timers -> call onGameLeaveMessage
            killAllTimers();
            onGameLeaveMessage(manager);
        } else {
            LOGGER.fine("Two reconnect timers stopped at the same time.");
        }
    }

    /**
     * Method used to stop the ReconnectState. Will pause all timers.
     */
    @Override
    public void stop() {
        LOGGER.warning("ReconnectState has been stopped.");
        killAllTimers();
    }
}