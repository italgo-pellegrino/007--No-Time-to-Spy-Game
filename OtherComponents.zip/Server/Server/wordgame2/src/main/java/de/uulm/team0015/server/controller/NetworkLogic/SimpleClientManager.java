package de.uulm.team0015.server.controller.NetworkLogic;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.model.DataTypes.Operations.GadgetAction;
import de.uulm.team0015.server.model.DataTypes.Operations.GambleAction;
import de.uulm.team0015.server.model.DataTypes.Operations.Movement;
import de.uulm.team0015.server.model.DataTypes.Operations.PropertyAction;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.ClientInformation;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Messages.MessageContainer;
import de.uulm.team0015.server.model.Messages.Receive.*;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * The SimpleClientManager is responsible for managing a SimpleClients connection and for parsing and delivery of messages to the MainServerLogic.
 * Therefore it is building the bridge between a SpimpleClient and the MainServerLogic by serializing and deserializing jsonStrings to message objects.
 * <p>
 * It keeps a instance of ClientInformation as well to for example, identifying a Manager.
 *
 * @author Tom Weisser, Max Raedler
 * @version 1.0
 * @see SimpleClient
 * @see MainServerLogic
 */
public class SimpleClientManager {
    private final static Logger LOGGER = Logger.getLogger(SimpleClientManager.class.getName());
    private SimpleClient client;
    private Gson gson;
    private MainServerLogic serverLogic;
    //The ClientInformation needs to be set after a correct HelloMessage
    public ClientInformation clientInformation;
    public String ipInformation;
    
    /**
     * name of Client
     */
    public String name;

    private boolean disconnectedByServer = false;

    /**
     * Constructor that will setup a new SimpleClientManager to manage incoming messages and the message forwarding messages to a client.
     *
     * @param client The client, which this Manager is going to manage.
     * @param logic  The MainServerLogic object, the Manager is a part of.
     */
    public SimpleClientManager(SimpleClient client, MainServerLogic logic) {
        ServerLogger.addHandler(LOGGER);

        this.client = client;
        gson = new Gson();
        this.serverLogic = logic;
        this.ipInformation = client.getSession().getRequestURI().toString();
        LOGGER.finer("Creating new SimpleClientManager for IP: " + ipInformation);
    }

    /**
     * Method, that is used to initiate a server sided disconnect with the client.
     */
    public void disconnect() {
        LOGGER.fine("Calling disconnect()-method for client with IP: " + ipInformation);
        setDisconnectedByServer(true);
        NTTSServerSocket.allClients.remove(client);
        try {
            client.close();
        } catch (IOException e) {
            LOGGER.severe("Disconnect failed for Client: " + ipInformation + "with reason" + e);
        }
    }

    /**
     * Method that passes a disconnect on to the MainServerLogic
     */
    public void onDisconnect() {
        if (!isDisconnectedByServer()) {
            NTTSServerSocket.allClients.remove(client);
            if (clientInformation != null) {
                LOGGER.fine("Registered Client with IP: " + ipInformation + " has cancelled the connection.");
                serverLogic.onDisconnect(this);
            } else {
                LOGGER.fine("Not registered Client with IP: " + ipInformation + " has cancelled the connection.");
            }
        } else {
            LOGGER.fine("Client with IP: " + ipInformation + " has been disconnected by the server");
        }
    }

    /**
     * Use this method to set the clientInformation after receiving the Hello-Message.
     *
     * @param clientInformation The information of the client.
     */
    public void setClientInformation(ClientInformation clientInformation) {
        this.clientInformation = clientInformation;
    }

    /**
     * Method that will check and validate a received message.
     * This method should only be called by the respective SimpleClient.
     * <p>
     * If a Message is parsable and correct the freshly generated message object is passed to the MainServerLogic.
     * If a Message won't be parsed correctly the error will be logged and be handled by the MainServerLogic.
     *
     * @param jsonMessage The received message in String-representation.
     */
    public void receive(String jsonMessage) {
        // 1. check if message is valid JSON
        if (checkJSON(jsonMessage)) {
            MessageContainer messageContainer = new MessageContainer();

            MessageTypeEnum messageTypeEnum;

            // 2. check if message can be cast to a MessageContainer
            if ((messageTypeEnum = checkMsgContainer(jsonMessage)) != null) {

                // 3. check if message can be cast to a valid MessageType and pass it on to MainServerLogic
                processMessage(jsonMessage, messageTypeEnum);
            } else {
                String exception = "Received MessageContainer with type=null by client with IP: " + ipInformation;
                LOGGER.fine(exception);
                serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
            }
        }
    }

    /**
     * Method that will check if a message contains valid JSON.
     *
     * @param jsonMessage The received message in String-representation.
     * @return true if the String contains a parsable JsonObject false if not
     */
    private boolean checkJSON(String jsonMessage) {
        try {
            gson.fromJson(jsonMessage, Object.class);
            return true;
        } catch (com.google.gson.JsonSyntaxException ex) {
            String exception = "Received invalid JSON by: " + ipInformation;
            LOGGER.fine(exception);
            serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
            return false;
        }
    }

    /**
     * Method that will check if a message can be cast to MessageContainer format.
     *
     * @param jsonMessage The received message in String-representation.
     * @return The type of the Message if there is one otherwise null if there isn't one or the message could not be parsed.
     */
    private MessageTypeEnum checkMsgContainer(String jsonMessage) {
        try {
            MessageContainer messageContainer = gson.fromJson(jsonMessage, MessageContainer.class);
            LOGGER.fine("Successfully parsed MessageContainer");
            return messageContainer.type;
        } catch (com.google.gson.JsonSyntaxException ex) {
            String exception = "Received invalid JSON for MessageContainer. Error at: " + ex.getMessage() + " By: " + ipInformation;
            LOGGER.fine(exception);
            serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
            return null;
        }
    }

    /**
     * Method that will check if a message can be cast to a specific message format and passes it on to the MainServerLogic.
     * If the message can't be parsed, nothing will happen, meaning no method is called in the MainServerLogic.
     *
     * @param jsonMessage The received message in String-representation.
     * @param messageType MessageType of the message, that it will be cast to.
     */
    private void processMessage(String jsonMessage, MessageTypeEnum messageType) {

        switch (messageType) {
            case GAME_LEAVE:
                try {
                    GameLeaveMessage gameLeaveMessage = gson.fromJson(jsonMessage, GameLeaveMessage.class);
                    LOGGER.fine("Received valid GameLeaveMessage by client with IP: " + ipInformation);
                    serverLogic.onGameLeaveMessage(this, gameLeaveMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for GameLeaveMessage. By: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case GAME_OPERATION:
                try {
                	/**
                	 * Änderung am 15.07.: GameOperationMessage wird gesondert geparst aufgrund eines außergewöhnlichen Parse Fehlers
                	 */
                	GameOperationMessage gameOperationMessage = parseGameOperationMessage(jsonMessage);
                    //GameOperationMessage gameOperationMessage = gson.fromJson(jsonMessage, GameOperationMessage.class);
                    LOGGER.fine("Received valid GameOperationMessage by client with IP: " + ipInformation);
                    serverLogic.onGameOperationMessage(this, gameOperationMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for GameOperationMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case HELLO:
                try {
                    HelloMessage helloMessage = gson.fromJson(jsonMessage, HelloMessage.class);
                    LOGGER.fine("Received valid HelloMessage by client with IP: " + ipInformation);
                    serverLogic.onHelloMessage(this, helloMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for HelloMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case ITEM_CHOICE:
                try {
                    ItemChoiceMessage itemChoiceMessage = gson.fromJson(jsonMessage, ItemChoiceMessage.class);
                    LOGGER.fine("Received valid ItemChoiceMessage by client with IP: " + ipInformation);
                    serverLogic.onItemChoiceMessage(this, itemChoiceMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for ItemChoiceMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case RECONNECT:
                try {
                    ReconnectMessage reconnectMessage = gson.fromJson(jsonMessage, ReconnectMessage.class);
                    LOGGER.fine("Received valid ReconnectMessage by client with IP: " + ipInformation);
                    serverLogic.onReconnectMessage(this, reconnectMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for ReconnectMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case REQUEST_GAME_PAUSE:
                try {
                    RequestGamePauseMessage requestGamePauseMessage = gson.fromJson(jsonMessage, RequestGamePauseMessage.class);
                    LOGGER.fine("Received valid RequestGamePauseMessage by client with IP: " + ipInformation);
                    serverLogic.onRequestGamePauseMessage(this, requestGamePauseMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for RequestGamePauseMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case REQUEST_META_INFORMATION:
                try {
                    RequestMetaInformationMessage requestMetaInformationMessage = gson.fromJson(jsonMessage, RequestMetaInformationMessage.class);
                    LOGGER.fine("Received valid RequestMetaInformationMessage by client with IP: " + ipInformation);
                    serverLogic.onRequestMetaInformationMessage(this, requestMetaInformationMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for RequestMetaInformationMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case EQUIPMENT_CHOICE:
                try {
                    EquipmentChoiceMessage equipmentChoiceMessage = gson.fromJson(jsonMessage, EquipmentChoiceMessage.class);
                    LOGGER.fine("Received valid EquipmentChoiceMessage by client with IP: " + ipInformation);
                    serverLogic.onEquipmentChoiceMessage(this, equipmentChoiceMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for EquipmentChoiceMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            case REQUEST_REPLAY:
                try {
                    RequestReplayMessage requestReplayMessage = gson.fromJson(jsonMessage, RequestReplayMessage.class);
                    LOGGER.fine("Received valid RequestReplayMessage by client with IP: " + ipInformation);
                    serverLogic.onRequestReplayMessage(this, requestReplayMessage);
                } catch (com.google.gson.JsonSyntaxException ex) {
                    String exception = "Received invalid JSON for RequestReplayMessage by: " + ipInformation;
                    LOGGER.fine(exception);
                    serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
                }
                break;

            default:
                String exception = "Received message of invalid type: " + messageType + " by: " + ipInformation;
                LOGGER.fine(exception);
                serverLogic.onFalseMessage(this, ErrorTypeEnum.ILLEGAL_MESSAGE, exception);
        }
    }
    
    /**
     * Hinzugefügt am 15.07.
     * 
     * Diese Methode deserialisiert die ankommende GameOperationMessage gesondert aufgrund eines außergewöhnlichen Parse Fehlers
     * @param json: Json-String
     * 
     * Rückgabe: Die deserialisierte GameOperationMessage
     */
    private GameOperationMessage parseGameOperationMessage(String json) {
    	GameOperationMessage gameOperationMessage = gson.fromJson(json, GameOperationMessage.class);
		
		/**
		 * Operation Attribut wird gesondert behandelt wegen JSON Parse Probleme
		 */
		JsonObject object = gson.fromJson(json, JsonObject.class);
		JsonObject OperationObject = object.getAsJsonObject("operation");
		switch(gameOperationMessage.operation.getType()) {
			/**
			 * Folgende Operationen werden durch Operation vollständig spezifiziert
			 */
			case RETIRE:
			break;
			case SPY_ACTION:
			break;
			case GADGET_ACTION:
				GadgetAction gadgetAction = gson.fromJson(OperationObject, GadgetAction.class);
				gameOperationMessage.operation = gadgetAction;
			break;
			case GAMBLE_ACTION:
				GambleAction gambleAction = gson.fromJson(OperationObject, GambleAction.class);
				gameOperationMessage.operation = gambleAction;
			break;
			case PROPERTY_ACTION:
				PropertyAction propertyAction = gson.fromJson(OperationObject, PropertyAction.class);
				gameOperationMessage.operation = propertyAction;
			break;
			case MOVEMENT:
				Movement movement = gson.fromJson(OperationObject, Movement.class);
				gameOperationMessage.operation = movement;
			break;
			/**
			 * Folgende Aktionen werden vom Server erzeugt
			 */
			case CAT_ACTION:
			break;
			case EXFILTRATION:
			break;
			case JANITOR_ACTION:
			break;
		}
		
		return gameOperationMessage;
    }
    
    
    

    /**
     * Use this method to send a message to this Client
     * This method will parse the given message and hands it over to the SimpleClient
     * <p>
     * If the Client has already been disconnected it will not try to send the message.
     *
     * @param message The message
     */
    public void sendMessage(MessageContainer message) {
        if (!isDisconnected()) {
            try {
                String jsonString = gson.toJson(message);
                LOGGER.config("Sending " + message.type + "-Message to Client with IP: " + ipInformation + ".");
                LOGGER.fine("SimpleClientManager: of " + ipInformation + " handover message to SimpleClient");
                client.send(jsonString);
            } catch (com.google.gson.JsonParseException ex) {
                LOGGER.severe("SimpleClientManager: of " + ipInformation + " wasn't able to create a String based on the given message");
            }
        } else {
            LOGGER.config("Tried to send " + message.type + "-Message to already disconnected client with IP: " + ipInformation);
        }
    }

    /**
     * Call this method to see, if client has been disconnected by the server.
     *
     * @return boolean that represents if a client is disconnected or not; true=disconnected, false=connected
     */
    boolean isDisconnectedByServer() {
        return disconnectedByServer;
    }

    /**
     * Call this method to set if the client has been disconnected by the server or not.
     *
     * @param disconnectedByServer true if the client has been disconnected by the server, false if not.
     */
    void setDisconnectedByServer(boolean disconnectedByServer) {
        this.disconnectedByServer = disconnectedByServer;
    }

    /**
     * Calls this method to see if the client is disconnected.
     *
     * @return true if the client is disconnected, false if not.
     */
    public boolean isDisconnected() {
        return client.isClosed();
    }
}
