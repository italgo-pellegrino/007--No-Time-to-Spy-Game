package de.uulm.team0015.server.model.DataTypes.ServerOnly;

import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Class for when the client requests the meta data of the chosen item.
 *
 * @author Max Raedler
 * @version 1.0
 */
public class RequestItemChoseMeta {
    public List<Character> characters;
    public List<GadgetEnum> gadgetEnums;

    /**
     * Constructor of class RequestItemChoseMeta
     */
    public RequestItemChoseMeta() {
        characters = Collections.synchronizedList(new ArrayList<Character>());
        gadgetEnums = Collections.synchronizedList(new ArrayList<GadgetEnum>());
    }
}
