package de.uulm.team0015.server.model.DataTypes.Stats;

/**
 * Class which represents one entry of statistics made during the game.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class StatisticsEntry {
    private String title;
    private String description;
    private String valuePlayer1;
    private String valuePlayer2;

    /**
     * Constructor of the class StatisticsEntry.
     *
     * @param title        The title of the statistic.
     * @param description  The description of the statistic.
     * @param valuePlayer1 The value for the statistic which player one has.
     * @param valuePlayer2 The value for the statistic which player two has.
     */
    public StatisticsEntry(String title, String description, String valuePlayer1, String valuePlayer2) {
        this.title = title;
        this.description = description;
        this.valuePlayer1 = valuePlayer1;
        this.valuePlayer2 = valuePlayer2;
    }

    /**
     * Setter for title.
     *
     * @param title The title of the statistic.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Setter for description.
     *
     * @param description The description of the statistic.
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Setter for valuePlayer1.
     *
     * @param valuePlayer1 The value for the statistic which player one has.
     */
    public void setValuePlayer1(String valuePlayer1) {
        this.valuePlayer1 = valuePlayer1;
    }

    /**
     * Setter for valuePlayer2.
     *
     * @param valuePlayer2 The value for the statistic which player two has.
     */
    public void setValuePlayer2(String valuePlayer2) {
        this.valuePlayer2 = valuePlayer2;
    }
}
