package de.uulm.team0015.server.controller.ServerLogic.states.tasks;

import de.uulm.team0015.server.controller.ServerLogic.states.GamePhaseState;

import java.util.TimerTask;

/**
 * MoveTimerTask that will be run upon exceeding of the time limit for a move.
 */
public class NpcTimerTask extends TimerTask {
    private GamePhaseState parent;

    /**
     * Constructor to create a new MoveTimerTask.
     *
     * @param parent The server state, which the task is used in.
     */
    public NpcTimerTask(GamePhaseState parent) {
        this.parent = parent;
    }

    /**
     * Will call the onMoveTimeout-method in the parent state.
     */
    @Override
    public void run() {
        parent.onNpcTimer();
    }
}
