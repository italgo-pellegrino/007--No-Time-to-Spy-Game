package de.uulm.team0015.server.model.DataTypes.ServerOnly;

import java.util.UUID;

/**
 * Class for the informations of a character, which contains the information of the character creation and the given UUID.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class CharacterInformation extends CharacterDescription {
    private UUID characterId;

    /**
     * Constructor of the class CharacterInformation.
     *
     * @param uuid        The id of the character.
     * @param description The informations of CharacterDescription for the character.
     */
    public CharacterInformation(UUID uuid, CharacterDescription description) {
        super(description.getName(), description.getDescription(), description.getGender(), description.getFeatures());
        this.characterId = uuid;
    }

    public UUID getCharacterId() {
        return characterId;
    }

    /**
     * toString method of class CharacterInformation
     *
     * @return the id of the character as a String.
     */
    @Override
    public String toString() {
        return "characterId" + characterId;
    }
}
