package de.uulm.team0015.server.controller.NetworkLogic;

import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Logger;

import javax.websocket.MessageHandler;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;

/**
 * Class representing a client connected to the server.
 * After constructor call the SimpleClientEmitter and SimpleClientReceiver are initiated as well
 * The information/data exchanged in this class must be String-based only!
 *
 * @author Simon Demharter
 * @author Tom Weisser, Max Raedler
 * @version 1.0
 * @see de.uulm.team0015.server.controller.NetworkLogic.SimpleClientEmitter
 * @see de.uulm.team0015.server.controller.NetworkLogic.SimpleClientReceiver
 * @see de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager
 */
public class SimpleClient{
    private SimpleClientManager simpleClientManager;
    private final static Logger LOGGER = Logger.getLogger(SimpleClient.class.getName());
    //private Socket socket;
    /**
     * Durch den �bergang in den WebSocket gibt es nun einen MessageHandler als "InputStream" und einen OutputStream output.
     * Die Session stellt die Verbindung zwischen den beiden Endpunkten dar.
     */
    private MessageHandler messageHandler;
    private RemoteEndpoint.Basic remote;
    private Session session;
    private SimpleClientEmitter emitter;
    //private SimpleClientReceiver receiver;
    private MainServerLogic mainServerLogic;
    public volatile boolean isClosed;
    static int connectedClients = 0;

    //ExecutorService executorService;


    /**
     * 
     * @param messageHandler: MessageHandler, welcher dem InputStream des Sockets entspricht
     * @param output: OutputStream, bei welchem der Client die Nachricht gesendet bekommt
     * @param mainServerLogic2: Reference to the MainServerLogic
     */
    public SimpleClient(RemoteEndpoint.Basic remote, Session session, MainServerLogic mainServerLogic2) {
    	ServerLogger.addHandler(LOGGER);

        if (connectedClients >= NTTSServerSocket.capacity) {
            LOGGER.config("New connection attempt by: " + session.getRequestURI().toString() + ". Server capacity is reached.");
            try {
                session.close();
            } catch (IOException e) {
                LOGGER.severe(e.toString());
            }
        } else {
            //this.socket = socket;
        	/**
        	 * Zuweisung der WebSocket spezifischen Parameter
        	 */
        	
        	this.remote = remote;
        	this.session = session;
            this.mainServerLogic = mainServerLogic2;
        }
	}
    
    /**
     * Nachtr�gliche Zuweisung des MessageHandlers
     */
    public void setMessageHandler(MessageHandler messageHandler) {
    	this.messageHandler = messageHandler;
    }


    /**
     * Hinzugef�gt um ein leeres Objekt zu erzeugen
     */
	public SimpleClient() {}


	/**
	 * - �berschrieben am 29.06.2020
	 * 
     * Method is called when a thread is started. Sets up Emitter Receiver and manager.
     */
    public void setUp() {
        LOGGER.config("A new client with IP: " + session.getId() + " connected to the Server.");

            LOGGER.finer("Starting assignment for Client with IP: " + session.getBasicRemote().toString());
            
            this.emitter = new SimpleClientEmitter(this, this.remote);
            

            this.simpleClientManager = new SimpleClientManager(this, mainServerLogic);

            connectedClients += 1;
            NTTSServerSocket.allClients.add(this);

            LOGGER.config("Client " + connectedClients + " of " + NTTSServerSocket.capacity + " connected.");
            LOGGER.finer("Assignment complete for: " + session.getBasicRemote().toString());

    }

    
    public Session getSession() {
    	return session;
    }

    /**
     * Receive method, that is called upon receiving a message, passes it on to the SimpleClientManager.
     *
     * @param jsonMessage received Message in String representation.
     */
    public void receive(String jsonMessage) {
        simpleClientManager.receive(jsonMessage);
    }

    /**
     * Send method, that is called by SimpleClientManager upon sending a message.
     *
     * @param jsonMessage Message that is send out to a client.
     */
    public void send(String jsonMessage) {
        emitter.sendMessage(jsonMessage);
    }

    /**
     * Getter for isClosed boolean.
     *
     * @return Returns if the connection to the client has been closed.
     */
    public boolean isClosed() {
        return isClosed;
    }

    /**
     * Setter for isClosed boolean.
     *
     * @param closed Boolean to set the clients isClosed attribute.
     */
    public void setClosed(boolean closed) {
        isClosed = closed;
    }

    

    /**
     * Close method, that is called to close the SimpleClient. Calls respective close() methods of contained objects and shuts down ExecutorService.
     *
     * @throws IOException throws IOException if any lower-leveled close() method fails to execute.
     */
    public void close() throws IOException {
        setDisconnectedByServer(true);
        setClosed(true);
        session.close();
        LOGGER.fine("Closed SimpleClient with IP: " + session.getRequestURI().toString() + " by force successfully.");
    }

    /**
     * Method used to get the associated SimpleClientManager
     *
     * @return returns the attached SimpleClientManager
     */
    public SimpleClientManager getSimpleClientManager() {
        return simpleClientManager;
    }

    /**
     * Getter for isDisconnectedByServer.
     *
     * @return if the client is disconnected by the server.
     */
    boolean isDisconnectedByServer() {
        return simpleClientManager.isDisconnectedByServer();
    }

    /**
     * Setter for isDisconnectedByServer.
     *
     * @param disconnectedByServer if the client is disconnected by the server.
     */
    void setDisconnectedByServer(boolean disconnectedByServer) {
        simpleClientManager.setDisconnectedByServer(disconnectedByServer);
    }
}