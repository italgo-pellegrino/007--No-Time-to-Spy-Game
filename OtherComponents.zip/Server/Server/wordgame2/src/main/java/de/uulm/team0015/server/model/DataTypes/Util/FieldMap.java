package de.uulm.team0015.server.model.DataTypes.Util;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;

/**
 * Class which represents the board and contains the specific fields.
 *
 * @author Simon Demharter, Marcel Rötzer
 * @version 1.0
 */
public class FieldMap {
    private final Field[][] map;

    /**
     * Constructor of the class FieldMap.
     *
     * @param map the fields of the map.
     */
    public FieldMap(Field[][] map) {
        this.map = map;
    }

    /**
     * Getter for map.
     *
     * @return the map.
     */
    public Field[][] getMap() {
        return map;
    }

    /**
     * Method to validate if the given point exists on the map.
     *
     * @param point The coordinates of the target field.
     * @throws TargetOutOfBoundsException If the given coordinates are out of bounds.
     */
    public void validatePoint(Point point) throws TargetOutOfBoundsException {
        try {
            Field field = map[point.getY()][point.getX()];
        } catch (ArrayIndexOutOfBoundsException exception) {
            throw new TargetOutOfBoundsException("The target field " + point.toString() + " is out of bounds!");
        }
    }

    /**
     * Method to validate if the target field has a character.
     *
     * @param point      The coordinates of the target field.
     * @param characters The characters currently active in the game.
     * @throws InvalidTargetException If there is no character on the target field.
     */
    public void validateFieldHasCharacter(Point point, Set<Character> characters) throws InvalidTargetException {
        if (!fieldHasCharacter(point, characters)) {
            throw new InvalidTargetException("There is no character on the target field " + point.toString() + "!");
        }
    }

    /**
     * Method to validate if the target field has no character.
     *
     * @param point      The coordinates of the target field.
     * @param characters The characters currently active in the game.
     * @throws InvalidTargetException If there is a character on the target field.
     */
    public void validateFieldHasNoCharacter(Point point, Set<Character> characters) throws InvalidTargetException {
        if (fieldHasCharacter(point, characters)) {
            throw new InvalidTargetException("There is a character on the target field " + point.toString() + "!");
        }
    }

    /**
     * Method to validate if the target field is a neighbour.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @throws InvalidTargetException If the target field is not a neighbour.
     */
    public void validateIsNeighbour(Point start, Point target) throws InvalidTargetException {
        if (!isNeighbour(start, target)) {
            throw new InvalidTargetException("The target field " + target.toString() + " is not a neighbour of " + start.toString() + "!");
        }
    }

    /**
     * Method to validate if the target field is a neighbour of the given state.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @param state  The state the target field should have.
     * @throws InvalidTargetException If the target field is not a neighbour or has the wrong state.
     */
    public void validateIsNeighbourOfState(Point start, Point target, FieldStateEnum state) throws InvalidTargetException {
        validateIsNeighbour(start, target);
        getField(target).validateIsState(state);
    }

    /**
     * Method to validate if the target field is a neighbour with a gadget of the given type.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @param gadget The type of gadget the target field should have.
     * @throws InvalidTargetException If the target field is not a neighbour, has no gadget or has the wrong gadget.
     */
    public void validateIsNeighbourWithGadgetOfType(Point start, Point target, GadgetEnum gadget) throws InvalidTargetException {
        validateIsNeighbour(start, target);
        getField(target).validateHasGadgetOfType(gadget);
    }

    /**
     * Method to validate if the target field is in sight.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @throws TargetOutOfSightException If the target field is not in sight.
     * @throws InvalidTargetException    If the target is the character itself.
     */
    public void validateIsInSight(Point start, Point target) throws TargetOutOfSightException, InvalidTargetException {
        if (target.equals(start)) {
            throw new InvalidTargetException("The target field " + target.toString() + "is the player character itself !");
        }
        if (!isInSight(start, target)) {
            throw new TargetOutOfSightException("The target field " + target.toString() + " is not in sight of " + start.toString() + "!");
        }
    }

    /**
     * Method to validate if the target field is in range.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @param range  The range of the gadget.
     * @throws TargetOutOfRangeException If the target field is not in range.
     * @throws InvalidTargetException    If the target is the character itself.
     */
    public void validateIsInRange(Point start, Point target, int range) throws TargetOutOfRangeException, InvalidTargetException {
        if (target.equals(start)) {
            throw new InvalidTargetException("The target field " + target.toString() + "is the player character itself !");
        }
        if (!isInRange(start, target, range)) {
            throw new TargetOutOfRangeException("The target field " + target.toString() + " is not in range of " + start.toString() + "! Expected a range of " + range + " but got " + getRange(start, target) + ".");
        }
    }

    /**
     * Method to validate if the target field is blocked.
     *
     * @param start      The coordinates of the start field.
     * @param target     The coordinates of the target field.
     * @param characters All the characters currently active in the game.
     * @throws TargetBlockedException If the target field is blocked.
     * @throws InvalidTargetException If the target is the character itself.
     */
    public void validateIsNotBlocked(Point start, Point target, Set<Character> characters) throws TargetBlockedException, InvalidTargetException {
        if (target.equals(start)) {
            throw new InvalidTargetException("The target field " + target.toString() + "is the player character itself !");
        }
        if (isBlocked(start, target, characters)) {
            throw new TargetBlockedException("The target field " + target.toString() + " is blocked with a character!");
        }
    }

    /**
     * Method to get the field of the given coordinates.
     *
     * @param point The coordinates of the field.
     * @return The field of the given coordinates.
     */
    public Field getField(Point point) {
        return map[point.getY()][point.getX()];
    }

    /**
     * Method to check if a character is on the given field.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return true if there is a character on the given field, false if not.
     */
    public boolean fieldHasCharacter(Point point, Set<Character> characters) {
        for (Character character : characters) {
            if (character.getCoordinates().equals(point))
                return true;
        }
        return false;
    }

    /**
     * Method to get the character on the field with the given coordinates.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return The character which is on the given field, null if there is none.
     */
    public Character getCharacterOnField(Point point, Set<Character> characters) {
        for (Character character : characters) {
            if (character.getCoordinates().equals(point)) {
                return character;
            }
        }
        return null;
    }

    /**
     * Method to get the neighbour field on top left side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getTopLeftNeighbour(Point point) {
        Point neighbour = new Point(point.getX() - 1, point.getY() - 1);
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on top side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getTopNeighbour(Point point) {
        Point neighbour = new Point(point.getX(), point.getY() - 1);
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on top right side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getTopRightNeighbour(Point point) {
        Point neighbour = new Point(point.getX() + 1, point.getY() - 1);
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on left side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getRightNeighbour(Point point) {
        Point neighbour = new Point(point.getX() + 1, point.getY());
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on bottom right side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getBottomRightNeighbour(Point point) {
        Point neighbour = new Point(point.getX() + 1, point.getY() + 1);
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on bottom side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getBottomNeighbour(Point point) {
        Point neighbour = new Point(point.getX(), point.getY() + 1);
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on bottom left side.
     *
     * @param point The coordinates of the field, null if the neighbour is out of bounds.
     * @return The neighbour field.
     */
    public Point getBottomLeftNeighbour(Point point) {
        Point neighbour = new Point(point.getX() - 1, point.getY() + 1);
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbour field on left side.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour field, null if the neighbour is out of bounds.
     */
    public Point getLeftNeighbour(Point point) {
        Point neighbour = new Point(point.getX() - 1, point.getY());
        try {
            validatePoint(neighbour);
        } catch (TargetOutOfBoundsException exception) {
            return null;
        }
        return neighbour;
    }

    /**
     * Method to get the neighbours of a given field.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbours of the given field if they are valid.
     */
    public Set<Point> getNeighbours(Point point) {
        Set<Point> neighbours = new HashSet<>();
        if (getTopLeftNeighbour(point) != null) {
            neighbours.add(getTopLeftNeighbour(point));
        }
        if (getTopNeighbour(point) != null) {
            neighbours.add(getTopNeighbour(point));
        }
        if (getTopRightNeighbour(point) != null) {
            neighbours.add(getTopRightNeighbour(point));
        }
        if (getRightNeighbour(point) != null) {
            neighbours.add(getRightNeighbour(point));
        }
        if (getBottomRightNeighbour(point) != null) {
            neighbours.add(getBottomRightNeighbour(point));
        }
        if (getBottomNeighbour(point) != null) {
            neighbours.add(getBottomNeighbour(point));
        }
        if (getBottomLeftNeighbour(point) != null) {
            neighbours.add(getBottomLeftNeighbour(point));
        }
        if (getLeftNeighbour(point) != null) {
            neighbours.add(getLeftNeighbour(point));
        }
        return neighbours;
    }

    /**
     * Method to check if the target field is a neighbour of the given field.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @return true if the target field is a neighbour, false if not.
     */
    public boolean isNeighbour(Point start, Point target) {
        for (Point point : getNeighbours(start)) {
            if (point.equals(target)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to check if adjacent fields to the character have a character on them.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return true if there is at least one neighbour field with a character, false if not.
     */
    public boolean neighbourHasCharacter(Point point, Set<Character> characters) {
        for (Point neighbours : getNeighbours(point)) {
            if (fieldHasCharacter(neighbours, characters)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to get the every character on neighbour fields.
     *
     * @param point      The coordinates of the field.
     * @param characters The characters currently active in the game.
     * @return The character which is on the given field, null if there is none.
     */
    public Set<Character> getNeighbourCharacters(Point point, Set<Character> characters) {
        Set<Character> neighbourCharacters = new HashSet<>();
        for (Point neighbours : getNeighbours(point)) {
            if (fieldHasCharacter(neighbours, characters)) {
                neighbourCharacters.add(getCharacterOnField(neighbours, characters));
            }
        }
        return neighbourCharacters;
    }

    /**
     * Method to count neighbour characters.
     *
     * @param point      The coordinates of the field.
     * @param characters The character currently active in the game.
     * @return The count of neighbour characters.
     */
    public int getNeighbourCharacterCount(Point point, Set<Character> characters) {
        return getNeighbourCharacters(point, characters).size();
    }

    /**
     * Method check if there are neighbour characters with the property babysitter.
     *
     * @param character         The target character.
     * @param characters        Every character on the map.
     * @param charactersPlayer1 Every character of player one on the map.
     * @param charactersPlayer2 Every character of player two on the map.
     * @return True if there is at least one neighbour character with the property babysitter, false if not.
     */
    public boolean checkBabysitter(Character character, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) {
        if (neighbourHasCharacter(character.getCoordinates(), characters)) {
            for (Character neighbour : getNeighbourCharacters(character.getCoordinates(), characters)) {
                if (neighbour.hasProperty(PropertyEnum.BABYSITTER)) {
                    // Check if same faction
                    if ((character.isMemberOfFaction(charactersPlayer1) && neighbour.isMemberOfFaction(charactersPlayer1))
                            || (character.isMemberOfFaction(charactersPlayer2) && neighbour.isMemberOfFaction(charactersPlayer2))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Method to get all neighbours with the property babysitter.
     *
     * @param character         The target character.
     * @param characters        Every character on the map.
     * @param charactersPlayer1 Every character of player one on the map.
     * @param charactersPlayer2 Every character of player two on the map.
     * @return Set of neighbour characters with the property babysitter.
     */
    public Set<Character> getBabysitters(Character character, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) {
        Set<Character> babysitters = new HashSet<>();
        for (Character neighbour : getNeighbourCharacters(character.getCoordinates(), characters)) {
            if (neighbour.hasProperty(PropertyEnum.BABYSITTER)) {
                // Check if same faction
                if ((character.isMemberOfFaction(charactersPlayer1) && neighbour.isMemberOfFaction(charactersPlayer1))
                        || (character.isMemberOfFaction(charactersPlayer2) && neighbour.isMemberOfFaction(charactersPlayer2))) {
                    babysitters.add(neighbour);
                }
            }
        }
        return babysitters;
    }

    /**
     * Method to get the neighbours of the given field which have the given state.
     *
     * @param point The coordinates of the field.
     * @param state The state of the neighbour fields.
     * @return The coordinates of the neighbour fields which have the given state, null if there are none.
     */
    public Set<Point> getNeighboursOfState(Point point, FieldStateEnum state) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighbours(point)) {
            if (getField(neighbour).isState(state)) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to check if any neighbour of the given field is of the given state.
     *
     * @param point The coordinates of the field.
     * @param state The state of the field.
     * @return true if at least one neighbour field is of the given state, false if not.
     */
    public boolean hasNeighboursOfState(Point point, FieldStateEnum state) {
        return !getNeighboursOfState(point, state).isEmpty();
    }

    /**
     * Method to get a random free neighbour point with no gadget and character on it.
     *
     * @param point      The coordinates of the field.
     * @param characters All characters on the map.
     * @return A random neighbour point.
     */
    public Point getRandomFreeNeighbour(Point point, Set<Character> characters) {
        // All free neighbour fields
        Set<Point> freeNeighbours = getNeighboursOfState(point, FieldStateEnum.FREE);
        // Remove fields with a gadget on it
        freeNeighbours.removeIf(neighbour -> getField(neighbour).hasGadget());
        // Remove fields with a character on it
        freeNeighbours.removeIf(neighbour -> fieldHasCharacter(neighbour, characters));

        if (freeNeighbours.isEmpty()) {
            return null;
        }

        return getRandomPoint(freeNeighbours);
    }

    /**
     * Method to get all the neighbours of the given field which have a gadget.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which have a gadget, null if there are none.
     */
    public Set<Point> getNeighboursWithGadget(Point point) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighbours(point)) {
            if (getField(neighbour).hasGadget()) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which have the given gadget.
     *
     * @param point      The coordinates of the field.
     * @param gadgetType The type of the gadget.
     * @return The coordinates of the neighbour fields which have the given gadget, null if there are none.
     */
    public Set<Point> getNeighboursWithGadgetOfType(Point point, GadgetEnum gadgetType) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighboursWithGadget(point)) {
            if (getField(neighbour).hasGadgetOfType(gadgetType)) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which are destroyed.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which are destroyed, null if there are none.
     */
    public Set<Point> getDestroyedNeighbours(Point point) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighbours(point)) {
            if (getField(neighbour).isDestroyed()) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which are inverted.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which are inverted, null if there are none.
     */
    public Set<Point> getInvertedNeighbours(Point point) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighbours(point)) {
            if (getField(neighbour).isInverted()) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which have the given safe index.
     *
     * @param point     The coordinates of the field.
     * @param safeIndex The index of the safe.
     * @return The coordinates of the neighbour fields which have the given safe index, null if there are none.
     */
    public Set<Point> getNeighboursWithSafeIndex(Point point, int safeIndex) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbourPoint : getNeighbours(point)) {
            if (getField(neighbourPoint).hasSafeIndex(safeIndex)) {
                neighbours.add(neighbourPoint);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which can are foggy.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbour fields which are foggy, null if there are none.
     */
    public Set<Point> getFoggyNeighbours(Point point) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighbours(point)) {
            if (getField(neighbour).isFoggy()) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get all the neighbours of the given field which can be moved on to.
     *
     * @param point The coordinates of the field.
     * @return The coordinates of the neighbours fields which are accessible, null if there are none.
     */
    public Set<Point> getAccessibleNeighbours(Point point) {
        Set<Point> neighbours = new HashSet<>();
        for (Point neighbour : getNeighbours(point)) {
            if (getField(neighbour).isAccessible()) {
                neighbours.add(neighbour);
            }
        }
        return neighbours;
    }

    /**
     * Method to get every field of the given coordinates.
     *
     * @param points The coordinates of the fields.
     * @return The fields of the given coordinates.
     */
    public Set<Field> getFields(Set<Point> points) {
        Set<Field> fields = new HashSet<>();

        for (Point point : points) {
            fields.add(getField(point));
        }
        return fields;
    }

    /**
     * Method to get the coordinates of every field of the map.
     *
     * @return The coordinates of the fields of the map.
     */
    public Set<Point> getPointsOfMap() {
        int x = 0;
        int y = 0;
        Set<Point> points = new HashSet<>();

        for (int i = y; i < map.length; i++) {
            for (int j = x; j < map[y].length; j++) {
                try {
                    Point point = new Point(j, i);
                    validatePoint(point);
                    points.add(point);
                } catch (TargetOutOfBoundsException exception) {
                    // don't add invalid points to the set
                }
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which are of the given state.
     *
     * @param state The state of the field.
     * @return The the coordinates of fields which are of the given state, null if there are none.
     */
    public Set<Point> getFieldsOfState(FieldStateEnum state) {
        Set<Point> points = new HashSet<>();

        for (Point point : getPointsOfMap()) {
            if (getField(point).isState(state)) {
                points.add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which have a gadget.
     *
     * @return The the coordinates of fields of the map which have a gadget, null if there are none.
     */
    public Set<Point> getFieldsWithGadgets() {
        Set<Point> points = new HashSet<>();

        for (Point point : getPointsOfMap()) {
            if (getField(point).hasGadget()) {
                points.add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which has the gadget of the given type.
     *
     * @param gadget The type of the gadget.
     * @return The coordinates of the field of the map which has the gadget of the given type, null if there is none.
     */
    public Set<Point> getFieldsWithGadgetOfType(GadgetEnum gadget) {
        Set<Point> points = new HashSet<>();

        for (Point point : getFieldsWithGadgets()) {
            if (getField(point).hasGadgetOfType(gadget)) {
                points.add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which are destroyed.
     *
     * @return The coordinates of the fields of the map which are destroyed, null if there are none.
     */
    public Set<Point> getDestroyedFields() {
        Set<Point> points = new HashSet<>();

        for (Point point : getPointsOfMap()) {
            if (getField(point).isDestroyed()) {
                points.add(point);
            }
        }
        return points;
    }

    /**
     * Method to get the coordinates of all the fields of the map which are inverted.
     *
     * @return The coordinates of thefields of the map which are inverted, null if there are none.
     */
    public Set<Point> getInvertedFields() {
        Set<Point> points = new HashSet<>();

        for (Point point : getPointsOfMap()) {
            if (getField(point).isInverted()) {
                points.add(point);
            }
        }
        return points;
    }


    /**
     * Method to get all the fields of the map which are foggy.
     *
     * @return The coordinates of the fields of the map which are foggy, null if there are none.
     */
    public Set<Point> getFoggyFields() {
        Set<Point> points = new HashSet<>();

        for (Point point : getPointsOfMap()) {
            if (getField(point).isFoggy()) {
                points.add(point);
            }
        }
        return points;
    }

    /**
     * Method to get all the field of the map which are free and have no character.
     *
     * @param characters The characters currently active in the game.
     * @return The coordinates of the fields of the map which are free and have no character.
     */
    public Set<Point> getFreeFields(Set<Character> characters) {
        Set<Point> points = new HashSet<>();

        for (Point point : getFieldsOfState(FieldStateEnum.FREE)) {
            if (!fieldHasCharacter(point, characters)) {
                points.add(point);
            }
        }
        return points;
    }

    /**
     * Method to check if a field on the map got updated.
     *
     * @return true if a field on the map got updated, false if not.
     */
    public boolean isMapUpdated() {
        for (Point point : getPointsOfMap()) {
            if (getField(point).isUpdated()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to get the coordinates of the fields in between two points.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @return The coordinates of the fields in between the given points.
     */
    public Set<Point> getPointsInBetween(Point start, Point target) {
        Set<Point> points = new HashSet<>();

        // The coordinates of the start field and target field
        int x = start.getX();
        int y = start.getY();
        int xTarget = target.getX();
        int yTarget = target.getY();

        // The x and y ranges to the target field
        int xRange = Math.abs(xTarget - x);
        int yRange = Math.abs(yTarget - y);

        // The number of fields to check
        int n = xRange + yRange - 1;

        // The x and y direction from the start to the target field
        int xDirection = xTarget > x ? 1 : -1;
        int yDirection = yTarget > y ? 1 : -1;

        // The offset to the target point
        int offset = xRange - yRange;

        // For intermediate points which are not in the middle of the grid, it suffices to multiply by 2
        xRange *= 2;
        yRange *= 2;

        while (n > 0) {
            // Go in x direction
            if (offset > 0) {
                x += xDirection;
                offset -= yRange;
            }

            // Go in y direction
            else if (offset < 0) {
                y += yDirection;
                offset += xRange;
            }

            // Go diagonal, get both fields which are tangent to the line
            else {
              //  points.add(new Point(x + xDirection, y));
              //  points.add(new Point(x, y + yDirection));
                x += xDirection;
                y += yDirection;
                offset += xRange - yRange;
                n--;
            }
            if (n > 0) {
                points.add(new Point(x, y));
            }
            n--;
        }
        return points;
    }

    /**
     * Method get the shortest range between two points.
     *
     * @param start  Coordinates of the character.
     * @param target Coordinates of the target.
     * @return true if target is in range, false if not.
     */
    public int getRange(Point start, Point target) {
        return Math.max(Math.abs(start.getX() - target.getX()), Math.abs(start.getY() - target.getY()));
    }

    /**
     * Method to check if a target is in range of the character.
     *
     * @param start  Coordinates of the character.
     * @param target Coordinates of the target.
     * @param range  Range of the character.
     * @return true if target is in range, false if not.
     */
    public boolean isInRange(Point start, Point target, int range) {
        return (getRange(start, target) <= range);
    }

    /**
     * Method to check if a target is in sight of the character.
     *
     * @param start  The coordinates of the start field.
     * @param target The coordinates of the target field.
     * @return true if the target field is in sight, false if not.
     */
    public boolean isInSight(Point start, Point target) {
        for (Point point : getPointsInBetween(start, target)) {
            if (getField(point).isState(FieldStateEnum.WALL) || getField(point).isState(FieldStateEnum.FIREPLACE) || getField(point).isFoggy()) {
                return false;
            }
        }
        return true;
    }

    /**
     * Method to check if a target is blocked by a character.
     *
     * @param start      The coordinates of the start field.
     * @param target     The coordinates of the target field.
     * @param characters All the characters currently active in the game.
     * @return true if the target field is blocked, false if not.
     */
    public boolean isBlocked(Point start, Point target, Set<Character> characters) {
        for (Point point : getPointsInBetween(start, target)) {
            if (fieldHasCharacter(point, characters)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to get a random point of a given list of coordinates.
     *
     * @param points The list of coordinates.
     * @return The chosen point.
     */
    public Point getRandomPoint(Set<Point> points) {
        int index = new Random().nextInt(points.size());
        Iterator<Point> iterator = points.iterator();
        for (int i = 0; i < index; i++) {
            iterator.next();
        }
        return iterator.next();
    }

    /**
     * Method to fill all empty bar tables of the map with a cocktail.
     */
    public void fillBarTables() {
        for (Point point : getFieldsOfState(FieldStateEnum.BAR_TABLE)) {
            if (!getField(point).hasGadget()) {
                getField(point).setGadget(new Cocktail());
            }
        }
    }

    /**
     * Method to heal every character on bar seat fields on the map.
     *
     * @param characters Set of all characters currently in the game.
     */
    public void healCharactersOnBarSeats(Set<Character> characters) {
        for (Point point : getFieldsOfState(FieldStateEnum.BAR_SEAT)) {
            if (fieldHasCharacter(point, characters)) {
                getCharacterOnField(point, characters).setHp(100);
            }
        }
    }

    /**
     * This method can be used to create a String which displays the map with all characters and gadgets on it.
     * Use this method for debug only
     *
     * @param characters The characters.
     * @return The Map as string with all characters and gadgets on it.
     */
    public String getMapAsString(Set<Character> characters) {
        StringBuilder builder = new StringBuilder();
        builder.append("\n");
        int rowNr = 0;
        for (Field[] toPrint : map) {
            StringBuilder format = new StringBuilder();
            String[] line = new String[toPrint.length];
            for (int j = 0; j < toPrint.length; j++) {
                format.append("|%15s");
                line[j] = toPrint[j].getState().toString();
                if (toPrint[j].getGadget() != null) {
                    line[j] = toPrint[j].getGadget().getGadgetEnum().toString();
                }
                for (Character ch : characters) {
                    if (ch.getCoordinates().getX() == j && ch.getCoordinates().getY() == rowNr) {
                        line[j] = ch.getName();
                    }
                }
            }
            builder.append(String.format(format.toString(), (Object[]) line));
            builder.append("|");
            builder.append("\n");
            rowNr++;
        }
        return builder.toString();
    }
}
