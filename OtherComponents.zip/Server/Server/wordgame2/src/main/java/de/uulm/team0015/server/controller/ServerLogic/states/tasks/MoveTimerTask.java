package de.uulm.team0015.server.controller.ServerLogic.states.tasks;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogic.states.ServerState;

import java.util.TimerTask;

/**
 * MoveTimerTask that will be run upon exceeding of the time limit for a move.
 */
public class MoveTimerTask extends TimerTask {
    private ServerState parent;
    private SimpleClientManager manager;

    /**
     * Constructor to create a new MoveTimerTask.
     *
     * @param parent  The server state, which the task is used in.
     * @param manager SimpleClientManager, for which the timer is running.
     */
    public MoveTimerTask(ServerState parent, SimpleClientManager manager) {
        this.parent = parent;
        this.manager = manager;
    }

    /**
     * Will call the onMoveTimeout-method in the parent state.
     */
    @Override
    public void run() {
        parent.onMoveTimeout(manager);
    }
}
