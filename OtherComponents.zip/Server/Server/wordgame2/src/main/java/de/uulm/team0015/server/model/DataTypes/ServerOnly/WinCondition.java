package de.uulm.team0015.server.model.DataTypes.ServerOnly;

import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.model.Enumerations.VictoryEnum;

import java.util.Random;
import java.util.UUID;

/**
 * Class for saving the values of the different win conditions.
 *
 * @author Alexander Preiß, Max Raedler
 * @version 1.0
 */
public class WinCondition {
    private int ipPlayer1 = 0;
    private int ipPlayer2 = 0;

    private int drankCocktailsPlayer1 = 0;
    private int drankCocktailsPlayer2 = 0;

    private int spilledCocktailsPlayer1 = 0;
    private int spilledCocktailsPlayer2 = 0;

    private boolean returnedCollarPlayer1 = false;
    private boolean returnedCollarPlayer2 = false;

    private int damageTakenPlayer1 = 0;
    private int damageTakenPlayer2 = 0;

    /**
     * Getter for ipPlayer1.
     *
     * @return The amount of ip player1 has collected.
     */
    public int getIpPlayer1() {
        return ipPlayer1;
    }

    /**
     * Setter for ipPlayer1.
     *
     * @param ipPlayer1 The amount of ip points player1 has collected.
     */
    public void setIpPlayer1(int ipPlayer1) {
        this.ipPlayer1 = ipPlayer1;
    }

    /**
     * Getter for ipPlayer2.
     *
     * @return The amount of ip player2 has collected.
     */
    public int getIpPlayer2() {
        return ipPlayer2;
    }

    /**
     * Setter for ipPlayer2.
     *
     * @param ipPlayer2 The amount of ip player2 has collected.
     */
    public void setIpPlayer2(int ipPlayer2) {
        this.ipPlayer2 = ipPlayer2;
    }

    /**
     * Getter for drinkedCocktailsPlayer1.
     *
     * @return The number of cocktails that player1 used as a drink.
     */
    public int getDrankCocktailsPlayer1() {
        return drankCocktailsPlayer1;
    }

    /**
     * Setter for drinkedCocktailsPlayer1.
     *
     * @param drankCocktailsPlayer1 The number of cocktails that player1 used as a drink.
     */
    public void setDrankCocktailsPlayer1(int drankCocktailsPlayer1) {
        this.drankCocktailsPlayer1 = drankCocktailsPlayer1;
    }

    /**
     * Getter for drinkedCocktailsPlayer2.
     *
     * @return The number of cocktails that player2 used as a drink.
     */
    public int getDrankCocktailsPlayer2() {
        return drankCocktailsPlayer2;
    }

    /**
     * Setter for drinkedCocktailsPlayer2.
     *
     * @param drankCocktailsPlayer2 The number of cocktails that player2 used as a drink.
     */
    public void setDrankCocktailsPlayer2(int drankCocktailsPlayer2) {
        this.drankCocktailsPlayer2 = drankCocktailsPlayer2;
    }

    /**
     * Getter for getSpilledCocktailsPlayer1.
     *
     * @return The amount of cocktails spilled by player1.
     */
    public int getSpilledCocktailsPlayer1() {
        return spilledCocktailsPlayer1;
    }

    /**
     * Setter for getSpilledCocktailsPlayer1.
     *
     * @param spilledCocktailsPlayer1 The amount of cocktails spilled by player1.
     */
    public void setSpilledCocktailsPlayer1(int spilledCocktailsPlayer1) {
        this.spilledCocktailsPlayer1 = spilledCocktailsPlayer1;
    }

    /**
     * Getter for getSpilledCocktailsPlayer2.
     *
     * @return The amount of cocktails spilled by player2.
     */
    public int getSpilledCocktailsPlayer2() {
        return spilledCocktailsPlayer2;
    }

    /**
     * Setter for getSpilledCocktailsPlayer2.
     *
     * @param spilledCocktailsPlayer2 The amount of cocktails spilled by player2.
     */
    public void setSpilledCocktailsPlayer2(int spilledCocktailsPlayer2) {
        this.spilledCocktailsPlayer2 = spilledCocktailsPlayer2;
    }

    /**
     * Getter for isReturnedCollarPlayer1.
     *
     * @return True of player1 returned the collar.
     */
    public boolean isReturnedCollarPlayer1() {
        return returnedCollarPlayer1;
    }

    /**
     * Setter for isReturnedCollarPlayer1.
     *
     * @param returnedCollarPlayer1 True of player1 returned the collar.
     */
    public void setReturnedCollarPlayer1(boolean returnedCollarPlayer1) {
        this.returnedCollarPlayer1 = returnedCollarPlayer1;
    }

    /**
     * Getter for isReturnedCollarPlayer2.
     *
     * @return True of player2 returned the collar.
     */
    public boolean isReturnedCollarPlayer2() {
        return returnedCollarPlayer2;
    }

    /**
     * Setter for isReturnedCollarPlayer2.
     *
     * @param returnedCollarPlayer2 True of player2 returned the collar.
     */
    public void setReturnedCollarPlayer2(boolean returnedCollarPlayer2) {
        this.returnedCollarPlayer2 = returnedCollarPlayer2;
    }

    /**
     * Getter for getDamageTakenPlayer1.
     *
     * @return The amount of damage factionPlayer1 has taken..
     */
    public int getDamageTakenPlayer1() {
        return damageTakenPlayer1;
    }

    /**
     * Setter for getDamageTakenPlayer1.
     *
     * @param damageTakenPlayer1 The amount of damage factionPlayer1 has taken.
     */
    public void setDamageTakenPlayer1(int damageTakenPlayer1) {
        this.damageTakenPlayer1 = damageTakenPlayer1;
    }

    /**
     * Getter for getDamageTakenPlayer2.
     *
     * @return The amount of damage factionPlayer2 has taken.
     */
    public int getDamageTakenPlayer2() {
        return damageTakenPlayer2;
    }

    /**
     * Setter for getDamageTakenPlayer2.
     *
     * @param damageTakenPlayer2 The amount of damage factionPlayer2 has taken.
     */
    public void setDamageTakenPlayer2(int damageTakenPlayer2) {
        this.damageTakenPlayer2 = damageTakenPlayer2;
    }

    /**
     * Method to add ipPoints which player1 gets after a successful game action.
     *
     * @param points The amount of ipPoints added.
     */
    public void addIpPlayer1(int points) {
        ipPlayer1 += points;
    }

    /**
     * Method to add ipPoints which player2 gets after a successful game action.
     *
     * @param points The amount of ipPoints added.
     */
    public void addIpPlayer2(int points) {
        ipPlayer2 += points;
    }

    /**
     * Method when a character in factionPlayer1 drinks a cocktail.
     */
    public void addDrankCocktailPlayer1() {
        drankCocktailsPlayer1 += 1;
    }

    /**
     * Method when a character in factionPlayer2 drinks a cocktail.
     */
    public void addDrankCocktailPlayer2() {
        drankCocktailsPlayer2 += 1;
    }

    /**
     * Method when a character in factionPlayer1 spills a cocktail.
     */
    public void addSpilledCocktailPlayer1() {
        spilledCocktailsPlayer1 += 1;
    }

    /**
     * Method when a character in factionPlayer1 spills a cocktail.
     */
    public void addSpilledCocktailPlayer2() {
        spilledCocktailsPlayer2 += 1;
    }

    /**
     * Method when a character in factionPlayer1 takes damage.
     *
     * @param damage The amount of damage the character takes.
     */
    public void addDamageTakenPlayer1(int damage) {
        damageTakenPlayer1 += damage;
    }

    /**
     * Method when a character in factionPlayer2 takes damage.
     *
     * @param damage The amount of damage the character takes.
     */
    public void addDamageTakenPlayer2(int damage) {
        damageTakenPlayer2 += damage;
    }

    /**
     * This method returns the winner based on the WinCondition
     *
     * @param player1 UUID of player1
     * @param player2 UUID of player2
     * @return The UUID of the winner
     */
    public UUID getWinner(UUID player1, UUID player2) {
    	/**
    	 * IP Punkte werden je nach Spieler aufsummiert!
    	 */
    	ipPlayer1 = calcIpPointsForPlayer1();
    	ipPlayer2 = calcIpPointsForPlayer2();
    	
        if (ipPlayer1 > ipPlayer2) {
            return player1;
        } else if (ipPlayer1 < ipPlayer2) {
            return player2;
        } else {
            if (returnedCollarPlayer1) {
                return player1;
            } else if (returnedCollarPlayer2) {
                return player2;
            } else {
                if (drankCocktailsPlayer1 > drankCocktailsPlayer2) {
                    return player1;
                } else if (drankCocktailsPlayer1 < drankCocktailsPlayer2) {
                    return player2;
                } else {
                    if (spilledCocktailsPlayer1 > spilledCocktailsPlayer2) {
                        return player1;
                    } else if (spilledCocktailsPlayer1 < spilledCocktailsPlayer2) {
                        return player2;
                    } else {
                        if (damageTakenPlayer1 < damageTakenPlayer2) {
                            return player1;
                        } else if (damageTakenPlayer1 > damageTakenPlayer2) {
                            return player2;
                        } else {
                            Random random = new Random();
                            int rand = random.nextInt(1);
                            if (rand == 1) {
                                return player1;
                            } else {
                                return player2;
                            }
                        }
                    }
                }
            }
        }
    }
    
    
    /**
     * Hinzugefügt am 19.07.
     * 
     * Diese Methode kalkuliert die IP Punkte des Spieler 1
     * 
     * @param player: Spieler 
     * @return Anzahl an gesammelten IP Punkten
     */
    public int calcIpPointsForPlayer1() {
    	int sumOfIps = 0;
    	for(de.uulm.team0015.server.model.DataTypes.Util.Character ch : MainServerLogic.player1Characters ) {
    		sumOfIps += ch.getChips() * MainServerLogic.initialMatchconfig.getChipsToIpFactor();
    		sumOfIps += ch.getIp();
    	}
    	return sumOfIps;
    }
    
    
    /**
     * Diese Methode kalkuliert die IP Punkte des Spieler 2
     * 
     * @param player: Spieler 
     * @return Anzahl an gesammelten IP Punkten
     */
    public int calcIpPointsForPlayer2() {
    	int sumOfIps = 0;
    	for(de.uulm.team0015.server.model.DataTypes.Util.Character ch : MainServerLogic.player2Characters ) {
    		sumOfIps += ch.getChips() * MainServerLogic.initialMatchconfig.getChipsToIpFactor();
    		sumOfIps += ch.getIp();
    	}
    	return sumOfIps;
    }
    
    

    /**
     * This method returns the VictoryEnum based on the WinCondition
     *
     * @return The correct VictoryEnum based on the WinCondition
     */
    public VictoryEnum getVictoryEnum() {
        if (ipPlayer1 != ipPlayer2) {
            return VictoryEnum.VICTORY_BY_IP;
        } else if (returnedCollarPlayer1 || returnedCollarPlayer2) {
            return VictoryEnum.VICTORY_BY_COLLAR;
        } else if (drankCocktailsPlayer1 != drankCocktailsPlayer2) {
            return VictoryEnum.VICTORY_BY_COLLAR;
        } else if (spilledCocktailsPlayer1 != spilledCocktailsPlayer2) {
            return VictoryEnum.VICTORY_BY_SPILLING;
        } else if (damageTakenPlayer1 != damageTakenPlayer2) {
            return VictoryEnum.VICTORY_BY_HP;
        } else {
            return VictoryEnum.VICTORY_BY_RANDOMNESS;
        }
    }
}