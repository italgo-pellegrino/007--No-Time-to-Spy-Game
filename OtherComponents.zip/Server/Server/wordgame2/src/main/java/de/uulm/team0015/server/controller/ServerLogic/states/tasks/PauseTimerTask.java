package de.uulm.team0015.server.controller.ServerLogic.states.tasks;

import de.uulm.team0015.server.controller.ServerLogic.states.timer.PausableTimer;

import java.util.TimerTask;

/**
 * PauseTimerTask used by PausableTimer.class
 */
public class PauseTimerTask extends TimerTask {
    private PausableTimer parent;

    /**
     * Constructor for PauseTimerTask.
     *
     * @param parent The PausableTimer using the task.
     */
    public PauseTimerTask(PausableTimer parent) {
        this.parent = parent;
    }

    /**
     * Will call the countDown-method in the parent PausableTimer
     */
    @Override
    public void run() {
        parent.countDown(1);
    }
}