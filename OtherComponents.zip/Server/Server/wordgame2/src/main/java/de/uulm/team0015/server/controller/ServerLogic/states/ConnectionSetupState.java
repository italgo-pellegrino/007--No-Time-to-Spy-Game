package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.ClientInformation;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Send.GameLeftMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * This class is representing the ConnectionSetupState which is the first state of the server.
 * It overrides the onHelloMessage and the onGameLeaveMessage in the abstract class ServerState.
 * By using this class you can ensure that all incoming messages from all clients are handled correctly.
 *
 * @author Tom Weisser, Max Raedler
 * @see ServerState
 */
public class ConnectionSetupState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(ConnectionSetupState.class.getName());
    private final ReentrantLock registrationLock;

    /**
     * Constructor and LOGGER setup.
     * Also sets the activeState to CONNECTION_SETUP_STATE.
     */
    public ConnectionSetupState() {
        super();
        ServerLogger.addHandler(LOGGER);
        ServerState.activeState = ServerStateEnum.CONNECTION_SETUP_STATE;
        LOGGER.warning("Entered the ConnectionSetupState");
        registrationLock = new ReentrantLock();
        ServerShell.print("Waiting for the connection of 2 players.");
    }

    /**
     * Override the onHelloMessage method in ServerState.
     * <p>
     * Only call this method if you ensured that the helloMessage is valid!
     * <p>
     * If the Client wants to be:
     * A spectator the handle process be passed on to the onSpectatorHello Method.
     * A Player he will registered by giving him a ClientInformation and he will be set as player1 or player2.
     * <p>
     * If the manager is set to player2 this class will call the constructor of the DecisionPhaseState
     * by doing that the Server-State saved in the mainServerLogic is set to DecisionPhaseState as well.
     * <p>
     * This method also sends a reply the connected client in the manager.
     * If the Client is already registered (his ClientInformation is not null) onFalseMessage will be called
     *
     * @param manager      The manager which holds the connection.
     * @param helloMessage The received Message.
     */
    @Override
    public void onHelloMessage(SimpleClientManager manager, HelloMessage helloMessage) {
    	
        // Lock to prevent players from registering at the same time.
        registrationLock.lock();
        
        /**
         * Änderung am 14.07. : Jeder Name kann höchstens nur einmal vergeben werden!! (s. Standard)
         * 
         * Basisfall: Name existiert bereits und Spieler 1 oder 2 sind nicht bereits verbunden! (Fehlerfall wird nämlich unten bereits abgeprüft)
         */
        if(ServerState.registeredNames.contains(helloMessage.name) && mainServerLogic.player1 != manager) {
        	LOGGER.finer("Client has sent a Hello Message with a required name that is already in use!");
        	System.out.println("Name already in use!!");
            onFalseMessage(manager, ErrorTypeEnum.NAME_NOT_AVAILABLE, "Name is already in use.");
            registrationLock.unlock();
            return;
        }
        else {
        	/**
        	 * Name wird im jeweiligen ClientManager gesetzt
        	 */
        	manager.name = helloMessage.name;
        	/**
        	 * Datenstruktur verwaltet alle Namen!
        	 */
        	ServerState.registeredNames.add(helloMessage.name);
        }
        
        
        
        if (helloMessage.role.equals(RoleEnum.SPECTATOR)) {
            // Unlock if not a player
            registrationLock.unlock();
            onSpectatorHello(manager, helloMessage);
        } else if (helloMessage.role.equals(RoleEnum.PLAYER) || helloMessage.role.equals(RoleEnum.AI)) {
            //Check if Player is already connected as player1 or player2
            if (mainServerLogic.player1 == manager) {
                LOGGER.finer("Player1 has sent a new illegal hello message");
                onFalseMessage(manager, ErrorTypeEnum.ALREADY_SERVING, "Sent HelloMessage, despite being already registered.");
                mainServerLogic.player1 = null;
                registrationLock.unlock();
                return;
            }
            // Create HelloReplyMessage
            HelloReplyMessage helloReplyMessage = HelloReplyMessage.createHelloReplyMessage(mainServerLogic.sessionID,
                    mainServerLogic.initialScenario,
                    mainServerLogic.initialMatchconfig,
                    mainServerLogic.initialCharacterInformation,
                    null /*This will be filled later*/,
                    "You are now registered as a player."
            );
            if (mainServerLogic.player1 == null) {
                //Handle the Message as player1

                //Create new Client information
                manager.setClientInformation(new ClientInformation(mainServerLogic.clientIdPlayer1, helloMessage.name, helloMessage.role));

                // Send HelloReplyMessage
                helloReplyMessage.clientId = mainServerLogic.clientIdPlayer1;
                helloReplyMessage.debugMessage += 1;
                manager.sendMessage(helloReplyMessage);

                mainServerLogic.player1 = manager;
                LOGGER.finer(manager.ipInformation + " in now registered as player1");
                ServerShell.print("Player 1 is now connected to the server, waiting for one more player.");
            } else {
                //Handle the Message as player2

                //Create new Client information
                manager.setClientInformation(new ClientInformation(mainServerLogic.clientIdPlayer2, helloMessage.name, helloMessage.role));

                // Send HelloReplyMessage
                helloReplyMessage.debugMessage += 2;
                helloReplyMessage.clientId = mainServerLogic.clientIdPlayer2;
                manager.sendMessage(helloReplyMessage);

                mainServerLogic.player2 = manager;
                LOGGER.finer(manager.ipInformation + " in now registered as player2");
                ServerShell.print("Player 2 is now connected to the server. The game will start now.");
                //Switch to next State
                new DecisionPhaseState();
            }
            // Unlock when done
            registrationLock.unlock();
        }
    }


    /**
     * Override the onGameLeaveMessage method in ServerState.
     * <p>
     * Before calling the method ensure that the clientInformation of the given manager is not null!
     * <p>
     * If the Client is:
     * A spectator the handle process be passed on to the onSpectatorLeave Method.
     * A player1 he gets a GameLeftMessage and is disconnected. And the player1 variable in the mainServerLogic is set to null.
     * <p>
     * Logically the manager should never be a player2, however if so this method does nothing.
     *
     * @param manager The manager which holds the connection.
     */
    @Override
    public void onGameLeaveMessage(SimpleClientManager manager) {
        // Lock to prevent registration while player disconnects
        registrationLock.lock();
        // manager is Player(1): disconnect the sending player -> unregister player 1
        if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
            mainServerLogic.player1 = null;
            // Create and send GameLeftMessage
            GameLeftMessage gameLeftMessage = GameLeftMessage.createGameLeftMessage(manager.clientInformation.getClientId(),
                    manager.clientInformation.getClientId(),
                    "Your connection is now closed");
            manager.sendMessage(gameLeftMessage);
            // Disconnect client
            manager.disconnect();
            ServerShell.print("Player 1 has left the game, waiting for two more players.");
            LOGGER.finer("player1 has left the game. A new client can now connect as player1");
            /**
             * Änderung am 14.07: Bereits registrierte Namen sollen frei werden!
             */
            if(manager != null) {
            	super.registeredNames.remove(manager.name);
            }
            // Unlock when unregistering is done
            registrationLock.unlock();
        } else if (manager.clientInformation.getRole().equals(RoleEnum.SPECTATOR)) {
            // Unlock if spectator
            registrationLock.unlock();
            onSpectatorLeave(manager);
        }
    }

    /**
     * This method will handle a disconnect from player 1 and frees his slot.
     *
     * @param manager SimpleClientManager of the disconnected player client.
     */
    @Override
    void onPlayerDisconnect(SimpleClientManager manager) {
        // Lock to prevent registration while player disconnects
        registrationLock.lock();
        ServerShell.print("Player 1 has left the game, waiting for two more players.");
        mainServerLogic.player1 = null;
        // unlock when unregistering is done
        
        /**
         * Änderung am 14.07.: Name muss wieder freigegeben werden!
         */
        registeredNames.remove(manager.name);
        registrationLock.unlock();
    }
}
