package de.uulm.team0015.server.model.DataTypes.Operations;

import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;

import java.util.UUID;

/**
 * Class for the baseline for every operation related to a character needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class Operation extends BaseOperation {
    private /*final*/ UUID characterId;

    /**
     * Constructor of the class Operation.
     *
     * @param type        The type of the operation.
     * @param successful  Whether the operation was successful or not.
     * @param target      The coordinates of the target.
     * @param characterId The id of the character.
     */
    public Operation(OperationEnum type, boolean successful, Point target, UUID characterId) {
        super(type, successful, target);
        this.characterId = characterId;
    }

    public Operation() {
    	super();
	}

	/**
     * Getter for characterId.
     *
     * @return The id of the character.
     */
    public UUID getCharacterId() {
        return characterId;
    }
}
