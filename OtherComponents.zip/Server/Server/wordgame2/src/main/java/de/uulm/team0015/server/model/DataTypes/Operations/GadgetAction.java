package de.uulm.team0015.server.model.DataTypes.Operations;

import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;

import java.util.UUID;

/**
 * Class for the operations using a gadget needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class GadgetAction extends Operation {
    private /*final*/ GadgetEnum gadget;

    /**
     * Constructor of the class GadgetAction.
     *
     * @param type        The type of the operation.
     * @param successful  Whether the operation was successful or not.
     * @param target      The coordinates of the target.
     * @param characterId The id of the character.
     * @param gadget      The type of gadget.
     */
    public GadgetAction(OperationEnum type, boolean successful, Point target, UUID characterId, GadgetEnum gadget) {
        super(type, successful, target, characterId);
        this.gadget = gadget;
    }

    /**
     * Getter for gadget.
     *
     * @return The type of gadget.
     */
    public GadgetEnum getGadget() {
        return gadget;
    }
}
