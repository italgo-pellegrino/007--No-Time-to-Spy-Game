package de.uulm.team0015.server.view;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;

/**
 * ServerShell class, that is used to setup a Command Line Interface for interacting with the server.
 * The ServerShell is a Thread, so it can run in parallel.
 * The shell accepts a variety of commands, that can be viewed with help commands --help and -h.
 *
 * @author Tom Weisser
 * @version 1.0
 * @see Thread
 */
public class ServerShell extends Thread {
    private final static Logger LOGGER = Logger.getLogger(ServerShell.class.getName());

    private boolean runShell;
    private final BufferedReader bufferedReader;

    private CharactersLoader charactersLoader;
    private MatchConfigLoader matchConfigLoader;
    private ScenarioLoader scenarioLoader;

    private MainServerLogic mainServerLogic;

    private int port = 7007; // 1 - 65535
    private int capacity = 20; // 3 - 500

    /**
     * Constructor that will setup a new ServerShell with reading and writing abilities, from and to the console.
     */
    public ServerShell() {
        ServerLogger.addHandler(LOGGER);
        bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        LOGGER.info("Server Shell has been setup successfully");

        charactersLoader = new CharactersLoader();
        matchConfigLoader = new MatchConfigLoader();
        scenarioLoader = new ScenarioLoader();
    }

    /**
     * Method that is used to start the shell(wait for input).
     * Will be called if the Thread is started.
     *
     * @throws IOException Throws an IOException if it fails to read a line from the BufferedReader
     */
    private void startShell() throws IOException {
        runShell = true;

        LOGGER.info("Shell has been started.");
        String welcome = "" +
                "       ________   ________     _____   __________  ____________;_\n" +
                "      - ______ \\ - ______ \\ .-'    /  / _____   //.  .  ._______/\n" +
                "     / /     / // /     / //_.-'  /  / /     /_// ___   /\n" +
                "    / /     / // /     / /     / /  / /____    /_/|_/,-'\n" +
                "   / /     / // /     / /     / /  /_____  '-.\n" +
                "  / /     / // /     / /     / /         '-. /\n" +
                " / /     / // /     / /     / /           / /\n" +
                "/ /_____/ // /_____/ / __.-' /_ _______.-' /\n" +
                "\\________- \\________-  \\_______-\\_______.-'\n\n" +
                "Welcome to the Team0015 ServerShell.\n" +
                "Please type in a command, type --help or -h for help.\n"
				+ "WebSocket - Server\n";
        print(welcome);
        while (runShell) {
            String input = bufferedReader.readLine();
            if (input  != null) {
                parseCommand(input);
            }
        }
    }

    /**
     * Method that is used to stop the shell and close the Command Line Input and Output.
     *
     * @throws IOException Throws an IOException if it fails to close the BufferedReader or PrintWriter.
     */
    private void stopShell() throws IOException {
        runShell = false;
        bufferedReader.close();
        LOGGER.info("Shell has been manually stopped.");
    }

    /**
     * Method that is used to parse the incoming commands and call their specific handler methods.
     *
     * @param input Passes in the command, that has been read in by the Command Line Interface.
     */
    private void parseCommand(String input) {
        if (input.trim().isEmpty()) {
            print("Please enter a valid command, type --help or -h for help.");
            return;
        }

        LOGGER.fine("Parsing command: " + input);
        String[] command = input.split(" ");

        switch (command[0]) {
            case "--config-charset":
            case "-c":
                if (command.length >= 2) {
                    configCharset(command[1]);
                } else {
                    print("The charset-path cannot be null, please enter a valid path.");
                    LOGGER.warning("Tried to use --config-charset command with null argument.");
                }
                break;
            case "--config-match":
            case "-m":
                if (command.length >= 2) {
                    configMatch(command[1]);
                } else {
                    print("The match-path cannot be null, please enter a valid path.");
                    LOGGER.warning("Tried to use --config-match command with null argument.");
                }
                break;
            case "--config-scenario":
            case "-s":
                if (command.length >= 2) {
                    configScenario(command[1]);
                } else {
                    print("The scenario-path cannot be null, please enter a valid path.");
                    LOGGER.warning("Tried to use --config-scenario command with null argument.");
                }
                break;
            case "--x":
                if (command.length >= 3) {
                    setKeyValue(command[1], command[2]);
                } else {
                    print("The key nor the value can be null, please enter a valid pair.");
                    LOGGER.warning("Tried to use --x command with null argument.");
                }
                break;
            case "--help":
            case "-h":
                showHelp();
                break;
            case "--port":
            case "-p":
                if (command.length >= 2) {
                    configPort(command[1]);
                } else {
                    print("The port can not be null, please enter a valid port.");
                    LOGGER.warning("Tried to use --port command with null argument.");
                }
                break;
            case "--verbosity":
            case "-v":
                if (command.length >= 2) {
                    configVerbosity(command[1]);
                } else {
                    print("The verbosity can not be null, please enter an integer between 0 and 6.");
                    LOGGER.warning("Tried to use --verbosity command with null argument.");
                }
                break;
            case "--start":
                startServer();
                break;
            case "--stop":
                stopServer();
                break;
            case "--quit":
            case "-q":
                quit();
                break;
            default:
                print("Please enter a valid command, type --help or -h for help.");
                break;
        }
    }

    // Methods for commands

    /**
     * Method that is used to validate a charset path and set it.
     *
     * @param path Passes in the path parameter, that has been read in by the Command Line Interface.
     */
    private void configCharset(String path) {
        CharactersLoader tempCharLoader = new CharactersLoader();
        tempCharLoader.setPath(path);
        if (tempCharLoader.load() != null) {
            this.charactersLoader = tempCharLoader;
            print("Successfully set charset to: " + path);
            LOGGER.info("Set charset path to: " + path);
        } else {
            print(path + " is not a valid path to a charset. Please enter a valid path.");
            LOGGER.warning("Tried to set charset to invalid path: " + path);
        }
    }

    /**
     * Method that is used to validate a match config and set it.
     *
     * @param path Passes in the path parameter, that has been read in by the Command Line Interface.
     */
    private void configMatch(String path) {
        MatchConfigLoader tempConfigLoader = new MatchConfigLoader();
        tempConfigLoader.setPath(path);
        if (tempConfigLoader.load() != null) {
            this.matchConfigLoader = tempConfigLoader;
            print("Successfully set match config to: " + path);
            LOGGER.info("Set match config path to: " + path);
        } else {
            print(path + " is not a valid path to a match config. Please enter a valid path.");
            LOGGER.warning("Tried to set match config to invalid path: " + path);
        }
    }

    /**
     * Method that is used to validate a scenario path and set it.
     *
     * @param path Passes in the path parameter, that has been read in by the Command Line Interface.
     */
    private void configScenario(String path) {
        ScenarioLoader tempScenLoader = new ScenarioLoader();
        tempScenLoader.setPath(path);
        if (tempScenLoader.load() != null) {
            this.scenarioLoader = tempScenLoader;
            print("Successfully set scenario to: " + path);
            LOGGER.info("Set scenario path to: " + path);
        } else {
            print(path + " is not a valid path to a scenario. Please enter a valid path.");
            LOGGER.warning("Tried to set scenario to invalid path: " + path);
        }
    }

    /**
     * Method, used to process key-value pairs.
     *
     * @param key   Key that has been entered
     * @param value Value that has been entered
     */
    private void setKeyValue(String key, String value) {
        LOGGER.fine("Parsing key-value pair.");
        switch (key) {
            case "cap":
                configCapacity(value);
                break;
            case "replay":
                configReplayTime(value);
                break;
            case "npctime":
                configNpcMaxMoveTime(value);
                break;
            case "clog":
                configLogToConsole(value);
                break;
            case "strict":
                configStrictness(value);
                break;
            default:
                print("Invalid key argument, type --help or -h for help.");
        }
    }

    /**
     * Method that is used print out the help page.
     */
    private void showHelp() {
        LOGGER.info("Displaying help page.");
        String helpPage = "\nThis help page gives an overview over the allowed commands and how to use them.\n\n" +
                "--help -h                    Displays this help page.\n\n" +
                "--config-charset -c <path>   Demands an absolute or relative path to a viable characters.json file.\n\n" +
                "--config-match -m <path>     Demands an absolute or relative path to a viable .match file.\n\n" +
                "--config-scenario -s <path>  Demands an absolute or relative path to a viable .scenario file.\n\n" +
                "--x <key> <value>            Allows for the passing on of key-value pairs. Available pairs are:\n\n" +
                "--x cap <int>                Sets the server capacity. Must be an integer between 3 and 500. Default is 20.\n\n" +
                "--x replay <int>             Sets the time period for which the request of replays after a game is possible in minutes. Default is 5 minutes.\n" +
                "                             The specified replay time period must be an integer greater or equals than zero, where zero means no replay available.\n\n" +
                "--x npctime <int>            Sets the maximum time for an NPC to take for a move in seconds. Default is 10 seconds.\n" +
                "                             The specified maximum move time for NPCs must be greater or equals than zero.\n\n" +
                "--x clog <boolean>           Configures the log output to the console. When false, all logs will be output to the /logs directory and only SEVERE logs will be written to the console.\n" +
                "                             When true, logs corresponding to the set log-level will be written to file and console. Default is false.\n\n" +
                "--x strict <boolean>         Configures the strictness, for the handling of possibly delayed messages(e.g. two players unpausing at the same time). Default is false.\n" +
                "                             False means possibly delayed messages will be sanctioned by striking the player, true means kicking the player immediately.\n\n" +
                "--port -p <port>             Demands a viable port number, to which the port of the server will be set. Default is 7007.\n\n" +
                "--verbosity -v <int>         Must be followed up with an integer that will determine the detail of the written logs.\n" +
                "                             Must be an integer between 0 and 6. Default value is 3 - INFO.\n" +
                "                             1    -    SEVERE    Only Errors that should not occur under any circumstance.\n" +
                "                             2    -    WARNING   Relevant information regarding player connection and game state.\n" +
                "                             3    -    INFO      Relevant information regarding spectator connection and inner state changes.\n" +
                "                             4    -    CONFIG    All incoming and outgoing network traffic.\n" +
                "                             5    -    FINE      Information regarding processing of messages\n" +
                "                             6,0  -    FINER     Every log message. \n\n" +
                "--start                      Use this to start the Server with the configured settings.\n\n" +
                "--stop                       Use this to stop the Server and shut down all connections.\n\n" +
                "--quit -q                    Use this to stop the ServerShell. Server needs to be stopped in order to use this.\n\n" +
                "For more information, please check out the documentation.\n";
        print(helpPage);
    }

    /**
     * Method that is used to process an incoming port argument and sets it, if valid.
     *
     * @param port Passes in the port parameter, that has been read in by the Command Line Interface. The specified port must be an integer between 1 and 65535.
     */
    private void configPort(String port) {
        try {
            int tryPort = Integer.parseInt(port);
            if (1 <= tryPort && tryPort <= 65535) {
                this.port = tryPort;
                print("Set port number to: " + this.port);
                LOGGER.info("Set port number to: " + this.port);
            } else {
                print("The specified port must be an integer between 1 and 65535.");
                LOGGER.warning("Tried to use --port command with non-valid integer argument: " + tryPort);
            }
        } catch (NumberFormatException nfe) {
            print("The specified port must be an integer between 1 and 65535.");
            LOGGER.warning("Tried to use --port command with non-integer argument: " + port);
        }
    }

    /**
     * Method that is used to configure the the log-level of the global log-handler.
     *
     * @param capacity Amount of possible connected clients. Must be an Integer between 3 and 500.
     */
    private void configCapacity(String capacity) {
        try {
            int tryCapacity = Integer.parseInt(capacity);
            if (3 <= tryCapacity && tryCapacity <= 500) {
                this.capacity = tryCapacity;
                print("Set server capacity to: " + this.capacity);
                LOGGER.info("Set server capacity to: " + this.capacity);
            } else {
                print("The specified server capacity must be an integer between 3 and 500.");
                LOGGER.warning("Tried to use --capacity command with non-valid integer argument: " + tryCapacity);
            }
        } catch (NumberFormatException nfe) {
            print("The specified server capacity must be an integer between 3 and 500.");
            LOGGER.warning("Tried to use --capacity command with non-integer argument: " + capacity);
        }
    }

    /**
     * Method that is called when NpcMaxMoveTime will be set.
     *
     * @param npcMaxMoveTime NpcMaxMoveTime in seconds. Must be a positive integer or 0.
     */
    private void configNpcMaxMoveTime(String npcMaxMoveTime) {
        try {
            int tryNpcMaxMoveTime = Integer.parseInt(npcMaxMoveTime);
            if (0 <= tryNpcMaxMoveTime) {
                MainServerLogic.npcMaxMoveTime = tryNpcMaxMoveTime;
                String npcMaxMoveTimeLog = "Set the maximum time for NPC moves to " + tryNpcMaxMoveTime + " seconds.";
                print(npcMaxMoveTimeLog);
                LOGGER.info(npcMaxMoveTimeLog);
            } else {
                print("The specified maximum move time for NPCs must be greater or equals than zero.");
                LOGGER.warning("Tried to set the NpcMaxMoveTime to non-valid integer argument: " + tryNpcMaxMoveTime);
            }
        } catch (NumberFormatException nfe) {
            print("The specified maximum move time for NPCs must be greater or equals than zero.");
            LOGGER.warning("Tried to set the NpcMaxMoveTime to non-integer argument: " + npcMaxMoveTime);
        }
    }

    /**
     * Method that is called when the ReplayTime will be set.
     *
     * @param replayTime Time for requesting replays after the game is over in minutes. Must be a positive integer or 0.
     */
    private void configReplayTime(String replayTime) {
        try {
            int tryReplayTime = Integer.parseInt(replayTime);
            if (0 <= tryReplayTime) {
                MainServerLogic.replayTime = tryReplayTime;
                String replayTimeLog = "Set the time period for the requesting of replays to " + tryReplayTime + " minutes.";
                if (tryReplayTime == 0) {
                    replayTimeLog = "Replays have been deactivated.";
                }
                print(replayTimeLog);
                LOGGER.info(replayTimeLog);
            } else {
                print("The specified replay time period must be greater or equals than zero.");
                LOGGER.warning("Tried to set the replayTime to non-valid integer argument: " + tryReplayTime);
            }
        } catch (NumberFormatException nfe) {
            print("The specified replay time period must be an integer greater or equals than zero.");
            LOGGER.warning("Tried to set the replayTime to non-integer argument: " + replayTime);
        }
    }

    /**
     * Method that is called, to configure logging output to the console.
     *
     * @param logToConsole Boolean that determines logging to the console.
     */
    private void configLogToConsole(String logToConsole) {
        boolean logToConBool = Boolean.parseBoolean(logToConsole);
        String logToConLog = "Set the output of logs to the console to: " + logToConBool + ".";
        print(logToConLog);
        LOGGER.info(logToConLog);
        ServerLogger.setConsoleOutput(logToConBool);
    }

    /**
     * Method that is called when entering the --x strict command.
     * Configures the server strictness regarding possibly delayed messages.
     *
     * @param strictness Boolean that determines strictness of the server.
     */
    private void configStrictness(String strictness) {
        boolean strictnessBool = Boolean.parseBoolean(strictness);
        String strictnessLog = "Set server strictness to: " + strictnessBool + ".";
        print(strictnessLog);
        LOGGER.info(strictnessLog);
        MainServerLogic.strictness = strictnessBool;
    }

    /**
     * Method that is used to configure the the log-level of the global log-handler.
     *
     * @param verbosity Must be an Integer between 0 and 7 (1 - SEVERE; 2 - WARNING; 3 - INFO; 4 - CONFIG; 5 - FINE; 6 - FINER; 7, 0 - FINEST)
     */
    private void configVerbosity(String verbosity) {

        try {
            int verbosityInt = Integer.parseInt(verbosity);

            switch (verbosityInt) {
                case 1:
                    ServerLogger.setLevel(Level.SEVERE);
                    LOGGER.severe("Set log-level to SEVERE.");
                    print("Set verbosity to: " + verbosity + " - " + Level.SEVERE);
                    break;
                case 2:
                    ServerLogger.setLevel(Level.WARNING);
                    LOGGER.warning("Set log-level to WARNING.");
                    print("Set verbosity to: " + verbosity + " - " + Level.WARNING);
                    break;
                case 3:
                    ServerLogger.setLevel(Level.INFO);
                    LOGGER.info("Set log-level to INFO.");
                    print("Set verbosity to: " + verbosity + " - " + Level.INFO);
                    break;
                case 4:
                    ServerLogger.setLevel(Level.CONFIG);
                    LOGGER.config("Set log-level to CONFIG.");
                    print("Set verbosity to: " + verbosity + " - " + Level.CONFIG);
                    break;
                case 5:
                    ServerLogger.setLevel(Level.FINE);
                    LOGGER.fine("Set log-level to FINE.");
                    print("Set verbosity to: " + verbosity + " - " + Level.FINE);
                    break;
                case 6:
                case 0:
                    ServerLogger.setLevel(Level.FINER);
                    LOGGER.finer("Set log-level to FINER.");
                    print("Set verbosity to: " + verbosity + " - " + Level.FINER);
                    break;
                default:
                    print("The specified verbosity must be an integer between 0 and 6.");
                    LOGGER.warning("Tried to use --verbosity command with non-valid integer argument: " + verbosity);
                    break;
            }
        } catch (NumberFormatException nfe) {
            print("The specified verbosity must be an integer between 0 and 6.");
            LOGGER.warning("Tried to use --verbosity command with non-integer argument: " + verbosity);
        }


    }

    /**
     * Method that is called when the --start command is called. Starts the Server for clients to connect to.
     */
    private void startServer() {
        if (mainServerLogic == null || !mainServerLogic.nttsServerSocket.run) {
            mainServerLogic = new MainServerLogic(scenarioLoader, matchConfigLoader, charactersLoader, port, capacity);
            LOGGER.info("MainServerLogic has been started.");
        } else {
            print("The Server is already running.");
            LOGGER.info("Tried the server while it was already running.");
        }
    }

    /**
     * Method that is called when the --stop command is called. Stops the Server and shuts down all connections.
     */
    private void stopServer() {
        if (mainServerLogic!= null && mainServerLogic.nttsServerSocket.run) {
            LOGGER.info("Telling MainServerLogic to shut down the server.");
            print("Shutting down the server on user request.");
            mainServerLogic.stop();
        } else {
            print("The Server is not running.");
            LOGGER.info("Tried shutting down server while it was not running.");
        }
    }

    /**
     * Method that is called when the --quit command is called.
     */
    private void quit() {
        if (mainServerLogic != null && mainServerLogic.nttsServerSocket.run) {
            print("The server is still running, to exit the shell, please shut down the server first using --stop.");
            LOGGER.warning("Tried quitting the shell, while server was still running.");
        } else {
            print("Stopping the Server Shell on user request. Thank you and bye bye.");
            LOGGER.info("Stopping Server Shell on user request.");
            try {
                stopShell();
            } catch (IOException ioe) {
                ioe.printStackTrace();
                LOGGER.severe(ioe.toString());
            }
        }
    }

    /**
     * Method that is used to print messages to the Command Line Interface.
     *
     * @param s String that will be printed out to the console.
     */
    public static void print(String s) {
        System.out.println(s);
    }

    @Override
    public void run() {
        try {
            startShell();
        } catch (IOException ioe) {
            LOGGER.severe(ioe.toString());
            ioe.printStackTrace();
        }
    }

    /**
     * Main method to start the server shell.
     *
     * @param args The arguments for the main method.
     */
    public static void main(String[] args) {
        ServerShell serverShell = new ServerShell();
        serverShell.start();
    }
}
