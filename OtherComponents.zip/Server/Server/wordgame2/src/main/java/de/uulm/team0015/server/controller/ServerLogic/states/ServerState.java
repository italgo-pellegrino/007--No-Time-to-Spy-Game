package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.NTTSServerSocket;
import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.ClientInformation;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Enumerations.VictoryEnum;
import de.uulm.team0015.server.model.Messages.Receive.*;
import de.uulm.team0015.server.model.Messages.Send.ErrorMessage;
import de.uulm.team0015.server.model.Messages.Send.GameLeftMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStartedMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import de.uulm.team0015.server.model.Messages.Send.StrikeMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Abstract ServerState class that represents a State the server can be in.
 * e.g. ConnectionSetupState, DecisionPhaseState etc.
 * The MainServerLogic passes operations on to the ServerState, who will determine what actions to take, depending on the current state.
 * Methods are defined for all states, states only override specific methods, that should behave differently in the given state.
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 * @see MainServerLogic
 * @see ConnectionSetupState
 * @see DecisionPhaseState
 * @see EquipmentPhaseState
 * @see GameEndState
 * @see GamePauseState
 * @see GamePhaseState
 * @see ReconnectState
 */
public abstract class ServerState {
    private final static Logger LOGGER = Logger.getLogger(ServerState.class.getName());

    public static MainServerLogic mainServerLogic;
    public static ServerStateEnum activeState;

    /**
     * Constructor, that sets up the Logger for the ServerState class. should be called with super() in other states.
     */
    public ServerState() {
        ServerLogger.addHandler(LOGGER);
        mainServerLogic.serverState = this;
    }

    /**
     * Method that is called upon the receiving of a not allowed message. Can be called from the in and outside of a state.
     * Leads to sending of an ErrorMessage and the disconnection with the client. If it is a player it leads to the end of game(call OnGameLeave of said client).
     *
     * @param manager       SimpleClientManager of the sending client.
     * @param errorTypeEnum Type of error because of which a client will be disconnected
     * @param debugMessage  Added explanation for the client
     */
    public void onFalseMessage(SimpleClientManager manager, ErrorTypeEnum errorTypeEnum, String debugMessage) {

        LOGGER.fine("Received a false message from Client with IP: " + manager.ipInformation + " Reason: " + debugMessage);

        // Create and send ErrorMessage
        
        /**
         * Änderung am 14.07.2020: ClientInformation muss nicht gesetzt sein, um eine Fehlernachricht zu senden
         */
        ErrorMessage errorMessage;
        if(manager.clientInformation == null) {
        	errorMessage = ErrorMessage.createErrorMessage(errorTypeEnum, null, debugMessage);
        }
        else {
        	errorMessage = ErrorMessage.createErrorMessage(errorTypeEnum, manager.clientInformation.getClientId(), debugMessage);
        }
        
        
        manager.sendMessage(errorMessage);

        // Disconnect Client
        manager.disconnect();

        // If Client is registered call the OnGameLeaveMessage
        if (manager.clientInformation != null)
            onGameLeaveMessage(manager);
    }

    /**
     * This method should never be called as it will be overwritten by the inherited methods.
     *
     * @param manager The simpleClientManager.
     */
    public void onMoveTimeout(SimpleClientManager manager) {
        LOGGER.severe("onMoveTimeout has been called in state where it does not exist. This should not happen.");
    }

    /**
     * This method should be called if a player takes too long to make a move.
     * e.g. ItemChoiceMessage, EquipmentChoiceMessage, GameOperationMessage
     * <p>Method will increase the players strikes and kicks him out if strikes reach the maximum.<br>
     * Strike count will be reset upon receiving a valid move.</p>
     *
     * @param manager SimpleClientManager of the client that failed to make a move
     * @param reason Reason why the client will be receiving a strike.
     */
    public void strikeClient(SimpleClientManager manager, String reason) {
        LOGGER.fine("Striking client.");
        // Increase client strikes
        manager.clientInformation.increaseStrikes(1);
        // Create StrikeMessage
        StrikeMessage strikeMessage = StrikeMessage.createStrikeMessage(manager.clientInformation.getNumberOfStrikes(),
                mainServerLogic.initialMatchconfig.getStrikeMaximum(),
                reason,
                manager.clientInformation.getClientId(),
                "Striking client.");
        // Send it
        manager.sendMessage(strikeMessage);
        // If client has reached strike maximum, kick him out
        if (manager.clientInformation.getNumberOfStrikes() >= mainServerLogic.initialMatchconfig.getStrikeMaximum()) {
            LOGGER.info("Client received too many consecutive strikes.");
            onFalseMessage(manager, ErrorTypeEnum.TOO_MANY_STRIKES, "Client received too many consecutive strikes.");
        }
    }

    /**
     * Method that is called upon receiving a GameLeaveMessage or a false message.
     * Takes different actions depending on clients role. e.g. PLAYER:(Broadcast GameLeft, Disconnect Client and enter GameEndState)
     *
     * @param manager SimpleClientManager of the client that is leaving the game/server.
     */
    public void onGameLeaveMessage(SimpleClientManager manager) {
        // Set up GameLeftMessage, ClientId will be set by broadcast
        GameLeftMessage gameLeftMessage = GameLeftMessage.createGameLeftMessage(manager.clientInformation.getClientId(),
                null,
                "A Player has left the game.");

        VictoryEnum victoryEnum;
        UUID winner;

        switch (manager.clientInformation.getRole()) {
            case PLAYER:
                // If PLAYER send GameLeave
                LOGGER.fine("Player left. Broadcasting GameLeftMessage.");
                // clientId will be set by the broadcast method in MainServerLogic
                mainServerLogic.broadcast(gameLeftMessage);
                mainServerLogic.messageHistory.add(gameLeftMessage);
                // After the player received his GameLeftMessage, disconnect him
                if (!manager.isDisconnected()) {
                    LOGGER.fine("Player left the Game. Disconnecting player.");
                    ServerShell.print("A player has left the game, the game is over now.");
                    victoryEnum = VictoryEnum.VICTORY_BY_LEAVE;
                    manager.disconnect();
                } else {
                    LOGGER.fine("Player has been kicked.");
                    ServerShell.print("A player has been kicked, the game is over now.");
                    victoryEnum = VictoryEnum.VICTORY_BY_KICK;
                }
                // call stop method of current state
                stop();
                // Change to GameEndState
                if (manager.clientInformation.getClientId().equals(mainServerLogic.player1.clientInformation.getClientId())) {
                    winner = mainServerLogic.clientIdPlayer2;
                    LOGGER.warning("Player 2 has won, the Game is over.");
                } else {
                    winner = mainServerLogic.clientIdPlayer1;
                    LOGGER.warning("Player 1 has won, the Game is over.");
                }
                new GameEndState(winner, victoryEnum);

                break;
            case AI:
                victoryEnum = VictoryEnum.VICTORY_BY_KICK;
                // Check if AI has already been disconnected(-> this is called by onFalseMessage -> no further error message and disconnecting needed)
                if (!manager.isDisconnected()) {
                    // If AI sends GameLeave
                    LOGGER.warning("An AI has left the game. This should not happen.");
                    // Create and send ErrorMessage to AI, disconnect AI
                    ErrorMessage errorMessage = ErrorMessage.createErrorMessage(ErrorTypeEnum.ILLEGAL_MESSAGE, manager.clientInformation.getClientId(), "Received not allowed GameLeaveMessage by AI.");
                    manager.sendMessage(errorMessage);
                    manager.disconnect();
                } else {
                    LOGGER.fine("AI disconnected broadcasting GameLeftMessage.");
                }
                // Broadcast GameLeftMessage
                // clientId will be set by the broadcast method in MainServerLogic
                mainServerLogic.broadcast(gameLeftMessage);
                mainServerLogic.messageHistory.add(gameLeftMessage);

                // call stop method of current state
                stop();
                // Change to GameEndState
                if (manager.clientInformation.getClientId().equals(mainServerLogic.player1.clientInformation.getClientId())) {
                    winner = mainServerLogic.clientIdPlayer2;
                    LOGGER.warning("Player 2 has won, the Game is over.");
                } else {
                    winner = mainServerLogic.clientIdPlayer1;
                    LOGGER.warning("Player 1 has won, the Game is over.");
                }
                new GameEndState(winner, victoryEnum);

                break;
            case SPECTATOR:
            default:
                onSpectatorLeave(manager);
                break;
        }
    }

    /**
     * Use this method to disconnect a spectator, when he sent a GameLeaveMessage.
     * <p>
     * By calling this the client will receive a GameLeftMessage, he will be removed from the spectators list and he will be disconnected
     * </p>
     *
     * @param manager SimpleClientManager of the spectator client that is leaving.
     */
    public void onSpectatorLeave(SimpleClientManager manager) {
        LOGGER.info("Spectator with IP:" + manager.ipInformation + " left the game.");
        /**
         * Änderung am 14.07. : Bereits benutzter Name wird wieder frei!
         */
        registeredNames.remove(manager.name);
        
        // Create new GameLeftMessage
        GameLeftMessage gameLeftMessage = GameLeftMessage.createGameLeftMessage(manager.clientInformation.getClientId(), manager.clientInformation.getClientId(), "Your connection is now closed");
        // send it to client
        manager.sendMessage(gameLeftMessage);
        // disconnect client
        manager.disconnect();
        // call onSpectatorDisconnect to handle unregistering
        onSpectatorDisconnect(manager);
    }

    /**
     * Method that is called, when a registered client loses connection.
     * Determines if the client is a player or spectator and passes him on to the respective methods.
     *
     * @param manager SimpleClientManager of the client that lost the connection
     */
    public void onDisconnect(SimpleClientManager manager) {
        LOGGER.finer("Client with IP:" + manager.ipInformation + " lost connection.");
        if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            onSpectatorDisconnect(manager);
        } else {
            onPlayerDisconnect(manager);
        }
    }

    /**
     * Method that is called, when a player disconnects. Handling depends on respective state.
     *
     * @param manager SimpleClientManager of the disconnected player client.
     */
    abstract void onPlayerDisconnect(SimpleClientManager manager);

    /**
     * Method that is called, when a spectator disconnects. Removes client from the registered spectators.
     *
     * @param manager SimpleClientManager of the disconnected spectator client.
     */
    public void onSpectatorDisconnect(SimpleClientManager manager) {
    	/**
    	 * Änderung am 14.07.: Bereits benutzter Name wird wieder frei!
    	 */
    	registeredNames.remove(manager.name);
    	
        LOGGER.info("Spectator with IP:" + manager.ipInformation + " has been disconnected and unregistered.");
        mainServerLogic.spectators.remove(manager);
        ServerShell.print("A spectator left the game, " + mainServerLogic.spectators.size() + " of " + (NTTSServerSocket.capacity - 2) + " spectators are still connected to the server.");
    }

    /**
     * Default method responding to the onGameOperation with a call of onFalseMessage()
     * Is overridden by state specific implementations.
     *
     * @param manager              SimpleClientManager that sent the GameOperationMessage
     * @param gameOperationMessage The message that was received
     */
    public void onGameOperationMessage(SimpleClientManager manager, GameOperationMessage gameOperationMessage) {
        String answerMessage;
        if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            answerMessage = "Spectators are not allowed to send a GameOperationMessage.";
            LOGGER.fine(answerMessage);
        } else {
            answerMessage = "Player sent GameOperationMessage at the wrong time.";
            LOGGER.config(answerMessage);
        }
        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, answerMessage);
    }

    
    /**
     * Änderung am 14.07. : Spieler oder Zuschauer mit dem gleichen Namen dürfen sich nicht registrieren
     */
    protected static Set<String> registeredNames = new HashSet<>();
    
    public static Set<String> getRegisteredNames() {
    	return registeredNames;
    }
    
    /**
     * Method that handles HelloMessages when the game has already started.
     * Clients who try to register as a player get rejected.
     * Is overridden by ConnectionSetupState to register players in the beginning.
     *
     * @param manager      SimpleClientManager that sent the HelloMessage
     * @param helloMessage The message that was received
     */
    public void onHelloMessage(SimpleClientManager manager, HelloMessage helloMessage) {
        // Test if client is spectator
        if (helloMessage.role == RoleEnum.SPECTATOR) {
        	
        	/**
        	 * Änderung am 14.07. : Name des Zuschauers soll nicht bereits vergeben sein!
        	 */
        	if(registeredNames.contains(helloMessage.name) && mainServerLogic.player1 != manager) {
            	LOGGER.finer("Client has sent a Hello Message with a required name that is already in use!");
            	System.out.println("Name already in use!!");
                onFalseMessage(manager, ErrorTypeEnum.NAME_NOT_AVAILABLE, "Name is already in use.");
                return;
            }
            else {
            	manager.name = helloMessage.name;
            	registeredNames.add(helloMessage.name);
            }
        	
            onSpectatorHello(manager, helloMessage);
        } else {
            // Call onFalseMessage if it is a player
            LOGGER.config("Failed to register new player. Game has already started. Disconnecting client.");
            manager.disconnect();
        }
    }

    /**
     * Only use this method if you ensured that the manager is a spectator!
     * <p>
     * This message registers a manager as spectator by giving him a ClientInformation, sending him a HelloReplyMessage, and adding him to the spectators list.
     * If the Client is already spectating the onFalseMessage is called.
     * </p>
     *
     * @param manager      SimpleClientManager of the spectator that sent the HelloMessage
     * @param helloMessage The message that was received
     */
    void onSpectatorHello(SimpleClientManager manager, HelloMessage helloMessage) {
        LOGGER.fine("Processing spectator HelloMessage.");
        if (mainServerLogic.spectators.contains(manager)) {
            onFalseMessage(manager, ErrorTypeEnum.ALREADY_SERVING, "Sent HelloMessage, despite being already registered.");
        } else if (mainServerLogic.spectators.size() >= NTTSServerSocket.capacity - 2) {
            LOGGER.fine("Reached max amount of spectators, disconnecting client.");
            manager.disconnect();
        } else {
            //Create new ClientInformation for this Manager
            manager.setClientInformation(new ClientInformation(UUID.randomUUID(), helloMessage.name, helloMessage.role));

            //Create HelloReplyMessage
            HelloReplyMessage helloReplyMessage = HelloReplyMessage.createHelloReplyMessage(mainServerLogic.sessionID,
                    mainServerLogic.initialScenario,
                    mainServerLogic.initialMatchconfig,
                    mainServerLogic.initialCharacterInformation,
                    manager.clientInformation.getClientId(),
                    "Answer to clients HelloMessage."
            );

            //Send reply to Client
            manager.sendMessage(helloReplyMessage);
            
            /**
             * Änderung am 19.07.: Zuschauer sollen eine GameStarted Message bekommen, auch
             * wenn das Spiel bereits gestartet hat
             * 
             */
            // Create and broadcast GameStartedMessage to all
            if(mainServerLogic.gamePhaseHasStarted) {
            	GameStartedMessage gameStartedMessage = GameStartedMessage.createGameStartedMessage(mainServerLogic.clientIdPlayer1,
                    mainServerLogic.clientIdPlayer2,
                    mainServerLogic.player1.clientInformation.getName(),
                    mainServerLogic.player2.clientInformation.getName(),
                    mainServerLogic.sessionID,
                    null,
                    "Both players are connected, the game starts.");
            	
            	manager.sendMessage(gameStartedMessage);
            }
            
            
            //Add Manager to spectators
            mainServerLogic.spectators.add(manager);
            ServerShell.print("Spectator " + mainServerLogic.spectators.size() + " of " + (NTTSServerSocket.capacity - 2) + " connected to the server.");
        }
    }

    /**
     * Default method that handles the receiving of ItemChoiceMessages when they are not allowed.
     * Calls OnFalseMessage with the SimpleClientManager and reason.
     * Is overridden in EquipmentPhaseState.
     *
     * @param manager           SimpleClientManager of the spectator that sent the ItemChoiceMessage.
     * @param itemChoiceMessage The message that was received.
     */
    public void onItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        String answerMessage;
        if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            answerMessage = "Spectators are not allowed to send an ItemChoiceMessage.";
            LOGGER.fine(answerMessage);
        } else {
            answerMessage = "Player sent ItemChoiceMessage at the wrong time.";
            LOGGER.config(answerMessage);
        }
        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, answerMessage);
    }

    /**
     * Handles ReconnectMessages in wrong states.
     * Is overridden in the ReconnectState to handle reconnects.
     *
     * @param manager          SimpleClientManager of the client that sent the ReconnectMessage.
     * @param reconnectMessage The message that was received.
     */
    public void onReconnectMessage(SimpleClientManager manager, ReconnectMessage reconnectMessage) {
        LOGGER.info("Received ReconnectMessage in wrong state. Disconnecting client.");
        manager.disconnect();
    }

    /**
     * This method checks if a player has sent the RequestPauseMessage and, if true, passes it on to the onPlayerPause() method.
     * Pause requests by AIs and Spectators get denied and will call the onFalseMessage() method.
     *
     * @param manager                 SimpleClientManager of the client that sent the RequestPauseMessage.
     * @param requestGamePauseMessage The message that was received.
     */
    public void onRequestGamePauseMessage(SimpleClientManager manager, RequestGamePauseMessage requestGamePauseMessage) {

        LOGGER.fine("Received RequestGamePauseMessage");
        if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Spectators cannot (un)pause the game.");
        } else if (manager.clientInformation.getRole() == RoleEnum.AI) {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "AI cannot (un)pause the game.");
        } else {
            onPlayerPause(manager, requestGamePauseMessage.gamePause);
        }
    }

    /**
     * Handles the receiving of RequestPauseMessage by a player in the wrong state.
     * Calls onFalseMessage with the client. Is overridden in pausable states and Reconnect state.
     *
     * @param manager SimpleClientManager of the player that tried to pause the game.
     * @param pause   Boolean indicating if the player wants to resume or pause
     */
    public void onPlayerPause(SimpleClientManager manager, boolean pause) {
        LOGGER.fine("Illegal player pause.");
        // Tried pausing game in unpausable state
        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Player tried pausing the game in unpausable state.");
    }

    /**
     * Handles the receiving of a RequestReplayMessage in any state other than the GameEndState.
     * Rejects the request by calling the onFalseMessage() method.
     *
     * @param manager SimpleClientManager of the client that tried to request the replay.
     */
    public void onRequestReplayMessage(SimpleClientManager manager) {
        String answerMessage = "Received RequestReplayMessage before the game was over.";
        LOGGER.fine(answerMessage);
        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, answerMessage);
    }

    /**
     * Default method for handling the receiving of an EquipmentChoiceMessage in a state other than the EquipmentPhaseState.
     * Responds with a call of onFalseMessage.
     *
     * @param manager                SimpleClientManager of the client that sent the EquipmentChoiceMessage.
     * @param equipmentChoiceMessage The message that was received.
     */
    public void onEquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        String answerMessage;
        if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            answerMessage = "Spectators are not allowed to send an EquipmentChoiceMessage.";
            LOGGER.fine(answerMessage);
        } else {
            answerMessage = "Player Sent EquipmentChoiceMessage at the wrong time.";
            LOGGER.config(answerMessage);
        }
        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, answerMessage);
    }

    /**
     * Default method for returning to a state after interruption.
     * Does nothing, is overwritten in states that can be interrupted.
     */
    public void onReturn() {
        // Returning not possible per default
        LOGGER.severe("Tried to return to state that cannot be interrupted. This should not happen.");
    }

    /**
     * Setter method for the static MainServerLogic reference.
     *
     * @param mainServerLogic MainServerLogic that will be set as a static attribute.
     */
    public static void setMainServerLogic(MainServerLogic mainServerLogic) {
        ServerState.mainServerLogic = mainServerLogic;
    }

    /**
     * Method for when the state has been stopped with no specific implementation.
     */
    public void stop() {
        LOGGER.warning("State with no specific stop() implementation has been stopped.");
    }
}
