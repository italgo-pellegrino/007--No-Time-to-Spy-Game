package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration for every type of Operation needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum OperationEnum {
    GADGET_ACTION,
    SPY_ACTION,
    GAMBLE_ACTION,
    PROPERTY_ACTION,
    MOVEMENT,
    CAT_ACTION,
    JANITOR_ACTION,
    EXFILTRATION,
    RETIRE
}
