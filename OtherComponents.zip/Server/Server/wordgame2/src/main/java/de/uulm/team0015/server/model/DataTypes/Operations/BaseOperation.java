package de.uulm.team0015.server.model.DataTypes.Operations;

import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;

/**
 * Class for the baseline for every operation needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class BaseOperation {
    private /*final*/ OperationEnum type;
    private boolean successful;
    private /*final*/ Point target;

    /**
     * Constructor of the class BaseOperation.
     *
     * @param type       The type of the operation.
     * @param successful Whether the operation was successful or not.
     * @param target     The coordinates of the target.
     */
    public BaseOperation(OperationEnum type, boolean successful, Point target) {
        this.type = type;
        this.successful = successful;
        this.target = target;
    }

    public BaseOperation() {
	}

	/**
     * Getter for type.
     *
     * @return The type of the operation.
     */
    public OperationEnum getType() {
        return type;
    }

    /**
     * Getter for successful.
     *
     * @return true if the operation was successful, false if not.
     */
    public boolean isSuccessful() {
        return successful;
    }

    /**
     * Setter for successful.
     *
     * @param successful true if the operation was successful, false if not.
     */
    public void setSuccessful(boolean successful) {
        this.successful = successful;
    }

    /**
     * Getter for target.
     *
     * @return The coordinates of the target.
     */
    public Point getTarget() {
        return target;
    }
}
