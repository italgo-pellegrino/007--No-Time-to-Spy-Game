package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when a character has an invalid property.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class InvalidPropertyException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public InvalidPropertyException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public InvalidPropertyException(String message) {
        super(message);
    }
}
