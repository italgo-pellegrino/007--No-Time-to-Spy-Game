package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.MoveTimerTask;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Messages.Receive.EquipmentChoiceMessage;
import de.uulm.team0015.server.model.Messages.Send.RequestEquipmentChoiceMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * This Class is representing the EquipmentPhaseState
 * While this state is active in the {@link MainServerLogic} it will handle a EquipmentChoiceMessage foreach player.
 * <p>
 * Because this state is based on an asynchronous message flow it is saving message he send to each player.
 * If a Message is received which is not valid syntactic and semantic the onFalseMessage is called.
 * <p>
 * To ensure thread-safeness we only access make the playerXMadeHisChoice fields volatile.
 * <p>
 * If all picks where make correctly this state will set a new GameOperationState as active state in the MainServerLogic
 *
 * @author Max Raedler
 */
public class EquipmentPhaseState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(EquipmentPhaseState.class.getName());
    private final RequestEquipmentChoiceMessage requestToPlayer1;
    private final RequestEquipmentChoiceMessage requestToPlayer2;
    private volatile boolean player1MadeHisChoice = false;
    private volatile boolean player2MadeHisChoice = false;
    private Timer player1MoveTimer, player2MoveTimer;
    private final long moveTimerLimit;

    /**
     * Constructor of the class EquipmentPhaseState.
     */
    public EquipmentPhaseState() {
        super();
        ServerLogger.addHandler(LOGGER);
        ServerState.activeState = ServerStateEnum.EQUIPMENT_PHASE_STATE;
        mainServerLogic.serverState = this;

        LOGGER.warning("Entered the EquipmentPhaseState");
        ServerShell.print("Distributing requests and waiting for equipment choices.");

        moveTimerLimit = mainServerLogic.initialMatchconfig.getTurnPhaseLimit() * 1000;

        ArrayList<UUID> charactersPlayer1 = (ArrayList<UUID>) mainServerLogic.player1Characters.stream().map(Character::getCharacterId).collect(Collectors.toList());
        ArrayList<UUID> charactersPlayer2 = (ArrayList<UUID>) mainServerLogic.player2Characters.stream().map(Character::getCharacterId).collect(Collectors.toList());
        requestToPlayer1 = RequestEquipmentChoiceMessage.createRequestEquipmentChoiceMessage(charactersPlayer1, mainServerLogic.player1Gadgets,
                mainServerLogic.clientIdPlayer1, "Here are your selected Characters and GadgetEnums");
        requestToPlayer2 = RequestEquipmentChoiceMessage.createRequestEquipmentChoiceMessage(charactersPlayer2, mainServerLogic.player2Gadgets,
                mainServerLogic.clientIdPlayer2, "Here are your selected Characters and GadgetEnums");

        mainServerLogic.player1.sendMessage(requestToPlayer1);
        startTimerPlayer1();
        LOGGER.finer("Sent a RequestItemChoiceMessage to Player1");
        mainServerLogic.player2.sendMessage(requestToPlayer2);
        startTimerPlayer2();
        LOGGER.finer("Sent a RequestItemChoiceMessage to Player2");
    }

    /**
     * Only call this method if you have ensured that the manager is player1 or player2
     * This message will
     * - Check if the Message is valid
     * - Call the handling method for the corresponding player
     * - Change the ServerState in the MainServerLogic if both players make their choice.
     * <p>
     *
     * @param manager                The Manger who sent the Message.
     * @param equipmentChoiceMessage The equipmentChoiceMessage.
     */
    @Override
    public void onEquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        if (!equipmentChoiceMessage.isValid()) {
            killAllTimers();
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Invalid onEquipmentChoiceMessage!");
            return;
        }
        if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
            player1MoveTimer.cancel();
            player1MoveTimer.purge();
            onPlayer1EquipmentChoiceMessage(manager, equipmentChoiceMessage);
        }
        if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer2)) {
            player2MoveTimer.cancel();
            player2MoveTimer.purge();
            onPlayer2EquipmentChoiceMessage(manager, equipmentChoiceMessage);
        }
        //And finally we can enter the GamePhaseState :)
        if (player1MadeHisChoice && player2MadeHisChoice) {
            LOGGER.warning("Both players made their equipment choices, entering now: GamePhaseState");
            killAllTimers();
            ServerShell.print("Both players made their choices, entering the game phase.");
            new GamePhaseState();
        }
    }

    /**
     * This Method is handling a EquipmentChoiceMessage of player1
     * <p>
     * It will check if the message is valid and if the player:
     * - Owns all the Characters he selected
     * - Owns all the Gadgets he selected
     * - Didn't gave the same Gadget to multiply Characters
     * If the player didn't it will call onFalseMessage
     * <p>
     * After ensuring that this method adds the selected Gadgets to the players Characters in the MainServerLogic.
     *
     * @param manager                The Manager who sent this message.
     * @param equipmentChoiceMessage The Message which contains the pick.
     */
    private void onPlayer1EquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        Iterator<Map.Entry<UUID, Set<GadgetEnum>>> iterator = equipmentChoiceMessage.equipment.entrySet().iterator();
        ArrayList<GadgetEnum> alreadyEquiped = new ArrayList<>();
        int row = 0;
        while (iterator.hasNext()) {
            Map.Entry<UUID, Set<GadgetEnum>> entry = iterator.next();
            UUID characterId = entry.getKey();
            Set<GadgetEnum> gadgetEnums = entry.getValue();

            //Check if the Player really owns all the Gadgets and Characters
            Character character = mainServerLogic.player1Characters.stream().filter(x -> x.getCharacterId().equals(characterId)).findAny().orElse(null);
            if (character == null) {
                LOGGER.info("The selected Character: " + characterId + " is not in the pool owned by player1");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "The selected Character: " + characterId + " is not in your pool at entry number: " + row);
                return;
            }
            for (GadgetEnum gadgetEnum : gadgetEnums) {
                if (!mainServerLogic.player1Gadgets.contains(gadgetEnum) || alreadyEquiped.contains(gadgetEnum)) {
                    LOGGER.info("The selected Gadget: " + gadgetEnum + " is not in the pool owned by player1");
                    onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "One of the selected Gadgets is not in your pool at entry number: " + row);
                    return;
                }
            }
            //Create new Gadgets for this Character.
            for (GadgetEnum gadgetEnum : gadgetEnums) {
                character.addGadget(gadgetEnum);
            }
            //Make sure he dont give the same Gadget to multiply Characters.
            alreadyEquiped.addAll(gadgetEnums);
            row += 1;
        }
        mainServerLogic.player1.clientInformation.resetStrikes();
        LOGGER.finer("Player1 made his EquipmentChoice successfully.");
        player1MadeHisChoice = true;
    }

    /**
     * This Method is handling a EquipmentChoiceMessage of player2
     * <p>
     * It will check if the message is valid and if the player:
     * - Owns all the Characters he selected
     * - Owns all the Gadgets he selected
     * - Didn't gave the same Gadget to multiply Characters
     * If the player didn't it will call onFalseMessage
     * <p>
     * After ensuring that this method adds the selected Gadgets to the players Characters in the MainServerLogic.
     *
     * @param manager                The Manager who sent this message.
     * @param equipmentChoiceMessage The Message which contains the pick.
     */
    private void onPlayer2EquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        Iterator<Map.Entry<UUID, Set<GadgetEnum>>> iterator = equipmentChoiceMessage.equipment.entrySet().iterator();
        ArrayList<GadgetEnum> alreadyEquiped = new ArrayList<>();
        int row = 0;
        while (iterator.hasNext()) {
            Map.Entry<UUID, Set<GadgetEnum>> entry = iterator.next();
            UUID characterId = entry.getKey();
            Set<GadgetEnum> gadgetEnums = entry.getValue();

            //Check if the Player really owns all the Gadgets and Characters
            Character character = mainServerLogic.player2Characters.stream().filter(x -> x.getCharacterId().equals(characterId)).findAny().orElse(null);
            if (character == null) {
                LOGGER.info("The selected Character: " + characterId + " is not in the pool owned by player2");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "The selected Characters is not in your pool at entry number: " + row);
                return;
            }
            for (GadgetEnum gadgetEnum : gadgetEnums) {
                if (!mainServerLogic.player2Gadgets.contains(gadgetEnum) || alreadyEquiped.contains(gadgetEnum)) {
                    LOGGER.info("The selected Gadget: " + gadgetEnum + " is not in the pool owned by player2");
                    onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "One of the selected Gadgets is not in your pool at entry number: " + row);
                    return;
                }
            }
            //Create new Gadgets for this Character.
            for (GadgetEnum gadgetEnum : gadgetEnums) {
                character.addGadget(gadgetEnum);
            }
            //Make sure he dont give the same Gadget to multiply Characters.
            alreadyEquiped.addAll(gadgetEnums);
            row += 1;
        }
        mainServerLogic.player2.clientInformation.resetStrikes();
        LOGGER.finer("Player2 make his EquipmentChoice successfully");
        player2MadeHisChoice = true;
    }

    /**
     * This Method can be used to correctly start a Player1 MoveTimer
     */
    private void startTimerPlayer1() {
        LOGGER.finer("Started timer MoveTimer for player1.");
        player1MoveTimer = new Timer();
        player1MoveTimer.schedule(new MoveTimerTask(this, mainServerLogic.player1), moveTimerLimit);
    }

    /**
     * This Method can be used to correctly start a Player2 MoveTimer
     */
    private void startTimerPlayer2() {
        LOGGER.finer("Started timer MoveTimer for player2.");
        player2MoveTimer = new Timer();
        player2MoveTimer.schedule(new MoveTimerTask(this, mainServerLogic.player2), moveTimerLimit);
    }

    /**
     * This Method can be used to correctly kill all running timers in this state
     */
    private void killAllTimers() {
        try {
            player1MoveTimer.cancel();
            player1MoveTimer.purge();
            player2MoveTimer.cancel();
            player2MoveTimer.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("A timer has already been closed.");
        }
    }

    /**
     * This method is called on a MoveTimeout
     * It will:
     * -Strike the Client.
     * -Start the corresponding timer.
     * -Send the request again.
     * <p>
     *
     * @param manager SimpleClientManager who failed to make a move
     */
    @Override
    public synchronized void onMoveTimeout(SimpleClientManager manager) {
        if (activeState == ServerStateEnum.EQUIPMENT_PHASE_STATE) {
            LOGGER.info("Striking client while in EquipmentPhaseState.");
            if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
                LOGGER.info("Player1 did not make a choice in the given time. He got a Strike.");
                strikeClient(manager, "You did not make your choice in the given time.");
                if (!manager.isDisconnected()) {
                    startTimerPlayer1();
                    mainServerLogic.player1.sendMessage(requestToPlayer1);
                } else {
                    LOGGER.fine("Player received last strike, not sending any more messages.");
                }
            } else if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer2)) {
                LOGGER.info("Player2 did not make a choice in the given time. He got a Strike.");
                strikeClient(manager, "You did not make your choice in the given time.");
                if (!manager.isDisconnected()) {
                    startTimerPlayer2();
                    mainServerLogic.player2.sendMessage(requestToPlayer2);
                } else {
                    LOGGER.fine("Player received last strike, not sending any more messages.");
                }
            }
        } else {
            LOGGER.severe("Tried striking client while state has already changed.");
        }
    }

    /**
     * This Method will stop all Timers and swap the serverstate in the {@link MainServerLogic} to a new {@link ReconnectState}.
     *
     * @param manager The manager which disconnects.
     */
    @Override
    public void onPlayerDisconnect(SimpleClientManager manager) {
        killAllTimers();
        mainServerLogic.serverState = new ReconnectState(this, manager);
    }

    /**
     * This Method will swap to a new GamePauseState
     *
     * @param manager SimpleClientManager of the player that tried to pause the game.
     * @param pause   If false the Server won't swap to the GamePauseState, it will run an onFalseMessage process.
     */
    @Override
    public void onPlayerPause(SimpleClientManager manager, boolean pause) {
        if (pause) {
            LOGGER.info("A player paused the game.");
            killAllTimers();
            new GamePauseState(this);
        } else {
            if (MainServerLogic.strictness) {
                String falseMessage = "A player tried to resume an already running game.";
                LOGGER.info(falseMessage);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, falseMessage);
            } else {
                String problem = "A player tried to resume an already running game. Message might have been delayed. Striking the player.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        }
    }

    /**
     * This method will swap back to the equipmentPhaseState.
     */
    @Override
    public void onReturn() {
        LOGGER.warning("Returning to EquipmentPhaseState");
        ServerShell.print("Returning to the equipment phase.");

        // Reset active state back to this state
        ServerState.activeState = ServerStateEnum.EQUIPMENT_PHASE_STATE;
        mainServerLogic.serverState = this;
        if (!player1MadeHisChoice) {
            startTimerPlayer1();
            mainServerLogic.player1.sendMessage(requestToPlayer1);
        }
        if (!player2MadeHisChoice) {
            startTimerPlayer2();
            mainServerLogic.player2.sendMessage(requestToPlayer2);
        }
        if (player1MadeHisChoice && player2MadeHisChoice) {
            LOGGER.warning("Both players made their equipment choices, entering now: GamePhaseState");
            killAllTimers();
            new GamePhaseState();
        }
    }

    /**
     * This method will stop the equipmentPhaseState.
     */
    @Override
    public void stop() {
        LOGGER.warning("EquipmentPhaseState has been stopped.");
        killAllTimers();
    }
}
