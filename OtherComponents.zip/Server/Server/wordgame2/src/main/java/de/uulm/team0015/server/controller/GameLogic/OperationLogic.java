package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.GamePhaseState;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Operations.*;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Exceptions.*;

import java.util.HashSet;
import java.util.Set;

/**
 * Class to handle the game logic actions for the operations.
 *
 * @author Alexander Preiß, Simon Demharter
 * @version 1.0
 */
public class OperationLogic {

    /**
     * Method for when a character uses his action points to use a gadget.
     *
     * @param gadgetAction      The operation for gadgetAction.
     * @param map               The board of the game.
     * @param matchconfig       The matchconfig.
     * @param characters        Set of all characters currently in game.
     * @param charactersPlayer1 Set of all characters in faction player1.
     * @param charactersPlayer2 Set of all characters in faction player2.
     * @param charactersNPC     Set of all npc characters.
     * @param cat               The cat.
     * @throws InvalidGadgetException       If the gadget is not in the inventory.
     * @throws InvalidActionPointsException If the character has not enough action points.
     * @throws InvalidTargetException       If an invalid target is selected.
     * @throws TargetOutOfSightException    If the target is out of sight.
     * @throws TargetOutOfRangeException    if the target is out of range.
     * @throws TargetBlockedException       If the target is blocked.
     * @throws TargetOutOfBoundsException   If the target field is out of bounds.
     * @throws InvalidCharacterException    If the character does not exist.
     */
    public static void gadgetAction(GadgetAction gadgetAction, FieldMap map, Matchconfig matchconfig, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Set<Character> charactersNPC, Character cat) throws InvalidGadgetException, InvalidActionPointsException, InvalidTargetException, TargetOutOfSightException, TargetOutOfRangeException, TargetBlockedException, TargetOutOfBoundsException, InvalidCharacterException {
        // Get the character
        Character.validateCharacter(characters, gadgetAction.getCharacterId());
        Character character = Character.getCharacter(characters, gadgetAction.getCharacterId());

        // Validate if the target point is on the map
        map.validatePoint(gadgetAction.getTarget());

        // Validate if the field is not foggy
        map.getField(character.getCoordinates()).validateIsNotFoggy();

        // Validate if the character has action points
        character.validateHasActionPoints();

        switch (gadgetAction.getGadget()) {
            case HAIRDRYER:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.hairdryer(character, gadgetAction.getTarget(), map, characters));
                break;
            case MOLEDIE:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.moledie(character, gadgetAction.getTarget(), map, characters, matchconfig));
                character.useGadget(GadgetEnum.MOLEDIE);
                break;
            case TECHNICOLOUR_PRISM:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.technicolorPrism(character, gadgetAction.getTarget(), map));
                character.useGadget(GadgetEnum.TECHNICOLOUR_PRISM);
                break;
            case BOWLER_BLADE:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.bowlerBlade(character, gadgetAction.getTarget(), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
                character.useGadget(GadgetEnum.BOWLER_BLADE);
                break;
            case POISON_PILLS:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.poisonPills(character, gadgetAction.getTarget(), map, characters));
                character.useGadget(GadgetEnum.POISON_PILLS);
                break;
            case LASER_COMPACT:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.laserCompact(character, gadgetAction.getTarget(), map, characters, matchconfig));
                break;
            case ROCKET_PEN:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.rocketPen(character, gadgetAction.getTarget(), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));
                character.useGadget(GadgetEnum.ROCKET_PEN);
                break;
            case GAS_GLOSS:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.gasGloss(character, gadgetAction.getTarget(), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
                character.useGadget(GadgetEnum.GAS_GLOSS);
                break;
            case MOTHBALL_POUCH:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.mothballPouch(character, gadgetAction.getTarget(), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));
                character.useGadget(GadgetEnum.MOTHBALL_POUCH);
                break;
            case FOG_TIN:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.fogTin(character, gadgetAction.getTarget(), map, matchconfig));
                character.useGadget(GadgetEnum.FOG_TIN);
                break;
            case GRAPPLE:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.grapple(character, gadgetAction.getTarget(), map, matchconfig));
                break;
            case JETPACK:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.jetpack(character, gadgetAction.getTarget(), map, characters));
                character.useGadget(GadgetEnum.JETPACK);
                break;
            case WIRETAP_WITH_EARPLUGS:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.wiretapWithEarplugs(character, gadgetAction.getTarget(), map, characters));
                break;
            case CHICKEN_FEED:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.chickenFeed(character, gadgetAction.getTarget(), map, characters, charactersPlayer1, charactersPlayer2));
                character.useGadget(GadgetEnum.CHICKEN_FEED);
                break;
            case NUGGET:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.nugget(character, gadgetAction.getTarget(), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));
                character.useGadget(GadgetEnum.NUGGET);
                break;
            case MIRROR_OF_WILDERNESS:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.mirrorOfWilderness(character, gadgetAction.getTarget(), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));
                break;
                /*
                 * Nicht konsistent mit dem Lastenheft: 19.07
                 * 
            case DIAMOND_COLLAR:
                character.validateHasGadget(gadgetAction.getGadget());
                gadgetAction.setSuccessful(GadgetLogic.diamondCollar(character, gadgetAction.getTarget(), map, characters, cat, matchconfig));
                character.useGadget(GadgetEnum.DIAMOND_COLLAR);
                break;
                */
            case COCKTAIL:
                if (map.getField(gadgetAction.getTarget()).isState(FieldStateEnum.BAR_TABLE)) {
                    // Pick up Cocktail
                    character.validateHasNoGadgetOfType(GadgetEnum.COCKTAIL);
                    gadgetAction.setSuccessful(GadgetLogic.pickupCocktail(character, map, gadgetAction.getTarget()));
                } else if (character.getCoordinates().equals(gadgetAction.getTarget())) {
                    // Drink Cocktail
                    character.validateHasGadget(GadgetEnum.COCKTAIL);
                    gadgetAction.setSuccessful(GadgetLogic.drinkCocktail(character, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
                    character.useGadget(GadgetEnum.COCKTAIL);
                } else {
                    // Spill Cocktail
                    character.validateHasGadget(GadgetEnum.COCKTAIL);
                    gadgetAction.setSuccessful(GadgetLogic.spillCocktail(character, gadgetAction.getTarget(), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
                    character.useGadget(GadgetEnum.COCKTAIL);
                }
                break;
            default:
                throw new InvalidGadgetException("Gadget does not exist! Gadget: " + gadgetAction.getGadget().toString() + ".");
        }
        character.useActionPoint();
    }

    /**
     * Method for when a character uses his action points to play on a roulette table.
     *
     * @param gambleAction The operation for gambleAction.
     * @param map          The board of the game.
     * @param characters   Set of all characters currently in the game.
     * @throws InvalidChipAmountException   If the character has not enough chips.
     * @throws InvalidTargetException       If the wrong target is selected.
     * @throws InvalidActionPointsException If the character has not enough action points.
     * @throws InvalidCharacterException    If the character does not exist.
     * @throws TargetOutOfBoundsException   If the target is out of bounds.
     */
    public static void gambleAction(GambleAction gambleAction, FieldMap map, Set<Character> characters) throws InvalidChipAmountException, InvalidTargetException, InvalidActionPointsException, InvalidCharacterException, TargetOutOfBoundsException {
        // Get the character
        Character.validateCharacter(characters, gambleAction.getCharacterId());
        Character character = Character.getCharacter(characters, gambleAction.getCharacterId());

        // Validate
        map.validatePoint(gambleAction.getTarget());
        map.getField(character.getCoordinates()).validateIsNotFoggy();
        character.validateHasActionPoints();
        character.validateHasChipAmount(gambleAction.getStake());

        gambleAction.setSuccessful(GambleLogic.gambleAction(character, map, gambleAction.getTarget(), gambleAction.getStake()));
        character.useActionPoint();
    }

    /**
     * Method for when a character has the property "Bang and Burn" and "Observation" and uses his action points to use them.
     *
     * @param propertyAction    The operation for propertyAction.
     * @param characters        Set of all characters currently in the game.
     * @param map               The board of the game.
     * @param charactersPlayer1 Set of all characters in faction player1.
     * @param charactersPlayer2 Set of all characters in faction player2.
     * @param matchconfig       The matchconfig.
     * @throws TargetOutOfBoundsException   If the target is out of bounds.
     * @throws InvalidTargetException       If an invalid target is selected.
     * @throws InvalidPropertyException     If the characters doesnt have the property.
     * @throws InvalidActionPointsException If the character has not enough action points.
     * @throws TargetOutOfSightException    If the target is out sight.
     * @throws InvalidGadgetException       If the characters has moledie in his inventory.
     * @throws InvalidCharacterException    If the character does not exist.
     */
    public static void propertyAction(PropertyAction propertyAction, Set<Character> characters, FieldMap map, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) throws TargetOutOfBoundsException, InvalidTargetException, InvalidPropertyException, InvalidActionPointsException, TargetOutOfSightException, InvalidGadgetException, InvalidCharacterException {
        // Get the character
        Character.validateCharacter(characters, propertyAction.getCharacterId());
        Character character = Character.getCharacter(characters, propertyAction.getCharacterId());

        // validate
        map.validatePoint(propertyAction.getTarget());
        map.getField(character.getCoordinates()).validateIsNotFoggy();
        character.validateHasActionPoints();

        switch (propertyAction.getUsedProperty()) {
            case OBSERVATION:
            	/**
            	 * Änderung am 15.07: Anpassung an Standard -> isEnemy Attribut
            	 */
            	boolean successful = PropertyLogic.observation(character, map, propertyAction.getTarget(), characters, charactersPlayer1, charactersPlayer2, matchconfig);
                propertyAction.setSuccessful(successful);
                propertyAction.setIsEnemy(successful);
                break;
            case BANG_AND_BURN:
                propertyAction.setSuccessful(PropertyLogic.bangAndBurn(character, map, propertyAction.getTarget()));
                break;
            default:
                throw new InvalidPropertyException("Property action does not exist! Property: " + propertyAction.getUsedProperty() + ".");
        }
        character.useActionPoint();
    }

    /**
     * Method for when a character uses his movement points to move to a game field.
     *
     * @param movement   The operation for movement.
     * @param map        The board of the game.
     * @param characters Set of all characters currently in the game.
     * @throws InvalidMovementPointsException If the character has not enough movement points.
     * @throws TargetOutOfBoundsException     If the target field is out of bounds.
     * @throws InvalidTargetException         If an invalid target is selected.
     * @throws InvalidCharacterException      If the character does not exist.
     */
    public static void movement(Movement movement, FieldMap map, Set<Character> characters) throws InvalidMovementPointsException, TargetOutOfBoundsException, InvalidTargetException, InvalidCharacterException {
        // Get the character
        Character.validateCharacter(characters, movement.getCharacterId());
        Character character = Character.getCharacter(characters, movement.getCharacterId());

        // Validate
        map.validatePoint(movement.getTarget());
        character.validateHasMovementPoints();
        map.validateIsNeighbour(character.getCoordinates(), movement.getTarget());
        map.getField(movement.getTarget()).validateIsAccessible();
        
        /**
         * Hinzugefügt am 18.07. : Übergabe der Diamanthalsbands an die Katze!
         */
        if(character.hasGadget(GadgetEnum.DIAMOND_COLLAR) && map.fieldHasCharacter(movement.getTarget(), catCollection)) {
        	character.updateIntelligencePoints(MainServerLogic.initialMatchconfig.getCatIp());
        	OperationLogic.cat.addGadget(GadgetEnum.DIAMOND_COLLAR);
        	GadgetLogic.checkHasWireTapWithEarplugs(character, characters, 0);
        	character.useGadget(GadgetEnum.DIAMOND_COLLAR);
        	
        	/**
        	 * Welche Fraktion hat der Katze das Halsband übergeben?
        	 */
        	if(character.isMemberOfFaction(MainServerLogic.player1Characters)){
        		MainServerLogic.winCondition.setReturnedCollarPlayer1(true);
        		MainServerLogic.winCondition.setReturnedCollarPlayer2(false);
        	}
        	else {
        		MainServerLogic.winCondition.setReturnedCollarPlayer1(false);
        		MainServerLogic.winCondition.setReturnedCollarPlayer2(true);
        	}
        }


        if (map.getField(movement.getTarget()).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR)) {
            character.addGadget(GadgetEnum.DIAMOND_COLLAR);
            map.getField(movement.getTarget()).setGadget(null);
        }

        if (map.getField(movement.getTarget()).hasGadgetOfType(GadgetEnum.BOWLER_BLADE)) {
            character.addGadget(GadgetEnum.BOWLER_BLADE);
            map.getField(movement.getTarget()).setGadget(null);
        }

        if (map.fieldHasCharacter(movement.getTarget(), characters)) {
            map.getCharacterOnField(movement.getTarget(), characters).setCoordinates(character.getCoordinates());
        }
        movement.setSuccessful(true);
        character.setCoordinates(movement.getTarget());
        character.useMovementPoint();
    }

    /**
     * Method for operation retire and spy-action.
     *
     * @param operation                 The operation for operationAction.
     * @param map                       The board of the game.
     * @param characters                Set of all characters currently in the game.
     * @param charactersPlayer1       Set of all characters in faction player1.
     * @param charactersPlayer2       Set of all characters in faction player2.
     * @param charactersNPC             Set of all npc´s in the game.
     * @param matchconfig               The matchconfig.
     * @param player1SafeCombinations The safe combinations of player one.
     * @param player2SafeCombinations The safe combinations of player two.
     * @throws InvalidTargetException          If an invalid target is selected.
     * @throws TargetOutOfBoundsException      If the target is out of bounds.
     * @throws InvalidActionPointsException    If the character has not enough action points.
     * @throws InvalidCharacterException       If the character does not exist.
     * @throws InvalidOperationException       If the operation does not exist.
     * @throws TargetOutOfRangeException       If the target is out of range.
     * @throws InvalidSafeCombinationException If the character does not have the right safe combinations.
     */
    public static void operationAction(Operation operation, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Set<Character> charactersNPC, Matchconfig matchconfig, Set<Integer> player1SafeCombinations, Set<Integer> player2SafeCombinations) throws InvalidTargetException, TargetOutOfBoundsException, InvalidActionPointsException, InvalidCharacterException, InvalidOperationException, TargetOutOfRangeException, InvalidSafeCombinationException {
        // Get the character
        Character.validateCharacter(characters, operation.getCharacterId());
        Character character = Character.getCharacter(characters, operation.getCharacterId());

        switch (operation.getType()) {
            case RETIRE:
                operation.setSuccessful(true);
                break;
            case SPY_ACTION:
                // Validate
                map.validatePoint(operation.getTarget());
                map.getField(character.getCoordinates()).validateIsNotFoggy();
                character.validateHasActionPoints();
                operation.setSuccessful(SpyLogic.spyLogic(character, map, operation.getTarget(), characters, charactersPlayer1, charactersPlayer2, charactersNPC, player1SafeCombinations, player2SafeCombinations, matchconfig));
                character.useActionPoint();
                break;
            default:
                throw new InvalidOperationException("Operation does not exist! Operation: " + operation.getType() + ".");
        }
    }

    /**
     * Method for when a character reaches 0 health points.
     *
     * @param exfiltration The operation for exfiltration.
     * @param map          The board of the game.
     * @param characters   Set of all characters currently in the game.
     */
    public static void exfiltration(Exfiltration exfiltration, FieldMap map, Set<Character> characters) {
        // Get the character
        Character character = Character.getCharacter(characters, exfiltration.getCharacterId());

        // Get all bar seats with no characters on the map
        Set<Point> freeBarSeats = map.getFieldsOfState(FieldStateEnum.BAR_SEAT);
        freeBarSeats.removeIf(point -> map.fieldHasCharacter(point, characters));
        Point target;

        if (!freeBarSeats.isEmpty()) {
            target = map.getRandomPoint(freeBarSeats);
        } else {
            target = getExfiltrationTarget(map.getFieldsOfState(FieldStateEnum.BAR_SEAT), map.getFieldsOfState(FieldStateEnum.BAR_SEAT), map, characters);
        }
        if (character.hasGadget(GadgetEnum.DIAMOND_COLLAR)) {
            character.removeGadget(GadgetEnum.DIAMOND_COLLAR);
            map.getField(character.getCoordinates()).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        }
        /**
         * Vorherige Position wird temporär gespeichert
         */
        Point from = character.getCoordinates();
        
        character.setCoordinates(target);
        character.setHp(1);
        exfiltration.setSuccessful(true);
        /**
         * Änderung am 19.07.2020
         */
        GamePhaseState.lastOperations.add(new Exfiltration(OperationEnum.EXFILTRATION, true, target, character.getCharacterId(), from));
        
        //GamePhaseState.lastOperations.add(new BaseOperation(OperationEnum.EXFILTRATION, true, target));
    }

    /**
     * Method to recursively get the coordinates the target will be moved on to when all bar tables are full and moves the characters on suitable fields accordingly.
     *
     * @param possibleTargets The possible targets the character could be moved to.
     * @param initialTargets  The initial possible targets the character could be moved to.
     * @param map             The board of the game.
     * @param characters      Set of all characters currently in the game.
     * @return The coordinates of the target the target will be moved on to.
     */
    private static Point getExfiltrationTarget(Set<Point> possibleTargets, Set<Point> initialTargets, FieldMap map, Set<Character> characters) {
        Point target = map.getRandomPoint(possibleTargets);
        Set<Point> displaceTargets = new HashSet<>();

        for (Point point : map.getAccessibleNeighbours(target)) {
            if (!map.fieldHasCharacter(point, characters)) {
                displaceTargets.add(point);
            }
        }

        if (!displaceTargets.isEmpty()) {
            map.getCharacterOnField(target, characters).setCoordinates(map.getRandomPoint(displaceTargets));
            return target;
        } else {
            possibleTargets.remove(target);

            if (!possibleTargets.isEmpty()) {
                return getExfiltrationTarget(possibleTargets, initialTargets, map, characters);
            } else {
                target = map.getRandomPoint(initialTargets);
                map.getCharacterOnField(target, characters).setCoordinates(getExfiltrationTarget(map.getAccessibleNeighbours(target), map.getAccessibleNeighbours(target), map, characters));
                return target;
            }
        }
    }

    /**
     * Cat Character in Collection
     */
    private static Set<Character> catCollection;
    private static Character cat;
    
    /**
     * Hinzugefügt am 18.07. : Die Katze im Spiel wird in dieser Klasse 
     * 
     * @param cat
     */
    
	public static void setCat(Character catCharacter) {
		OperationLogic.cat = catCharacter;
		OperationLogic.catCollection = new HashSet<Character>();
		OperationLogic.catCollection.add(catCharacter);
	}
}
