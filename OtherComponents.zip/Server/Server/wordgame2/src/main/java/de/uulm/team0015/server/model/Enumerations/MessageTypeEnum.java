package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration for every type of messages.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum MessageTypeEnum {
    // GameInitialization
    HELLO,
    HELLO_REPLY,
    RECONNECT,
    GAME_STARTED,

    // DraftPhase
    REQUEST_ITEM_CHOICE,
    ITEM_CHOICE,
    REQUEST_EQUIPMENT_CHOICE,
    EQUIPMENT_CHOICE,

    // GamePhase
    GAME_STATUS,
    REQUEST_GAME_OPERATION,
    GAME_OPERATION,

    // EndGame
    STATISTICS,

    // ControlMessages
    GAME_LEAVE,
    GAME_LEFT,
    REQUEST_GAME_PAUSE,
    GAME_PAUSE,
    REQUEST_META_INFORMATION,
    META_INFORMATION,
    STRIKE,
    ERROR,

    // Optional components
    REQUEST_REPLAY,
    REPLAY
}
