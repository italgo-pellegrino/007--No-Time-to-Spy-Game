package de.uulm.team0015.server.model.DataTypes.Gadgets;

import de.uulm.team0015.server.model.Enumerations.GadgetEnum;

/**
 * Class for the baseline of the gadgets needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 */
public class Gadget {
    private final GadgetEnum gadget;
    private int usages;

    /**
     * Constructor of the class Gadget.
     *
     * @param gadget The type of gadget.
     */
    public Gadget(GadgetEnum gadget) {
        this.gadget = gadget;
    }

    /**
     * Constructor of the class Gadget.
     *
     * @param gadget The type of gadget.
     * @param usages Usages of gadget.
     */
    public Gadget(GadgetEnum gadget, int usages) {
        this.gadget = gadget;
        this.usages = usages;
    }

    /**
     * Getter for gadget.
     *
     * @return The type of the gadget.
     */
    public GadgetEnum getGadgetEnum() {
        return gadget;
    }

    /**
     * Getter for usages.
     *
     * @return The amount of usages for the gadget.
     */
    public int getUsages() {
        return usages;
    }

    /**
     * Method for when a gadget with usages is being used.
     */
    public void use() {
        usages -= 1;
    }
}
