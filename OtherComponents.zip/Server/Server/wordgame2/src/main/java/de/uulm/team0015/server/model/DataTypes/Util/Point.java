package de.uulm.team0015.server.model.DataTypes.Util;

/**
 * Class for the coordinates of a field needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class Point {
    private final int x;
    private final int y;

    /**
     * Constructor of the class Point.
     *
     * @param x The x coordinate of the point.
     * @param y The y coordinate of the point.
     */
    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Getter for x.
     *
     * @return The x coordinate of the point.
     */
    public int getX() {
        return x;
    }

    /**
     * Getter for y.
     *
     * @return The y coordinate of the point.
     */
    public int getY() {
        return y;
    }

    /**
     * toString method of class Point.
     *
     * @return the coordinates as a String.
     */
    @Override
    public String toString() {
        return "[" + x + "|" + y + "]";
    }

    /**
     * equals method of class Point.
     *
     * @param o The given point.
     * @return true if the given point is equal to this point, false if not.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Point point = (Point) o;
        return x == point.x && y == point.y;
    }
}
