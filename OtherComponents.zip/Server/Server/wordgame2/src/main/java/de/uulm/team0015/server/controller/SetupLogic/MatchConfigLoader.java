package de.uulm.team0015.server.controller.SetupLogic;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;

import java.util.logging.Logger;

/**
 * With this class you can load a MatchConfig
 * Before loading you should change the path to your File
 * If any error occurred .load() will return null
 *
 * @author Max Raedler
 * @version 1.0
 */
public class MatchConfigLoader {
    private String path;
    private final static Logger LOGGER = Logger.getLogger(MatchConfigLoader.class.getName());

    /**
     * Getter for path.
     *
     * @return The path of the matchconfig.match file.
     */
    public String getPath() {
        return path;
    }

    /**
     * Setter for path.
     *
     * @param path The path of the matchconfig.match file.
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Constructor for class MatchConfigLoader.
     */
    public MatchConfigLoader() {
        path = "default/matchconfig.match";
        ServerLogger.addHandler(LOGGER);
    }

    /**
     * Reads a File at the given path with readFileToString()
     *
     * @return The Scenario which is described in the file the field path directs, null if the file wasn't found or the JSON-File can't be parsed
     */
    public Matchconfig load() {
        String jsonString = ScenarioLoader.readFileToString(path, "Matchconfig");
        if (jsonString == null) {
            return null;
        }
        Gson gson = new Gson();
        try {
            if (!checkRequired(jsonString)) {
                return null;
            }
            Matchconfig matchconfig = gson.fromJson(jsonString, Matchconfig.class);
            if (!checkBounds(matchconfig)) {
                return null;
            }
            String Message = "Loaded Matchconfig successfully!";
            LOGGER.info(Message);
            return matchconfig;
        } catch (JsonSyntaxException jse) {
            String Message = "An JSON-Parser error by GSON occurred: " + jse.getMessage();
            LOGGER.severe(Message);
            return null;
        }
    }

    /**
     * Checks if all required keys exist, logs missing ones.
     *
     * @param jsonString String to check
     * @return true if all required keys exist, false if not
     */
    private boolean checkRequired(String jsonString) {
        JsonObject object = (JsonObject) JsonParser.parseString(jsonString);
        if (!object.has("moledieRange")) {
            String message = "Error while loading Matchconfig: moledieRange does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("bowlerBladeRange")) {
            String message = "Error while loading Matchconfig: bowlerBladeRange does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("bowlerBladeHitChance")) {
            String message = "Error while loading Matchconfig: bowlerBladeHitChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("bowlerBladeDamage")) {
            String message = "Error while loading Matchconfig: bowlerBladeDamage does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("laserCompactHitChance")) {
            String message = "Error while loading Matchconfig: laserCompactHitChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("rocketPenDamage")) {
            String message = "Error while loading Matchconfig: rocketPenDamage does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("gasGlossDamage")) {
            String message = "Error while loading Matchconfig: gasGlossDamage does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("mothballPouchRange")) {
            String message = "Error while loading Matchconfig: mothballPouchRange does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("mothballPouchDamage")) {
            String message = "Error while loading Matchconfig: moledieRange does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("fogTinRange")) {
            String message = "Error while loading Matchconfig: fogTinRange does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("grappleRange")) {
            String message = "Error while loading Matchconfig: grappleRange does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("grappleHitChance")) {
            String message = "Error while loading Matchconfig: grappleHitChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("wiretapWithEarplugsFailChance")) {
            String message = "Error while loading Matchconfig: wiretapWithEarplugsFailChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("mirrorSwapChance")) {
            String message = "Error while loading Matchconfig: mirrorSwapChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("cocktailDodgeChance")) {
            String message = "Error while loading Matchconfig: cocktailDodgeChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("cocktailHp")) {
            String message = "Error while loading Matchconfig: cocktailHp does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("spySuccessChance")) {
            String message = "Error while loading Matchconfig: spySuccessChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("babysitterSuccessChance")) {
            String message = "Error while loading Matchconfig: babysitterSuccessChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("honeyTrapSuccessChance")) {
            String message = "Error while loading Matchconfig: honeyTrapSuccessChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("observationSuccessChance")) {
            String message = "Error while loading Matchconfig: observationSuccessChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("chipsToIpFactor")) {
            String message = "Error while loading Matchconfig: chipsToIpFactor does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("spySuccessChance")) {
            String message = "Error while loading Matchconfig: spySuccessChance does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("roundLimit")) {
            String message = "Error while loading Matchconfig: roundLimit does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("turnPhaseLimit")) {
            String message = "Error while loading Matchconfig: turnPhaseLimit does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("catIp")) {
            String message = "Error while loading Matchconfig: catIp does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("strikeMaximum")) {
            String message = "Error while loading Matchconfig: strikeMaximum does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("pauseLimit")) {
            String message = "Error while loading Matchconfig: pauseLimit does not exist!";
            LOGGER.severe(message);
            return false;
        }
        if (!object.has("reconnectLimit")) {
            String message = "Error while loading Matchconfig: reconnectLimit does not exist!";
            return false;
        }
        return true;
    }

    /**
     * Checks if all required keys are in their bounds, logs false ones.
     * Important! all ways call this method after checkRequired is called!
     *
     * @param matchconfig Matchconfig which needs to be checked
     * @return true if all required Keys are correct false if not
     */
    private boolean checkBounds(Matchconfig matchconfig) {
        if (matchconfig.getGrappleHitChance() < 0 || matchconfig.getGrappleHitChance() > 1) {
            String message = "Error while loading Matchconfig: grappleHitChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getBowlerBladeHitChance() < 0 || matchconfig.getBowlerBladeHitChance() > 1) {
            String message = "Error while loading Matchconfig: bowlerBladeHitChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getLaserCompactHitChance() < 0 || matchconfig.getLaserCompactHitChance() > 1) {
            String message = "Error while loading Matchconfig: laserCompactHitChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getWiretapWithEarplugsFailChance() < 0 || matchconfig.getWiretapWithEarplugsFailChance() > 1) {
            String message = "Error while loading Matchconfig: wiretapWithEarplugsFailChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getMirrorSwapChance() < 0 || matchconfig.getMirrorSwapChance() > 1) {
            String message = "Error while loading Matchconfig: mirrorSwapChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getCocktailDodgeChance() < 0 || matchconfig.getCocktailDodgeChance() > 1) {
            String message = "Error while loading Matchconfig: cocktailDodgeChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getSpySuccessChance() < 0 || matchconfig.getSpySuccessChance() > 1) {
            String message = "Error while loading Matchconfig: spySuccessChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getBabysitterSuccessChance() < 0 || matchconfig.getBabysitterSuccessChance() > 1) {
            String message = "Error while loading Matchconfig: babysitterSuccessChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        if (matchconfig.getObservationSuccessChance() < 0 || matchconfig.getObservationSuccessChance() > 1) {
            String message = "Error while loading Matchconfig: observationSuccessChance is invalid!";
            LOGGER.severe(message);
            return false;
        }
        return true;
    }
}
