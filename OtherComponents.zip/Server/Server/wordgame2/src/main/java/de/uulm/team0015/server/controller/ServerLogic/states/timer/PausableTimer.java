package de.uulm.team0015.server.controller.ServerLogic.states.timer;

import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.states.GamePauseState;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.PauseTimerTask;

import java.util.Timer;
import java.util.logging.Logger;

/**
 * The PausableTimer class represents a timer that can be paused and resumed using a PauseTimerTask.
 * Will be used by the GamePauseState to determine the remaining pause time.
 *
 * @author Tom Weisser
 * @version 1.0
 * @see PauseTimerTask
 * @see GamePauseState
 */
public class PausableTimer {
    private final static Logger LOGGER = Logger.getLogger(PausableTimer.class.getName());

    GamePauseState parentState;

    int remainingTime;
    Timer timer;

    /**
     * Constructor for GamePauseState will create a PausableTimer object and start it.
     *
     * @param parentState The parent GamePauseState, to which the timer belongs and will return to.
     * @param duration Duration after which the pause timer will return to the parent state in seconds.
     */
    public PausableTimer(GamePauseState parentState, int duration) {
        ServerLogger.addHandler(LOGGER);
        this.parentState = parentState;
        remainingTime = duration;
        start();
    }

    /**
     * Method, that is used to start the timer. The timer task will be scheduled to run every second.
     */
    public void start() {
        timer = new Timer();
        timer.scheduleAtFixedRate(new PauseTimerTask(this), 1000, 1000);
    }

    /**
     * Method used to stop or pause the PausableTimer
     */
    public void stop() {
        try {
            timer.cancel();
            timer.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("Pause timer has already been closed");
        }
    }

    /**
     * Method that will be called by PauseTimerTask.
     *
     * @param amount Amount of time in seconds to count down on timer run out.
     */
    public void countDown(int amount) {
        remainingTime -= amount;
        if (remainingTime <= 0) {
            onCompletion();
        }
    }

    /**
     * Method that will be called, when the timer limit is reached. Will call back to parent PauseState.
     */
    public void onCompletion() {
        stop();
        parentState.onPauseOver();
    }

    /**
     * Method to retrieve the remaining pause time.
     *
     * @return The remaining pause time in seconds
     */
    public int getRemainingTime() {
        return remainingTime;
    }
}
