package de.uulm.team0015.server.model.DataTypes.Gadgets;

import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;

import java.util.UUID;

/**
 * Class for the gadget WireTapWithEarplugs, which has additional information compared to the baseline gadget.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 */
public class WireTapWithEarplugs extends Gadget {
    private boolean working;
    private UUID activeOn;

    /**
     * Constructor of the class WireTapWithEarplugs.
     */
    public WireTapWithEarplugs() {
        super(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        this.activeOn = null;
    }

    /**
     * Getter for working.
     *
     * @return true if the wiretap is working, false if not.
     */
    public boolean isWorking() {
        return working;
    }

    /**
     * Setter for working.
     *
     * @param working Whether the wiretap is working or not.
     */
    public void setWorking(boolean working) {
        this.working = working;
    }

    /**
     * Getter for activeOn.
     *
     * @return The id of the character on which the wiretap is on.
     */
    public UUID getActiveOn() {
        return activeOn;
    }

    /**
     * Setter for activeOn.
     *
     * @param activeOn The id of the character on which the wiretap is on.
     */
    public void setActiveOn(UUID activeOn) {
        this.activeOn = activeOn;
    }

    /**
     * Method to check if the WireTapWithEarplugs is already active.
     *
     * @throws InvalidTargetException If the WireTapWithEarplugs is already active.
     */
    public void validateIsNotInUse() throws InvalidTargetException {
        if (activeOn != null) {
            throw new InvalidTargetException("WireTapWithEarplugs is already active and can not be used again!");
        }
    }

    /**
     * Method to set up the gadget when set on a character.
     *
     * @param character The character on which the wiretap is set.
     */
    public void setupWireTapWithEarplugs(Character character) {
        working = true;
        activeOn = character.getCharacterId();
    }
}
