package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when the target is out of sight.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class TargetOutOfSightException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public TargetOutOfSightException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public TargetOutOfSightException(String message) {
        super(message);
    }
}
