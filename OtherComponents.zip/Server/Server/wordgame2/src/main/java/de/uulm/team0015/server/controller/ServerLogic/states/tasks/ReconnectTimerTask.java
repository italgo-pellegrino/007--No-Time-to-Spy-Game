package de.uulm.team0015.server.controller.ServerLogic.states.tasks;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogic.states.ReconnectState;

import java.util.TimerTask;

/**
 * ReconnectTimerTask used by the ReconnectState to determine if a player has exceeded the reconnect time limit.
 */
public class ReconnectTimerTask extends TimerTask {
    private ReconnectState parent;
    private SimpleClientManager manager;

    /**
     * Constructor for the ReconnectTimerTask.
     *
     * @param parent  Reconnect state the task is used in.
     * @param manager Client for which the time is being tracked.
     */
    public ReconnectTimerTask(ReconnectState parent, SimpleClientManager manager) {
        this.parent = parent;
        this.manager = manager;
    }

    /**
     * Calls the onReconnectFailure()-method in the parent state.
     */
    @Override
    public void run() {
        parent.onReconnectFailure(manager);
    }
}