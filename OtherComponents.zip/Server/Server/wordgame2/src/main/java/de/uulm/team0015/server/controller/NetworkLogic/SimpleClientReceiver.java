/*
package de.uulm.team0015.server.controller.NetworkLogic;

import de.uulm.team0015.server.controller.ServerLogger;

import java.io.BufferedReader;
import java.io.IOException;
import java.net.SocketException;
import java.util.logging.Logger;

import javax.websocket.MessageHandler;

/**
 * This Class extends a Thread
 * If the run() is called an idle mode is started and the client is reading Strings from the input.
 * After receiving a String, run() is calling the receive(String jsonMessage) at the private SimpleClient
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 * @see de.uulm.team0015.server.controller.NetworkLogic.SimpleClient
 * @see SimpleClient
 /
public class SimpleClientReceiver{
    private final static Logger LOGGER = Logger.getLogger(SimpleClientReceiver.class.getName());
    //private BufferedReader input;
    private SimpleClient client;
	private MessageHandler messageHandler;

    /*deprecated
    /**
     * The SimpleClientReceiver is passes on an BufferedReader as an input source to receive messages.
     *
     * @param client Linked SimpleClient
     * @param input  BufferedReader for the receiver to use
     *
    public SimpleClientReceiver(SimpleClient client, BufferedReader input) {
        ServerLogger.addHandler(LOGGER);

        this.input = input;
        this.client = client;
    }
    /

    
    /**
     * 
     * @param client: Client, welcher die Verbindung verwaltet
     * @param messageHandler: MessageHandler, welcher die Logik zur Verarbeitung der ankommenden Nachrichten enth�lt
     /
    public SimpleClientReceiver(SimpleClient client, MessageHandler messageHandler) {
    	ServerLogger.addHandler(LOGGER);

        this.messageHandler = messageHandler;
        this.client = client;
	}

	/**
     * Method that is used to shutdown the BufferedReader and by that the receiver.
     *
     * @throws IOException Thrown if closing of the BufferedReader fails.
     /
    public void close() throws IOException {
       // messageHandler = null;
    }

    /**
     * Getter for isDisconnectedByServer from the simpleClient class.
     *
     * @return if the client is disconnected by the server.
     /
    boolean isDisconnectedByServer() {
        return client.isDisconnectedByServer();
    }

    /**
     * Setter for isDisconnectedByServer from the SimpleClient class.
     *
     * @param disconnectedByServer if the client is disconnected by the server.
     /
    void setDisconnectedByServer(boolean disconnectedByServer) {
        client.setDisconnectedByServer(disconnectedByServer);
    }

    /*
    
    /**
     * Method to run the simpleClientReceiver.
     
    @Override
    public void run() {
        String received;
        try {
            while ((received = input.readLine()) != null) {
                LOGGER.fine("Received From: " + client.getSession().getRequestURI().toString() + " Message: " + received);
                try {
                    client.receive(received);
                } catch (Exception e) {
                    e.printStackTrace();
                    LOGGER.warning(e.toString());
                }
            }
        } catch (SocketException se) {
            LOGGER.fine("Client with IP " + client.getSession().getRequestURI().toString() + " disconnected: " + se.toString());
        } catch (IOException e) {
            try {
                close();
                LOGGER.fine("SimpleClientReceiver(IP=" + client.getSession().getRequestURI().toString() + ") closed components successfully");
            } catch (IOException ioe) {
                LOGGER.severe("Attempt to close receiver after shutdown from above failed: " + ioe);
            }
        }
        // set SimpleClient to closed
        client.setClosed(true);
        LOGGER.fine("SimpleClientReceiver(IP=" + client.getSession().getRequestURI().toString() + ") terminated successfully");
    }
    /
}
*/