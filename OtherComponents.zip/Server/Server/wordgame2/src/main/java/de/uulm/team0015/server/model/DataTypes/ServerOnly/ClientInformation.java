package de.uulm.team0015.server.model.DataTypes.ServerOnly;

import de.uulm.team0015.server.model.Enumerations.RoleEnum;

import java.util.UUID;

/**
 * Each SimpleClientManager has a ClientInformation.
 * This Class keeps all Game-play relevant information about this client
 *
 * @author Max Raedler
 */
public class ClientInformation {
    private final UUID clientId;
    private final String name;
    private final RoleEnum role;
    private int numberOfStrikes = 0;

    /**
     * Constructor of the class ClientInformation.
     *
     * @param uuid The id of the client.
     * @param name The name of the client.
     * @param role The role the client takes.
     */
    public ClientInformation(UUID uuid, String name, RoleEnum role) {
        this.clientId = uuid;
        this.name = name;
        this.role = role;
    }

    /**
     * Getter for uuid.
     *
     * @return The id of the client.
     */
    public UUID getClientId() {
        return clientId;
    }

    /**
     * Getter for name.
     *
     * @return The name of the client.
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for role.
     *
     * @return The role of the client (Player or Spectator).
     */
    public RoleEnum getRole() {
        return role;
    }

    /**
     * Getter for numberOfStrikes.
     *
     * @return The amount of strikes for the client.
     */
    public int getNumberOfStrikes() {
        return numberOfStrikes;
    }

    /**
     * method for when the client receives a strike.
     *
     * @param strikeAmount The amount of strikes the client receives.
     */
    public void increaseStrikes(int strikeAmount) {
        numberOfStrikes += strikeAmount;
    }

    /**
     * Use this method to reset the strikeAmount of this Client
     */
    public void resetStrikes() {
        numberOfStrikes = 0;
    }
}
