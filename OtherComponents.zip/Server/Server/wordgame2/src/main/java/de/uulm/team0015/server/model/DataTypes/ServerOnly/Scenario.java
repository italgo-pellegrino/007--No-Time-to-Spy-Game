package de.uulm.team0015.server.model.DataTypes.ServerOnly;

import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;

/**
 * Class for the board configuration containing the state of the fields needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß, Max Raedler
 * @version 1.0
 */
public class Scenario {
    private FieldStateEnum[][] scenario;

    /**
     * Getter for scenario.
     *
     * @return The type of field states of the game board.
     */
    public FieldStateEnum[][] getScenario() {
        return scenario;
    }

    /**
     * toString method of class Scenario.
     *
     * @return The field types of the game board as a string.
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        for (FieldStateEnum[] toPrint : scenario) {
            String format = "";
            String[] line = new String[toPrint.length];
            for (int j = 0; j < toPrint.length; j++) {
                format = format + "|%15s";
                line[j] = toPrint[j].toString();
            }
            builder.append(String.format(format, (Object[]) line));
            builder.append("|");
            builder.append("\n");
        }
        return builder.toString();
    }
}
