package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;

import java.util.Set;

/**
 * Class to handle the game logic actions for the general game.
 *
 * @author Max Raedler
 * @version 1.0
 */
public class VictoryLogic {

    /**
     * Method to check if a player reached a win condition.
     *
     * @param cat           The cat character.
     * @param janitor       The janitor character.
     * @param allCharacters Set of all characters on the map.
     * @return true if the game is over, false if not.
     */
    public static boolean isGameOver(Character cat, Character janitor, Set<Character> allCharacters) {
        if (cat.hasGadget(GadgetEnum.DIAMOND_COLLAR)) {
            return true;
        } else return allCharacters.contains(cat) && allCharacters.contains(janitor) && allCharacters.size() == 2;
    }
}
