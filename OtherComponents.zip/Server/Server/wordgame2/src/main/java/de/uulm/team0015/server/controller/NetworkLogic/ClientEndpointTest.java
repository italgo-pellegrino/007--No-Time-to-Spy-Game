package de.uulm.team0015.server.controller.NetworkLogic;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.logging.Logger;

import javax.websocket.ClientEndpoint;
import javax.websocket.CloseReason;
import javax.websocket.DeploymentException;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;

import org.glassfish.tyrus.client.ClientManager;

@ClientEndpoint
public class ClientEndpointTest{

    private static CountDownLatch latch;
    private Logger logger = Logger.getLogger(this.getClass().getName());
    
    private RemoteEndpoint.Basic remote;
    
    private FileWriter fs;
    private FileReader fr;
    
    private List<File> files;
    private Session session;

    @OnOpen
    public void onOpen(Session session) {
    	this.session = session;
        logger.info("Connected ... " + session.getId());
        try {
        	String hello = "{\"name\":\"Ita2\",\"role\":\"PLAYER\",\"playerId\":\"a8c4b724-95b5-4937-95c6-c36012f304f0\",\"type\":\"HELLO\",\"creationDate\":\"01.07.2020 15:06:53.2386779+02:00\",\"debugMessage\":\"DebugMessage\"}";
        		session.getBasicRemote().sendText(hello);
        		//session.getBasicRemote().sendText(hello);
        		
            
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @OnMessage
    public String onMessage(String scrambledWord, Session session) {
    	/**
    	 * Empfangene Messages werden gepuffert
    	 */
    	
    	System.out.println("Received Message: " + scrambledWord);
    	try {
    		fs.write(scrambledWord + "\n");
    		fs.flush();
    		}
    		catch (IOException e) {
    			e.printStackTrace();
    	}
    	
    	
    	
    	System.out.println("Received Message: " + scrambledWord);
    	
    	return "";
    	
    	/*
        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
        try {
            logger.info("Unscramble the word ...." + scrambledWord);
            String unscrambledWord = bufferRead.readLine();
            return unscrambledWord;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        */
    }

    @OnClose
    public void onClose(Session session, CloseReason closeReason) {
        logger.info(String.format("Session %s close because of %s", session.getId(), closeReason));
        latch.countDown();
    }
    
    public void println(String message) {
    	try {
			remote.sendText(message);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    public static void main(String[] args) throws IOException {
        //latch = new CountDownLatch(1);

        ClientManager client = ClientManager.createClient();
        Session s = null;
        try {
            s = client.connectToServer(ClientEndpointTest.class, new URI("ws://localhost:7007/websockets/game"));
            //latch.await();
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            br.readLine();

        } catch (DeploymentException | URISyntaxException e /*| InterruptedException e*/) {
            throw new RuntimeException(e);
        }
        finally {
        	s.close();
        }
    }
    
    
    /**
     * Diese Methode sorgt für die Verbindung des Clients zum Server und erstellt eine gesonderte Testdatei
     * 
     * @param port
     */
    public void connect(int port, int player) {
    	try {
    		if(files == null) {
    			files = new ArrayList<File>();
    		}
    		
    		File file = new File("test" + port + player + ".txt");
    		
			fs = new FileWriter(file);
			fr = new FileReader(file);
			
			files.add(file);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
    	latch = new CountDownLatch(1);

        ClientManager client = ClientManager.createClient();
        try {
            client.connectToServer(ClientEndpointTest.class, new URI("ws://localhost:" + port + "/websockets/game"));
            latch.await();

        } catch (DeploymentException | URISyntaxException | InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    
    
    public String readMessage() {
    	int i;
    	String message = null;
    	try {
			while((i =fr.read()) !=  Integer.parseInt("\n")) {
				message += (char) i;
			}
			//Um "\n" zu skippen
			fr.read();
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	return message;
    	
    }
    
    public void reset() {
    	for(File file: files) {
    		file.delete();
    	}
    	
    	try {
    		if(session.isOpen()) {
    			session.close();
    		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void sendMessage() {
    	
    }
}