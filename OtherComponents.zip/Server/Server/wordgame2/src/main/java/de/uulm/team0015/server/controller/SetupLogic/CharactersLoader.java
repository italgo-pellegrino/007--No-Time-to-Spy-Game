package de.uulm.team0015.server.controller.SetupLogic;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.CharacterDescription;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.CharacterInformation;
import de.uulm.team0015.server.model.Enumerations.GenderEnum;

import java.util.UUID;
import java.util.logging.Logger;

/**
 * With this class you can load an array of CharacterDescriptions
 * Before loading you should change the path to your File
 * If any error occurred .load() will return null
 *
 * @author Max Raedler
 * @version 1.0
 */
public class CharactersLoader {
    private String path;
    private final static Logger LOGGER = Logger.getLogger(CharactersLoader.class.getName());

    /**
     * Getter for path.
     *
     * @return The path of the character.json file.
     */
    public String getPath() {
        return path;
    }

    /**
     * Setter for path.
     *
     * @param path The path of the character.json file.
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Constructor for class CharactersLoader.
     */
    public CharactersLoader() {
        path = "default/characters.json";
        ServerLogger.addHandler(LOGGER);
    }

    /**
     * Reads a File at the given path with readFileToString()
     *
     * @return An array of CharacterDescription, null if the file wasn't found or the JSON-File can't be parsed
     */
    public CharacterInformation[] load() {
        String jsonString = ScenarioLoader.readFileToString(path, "CharacterDescription");
        if (jsonString == null) {
            return null;
        }
        Gson gson = new Gson();
        try {
            CharacterDescription[] descriptions = gson.fromJson(jsonString, CharacterDescription[].class);
            for (CharacterDescription d : descriptions) {
                if (d.getGender() == null) {
                    d.setGender(GenderEnum.DIVERSE);
                }
                if (d.getFeatures().contains(null)) {
                    String Message = "Error while loading CharacterDescription(s) it seems that a features-Set contains illegal arguments!";
                    LOGGER.severe(Message);
                    return null;
                }
                if (d.getName().length() < 3) {
                    String Message = "Error while loading CharacterDescription(s) it seems like a character name is too short!";
                    LOGGER.severe(Message);
                    return null;
                }
            }
            String Message = "Loaded CharacterDescription(s) successfully!";
            LOGGER.info(Message);
            CharacterInformation[] informations = new CharacterInformation[descriptions.length];
            for (int i = 0; i < descriptions.length; i++) {
                CharacterInformation information = new CharacterInformation(UUID.randomUUID(), descriptions[i]);
                informations[i] = information;
            }
            Message = "Created CharacterInformations(s) successfully!";
            LOGGER.info(Message);
            return informations;
        } catch (JsonSyntaxException jse) {
            String Message = "A JSON-Parser error by GSON occurred: " + jse.getMessage();
            LOGGER.severe(Message);
            return null;
        }
    }
}
