package de.uulm.team0015.server.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.logging.*;

/**
 * ServerLogger class, that is used to setup a global handler for all loggers.
 * The logging level can be set globally by any class.(It is intended though, to be only used by the ServerShell and the configVerbosity command)
 * A logger can be set up by defining a logger attribute in the class that you want to use the logger in, containing the name of the class:
 * private final static Logger LOGGER = Logger.getLogger(CLASSNAME.class.getName());
 * It can then be added to the global Handler by calling the addHandler method in the first line of the constructor:
 * ServerLogger.addHandler(LOGGER);
 * Messages can then be logged by calling the respective method for the log level. e.g.:
 * LOGGER.info("message");
 *
 * @author Tom Weisser
 * @version 1.0
 * @see Logger
 */
public class ServerLogger {
    static private final Logger GLOBALLOGGER = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
    static private FileHandler logFile;
    static private boolean isSetup = false;
    static private Handler consoleHandler;
    public static boolean printToConsole = false;

    /**
     * Static setup function, that is used to setup the global logger and FileHandler.
     * The .log file of the log will be saved to the /logs directory, using the date and time in the filename, to guarantee distinction between logs.
     *
     * @throws IOException Throws an IOException if the setup of the logfile fails.
     */
    static public void setup() throws IOException {
        isSetup = true;

        Logger rootLogger = Logger.getLogger("");
        Handler[] handlers = rootLogger.getHandlers();
        if (handlers[0] instanceof ConsoleHandler) {
            consoleHandler = handlers[0];
            consoleHandler.setLevel(Level.SEVERE);
        }

        Files.createDirectories(Paths.get("logs"));
        // add signature to filename, containing current date and time
        LocalDateTime dateTime = LocalDateTime.now();
        DateTimeFormatter formatDateTime = DateTimeFormatter.ofPattern("dd-MM-yyyy_HH-mm-ss");
        String outputPath = "logs/ServerLog_" + dateTime.format(formatDateTime) + ".log";
        logFile = new FileHandler(outputPath);

        //GLOBALLOGGER.setLevel(Level.INFO);
        GLOBALLOGGER.setLevel(Level.ALL);
        
        /**
         * �nderung am 30.06.2020
         */
        //logFile.setLevel(Level.INFO);
        logFile.setLevel(Level.ALL);

        // create a log formatter
        SimpleFormatter formatter = new SimpleFormatter();
        logFile.setFormatter(formatter);
        GLOBALLOGGER.addHandler(logFile);
    }

    /**
     * Static function that is used to add a new logger to the global handler.
     * If no global Handler has been initialized yet, it will do so by calling the setup method.
     *
     * @param logger A logger object, which the global Handler will be added to.
     */
    public static void addHandler(Logger logger) {
        if (!isSetup) {
            try {
                setup();
            } catch (IOException ioe) {
                ioe.printStackTrace();
            }
        }

        // Check if class already has handler registered
        if (!Arrays.asList(logger.getHandlers()).contains(logFile)) {
            logger.addHandler(logFile);
            logger.setLevel(Level.FINEST);
        }
    }

    /**
     * Static function that is used to globally set the Level of the Handler processing all the log messages.
     *
     * @param level A Level object, which the global Handler will be set to by calling its' respective setLevel(Level) method.
     */
    public static void setLevel(Level level) {
        GLOBALLOGGER.setLevel(level);
        logFile.setLevel(level);
        if (printToConsole) {
            consoleHandler.setLevel(level);
        } else {
            consoleHandler.setLevel(Level.SEVERE);
        }
    }

    public static void setConsoleOutput(boolean printToConsole) {
        ServerLogger.printToConsole = printToConsole;
        if (printToConsole) {
            consoleHandler.setLevel(logFile.getLevel());
        } else {
            consoleHandler.setLevel(Level.SEVERE);
        }
    }
}
