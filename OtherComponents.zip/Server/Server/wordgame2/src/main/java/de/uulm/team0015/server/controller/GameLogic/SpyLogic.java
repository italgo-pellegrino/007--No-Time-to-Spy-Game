package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidSafeCombinationException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfRangeException;

import java.util.Collections;
import java.util.Set;

/**
 * Class to handle the game logic actions for the spy action.
 *
 * @author Manuel Werner, Simon Demharter
 * @version 1.0
 */
public class SpyLogic {
	
	/**
	 * Bool, welches überprüft ob das Diamanthalsband schon auf dem Spielfeld ist
	 */
	private static boolean diamondCollarInMap;
	

    /**
     * Method for when a character spies on another character.
     *
     * @param character                 The character that is spying.
     * @param map                       The board of the game.
     * @param target                    The target of the character.
     * @param characters                Set of all characters currently in the game.
     * @param charactersPlayer1       Set of all characters in faction player1.
     * @param charactersPlayer2       Set of all characters in faction player2.
     * @param charactersNPC             Set of all npc characters.
     * @param player1SafeCombinations The safe combinations of player one.
     * @param player2SafeCombinations The safe combinations of player two.
     * @param matchconfig               The matchconfig.
     * @return true if the character successfully spied on another character, false if not.
     * @throws InvalidTargetException          If the character targets an invalid field.
     * @throws TargetOutOfRangeException       If the target is out of range.
     * @throws InvalidSafeCombinationException If the character does not have the right safe combination.
     */
    public static boolean spyLogic(Character character, FieldMap map, Point target, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Set<Character> charactersNPC, Set<Integer> player1SafeCombinations, Set<Integer> player2SafeCombinations, Matchconfig matchconfig) throws InvalidTargetException, TargetOutOfRangeException, InvalidSafeCombinationException {
        try {
            // Spying on a character
            map.validateFieldHasCharacter(target, characters);
            map.validateIsNeighbour(character.getCoordinates(), target);

            if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersNPC)) {
                double successChance = matchconfig.getSpySuccessChance();

                if (character.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || character.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
                    successChance /= 2;
                }

                if (Math.random() < successChance) {
                    character.updateIntelligencePoints(matchconfig.getSecretToIpFactor());
                    GadgetLogic.checkHasWireTapWithEarplugs(character, characters, matchconfig.getSecretToIpFactor());

                    if (character.isMemberOfFaction(charactersPlayer1)) {
                        if (player1SafeCombinations.isEmpty()) {
                            player1SafeCombinations.add(1);
                        } else {
                        	int newSecret = Collections.max(player1SafeCombinations) + 1;
                        	if(newSecret <= MainServerLogic.amountOfSafes) {
                        		player1SafeCombinations.add(newSecret);
                        	}
                        }
                    } else if (character.isMemberOfFaction(charactersPlayer2)) {
                        if (player2SafeCombinations.isEmpty()) {
                            player2SafeCombinations.add(1);
                        } else {
                        	int newSecret = Collections.max(player2SafeCombinations) + 1;
                        	if(newSecret <= MainServerLogic.amountOfSafes) {
                        		player2SafeCombinations.add(newSecret);
                        	}
                        }
                    }
                    return true;
                } else {
                    if (character.hasProperty(PropertyEnum.TRADECRAFT)) {
                        if (Math.random() < successChance) {
                            character.updateIntelligencePoints(matchconfig.getSecretToIpFactor());
                            GadgetLogic.checkHasWireTapWithEarplugs(character, characters, matchconfig.getSecretToIpFactor());

                            if (character.isMemberOfFaction(charactersPlayer1)) {
                                if (player1SafeCombinations.isEmpty()) {
                                	/**
                                	 * Tresor 0 gibt es nicht! ... Änderung am 18.07
                                	 */
                                    player1SafeCombinations.add(1);
                                } else {
                                	int newSecret = Collections.max(player1SafeCombinations) + 1;
                                	if(newSecret <= MainServerLogic.amountOfSafes) {
                                		player1SafeCombinations.add(newSecret);
                                	}
                                }
                            } else if (character.isMemberOfFaction(charactersPlayer2)) {
                                if (player2SafeCombinations.isEmpty()) {
                                	/**
                                	 * Tresor 0 gibt es nicht! ... Änderung am 18.07
                                	 */
                                    player2SafeCombinations.add(1);
                                } else {
                                	int newSecret = Collections.max(player2SafeCombinations) + 1;
                                	if(newSecret <= MainServerLogic.amountOfSafes) {
                                		player2SafeCombinations.add(newSecret);
                                	}
                                }
                            }
                            return true;
                        }
                    }
                }
            }
            return false;

        } catch (InvalidTargetException exception) {
            // Spying on a safe
            map.getField(target).validateIsState(FieldStateEnum.SAFE);

            if (character.hasProperty(PropertyEnum.FLAPS_AND_SEALS)) {
                map.validateIsInRange(character.getCoordinates(), target, 2);
            } else {
                map.validateIsNeighbour(character.getCoordinates(), target);
            }

            if (character.isMemberOfFaction(charactersPlayer1)) {
                character.validateHasSafeCombination(map.getField(target).getSafeIndex(), player1SafeCombinations);
                character.updateIntelligencePoints(matchconfig.getSecretToIpFactor());
                GadgetLogic.checkHasWireTapWithEarplugs(character, characters, matchconfig.getSecretToIpFactor());

                if (map.getFieldsOfState(FieldStateEnum.SAFE).size() > map.getField(target).getSafeIndex()) {
                    player1SafeCombinations.remove(map.getField(target).getSafeIndex());
                    player1SafeCombinations.add(map.getField(target).getSafeIndex() + 1);
                    return true;
                } else if (map.getFieldsOfState(FieldStateEnum.SAFE).size() == map.getField(target).getSafeIndex()) {
                    /**
                     * Diamanthalsband schon im Umlauf, Änderung am 19.07
                     */
                	if(!diamondCollarInMap) {
                    	character.addGadget(GadgetEnum.DIAMOND_COLLAR);
                    	diamondCollarInMap = true;
                    }
                	
                    player1SafeCombinations.remove(map.getField(target).getSafeIndex());
                    return true;
                }
            } else if (character.isMemberOfFaction(charactersPlayer2)) {
                character.validateHasSafeCombination(map.getField(target).getSafeIndex(), player2SafeCombinations);
                character.updateIntelligencePoints(matchconfig.getSecretToIpFactor());
                GadgetLogic.checkHasWireTapWithEarplugs(character, characters, matchconfig.getSecretToIpFactor());

                if (map.getFieldsOfState(FieldStateEnum.SAFE).size() > map.getField(target).getSafeIndex()) {
                    player2SafeCombinations.remove(map.getField(target).getSafeIndex());
                    player2SafeCombinations.add(map.getField(target).getSafeIndex() + 1);
                    return true;
                } else if (map.getFieldsOfState(FieldStateEnum.SAFE).size() == map.getField(target).getSafeIndex()) {
                	/**
                     * Diamanthalsband schon im Umlauf, Änderung am 19.07
                     */
                	if(!diamondCollarInMap) {
                    	character.addGadget(GadgetEnum.DIAMOND_COLLAR);
                    	diamondCollarInMap = true;
                    }
                    player2SafeCombinations.remove(map.getField(target).getSafeIndex());
                    return true;
                }
            }
            return false;
        }
    }
}
