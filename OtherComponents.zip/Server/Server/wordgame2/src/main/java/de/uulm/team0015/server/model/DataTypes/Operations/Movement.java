package de.uulm.team0015.server.model.DataTypes.Operations;

import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;

import java.util.UUID;

/**
 * Class for the operations when a character uses his movement points to move to another field needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class Movement extends Operation {
    private /*final*/ Point from;

    /**
     * Constructor of the class Movement.
     *
     * @param type        The type of the operation.
     * @param successful  Whether the operation was successful or not.
     * @param target      The coordinates of the target.
     * @param characterId The id of the character.
     * @param from        The coordinates of the character.
     */
    public Movement(OperationEnum type, boolean successful, Point target, UUID characterId, Point from) {
        super(type, successful, target, characterId);
        this.from = from;
    }
    
    

    /**
     * Getter for from.
     *
     * @return The coordinates of the character.
     */
    public Point getFrom() {
        return from;
    }
}
