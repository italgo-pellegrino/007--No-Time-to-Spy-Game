package de.uulm.team0015.server.model.DataTypes.Util;

import java.util.Set;

/**
 * Class which represents the current state of the game for a specific player.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class State {
    private int currentRound;
    private FieldMap map;
    private Set<Integer> mySafeCombinations;
    private Set<Character> characters;
    private Point catCoordinates;
    private Point janitorCoordinates;

    /**
     * Constructor of the class State.
     *
     * @param currentRound       The count of the current round.
     * @param map                The game board.
     * @param mySafeCombinations The safe combinations of the characters.
     * @param characters         The characters of the faction from the player.
     * @param catCoordinates     The coordinates of the cat.
     * @param janitorCoordinates The coordinates of the janitor.
     */
    public State(int currentRound, FieldMap map, Set<Integer> mySafeCombinations, Set<Character> characters, Point catCoordinates, Point janitorCoordinates) {
        this.currentRound = currentRound;
        this.map = map;
        this.mySafeCombinations = mySafeCombinations;
        this.characters = characters;
        this.catCoordinates = catCoordinates;
        this.janitorCoordinates = janitorCoordinates;
    }

    /**
     * Getter for currentRound.
     *
     * @return The count of the current round.
     */
    public int getCurrentRound() {
        return currentRound;
    }

    /**
     * Getter for map.
     *
     * @return The game board.
     */
    public FieldMap getMap() {
        return map;
    }

    /**
     * Setter for map.
     *
     * @param map The game board.
     */
    public void setMap(FieldMap map) {
        this.map = map;
    }

    /**
     * Getter for mySafeCombinations.
     *
     * @return The safe combinations of the characters.
     */
    public Set<Integer> getMySafeCombinations() {
        return mySafeCombinations;
    }

    /**
     * Getter for characters.
     *
     * @return The characters of the faction from the player.
     */
    public Set<Character> getCharacters() {
        return characters;
    }

    /**
     * Getter for catCoordinates.
     *
     * @return The coordinates of the cat.
     */
    public Point getCatCoordinates() {
        return catCoordinates;
    }

    /**
     * Setter for catCoordinates.
     *
     * @param catCoordinates The coordinates of the cat.
     */
    public void setCatCoordinates(Point catCoordinates) {
        this.catCoordinates = catCoordinates;
    }

    /**
     * Getter for janitorCoordinates.
     *
     * @return The coordinates of the janitor.
     */
    public Point getJanitorCoordinates() {
        return janitorCoordinates;
    }

    /**
     * Setter for janitorCoordinates.
     *
     * @param janitorCoordinates The coordinates of the janitor.
     */
    public void setJanitorCoordinates(Point janitorCoordinates) {
        this.janitorCoordinates = janitorCoordinates;
    }
}
