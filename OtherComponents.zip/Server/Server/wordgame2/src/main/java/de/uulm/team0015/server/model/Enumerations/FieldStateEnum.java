package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration for every type of field needed for game logic purposes and creating a scenario.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum FieldStateEnum {
    BAR_TABLE,
    ROULETTE_TABLE,
    WALL,
    FREE,
    BAR_SEAT,
    SAFE,
    FIREPLACE,
}
