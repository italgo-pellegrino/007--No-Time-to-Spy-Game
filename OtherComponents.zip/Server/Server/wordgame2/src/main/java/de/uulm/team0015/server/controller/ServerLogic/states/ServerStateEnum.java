package de.uulm.team0015.server.controller.ServerLogic.states;

/**
 * Enumeration for the states of the server.
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 */
public enum ServerStateEnum {
    CONNECTION_SETUP_STATE,
    DECISION_PHASE_STATE,
    EQUIPMENT_PHASE_STATE,
    GAME_END_STATE,
    GAME_OPERATION_STATE,
    GAME_PAUSE_STATE,
    GAME_PHASE_STATE,
    RECONNECT_STATE
}
