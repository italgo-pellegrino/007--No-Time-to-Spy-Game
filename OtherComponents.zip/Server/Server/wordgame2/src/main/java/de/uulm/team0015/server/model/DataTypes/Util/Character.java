package de.uulm.team0015.server.model.DataTypes.Util;

import de.uulm.team0015.server.controller.GameLogic.OperationLogic;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Gadgets.WireTapWithEarplugs;
import de.uulm.team0015.server.model.DataTypes.Operations.Exfiltration;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;

import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Class for the informations of a character needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 */
public class Character {
    private final UUID characterId;
    private final String name;
    private Point coordinates;
    private int mp, ap, hp, ip, chips;
    private Set<PropertyEnum> properties;
    private Set<Gadget> gadgets;

    /**
     * Constructor of the class Character.
     *
     * @param characterId The id of the character.
     * @param name        The name of the character.
     * @param coordinates The coordinates of the character on the game board.
     * @param properties  The properties of the character.
     * @param gadgets     The gadgets in the inventory of the character.
     */
    public Character(UUID characterId, String name, Point coordinates, Set<PropertyEnum> properties, Set<Gadget> gadgets) {
        this.characterId = characterId;
        this.name = name;
        this.coordinates = coordinates;
        this.properties = properties;
        this.gadgets = gadgets;

        // standard values
        this.mp = 0;
        this.ap = 0;
        this.hp = 100;
        this.ip = 0;
        this.chips = 10;
    }

    /**
     * Getter for characterId.
     *
     * @return The id of the character.
     */
    public UUID getCharacterId() {
        return characterId;
    }

    /**
     * Getter for name.
     *
     * @return The name of the character.
     */
    public String getName() {
        return name;
    }

    /**
     * Getter for coordinates.
     *
     * @return The coordinates of the character on the game board.
     */
    public Point getCoordinates() {
        return coordinates;
    }

    /**
     * Setter for coordinates.
     *
     * @param coordinates The coordinates of the character on the game board.
     */
    public void setCoordinates(Point coordinates) {
        this.coordinates = coordinates;
    }

    /**
     * Getter for movementPoints.
     *
     * @return The amount of movement points of the character.
     */
    public int getMp() {
        return mp;
    }

    /**
     * Setter for movementPoints.
     *
     * @param mp The amount of movement points of the character.
     */
    public void setMp(int mp) {
        this.mp = mp;
    }

    /**
     * Getter for actionPoints.
     *
     * @return The amount of action points of the character.
     */
    public int getAp() {
        return ap;
    }

    /**
     * Setter for actionPoints.
     *
     * @param ap The amount of action points of the character.
     */
    public void setAp(int ap) {
        this.ap = ap;
    }

    /**
     * Getter for healthPoints.
     *
     * @return The amount of health points of the character.
     */
    public int getHp() {
        return hp;
    }

    /**
     * Setter for healthPoints.
     *
     * @param hp The amount of health points of the character.
     */
    public void setHp(int hp) {
        this.hp = hp;
    }

    /**
     * Getter for intelligencePoints.
     *
     * @return The amount of intelligence points of the character.
     */
    public int getIp() {
        return ip;
    }

    /**
     * Setter for intelligencePoints.
     *
     * @param ip The amount of intelligence points of the character.
     */
    public void setIp(int ip) {
        this.ip = ip;
    }

    /**
     * Getter for chips.
     *
     * @return The amount of chips of the character.
     */
    public int getChips() {
        return chips;
    }

    /**
     * Getter for properties.
     *
     * @return The properties of the character.
     */
    public Set<PropertyEnum> getProperties() {
        return properties;
    }

    /**
     * Getter for gadgets.
     *
     * @return The gadgets in the inventory of the character.
     */
    public Set<Gadget> getGadgets() {
        return gadgets;
    }

    /**
     * Method to validate if the given target is this character.
     *
     * @param target The coordinates of the target character.
     * @throws InvalidTargetException If the given target is not this character.
     */
    public void validateIsCharacter(Point target) throws InvalidTargetException {
        if (!getCoordinates().equals(target)) {
            throw new InvalidTargetException("The target on the field " + target.toString() + " is not the character " + name + "!");
        }
    }

    /**
     * Method to validate if the id belongs to a valid character.
     *
     * @param characters  The character currently active in the game.
     * @param characterId The id of the character.
     * @throws InvalidCharacterException If the character does not exist.
     */
    public static void validateCharacter(Set<Character> characters, UUID characterId) throws InvalidCharacterException {
        if (characters.stream().filter(x -> x.getCharacterId().equals(characterId)).findAny().orElse(null) == null) {
            throw new InvalidCharacterException("The character with the id" + characterId + " does not exist!");
        }
    }

    /**
     * Method to validate if the character has enough movement points.
     *
     * @throws InvalidMovementPointsException If the character does not have enough movement points.
     */
    public void validateHasMovementPoints() throws InvalidMovementPointsException {
        if (mp == 0) {
            throw new InvalidMovementPointsException("The character " + getName() + " has no movement points left!");
        }
    }

    /**
     * Method to validate if the character has enough action points.
     *
     * @throws InvalidActionPointsException If the character does not have enough action points.
     */
    public void validateHasActionPoints() throws InvalidActionPointsException {
        if (ap == 0) {
            throw new InvalidActionPointsException("The character " + getName() + " has no action points left!");
        }
    }

    /**
     * Method to validate if the character has enough chips for his desired bet.
     *
     * @param bet The amount of chips the character wants to bet.
     * @throws InvalidChipAmountException If the character does not have enough chips.
     */
    public void validateHasChipAmount(int bet) throws InvalidChipAmountException {
        if ((chips < bet)) {
            throw new InvalidChipAmountException("The character " + getName() + " has not enough chips for that bet! Expected at least " + bet + ", but got " + chips + ".");
        }
    }

    /**
     * Method to validate if the character has the given property.
     *
     * @param propertyEnum The type of property.
     * @throws InvalidPropertyException If the character does not have the given property.
     */
    public void validateHasProperty(PropertyEnum propertyEnum) throws InvalidPropertyException {
        if (!hasProperty(propertyEnum)) {
            throw new InvalidPropertyException("The character " + getName() + " does not have the property " + propertyEnum.toString() + "!");
        }
    }

    /**
     * Method to validate if the character has the given gadget.
     *
     * @param gadgetEnum The type of gadget.
     * @throws InvalidGadgetException If the character does not have the given gadget in his inventory.
     */
    public void validateHasGadget(GadgetEnum gadgetEnum) throws InvalidGadgetException {
        if (!hasGadget(gadgetEnum)) {
            throw new InvalidGadgetException("The character " + getName() + " does not have the gadget " + gadgetEnum.toString() + " in his inventory!");
        }
    }

    /**
     * Method to validate if the character has no gadget of the given type in his inventory.
     *
     * @param gadget The type of gadget.
     * @throws InvalidGadgetException If the character has the given gadget in his inventory.
     */
    public void validateHasNoGadgetOfType(GadgetEnum gadget) throws InvalidGadgetException {
        if (hasGadget(gadget)) {
            throw new InvalidGadgetException("The character " + getName() + " has the gadget " + gadget.toString() + " in his inventory!");
        }
    }

    /**
     * Method to validate if the character is not a member of the given faction.
     *
     * @param faction The faction.
     * @throws InvalidTargetException If the character is a member of the given faction.
     */
    public void validateIsNoMemberOfFaction(Set<Character> faction) throws InvalidTargetException {
        if (isMemberOfFaction(faction)) {
            throw new InvalidTargetException("The character " + getName() + " is a member of the wrong faction!");
        }
    }

    /**
     * Method to validate if the character has the given safe combination.
     *
     * @param safeCombination The combination for the safe.
     * @param teamSafeCombination The safe combinations available to the characters fraction.
     * @throws InvalidSafeCombinationException If the character does not have the given safe combination.
     */
    public void validateHasSafeCombination(int safeCombination, Set<Integer> teamSafeCombination) throws InvalidSafeCombinationException {
        if (!teamSafeCombination.contains(safeCombination)) {
            throw new InvalidSafeCombinationException("The Character " + name + " does not have the safe combination " + safeCombination + " to open that safe.");
        }
    }

    /**
     * Method to get the character of the given character id.
     *
     * @param characters  The characters currently active in the game.
     * @param characterId The id of the character.
     * @return The character of the given character id.
     */
    public static Character getCharacter(Set<Character> characters, UUID characterId) {
        return characters.stream().filter(x -> x.getCharacterId().equals(characterId)).findAny().orElse(null);
    }

    /**
     * Method to check if the character is on the given field.
     *
     * @param point The coordinates of the field.
     * @return true if the character is on the given field, false if not.
     */
    public boolean isOnField(Point point) {
        return coordinates.equals(point);
    }

    /**
     * Method for when the character uses an action point.
     */
    public void useActionPoint() {
        ap -= 1;
    }

    /**
     * Method for when the character uses an movement point.
     */
    public void useMovementPoint() {
        mp -= 1;
    }

    /**
     * Method to update intelligence points from a character.
     *
     * @param intelligencePoints The amount of intelligence points the character receives, negative if he looses that amount.
     */
    public void updateIntelligencePoints(int intelligencePoints) {
        ip += intelligencePoints;
    }

    /**
     * Method to add chips to the the character.
     *
     * @param chips Amount of chips to be added.
     */
    public void updateChips(int chips) {
        this.chips += chips;
    }

    /**
     * Method for when the character takes damage.
     *
     * @param damage            The amount of damage the character receives.
     * @param map               The board of the game.
     * @param characters        Set of all characters currently in the game.
     * @param charactersPlayer1 Set of all characters in faction player1.
     * @param charactersPlayer2 Set of all characters in faction player2.
     */
    public void takeDamage(int damage, FieldMap map, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2) {
        if (hasProperty(PropertyEnum.TOUGHNESS)) {
            damage /= 2;
        }

        if (damage < hp) {
            hp -= damage;
        } else {
            damage = hp;
            Exfiltration exfiltration = new Exfiltration(OperationEnum.EXFILTRATION, false, null, getCharacterId(), getCoordinates());
            OperationLogic.exfiltration(exfiltration, map, characters);
        }

        if (isMemberOfFaction(charactersPlayer1)) {
            MainServerLogic.winCondition.addDamageTakenPlayer1(damage);
        } else if (isMemberOfFaction(charactersPlayer2)) {
            MainServerLogic.winCondition.addDamageTakenPlayer2(damage);
        }
    }

    /**
     * Method for when the character gets healed.
     *
     * @param heal The amount of healing the character receives.
     */
    public void getHealed(int heal) {
        hp += heal;

        if (hp > 100) {
            hp = 100;
        }
    }

    /**
     * Method to check if the character has the given property.
     *
     * @param propertyEnum The type of the property.
     * @return true if character has the given property, false if not
     */
    public boolean hasProperty(PropertyEnum propertyEnum) {
        for (PropertyEnum property : this.properties) {
            if (property.equals(propertyEnum)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to add a property to the character if the character doesn't have the property yet.
     *
     * @param propertyEnum The type of the property.
     */
    public void addProperty(PropertyEnum propertyEnum) {
        if (!hasProperty(propertyEnum)) {
            properties.add(propertyEnum);
        }
    }

    /**
     * Method to remove a property from the character if the character has the given property.
     *
     * @param propertyEnum The type of the property.
     */
    public void removeProperty(PropertyEnum propertyEnum) {
        properties.removeIf(property -> property.equals(propertyEnum));
    }

    /**
     * Method to check if the character has the given gadget in his inventory.
     *
     * @param gadgetEnum The type of the gadget.
     * @return true if character has the given gadget, false if not.
     */
    public boolean hasGadget(GadgetEnum gadgetEnum) {
        for (Gadget gadget : this.gadgets) {
            if (gadget.getGadgetEnum().equals(gadgetEnum)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to get the gadget of the given type if the character has the gadget in his inventory.
     *
     * @param gadgetEnum The type of the gadget.
     * @return The gadget of the given type, null if the gadget is not in the inventory .
     */
    public Gadget getGadget(GadgetEnum gadgetEnum) {
        for (Gadget gadget : gadgets) {
            if (gadget.getGadgetEnum().equals(gadgetEnum)) {
                return gadget;
            }
        }
        return null;
    }

    /**
     * Method to get the cocktail of the character.
     *
     * @return The cocktail, null if he has none.
     */
    public Cocktail getCocktail() {
        for (Gadget gadget : gadgets) {
            if (gadget.getGadgetEnum().equals(GadgetEnum.COCKTAIL)) {
                return (Cocktail) gadget;
            }
        }
        return null;
    }

    /**
     * Method to get the gadget WireTapWithEarplugs of the character.
     *
     * @return The WireTapWithEarplugs, null if he has none.
     */
    public WireTapWithEarplugs getWireTapWithEarplugs() {
        for (Gadget gadget : gadgets) {
            if (gadget.getGadgetEnum().equals(GadgetEnum.WIRETAP_WITH_EARPLUGS)) {
                return (WireTapWithEarplugs) gadget;
            }
        }
        return null;
    }


    /**
     * Method to get the character who has the gadget of the given type.
     *
     * @param characters The characters currently active in the game.
     * @param gadget     The type of gadget.
     * @return The character with the gadget of the given type if there is one, null if there is none.
     */
    public static Character getCharacterWithGadgetOfType(Set<Character> characters, GadgetEnum gadget) {
        return characters.stream().filter(c -> c.hasGadget(gadget)).findAny().orElse(null);
    }

    /**
     * Method to add the gadget into the inventory of the character if the character doesn't have the gadget yet.
     * This method is used when the gadget has no usage limit.
     *
     * @param gadgetEnum The type of the gadget.
     */
    public void addGadget(GadgetEnum gadgetEnum) {
        if (!hasGadget(gadgetEnum)) {
            switch (gadgetEnum) {
                case HAIRDRYER:
                    gadgets.add(new Gadget(GadgetEnum.HAIRDRYER));
                    break;
                case MOLEDIE:
                    gadgets.add(new Gadget(GadgetEnum.MOLEDIE, 1));
                    break;
                case TECHNICOLOUR_PRISM:
                    gadgets.add(new Gadget(GadgetEnum.TECHNICOLOUR_PRISM, 1));
                    break;
                case BOWLER_BLADE:
                    gadgets.add(new Gadget(GadgetEnum.BOWLER_BLADE, 1));
                    break;
                case MAGNETIC_WATCH:
                    gadgets.add(new Gadget(GadgetEnum.MAGNETIC_WATCH));
                    break;
                case POISON_PILLS:
                    gadgets.add(new Gadget(GadgetEnum.POISON_PILLS, 5));
                    break;
                case LASER_COMPACT:
                    gadgets.add(new Gadget(GadgetEnum.LASER_COMPACT));
                    break;
                case ROCKET_PEN:
                    gadgets.add(new Gadget(GadgetEnum.ROCKET_PEN, 1));
                    break;
                case GAS_GLOSS:
                    gadgets.add(new Gadget(GadgetEnum.GAS_GLOSS, 1));
                    break;
                case MOTHBALL_POUCH:
                    gadgets.add(new Gadget(GadgetEnum.MOTHBALL_POUCH, 5));
                    break;
                case FOG_TIN:
                    gadgets.add(new Gadget(GadgetEnum.FOG_TIN, 1));
                    break;
                case GRAPPLE:
                    gadgets.add(new Gadget(GadgetEnum.GRAPPLE));
                    break;
                case JETPACK:
                    gadgets.add(new Gadget(GadgetEnum.JETPACK, 1));
                    break;
                case WIRETAP_WITH_EARPLUGS:
                    gadgets.add(new WireTapWithEarplugs());
                    break;
                case CHICKEN_FEED:
                    gadgets.add(new Gadget(GadgetEnum.CHICKEN_FEED, 1));
                    break;
                case NUGGET:
                    gadgets.add(new Gadget(GadgetEnum.NUGGET, 1));
                    break;
                case MIRROR_OF_WILDERNESS:
                    gadgets.add(new Gadget(GadgetEnum.MIRROR_OF_WILDERNESS, 1));
                    break;
                case POCKET_LITTER:
                    gadgets.add(new Gadget(GadgetEnum.POCKET_LITTER));
                    break;
                case DIAMOND_COLLAR:
                    gadgets.add(new Gadget(GadgetEnum.DIAMOND_COLLAR, 1));
                    break;
                case COCKTAIL:
                    gadgets.add(new Cocktail());
                    break;
                /**
                 * Anti Schnabel Maske fehlt, Zusatz am 19.07
                 */
                case ANTI_PLAGUE_MASK:
                	gadgets.add(new Gadget(GadgetEnum.ANTI_PLAGUE_MASK));
                	break;
            }
        }
    }

    /**
     * Method to remove the gadget from the character if the character has the given gadget.
     *
     * @param gadgetEnum The type of the gadget.
     */
    public void removeGadget(GadgetEnum gadgetEnum) {
        gadgets.removeIf(gadget -> gadget.getGadgetEnum().equals(gadgetEnum));
    }

    /**
     * Method to use a gadget that has limited usages.
     *
     * @param gadgetEnum The type of the gadget.
     */
    public void useGadget(GadgetEnum gadgetEnum) {
        Gadget gadget = getGadget(gadgetEnum);
        gadget.use();
        if (gadget.getUsages() == 0) {
            removeGadget(gadgetEnum);
        }
    }

    /**
     * Method to check if the character is a member of the given faction.
     *
     * @param faction The faction.
     * @return true if character is a member of the given faction, false if not.
     */
    public boolean isMemberOfFaction(Set<Character> faction) {
        for (Character characters : faction) {
            if (characterId.equals(characters.characterId)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Method to set the movement and actions points, needed for every new round.
     */
    public void setupPoints() {
        int movementPoints = 2;
        int actionPoints = 1;


        if (hasProperty(PropertyEnum.NIMBLENESS)) {
            movementPoints = 3;
        }
        if (hasProperty(PropertyEnum.SLUGGISHNESS)) {
            movementPoints = 1;
        }
        if (hasProperty(PropertyEnum.SPRYNESS)) {
            actionPoints = 2;
        }

        if (hasProperty(PropertyEnum.AGILITY)) {
            if (Math.random() < 0.5) {
                movementPoints += 1;
            } else {
                actionPoints += 1;
            }
        }

        if (hasProperty(PropertyEnum.PONDEROUSNESS)) {
            if (Math.random() < 0.5) {
                movementPoints -= 1;
            } else {
                actionPoints -= 1;
            }

        }

        setMp(movementPoints);
        setAp(actionPoints);

    }

    /**
     * Method to get the coordinates of a random character of a given list of characters.
     *
     * @param characters All characters on the map.
     * @return The coordinates of the chosen character.
     */
    public static Character getRandomCharacter(Set<Character> characters) {
        int index = new Random().nextInt(characters.size());
        Iterator<Character> character = characters.iterator();
        for (int i = 0; i < index; i++) {
            character.next();
        }
        return character.next();
    }

    /**
     * toString method of the class Character.
     *
     * @return The attributes of the character as a String.
     */
    @Override
    public String toString() {
        return "characterId: " + characterId +
                "\n" +
                "name" + name +
                "\n" +
                "coordinates" + coordinates +
                "\n" +
                "movementPoints" + mp +
                "\n" +
                "actionPoints" + ap +
                "\n" +
                "healthPoints" + hp +
                "\n" +
                "intelligencePoints" + ip +
                "\n" +
                "chips" + chips +
                "\n" +
                "properties" + properties +
                "\n" +
                "gadgets" + gadgets;
    }
}
