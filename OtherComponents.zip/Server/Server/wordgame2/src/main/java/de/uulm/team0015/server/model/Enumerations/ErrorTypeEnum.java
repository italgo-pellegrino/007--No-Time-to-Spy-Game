package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration for every type of error occurring during the runtime of the application.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum ErrorTypeEnum {
    NAME_NOT_AVAILABLE,
    ALREADY_SERVING,
    SESSION_DOES_NOT_EXIST,
    ILLEGAL_MESSAGE,
    TOO_MANY_STRIKES,
    GENERAL
}
