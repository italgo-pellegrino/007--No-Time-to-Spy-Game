package de.uulm.team0015.server.controller.SetupLogic;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Scenario;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;

import java.io.*;
import java.util.logging.Logger;

/**
 * With this class you can load a Scenario
 * Before loading you should change the path to your File
 * If any error occurred .load() will return null
 *
 * @author Max Raedler
 * @version 1.0
 */
public class ScenarioLoader {
    private String path;
    private final static Logger LOGGER = Logger.getLogger(ScenarioLoader.class.getName());

    /**
     * Getter for path.
     *
     * @return The path of the example.scenario file.
     */
    public String getPath() {
        return path;
    }

    /**
     * Setter for path.
     *
     * @param path The path of the example.scenario file.
     */
    public void setPath(String path) {
        this.path = path;
    }

    /**
     * Constructor for class ScenarioLoader.
     */
    public ScenarioLoader() {
        path = "default/example.scenario";
        ServerLogger.addHandler(LOGGER);
    }

    /**
     * Reads a File at the given path with readFileToString()
     *
     * @return null if the file was not found or the JSON-File can not be parsed
     */
    public Scenario load() {
        String jsonString = ScenarioLoader.readFileToString(path, "Scenario");
        if (jsonString == null) {
            return null;
        }
        Gson gson = new Gson();
        try {
            Scenario scenario = gson.fromJson(jsonString, Scenario.class);

            FieldStateEnum[][] scen = scenario.getScenario();
            for (int i = 0; i < scen.length; i++) {
                for (int j = 0; j < scen[i].length; j++) {
                    if (scen[i][j] == null) {
                        String message = "Error while loading Scenario: Some FieldEnumerations are not recognized!";
                        LOGGER.severe(message);
                        return null;
                    }
                }
            }
            String message = "Loaded Scenario successfully!";
            LOGGER.info(message);
            return scenario;
        } catch (JsonSyntaxException jse) {
            String Message = "An JSON-Parser error by GSON occurred: " + jse.getMessage();
            LOGGER.severe(Message);
            return null;
        }

    }

    /**
     * Reads a File at the given path.
     *
     * @param path   The path of the file.
     * @param loader The loader.
     * @return The read file.
     */
    protected static String readFileToString(String path, String loader) {
        try {
            File file = new File(path);
            if (file.canRead()) {
                String Message = loader + " file found!";
                LOGGER.info(Message);
            } else {
                String Message = "Error: " + loader + " file not found!";
                LOGGER.severe(Message);
            }
            BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
            String str;
            StringBuilder builder = new StringBuilder();
            while ((str = input.readLine()) != null) {
                builder.append(str);
            }
            input.close();
            return builder.toString();
        } catch (IOException e) {
            String Message = "Error while reading " + loader + " file: " + e.toString();
            LOGGER.severe(Message);
            return null;
        }
    }
}
