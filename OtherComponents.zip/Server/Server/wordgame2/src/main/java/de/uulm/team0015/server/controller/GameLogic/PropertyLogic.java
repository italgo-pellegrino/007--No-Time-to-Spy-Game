package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidGadgetException;
import de.uulm.team0015.server.model.Exceptions.InvalidPropertyException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfSightException;

import java.util.Set;

/**
 * Class to handle the game logic actions for the properties.
 *
 * @author Alexander Preiß, Manuel Werner, Simon Demharter
 * @version 1.0
 */
public class PropertyLogic {

    /**
     * Method for when a character has the bangAndBurn property and uses it.
     *
     * @param character Character who uses a property.
     * @param map       The board of the game.
     * @param target    The coordinates of the target.
     * @return True if the property was used successfully, false if not.
     * @throws InvalidTargetException   If the character targets an invalid field.
     * @throws InvalidPropertyException If the character has not the right property.
     */
    public static boolean bangAndBurn(Character character, FieldMap map, Point target) throws InvalidTargetException, InvalidPropertyException {
        map.validateIsNeighbourOfState(character.getCoordinates(), target, FieldStateEnum.ROULETTE_TABLE);
        character.validateHasProperty(PropertyEnum.BANG_AND_BURN);
        map.getField(target).setDestroyed(true);
        return true;
    }

    /**
     * Method for when a character has the observation property and uses it.
     *
     * @param character         Character who uses a property.
     * @param map               The board of the game.
     * @param target            The coordinates of the target.
     * @param characters        Set of all characters on the map.
     * @param charactersPlayer1 Characters of player1.
     * @param charactersPlayer2 Characters of player2.
     * @param matchconfig       The match config.
     * @return True if the property was used successfully, false if not.
     * @throws InvalidTargetException    If the character targets an invalid field.
     * @throws InvalidPropertyException  If the character has not the right property.
     * @throws TargetOutOfSightException If the character targets a field which is out of range.
     * @throws InvalidGadgetException    If the gadget is not in the inventory.
     */
    public static boolean observation(Character character, FieldMap map, Point target, Set<Character> characters, Set<Character> charactersPlayer1, Set<Character> charactersPlayer2, Matchconfig matchconfig) throws InvalidTargetException, InvalidPropertyException, TargetOutOfSightException, InvalidGadgetException {
        // Validate
        map.validateFieldHasCharacter(target, characters);
        character.validateHasProperty(PropertyEnum.OBSERVATION);
        map.validateIsInSight(character.getCoordinates(), target);
        character.validateHasNoGadgetOfType(GadgetEnum.MOLEDIE);

        double successChance = matchconfig.getObservationSuccessChance();

        // Check if the character has clammy clothes or constant clammy clothes
        if (character.hasProperty(PropertyEnum.CLAMMY_CLOTHES) || character.hasProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES)) {
            successChance = successChance / 2;
        }
        // Check if the target has pocketLitter
        if (map.getCharacterOnField(target, characters).hasGadget(GadgetEnum.POCKET_LITTER)) {
            return false;
        }

        if (character.isMemberOfFaction(charactersPlayer1)) {
            if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer2)) {
                if (Math.random() < successChance) {
                    return true;
                } else {
                    if (character.hasProperty(PropertyEnum.TRADECRAFT)) {
                        return Math.random() < successChance;
                    }
                }
            }
        } else if (character.isMemberOfFaction(charactersPlayer2)) {
            if (map.getCharacterOnField(target, characters).isMemberOfFaction(charactersPlayer1)) {
                if (Math.random() < successChance) {
                    return true;
                } else {
                    if (character.hasProperty(PropertyEnum.TRADECRAFT)) {
                        return Math.random() < successChance;
                    }
                }
            }
        }
        return false;
    }
}
