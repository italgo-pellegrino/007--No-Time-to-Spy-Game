package de.uulm.team0015.server.model.DataTypes.Gadgets;

import de.uulm.team0015.server.model.Enumerations.GadgetEnum;

/**
 * Class for the gadget Cocktail, which has additional information compared to the baseline gadget.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 */
public class Cocktail extends Gadget {
    private boolean isPoisoned;

    /**
     * Constructor of the class Cocktail.
     */
    public Cocktail() {
        super(GadgetEnum.COCKTAIL, 1);
        this.isPoisoned = false;
    }

    /**
     * Getter for isPoisoned.
     *
     * @return true if the cocktail is poisoned, false if not.
     */
    public boolean isPoisoned() {
        return isPoisoned;
    }

    /**
     * Method to poison the cocktail.
     */
    public void poison() {
        isPoisoned = true;
    }
}
