package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration to define the gender for the characters.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum GenderEnum {
    MALE,
    FEMALE,
    DIVERSE
}
