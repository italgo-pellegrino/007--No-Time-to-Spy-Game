package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumerations for every type of victory condition and relevant to determine the winner of a game.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum VictoryEnum {
    VICTORY_BY_IP,
    VICTORY_BY_COLLAR,
    VICTORY_BY_DRINKING,
    VICTORY_BY_SPILLING,
    VICTORY_BY_HP,
    VICTORY_BY_RANDOMNESS,
    VICTORY_BY_LEAVE,
    VICTORY_BY_KICK
}
