package de.uulm.team0015.server.model.DataTypes.ServerOnly;

/**
 * Class containing the information for the scenario configuration.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class Matchconfig {
    // Gadget: Moledie
    private int moledieRange;

    // Gadget: BowlerBlade
    private int bowlerBladeRange;
    private double bowlerBladeHitChance;
    private int bowlerBladeDamage;

    // Gadget: LaserCompact
    private double laserCompactHitChance;

    // Gadget: RocketPen
    private int rocketPenDamage;

    // Gadget: GasGloss
    private int gasGlossDamage;

    // Gadget: MothballPouch
    private int mothballPouchRange;
    private int mothballPouchDamage;

    // Gadget: FogTin
    private int fogTinRange;

    // Gadget: Grapple
    private int grappleRange;
    private double grappleHitChance;

    // Gadget: WiretapWithEarplugs
    private double wiretapWithEarplugsFailChance;

    // Gadget: Mirror
    private double mirrorSwapChance;

    // Gadget: Cocktail
    private double cocktailDodgeChance;
    private int cocktailHp;

    // GameActions
    private double spySuccessChance;
    private double babysitterSuccessChance;
    private double honeyTrapSuccessChance;
    private double observationSuccessChance;

    // GameFactors
    private int chipsToIpFactor;
    private int secretToIpFactor;
    private int minChipsRoulette;
    private int maxChipsRoulette;
    private int roundLimit;
    private int turnPhaseLimit;
    private int catIp;
    private int strikeMaximum;
    private int pauseLimit;
    private int reconnectLimit;

    /**
     * Getter for moledieRange.
     *
     * @return The range of the gadget moledie.
     */
    public int getMoledieRange() {
        return moledieRange;
    }

    /**
     * Setter for moledieRange.
     *
     * @param moledieRange The range of the gadget moledie.
     */
    public void setMoledieRange(int moledieRange) {
        this.moledieRange = moledieRange;
    }

    /**
     * Getter for bowlerBladeRange.
     *
     * @return The range of the gadget bowlerBlade.
     */
    public int getBowlerBladeRange() {
        return bowlerBladeRange;
    }

    /**
     * Setter for bowlerBladeRange.
     *
     * @param bowlerBladeRange The range of the gadget bowlerBlade.
     */
    public void setBowlerBladeRange(int bowlerBladeRange) {
        this.bowlerBladeRange = bowlerBladeRange;
    }

    /**
     * Getter for bowlerBladeHitChance.
     *
     * @return The hit chance of the gadget bowlerBlade.
     */
    public double getBowlerBladeHitChance() {
        return bowlerBladeHitChance;
    }

    /**
     * Setter for bowlerBladeHitChance.
     *
     * @param bowlerBladeHitChance The hit chance of the gadget bowlerBlade.
     */
    public void setBowlerBladeHitChance(double bowlerBladeHitChance) {
        this.bowlerBladeHitChance = bowlerBladeHitChance;
    }

    /**
     * Getter for bowlerBladeDamage.
     *
     * @return The damage of the gadget bowlerBlade.
     */
    public int getBowlerBladeDamage() {
        return bowlerBladeDamage;
    }

    /**
     * Setter for bowlerBladeDamage.
     *
     * @param bowlerBladeDamage The damage of the gadget bowlerBlade.
     */
    public void setBowlerBladeDamage(int bowlerBladeDamage) {
        this.bowlerBladeDamage = bowlerBladeDamage;
    }

    /**
     * Getter for laserCompactHitChance.
     *
     * @return The hit chance of the gadget laserCompact.
     */
    public double getLaserCompactHitChance() {
        return laserCompactHitChance;
    }

    /**
     * Setter for laserCompactHitChance.
     *
     * @param laserCompactHitChance The hit chance of the gadget laserCompact.
     */
    public void setLaserCompactHitChance(double laserCompactHitChance) {
        this.laserCompactHitChance = laserCompactHitChance;
    }

    /**
     * Getter for rocketPenDamage.
     *
     * @return The damage of the gadget rocketPen.
     */
    public int getRocketPenDamage() {
        return rocketPenDamage;
    }

    /**
     * Setter  for rocketPenDamage.
     *
     * @param rocketPenDamage The damage of the gadget rocketPen.
     */
    public void setRocketPenDamage(int rocketPenDamage) {
        this.rocketPenDamage = rocketPenDamage;
    }

    /**
     * Getter for gasGlossDamage.
     *
     * @return The damage of the gadget gasGloss.
     */
    public int getGasGlossDamage() {
        return gasGlossDamage;
    }

    /**
     * Setter for gasGlossDamage.
     *
     * @param gasGlossDamage The damage of the gadget gasGloss.
     */
    public void setGasGlossDamage(int gasGlossDamage) {
        this.gasGlossDamage = gasGlossDamage;
    }

    /**
     * Getter for mothballPouchRange.
     *
     * @return The range of the gadget mothballPouch.
     */
    public int getMothballPouchRange() {
        return mothballPouchRange;
    }

    /**
     * Setter for mothballPouchRange.
     *
     * @param mothballPouchRange The range of the gadget mothballPouch.
     */
    public void setMothballPouchRange(int mothballPouchRange) {
        this.mothballPouchRange = mothballPouchRange;
    }

    /**
     * Getter for mothballPouchDamage.
     *
     * @return The damage of the gadget mothballPouch.
     */
    public int getMothballPouchDamage() {
        return mothballPouchDamage;
    }

    /**
     * Setter for mothballPouchDamage.
     *
     * @param mothballPouchDamage The damage of the gadget mothballPouch.
     */
    public void setMothballPouchDamage(int mothballPouchDamage) {
        this.mothballPouchDamage = mothballPouchDamage;
    }

    /**
     * Getter for fogTinRange.
     *
     * @return The range of the gadget fogTin.
     */
    public int getFogTinRange() {
        return fogTinRange;
    }

    /**
     * Setter for fogTinRange.
     *
     * @param fogTinRange The range of the gadget fogTin.
     */
    public void setFogTinRange(int fogTinRange) {
        this.fogTinRange = fogTinRange;
    }

    /**
     * Getter for grappleRange.
     *
     * @return The range of the gadget grapple.
     */
    public int getGrappleRange() {
        return grappleRange;
    }

    /**
     * Setter for grappleRange.
     *
     * @param grappleRange The range of the gadget grapple.
     */
    public void setGrappleRange(int grappleRange) {
        this.grappleRange = grappleRange;
    }

    /**
     * Getter for grappleHitChance.
     *
     * @return The hit chance of the gadget grapple.
     */
    public double getGrappleHitChance() {
        return grappleHitChance;
    }

    /**
     * Setter for grappleHitChance.
     *
     * @param grappleHitChance The hit chance of the gadget grapple.
     */
    public void setGrappleHitChance(double grappleHitChance) {
        this.grappleHitChance = grappleHitChance;
    }

    /**
     * Getter for wiretapWithEarplugsFailChance.
     *
     * @return The fail chance of the gadget wiretapWithEarplugs.
     */
    public double getWiretapWithEarplugsFailChance() {
        return wiretapWithEarplugsFailChance;
    }

    /**
     * Setter for wiretapWithEarplugsFailChance.
     *
     * @param wiretapWithEarplugsFailChance The fail chance of the gadget wiretapWithEarplugs.
     */
    public void setWiretapWithEarplugsFailChance(double wiretapWithEarplugsFailChance) {
        this.wiretapWithEarplugsFailChance = wiretapWithEarplugsFailChance;
    }

    /**
     * Getter for mirrorSwapChance.
     *
     * @return The swap chance of the gadget mirror.
     */
    public double getMirrorSwapChance() {
        return mirrorSwapChance;
    }

    /**
     * Setter for mirrorSwapChance.
     *
     * @param mirrorSwapChance The swap chance of the gadget mirror.
     */
    public void setMirrorSwapChance(double mirrorSwapChance) {
        this.mirrorSwapChance = mirrorSwapChance;
    }

    /**
     * Getter for cocktailDodgeChance.
     *
     * @return The dodge chance for the gadget cocktail.
     */
    public double getCocktailDodgeChance() {
        return cocktailDodgeChance;
    }

    /**
     * Setter for cocktailDodgeChance.
     *
     * @param cocktailDodgeChance The dodge chance for the gadget cocktail.
     */
    public void setCocktailDodgeChance(double cocktailDodgeChance) {
        this.cocktailDodgeChance = cocktailDodgeChance;
    }

    /**
     * Getter for cocktailHp.
     *
     * @return The amount of health points you get from the gadget cocktail.
     */
    public int getCocktailHp() {
        return cocktailHp;
    }

    /**
     * Setter for cocktailHp.
     *
     * @param cocktailHp The amount of health points you get from the gadget cocktail.
     */
    public void setCocktailHp(int cocktailHp) {
        this.cocktailHp = cocktailHp;
    }

    /**
     * Getter for spySuccessChance.
     *
     * @return The success chance of the action spy.
     */
    public double getSpySuccessChance() {
        return spySuccessChance;
    }

    /**
     * Setter for spySuccessChance.
     *
     * @param spySuccessChance The success chance of the action spy.
     */
    public void setSpySuccessChance(double spySuccessChance) {
        this.spySuccessChance = spySuccessChance;
    }

    /**
     * Getter for babysitterSuccessChance.
     *
     * @return The success chance of the property babysitter.
     */
    public double getBabysitterSuccessChance() {
        return babysitterSuccessChance;
    }

    /**
     * Setter for babysitterSuccessChance.
     *
     * @param babysitterSuccessChance The success chance of the property babysitter.
     */
    public void setBabysitterSuccessChance(double babysitterSuccessChance) {
        this.babysitterSuccessChance = babysitterSuccessChance;
    }

    /**
     * Getter for honeyTrapSuccessChance.
     *
     * @return The success chance of the property honeyTrap.
     */
    public double getHoneyTrapSuccessChance() {
        return honeyTrapSuccessChance;
    }

    /**
     * Setter for honeyTrapSuccessChance.
     *
     * @param honeyTrapSuccessChance The success chance of the property honeyTrap.
     */
    public void setHoneyTrapSuccessChance(double honeyTrapSuccessChance) {
        this.honeyTrapSuccessChance = honeyTrapSuccessChance;
    }

    /**
     * Getter for observationSuccessChance.
     *
     * @return The success chance of the property observation.
     */
    public double getObservationSuccessChance() {
        return observationSuccessChance;
    }

    /**
     * Setter for observationSuccessChance.
     *
     * @param observationSuccessChance The success chance of the property observation.
     */
    public void setObservationSuccessChance(double observationSuccessChance) {
        this.observationSuccessChance = observationSuccessChance;
    }

    /**
     * Getter for chipsToIpFactor.
     *
     * @return The factor at which chips will be converted into intelligence points.
     */
    public int getChipsToIpFactor() {
        return chipsToIpFactor;
    }

    /**
     * Setter for chipsToIpFactor.
     *
     * @param chipsToIpFactor The factor at which chips will be converted into intelligence points.
     */
    public void setChipsToIpFactor(int chipsToIpFactor) {
        this.chipsToIpFactor = chipsToIpFactor;
    }

    /**
     * Getter for secretToIpFactor.
     *
     * @return The factor at which secrets will be converted into intelligence points.
     */
    public int getSecretToIpFactor() {
        return secretToIpFactor;
    }

    /**
     * Setter for secretToIpFactor
     *
     * @param secretToIpFactor The factor at which secrets will be converted into intelligence points.
     */
    public void setSecretToIpFactor(int secretToIpFactor) {
        this.secretToIpFactor = secretToIpFactor;
    }

    /**
     * Getter for minChipsRoulette.
     *
     * @return The minimum amount of chips a roulette table can have.
     */
    public int getMinChipsRoulette() {
        return minChipsRoulette;
    }

    /**
     * Setter for minChipsRoulette.
     *
     * @param minChipsRoulette The minimum amount of chips a roulette table can have.
     */
    public void setMinChipsRoulette(int minChipsRoulette) {
        this.minChipsRoulette = minChipsRoulette;
    }

    /**
     * Getter for maxChipsRoulette.
     *
     * @return The maximum amount of chips a roulette table can have.
     */
    public int getMaxChipsRoulette() {
        return maxChipsRoulette;
    }

    /**
     * Setter for maxChipsRoulette
     *
     * @param maxChipsRoulette The maximum amount of chips a roulette table can have.
     */
    public void setMaxChipsRoulette(int maxChipsRoulette) {
        this.maxChipsRoulette = maxChipsRoulette;
    }

    /**
     * Getter for roundLimit.
     *
     * @return The number of maximum rounds able to play in a game.
     */
    public int getRoundLimit() {
        return roundLimit;
    }

    /**
     * Setter for roundLimit.
     *
     * @param roundLimit The number of maximum round able to play in a game.
     */
    public void setRoundLimit(int roundLimit) {
        this.roundLimit = roundLimit;
    }

    /**
     * Getter for turnPhaseLimit.
     *
     * @return The maximum amount of seconds a turnPhase can last in a game.
     */
    public int getTurnPhaseLimit() {
        return turnPhaseLimit;
    }

    /**
     * Setter for turnPhaseLimit.
     *
     * @param turnPhaseLimit The maximum amount of seconds a turnPhase can last in a game.
     */
    public void setTurnPhaseLimit(int turnPhaseLimit) {
        this.turnPhaseLimit = turnPhaseLimit;
    }

    /**
     * Getter for catIp.
     *
     * @return The amount of intelligence points of the cat.
     */
    public int getCatIp() {
        return catIp;
    }

    /**
     * Setter for catIp.
     *
     * @param catIp The amount if intelligence points of the cat.
     */
    public void setCatIp(int catIp) {
        this.catIp = catIp;
    }

    /**
     * Getter for strikeMaximum.
     *
     * @return The number of maximum strikes a client can get.
     */
    public int getStrikeMaximum() {
        return strikeMaximum;
    }

    /**
     * Setter for strikeMaximum.
     *
     * @param strikeMaximum The number of maximum strikes a client can get.
     */
    public void setStrikeMaximum(int strikeMaximum) {
        this.strikeMaximum = strikeMaximum;
    }

    /**
     * Getter for pauseLimit.
     *
     * @return The maximum amount of seconds a pause can last in a game.
     */
    public int getPauseLimit() {
        return pauseLimit;
    }

    /**
     * Setter for pauseLimit.
     *
     * @param pauseLimit The maximum amount of seconds a pause can last in a game.
     */
    public void setPauseLimit(int pauseLimit) {
        this.pauseLimit = pauseLimit;
    }

    /**
     * Getter for reconnectLimit.
     *
     * @return The maximum amount of seconds a client can take to reconnect to the game.
     */
    public int getReconnectLimit() {
        return reconnectLimit;
    }

    /**
     * Setter for reconnectLimit.
     *
     * @param reconnectLimit The maximum amount of seconds a client can take to reconnect to the game.
     */
    public void setReconnectLimit(int reconnectLimit) {
        this.reconnectLimit = reconnectLimit;
    }

    /**
     * ToString method for the class Matchconfig.
     *
     * @return The values of Matchconfig as a String.
     */
    @Override
    public String toString() {
        return  // Gadget: Moledie
                "moledieRange: " + moledieRange +
                "\n" +

                // Gadget: BowlerBlade
                "bowlerBladeRange: " + bowlerBladeRange +
                "\n" +
                "bowlerBladeHitChance: " + bowlerBladeHitChance +
                "\n" +
                "bowlerBladeDamage: " + bowlerBladeDamage +
                "\n" +

                // Gadget: LaserCompact
                "laserCompactHitChance: " + laserCompactHitChance +
                "\n" +

                // Gadget: RocketPen
                "rocketPenDamage: " + rocketPenDamage +
                "\n" +

                // Gadget: GasGloss
                "gasGlossDamage: " + gasGlossDamage +
                "\n" +

                // Gadget: MothballPouch
                "mothballPouchRange: " + mothballPouchRange +
                "\n" +
                "mothballPouchDamage: " + mothballPouchDamage +
                "\n" +

                // Gadget: FogTin
                "fogTinRange: " + fogTinRange +
                "\n" +

                // Gadget: Grapple
                "grappleRange: " + grappleRange +
                "\n" +
                "grappleHitChance: " + grappleHitChance +
                "\n" +

                // Gadget: WiretapWithEarplugs
                "wiretapWithEarplugsFailChance: " + wiretapWithEarplugsFailChance +
                "\n" +

                // Gadget: Mirror
                "mirrorSwapChance: " + mirrorSwapChance +
                "\n" +

                // Gadget: Cocktail
                "cocktailDodgeChance: " + cocktailDodgeChance +
                "\n" +
                "cocktailHp: " + cocktailHp +
                "\n" +

                // GameActions
                "spySuccessChance: " + spySuccessChance +
                "\n" +
                "babysitterSuccessChance: " + babysitterSuccessChance +
                "\n" +
                "honeyTrapSuccessChance: " + honeyTrapSuccessChance +
                "\n" +
                "observationSuccessChance: " + observationSuccessChance +
                "\n" +

                // GameFactors
                "chipsToIpFactor: " + chipsToIpFactor +
                "\n" +
                "roundLimit: " + roundLimit +
                "\n" +
                "turnPhaseLimit: " + turnPhaseLimit +
                "\n" +
                "catIp: " + catIp +
                "\n" +
                "strikeMaximum: " + strikeMaximum +
                "\n" +
                "pauseLimit: " + pauseLimit +
                "\n" +
                "reconnectLimit: " + reconnectLimit;
    }
}
