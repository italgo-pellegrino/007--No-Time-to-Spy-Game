package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.timer.PausableTimer;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.Receive.EquipmentChoiceMessage;
import de.uulm.team0015.server.model.Messages.Receive.GameOperationMessage;
import de.uulm.team0015.server.model.Messages.Receive.ItemChoiceMessage;
import de.uulm.team0015.server.model.Messages.Send.GamePauseMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.logging.Logger;

/**
 * GamePauseState, used to handle a pause by a player.
 *
 * @author Tom Weisser
 * @version 1.0
 * @see ServerState
 */
public class GamePauseState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(GamePauseState.class.getName());
    private final ServerState previous;
    private ServerStateEnum previousStateEnum;
    private final PausableTimer pauseTimer;

    /**
     * GamePauseState-Constructor, will start the timer upon entry.
     *
     * @param previous The state in which the pause has been made.
     */
    public GamePauseState(ServerState previous) {
        super();
        ServerLogger.addHandler(LOGGER);
        previousStateEnum = ServerState.activeState;
        mainServerLogic.serverState = this;
        ServerState.activeState = ServerStateEnum.GAME_PAUSE_STATE;
        this.previous = previous;

        LOGGER.warning("A player has paused the game, entering GamePauseState.");
        ServerShell.print("A player has paused the game, stopping for " + mainServerLogic.initialMatchconfig.getPauseLimit() + " seconds.");

        // Create GamePauseMessage
        GamePauseMessage gamePauseMessage = GamePauseMessage.createGamePauseMessage(true,
                false,
                null,
                "Game has been paused by a player.");
        // Broadcast GamePauseMessage
        mainServerLogic.broadcast(gamePauseMessage);

        // Start timer
        pauseTimer = new PausableTimer(this, mainServerLogic.initialMatchconfig.getPauseLimit());
    }

    /**
     * Override of the onPLayerPause method. Checks, if a player wants to resume the game.
     * If a player tries to pause the already paused game, he will get a strike.
     *
     * @param manager SimpleClientManager of the player that tried to pause the game.
     * @param pause   Boolean indicating if the player wants to resume or pause
     */
    @Override
    public void onPlayerPause(SimpleClientManager manager, boolean pause) {
        if (!pause) {
            String debugMessage = "A player has resumed the game, the pause is over.";
            LOGGER.warning(debugMessage);
            ServerShell.print(debugMessage);
            // Stopping the pause timer
            pauseTimer.stop();
            // Create GamePauseMessage to resume game
            GamePauseMessage gamePauseMessage = GamePauseMessage.createGamePauseMessage(false,
                    false,
                    null,
                    debugMessage);
            // Send GamePauseMessage
            mainServerLogic.broadcast(gamePauseMessage);
            // Return to previous state
            /**
             * Änderungsmaßnahme am 15.07. -> Zustandsänderung von GamePausePhase in einen anderen State
             */
            //Der "vorherige Zustand" war dieses GamePause Objekt, Zurücksetzung nicht nötig, da ein immer ein neues GamePause Object instanziiert wird
            //previousStateEnum = ServerState.activeState;
            //this.previous = this;
            
            /** **/
            previous.onReturn();
        } else {
            if (MainServerLogic.strictness) {
                String problem = "Player tried to pause already paused game.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Player tried to pause already paused game. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        }
    }

    /**
     * Method to handle a player disconnect during pause, will change to ReconnectState.
     *
     * @param manager SimpleClientManager of the disconnected player client.
     */
    @Override
    public void onPlayerDisconnect(SimpleClientManager manager) {
        pauseTimer.stop();
        new ReconnectState(this, manager);
    }

    /**
     * Method to handle delayed ItemChoiceMessage.
     *
     * @param manager           SimpleClientManager of the spectator that sent the ItemChoiceMessage.
     * @param itemChoiceMessage The message that was received.
     */
    @Override
    public void onItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        if (previousStateEnum == ServerStateEnum.DECISION_PHASE_STATE) {
            if (MainServerLogic.strictness) {
                String problem = "Received ItemChoiceMessage by player during pause.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Received ItemChoiceMessage by player during pause. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        } else {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent ItemChoiceMessage in wrong state.");
        }
    }

    /**
     * Method to handle delayed EquipmentChoiceMessage.
     *
     * @param manager                SimpleClientManager of the client that sent the EquipmentChoiceMessage.
     * @param equipmentChoiceMessage The message that was received.
     */
    @Override
    public void onEquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        if (previousStateEnum == ServerStateEnum.EQUIPMENT_PHASE_STATE) {
            if (MainServerLogic.strictness) {
                String problem = "Received EquipmentChoiceMessage by player during pause.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Received EquipmentChoiceMessage by player during pause. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        } else {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent EquipmentChoiceMessage in wrong state.");
        }
    }

    /**
     * Method to handle delayed GameOperationMessage.
     *
     * @param manager              SimpleClientManager that sent the GameOperationMessage
     * @param gameOperationMessage The message that was received
     */
    @Override
    public void onGameOperationMessage(SimpleClientManager manager, GameOperationMessage gameOperationMessage) {
        if (previousStateEnum == ServerStateEnum.GAME_PHASE_STATE) {
            if (MainServerLogic.strictness) {
                String problem = "Received GameOperationMessage by player during pause. Message might have been delayed.";
                LOGGER.info(problem);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, problem);
            } else {
                String problem = "Received GameOperationMessage by player during pause. Message might have been delayed.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        } else {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent GameOperationMessage in wrong state.");
        }
    }

    /**
     * Method that is called, when returning to the GamePauseState from the ReconnectState.
     */
    @Override
    public void onReturn() {
        String returnString = "Returned from ReconnectState to PauseState. Resuming timer, " + getRemainingTime() + " seconds remaining.";
        LOGGER.warning(returnString);
        ServerShell.print(returnString);
        mainServerLogic.serverState = this;
        ServerState.activeState = ServerStateEnum.GAME_PAUSE_STATE;
        // Setting the previous ServerStateEnum to ReconnectState, Delayed messages are not allowed anymore.
        previousStateEnum = ServerStateEnum.RECONNECT_STATE;
        pauseTimer.start();
    }

    /**
     * Method, that is called by the PausableTimer on expiry.
     * Ends the pause by broadcasting GamePauseMessage and calling onReturn() in previous state.
     */
    public void onPauseOver() {
        String debugMessage = "The pause has reached the time limit. Resuming game.";
        LOGGER.warning(debugMessage);
        ServerShell.print(debugMessage);

        // Create GamePauseMessage to resume game
        GamePauseMessage gamePauseMessage = GamePauseMessage.createGamePauseMessage(false,
                false,
                null,
                debugMessage);
        // Send GamePauseMessage
        mainServerLogic.broadcast(gamePauseMessage);
        // Return to previous state
        previous.onReturn();
    }

    /**
     * Getter method for the remaining time of the respective PausableTimer
     *
     * @return Will return the amount of time remaining in the pause.
     */
    public int getRemainingTime() {
        return pauseTimer.getRemainingTime();
    }

    /**
     * Getter method for the ServerStateEnum of the previous state
     *
     * @return The ServerStateEnum of the state, the server was in before the pause.
     */
    ServerStateEnum getPreviousStateEnum() {
        return previousStateEnum;
    }

    /**
     * Method used to stop the GamePauseState by stopping the PausableTimer.
     */
    @Override
    public void stop() {
        LOGGER.warning("GamePauseState has been stopped.");
        pauseTimer.stop();
    }
}
