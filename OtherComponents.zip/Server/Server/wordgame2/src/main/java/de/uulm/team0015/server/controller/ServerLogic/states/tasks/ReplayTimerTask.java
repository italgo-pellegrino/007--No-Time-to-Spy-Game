package de.uulm.team0015.server.controller.ServerLogic.states.tasks;

import de.uulm.team0015.server.controller.ServerLogic.states.GameEndState;

import java.util.TimerTask;

/**
 * ReplayTimerTask used by the GameEndState to determine if the replay request time limit has been reached.
 */
public class ReplayTimerTask extends TimerTask {
    private GameEndState parent;

    /**
     * Constructor for ReplayTimerTask.
     *
     * @param parent Parent GameEndState that uses this task.
     */
    public ReplayTimerTask(GameEndState parent) {
        this.parent = parent;
    }

    /**
     * Calls the onReplay()-method in the parent state.
     */
    @Override
    public void run() {
        parent.onReplayTimerEnd();
    }
}
