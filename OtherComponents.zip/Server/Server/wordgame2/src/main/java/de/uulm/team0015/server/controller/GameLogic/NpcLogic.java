package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Operations.GadgetAction;
import de.uulm.team0015.server.model.DataTypes.Operations.GambleAction;
import de.uulm.team0015.server.model.DataTypes.Operations.Movement;
import de.uulm.team0015.server.model.DataTypes.Operations.Operation;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import de.uulm.team0015.server.model.Exceptions.TargetBlockedException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfRangeException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfSightException;

import java.util.*;
import java.util.stream.Collectors;

/**
 * This class contains the Logic which is used to generate Operations for npcs
 *
 * @author Max Raedler
 */
public class NpcLogic {

    /**
     * This methods returns a valid, random Movement for one npc.
     * Only call this method if the npc has enough mp.
     *
     * @param npc      The npc
     * @param fieldMap The current FieldMap
     * @return Either a Movement Operation or a retire Operation if there is no possible move.
     */
    public static Operation randomMove(Character npc, FieldMap fieldMap) {
        Set<Point> accessibleNeighbours = fieldMap.getAccessibleNeighbours(npc.getCoordinates());
        Set<Point> neighboursWithGadgets = fieldMap.getNeighboursWithGadget(npc.getCoordinates());
        neighboursWithGadgets.removeIf(point -> !fieldMap.getField(point).isAccessible());

        if (!neighboursWithGadgets.isEmpty()) {
            return new Movement(OperationEnum.MOVEMENT, true, fieldMap.getRandomPoint(neighboursWithGadgets), npc.getCharacterId(), npc.getCoordinates());
        } else if (!accessibleNeighbours.isEmpty()) {
            return new Movement(OperationEnum.MOVEMENT, true, fieldMap.getRandomPoint(accessibleNeighbours), npc.getCharacterId(), npc.getCoordinates());
        } else {
            return new Operation(OperationEnum.RETIRE, true, npc.getCoordinates(), npc.getCharacterId());
        }
    }

    /**
     * This methods returns a valid, (Action) Operation for a specific npc
     * Only call this method if the npc has enough ap.
     *
     * @param npc           The npc
     * @param fieldMap      The current FieldMap
     * @param allCharacters A set of all Characters on the FieldMap
     * @param matchconfig   The preloaded Matchconfig
     * @return Either a gable,gadget,... Operation or a retire Operation if there is no possible action.
     */
    public static Operation randomAction(Character npc, FieldMap fieldMap, Set<Character> allCharacters, Matchconfig matchconfig) {
        if (fieldMap.getField(npc.getCoordinates()).isFoggy()) {
            return new Operation(OperationEnum.RETIRE, true, npc.getCoordinates(), npc.getCharacterId());
        }
        Random random = new Random();

        Point npcCouldGamble = couldGamble(npc, fieldMap);

        HashMap<Gadget, Point> npcCouldUseGadget = null;

        ArrayList<Point> neighbourCocktails = new ArrayList<>(fieldMap.getNeighboursWithGadgetOfType(npc.getCoordinates(), GadgetEnum.COCKTAIL));

        if (npc.getGadgets().size() > 0) {
            npcCouldUseGadget = couldUseGadget(npc, fieldMap, allCharacters, matchconfig);
        }

        int val = random.nextInt(100);
        if (npcCouldGamble != null && npc.getChips() != 0 && (val < 50 || npcCouldUseGadget == null)) {
            int maxAmnt = fieldMap.getField(npcCouldGamble).getChipAmount();
            if (npc.getChips() < maxAmnt) {
                maxAmnt = npc.getChips();
            }
            return new GambleAction(OperationEnum.GAMBLE_ACTION, true, npcCouldGamble, npc.getCharacterId(), 1 + random.nextInt(maxAmnt));
        } else if (npc.getCocktail() == null && neighbourCocktails.size() != 0 && (val < 75 || npcCouldUseGadget == null)) {
            return new GadgetAction(OperationEnum.GADGET_ACTION, true, neighbourCocktails.get(0), npc.getCharacterId(), GadgetEnum.COCKTAIL);
        } else if (npcCouldUseGadget != null && npcCouldUseGadget.size() != 0) {
            Iterator it = npcCouldUseGadget.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Gadget, Point> entry = (Map.Entry<Gadget, Point>) it.next();
                if (entry.getKey().getGadgetEnum().equals(GadgetEnum.MOLEDIE)) {
                    return new GadgetAction(OperationEnum.GADGET_ACTION, true, entry.getValue(), npc.getCharacterId(), GadgetEnum.MOLEDIE);
                }
            }
            Map.Entry<Gadget, Point>[] entries = npcCouldUseGadget.entrySet().toArray(new Map.Entry[0]);
            Map.Entry<Gadget, Point> randomEntry = entries[random.nextInt(entries.length)];
            return new GadgetAction(OperationEnum.GADGET_ACTION, true, randomEntry.getValue(), npc.getCharacterId(), randomEntry.getKey().getGadgetEnum());
        } else {
            return new Operation(OperationEnum.RETIRE, true, npc.getCoordinates(), npc.getCharacterId());
        }
    }

    /**
     * Method to get all the possibilities to use a gadget for the npc character.
     *
     * @param npc           The npc character.
     * @param fieldMap      The board of the game.
     * @param allCharacters A set of all Characters on the FieldMap.
     * @param matchconfig   The preloaded Matchconfig.
     * @return The hashset with the possible targets for every gadget of the npc.
     */
    private static HashMap<Gadget, Point> couldUseGadget(Character npc, FieldMap fieldMap, Set<Character> allCharacters, Matchconfig matchconfig) {
        Set<Gadget> gadgets = npc.getGadgets();
        HashMap<Gadget, Point> usableGadgets = new HashMap<>();
        for (Gadget gadget : gadgets) {
            switch (gadget.getGadgetEnum()) {
                case HAIRDRYER:
                    if (npc.hasProperty(PropertyEnum.CLAMMY_CLOTHES)) {
                        usableGadgets.put(gadget, npc.getCoordinates());
                    }
                    break;
                case MOLEDIE:
                    if (gadget.getUsages() > 0) {
                        boolean foundtarget = false;
                        for (Character target : allCharacters) {
                            if (!target.getCharacterId().equals(npc.getCharacterId())) {
                                try {
                                    fieldMap.validateIsInRange(npc.getCoordinates(), target.getCoordinates(), matchconfig.getMoledieRange());
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target.getCoordinates());
                                } catch (TargetOutOfRangeException | InvalidTargetException | TargetOutOfSightException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target.getCoordinates());
                                foundtarget = true;
                                break;
                            }
                        }
                        if (!foundtarget) {
                            ArrayList<Point> freeFields = new ArrayList<>(fieldMap.getFreeFields(allCharacters));
                            for (Point target : freeFields) {
                                try {
                                    fieldMap.validateIsInRange(npc.getCoordinates(), target, matchconfig.getMoledieRange());
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target);
                                } catch (TargetOutOfRangeException | InvalidTargetException | TargetOutOfSightException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target);
                                break;
                            }
                        }
                    }
                    break;
                case TECHNICOLOUR_PRISM:
                    if (gadget.getUsages() > 0) {
                        Set<Point> tables = fieldMap.getNeighboursOfState(npc.getCoordinates(), FieldStateEnum.ROULETTE_TABLE);
                        if (!tables.isEmpty()) {
                            usableGadgets.put(gadget, tables.iterator().next());
                        }
                    }
                    break;
                case BOWLER_BLADE:
                    if (gadget.getUsages() > 0) {
                        for (Character target : allCharacters) {
                            if (!target.getCharacterId().equals(npc.getCharacterId())) {
                                try {
                                    fieldMap.validateIsInRange(npc.getCoordinates(), target.getCoordinates(), matchconfig.getBowlerBladeRange());
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target.getCoordinates());
                                    fieldMap.validateIsNotBlocked(npc.getCoordinates(), target.getCoordinates(), allCharacters);
                                } catch (TargetOutOfRangeException | InvalidTargetException | TargetOutOfSightException | TargetBlockedException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target.getCoordinates());
                                break;
                            }
                        }
                    }
                    break;
                case POISON_PILLS:
                    if (gadget.getUsages() > 0) {
                        ArrayList<Character> neighbourCharacters = new ArrayList<>(fieldMap.getNeighbourCharacters(npc.getCoordinates(), allCharacters));
                        ArrayList<Point> neighboursWithCocktail = new ArrayList<>(fieldMap.getNeighboursWithGadgetOfType(npc.getCoordinates(), GadgetEnum.COCKTAIL));

                        if (neighboursWithCocktail.size() >= 1) {
                            usableGadgets.put(gadget, neighboursWithCocktail.get(0));
                        } else {
                            for (Character c : neighbourCharacters) {
                                if (c.hasGadget(GadgetEnum.COCKTAIL)) {
                                    usableGadgets.put(gadget, c.getCoordinates());
                                    break;
                                }
                            }
                        }
                    }
                    break;
                case LASER_COMPACT:
                    ArrayList<Character> charactersWithCocktail = (ArrayList<Character>) allCharacters.stream().filter(x -> x.getCocktail() != null).collect(Collectors.toList());
                    if (charactersWithCocktail.size() >= 1) {
                        for (Character target : charactersWithCocktail) {
                            if (!target.getCharacterId().equals(npc.getCharacterId())) {
                                try {
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target.getCoordinates());
                                } catch (InvalidTargetException | TargetOutOfSightException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target.getCoordinates());
                                break;
                            }
                        }
                    } else {
                        ArrayList<Point> allCocktailsOnMap = new ArrayList<>(fieldMap.getFieldsWithGadgetOfType(GadgetEnum.COCKTAIL));
                        for (Point target : allCocktailsOnMap) {
                            try {
                                fieldMap.validateIsInSight(npc.getCoordinates(), target);
                            } catch (TargetOutOfSightException | InvalidTargetException e) {
                                continue;
                            }
                            usableGadgets.put(gadget, target);
                            break;
                        }
                    }
                    break;
                case ROCKET_PEN:
                    if (gadget.getUsages() > 0) {
                        for (Character target : allCharacters) {
                            if (!target.getCharacterId().equals(npc.getCharacterId())) {
                                try {
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target.getCoordinates());
                                } catch (InvalidTargetException | TargetOutOfSightException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target.getCoordinates());
                                break;
                            }
                        }
                    }
                    break;
                case GAS_GLOSS:
                    if (gadget.getUsages() > 0) {
                        ArrayList<Character> neighbourCharacters = new ArrayList<>(fieldMap.getNeighbourCharacters(npc.getCoordinates(), allCharacters));
                        if (neighbourCharacters.size() >= 1) {
                            usableGadgets.put(gadget, neighbourCharacters.get(0).getCoordinates());
                        }
                    }
                    break;
                case MOTHBALL_POUCH:
                    if (gadget.getUsages() > 0) {
                        ArrayList<Point> fireplaces = new ArrayList<>(fieldMap.getFieldsOfState(FieldStateEnum.FIREPLACE));
                        for (Point target : fireplaces) {
                            if (!fieldMap.getField(target).isDestroyed()) {
                                try {
                                    fieldMap.validateIsInRange(npc.getCoordinates(), target, matchconfig.getMothballPouchRange());
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target);
                                } catch (TargetOutOfRangeException | InvalidTargetException | TargetOutOfSightException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target);
                                break;
                            }
                        }
                    }
                    break;
                case FOG_TIN:
                    if (gadget.getUsages() > 0) {
                        for (Character target : allCharacters) {
                            if (!target.equals(npc)) {
                                try {
                                    fieldMap.validateIsInRange(npc.getCoordinates(), target.getCoordinates(), matchconfig.getFogTinRange());
                                    fieldMap.validateIsInSight(npc.getCoordinates(), target.getCoordinates());
                                } catch (TargetOutOfRangeException | InvalidTargetException | TargetOutOfSightException e) {
                                    continue;
                                }
                                usableGadgets.put(gadget, target.getCoordinates());
                                break;
                            }
                        }
                    }
                    break;
                case GRAPPLE:
                    ArrayList<Point> fieldsWithGadgets = new ArrayList<>(fieldMap.getFieldsWithGadgets());
                    for (Point target : fieldsWithGadgets) {
                        try {
                            fieldMap.validateIsInRange(npc.getCoordinates(), target, matchconfig.getGrappleRange());
                            fieldMap.validateIsInSight(npc.getCoordinates(), target);
                        } catch (TargetOutOfRangeException | InvalidTargetException | TargetOutOfSightException e) {
                            continue;
                        }
                        usableGadgets.put(gadget, target);
                        break;
                    }
                    break;
                case JETPACK:
                    if (gadget.getUsages() > 0) {
                        Point target = fieldMap.getRandomPoint(fieldMap.getFreeFields(allCharacters));
                        usableGadgets.put(gadget, target);
                    }
                    break;
                case COCKTAIL:
                    if (gadget.getUsages() > 0) {
                        if (npc.getHp() < 100) {
                            usableGadgets.put(gadget, npc.getCoordinates());
                        } else {
                            ArrayList<Character> neighbourCharacters = new ArrayList<>(fieldMap.getNeighbourCharacters(npc.getCoordinates(), allCharacters));
                            if (neighbourCharacters.size() >= 1) {
                                usableGadgets.put(gadget, neighbourCharacters.get(0).getCoordinates());
                            }
                        }
                    }
                    break;
            }
        }
        return usableGadgets;
    }

    /**
     * Method to get a target point for when the npc character gambles.
     *
     * @param npc      The npc character.
     * @param fieldMap The board of the game.
     * @return The target point of the gamble action.
     */
    private static Point couldGamble(Character npc, FieldMap fieldMap) {
        boolean rouletteInRange = fieldMap.hasNeighboursOfState(npc.getCoordinates(), FieldStateEnum.ROULETTE_TABLE);

        if (!rouletteInRange)
            return null;

        Set<Point> rouletteCords = fieldMap.getNeighboursOfState(npc.getCoordinates(), FieldStateEnum.ROULETTE_TABLE);
        for (Point rouletteTable : rouletteCords) {
            if (!fieldMap.getField(rouletteTable).isDestroyed() && !(fieldMap.getField(rouletteTable).getChipAmount() == 0)) {
                return rouletteTable;
            }
        }
        return null;
    }

    /**
     * Method for when the janitor removes a character in the game.
     *
     * @param janitor           The janitor character.
     * @param cat               The cat character.
     * @param map               The board of the game.
     * @param characters        Set of all characters on the map.
     * @param removedCharacters Set of all the removed characters in the game.
     * @param playerRotation    Set of the current character turn order.
     * @return The new coordinates of the janitor.
     */
    public static Point janitor(Character janitor, Character cat, FieldMap map, Set<Character> characters, Set<Character> removedCharacters, ArrayList<Character> playerRotation) {
        characters.remove(cat);
        characters.remove(janitor);
        Character closestCharacter = Collections.min(characters, Comparator.comparing(character -> map.getRange(janitor.getCoordinates(), character.getCoordinates())));
        characters.add(janitor);
        characters.add(cat);
        // Remove the closest character to the janitor from the game.
        characters.remove(closestCharacter);
        playerRotation.remove(closestCharacter);
        removedCharacters.add(closestCharacter);

        // Janitor moves to the new point.
        janitor.setCoordinates(closestCharacter.getCoordinates());
        return janitor.getCoordinates();
    }
}
