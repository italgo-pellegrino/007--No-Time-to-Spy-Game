package de.uulm.team0015.server.model.DataTypes.Operations;

import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;

import java.util.UUID;

/**
 * Class for the operations influenced by a property from a character needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class PropertyAction extends Operation {
    private /*final*/ PropertyEnum usedProperty;
    
    /**
     * Seit einer höheren Version des Standards: isEnemy Attribut (15.07.)
     */
    private boolean isEnemy;
    

    /**
     * Constructor of the class PropertyAction.
     *
     * @param type         The type of the operation.
     * @param successful   Whether the operation was successful or not.
     * @param target       The coordinates of the target.
     * @param characterId  The id of the character.
     * @param usedProperty The property of the character which is being used.
     */
    public PropertyAction(OperationEnum type, boolean successful, Point target, UUID characterId, PropertyEnum usedProperty) {
        super(type, successful, target, characterId);
        this.usedProperty = usedProperty;
    }
    
    /**
     * Falls die Observation Aktion erfolgreich war -> isEnemy: true, sonst false
     */
    public void setIsEnemy(boolean isEnemy) {
    	this.isEnemy = isEnemy;
    }

    /**
     * Getter for usedProperty.
     *
     * @return The property of the character which is being used.
     */
    public PropertyEnum getUsedProperty() {
        return usedProperty;
    }
}
