package de.uulm.team0015.server.model.DataTypes.Stats;

/**
 * Class which contains every entry of statistics made during the game.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class Statistics {
    private StatisticsEntry[] entries;

    /**
     * Constructor of the class Statistics.
     *
     * @param entries The statistic entries.
     */
    public Statistics(StatisticsEntry[] entries) {
        this.entries = entries;
    }

    /**
     * Getter for entries.
     *
     * @return the statistic entries.
     */
    public StatisticsEntry[] getEntries() {
        return entries;
    }
}
