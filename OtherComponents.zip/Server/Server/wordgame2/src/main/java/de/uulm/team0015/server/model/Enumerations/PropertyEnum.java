package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration for every type of properties of the characters needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum PropertyEnum {
    NIMBLENESS,
    SLUGGISHNESS,
    PONDEROUSNESS,
    SPRYNESS,
    AGILITY,
    LUCKY_DEVIL,
    JINX,
    CLAMMY_CLOTHES,
    CONSTANT_CLAMMY_CLOTHES,
    ROBUST_STOMACH,
    TOUGHNESS,
    BABYSITTER,
    HONEY_TRAP,
    BANG_AND_BURN,
    FLAPS_AND_SEALS,
    TRADECRAFT,
    OBSERVATION
}
