package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when the target is out of range.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class TargetOutOfRangeException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public TargetOutOfRangeException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public TargetOutOfRangeException(String message) {
        super(message);
    }
}
