package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.ReplayTimerTask;
import de.uulm.team0015.server.model.DataTypes.Stats.Statistics;
import de.uulm.team0015.server.model.DataTypes.Stats.StatisticsEntry;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Enumerations.VictoryEnum;
import de.uulm.team0015.server.model.Messages.MessageContainer;
import de.uulm.team0015.server.model.Messages.Send.GameLeftMessage;
import de.uulm.team0015.server.model.Messages.Send.ReplayMessage;
import de.uulm.team0015.server.model.Messages.Send.StatisticsMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.Date;
import java.util.Timer;
import java.util.UUID;
import java.util.logging.Logger;

import static de.uulm.team0015.server.controller.ServerLogic.MainServerLogic.DATE_FORMAT;

/**
 * GameEndState, used to handle the ending of a game and distribution of ReplayMessages.
 *
 * @author Tom Weisser
 * @version 1.0
 * @see ServerState
 */
public class GameEndState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(GameEndState.class.getName());
    Timer replayTimer = new Timer();
    private ReplayMessage replay;

    /**
     * Constructor for the GameEndState.
     * Will broadcast StatisticsMessage and allow for Replay Requests if possible.
     *
     * @param winner      UUID of the winning player
     * @param victoryEnum Reason for which the player has won
     */
    public GameEndState(UUID winner, VictoryEnum victoryEnum) {
        super();
        ServerLogger.addHandler(LOGGER);
        ServerState.activeState = ServerStateEnum.GAME_END_STATE;

        StatisticsMessage statisticsMessage;

        // set gameEnd time
        mainServerLogic.gameEnd = DATE_FORMAT.format(new Date(System.currentTimeMillis()));

        // if the GamePhase has started, there will be a replay available
        if (mainServerLogic.gamePhaseHasStarted && MainServerLogic.replayTime > 0) {

            String debugMessage = "Entering GameEndState, broadcasting StatisticsMessage. Waiting " + MainServerLogic.replayTime + " minutes for replay requests.";
            ServerShell.print("The game has ended, broadcasting StatisticsMessage. Waiting " + MainServerLogic.replayTime + " minutes for replay requests.");
            LOGGER.warning(debugMessage);

            long time = MainServerLogic.replayTime * 60 * 1000;
            replayTimer.schedule(new ReplayTimerTask(this), time);

            // create and broadcast StatisticsMessage
            statisticsMessage = StatisticsMessage.createStatisticsMessage(createStatistics(),
                    winner,
                    victoryEnum,
                    true,
                    null,
                    debugMessage);
            mainServerLogic.messageHistory.add(statisticsMessage);
            createReplay();
            mainServerLogic.broadcast(statisticsMessage);
        } else if (mainServerLogic.gamePhaseHasStarted && MainServerLogic.replayTime == 0) {
            String debugMessage = "Entering GameEndState, broadcasting StatisticsMessage. No replay available, closing all connections.";
            LOGGER.warning(debugMessage);
            ServerShell.print(debugMessage);

            // create and broadcast StatisticsMessage
            statisticsMessage = StatisticsMessage.createStatisticsMessage(createStatistics(),
                    winner,
                    victoryEnum,
                    false,
                    null,
                    debugMessage);
            mainServerLogic.messageHistory.add(statisticsMessage);
            mainServerLogic.broadcast(statisticsMessage);
            mainServerLogic.stop();
        } else {
            String debugMessage = "Entering GameEndState, broadcasting StatisticsMessage. The game phase has not even started. No replay available, closing all connections.";
            LOGGER.warning(debugMessage);
            ServerShell.print(debugMessage);

            // create Statistics
            StatisticsEntry[] statArray = new StatisticsEntry[1];
            statArray[0] = new StatisticsEntry("Bad Game",
                    "The game did not even start properly, so there are no Statistics available. Boooring.",
                    "--",
                    "--");
            Statistics statistics = new Statistics(statArray);

            statisticsMessage = StatisticsMessage.createStatisticsMessage(statistics,
                    winner,
                    victoryEnum,
                    false,
                    null,
                    debugMessage);
            mainServerLogic.broadcast(statisticsMessage);
            mainServerLogic.stop();
        }
    }

    /**
     * Method used to create a Statistics object, necessary for the StatisticsMessage.
     * Will generate StatisticsEntries from the WinCondition in the MainServerLogic.
     *
     * @return The Statistics object, which has been created
     * @see MainServerLogic
     * @see de.uulm.team0015.server.model.DataTypes.ServerOnly.WinCondition
     */
    private Statistics createStatistics() {
        // create Statistics
        StatisticsEntry[] statArray = new StatisticsEntry[5];
        // Intelligence Points
        statArray[0] = new StatisticsEntry("Intelligence Points",
                "Shows who of the players has obtained more Intelligence Points and therefore won the game.",
                "" + MainServerLogic.winCondition.getIpPlayer1(),
                "" + MainServerLogic.winCondition.getIpPlayer2());
        // Amount of drank cocktails
        statArray[1] = new StatisticsEntry("Drank Cocktails",
                "Exposes the bigger Booze Lover.",
                "" + MainServerLogic.winCondition.getDrankCocktailsPlayer1(),
                "" + MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        // Amount of spilled cocktails
        statArray[2] = new StatisticsEntry("Spilled Cocktails",
                "Exposes the nastier casino guest.",
                "" + MainServerLogic.winCondition.getSpilledCocktailsPlayer1(),
                "" + MainServerLogic.winCondition.getSpilledCocktailsPlayer2());
        // Who has returned the collar
        statArray[3] = new StatisticsEntry("Returned collar",
                "Shows who of the players has returned the diamond collar to the cat.",
                "" + MainServerLogic.winCondition.isReturnedCollarPlayer1(),
                "" + MainServerLogic.winCondition.isReturnedCollarPlayer2());
        // Damage taken
        statArray[4] = new StatisticsEntry("Damage taken",
                "Identifies the punching bag.",
                "" + MainServerLogic.winCondition.getDamageTakenPlayer1(),
                "" + MainServerLogic.winCondition.getDamageTakenPlayer2());
        return new Statistics(statArray);
    }

    /**
     * Method that will create a ReplayMessage-Template and save it into the replay-attribute.
     * On sending of a replay message the template will be used.
     */
    private void createReplay() {
        String debugMessage = "Created replay for the last game.";
        LOGGER.fine(debugMessage);
        MessageContainer[] messageHistory = mainServerLogic.messageHistory.toArray(new MessageContainer[0]);
        replay = ReplayMessage.createReplayMessage(mainServerLogic.sessionID,
                mainServerLogic.gameStart,
                mainServerLogic.gameEnd,
                mainServerLogic.clientIdPlayer1,
                mainServerLogic.clientIdPlayer2,
                mainServerLogic.player1.clientInformation.getName(),
                mainServerLogic.player2.clientInformation.getName(),
                GamePhaseState.currentRound,
                mainServerLogic.initialScenario,
                mainServerLogic.initialMatchconfig,
                mainServerLogic.initialCharacterInformation,
                messageHistory,
                null,
                debugMessage);
    }

    /**
     * Method to handle the receiving of a GameLeaveMessage in the GameEndState.
     * Will answer with a GameLeftMessage and disconnect the client.
     *
     * @param manager SimpleClientManager of the client that is leaving the game/server.
     */
    @Override
    public void onGameLeaveMessage(SimpleClientManager manager) {
        if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            LOGGER.fine("Spectator left the game in GameEndState.");
            onSpectatorLeave(manager);
        } else {
            String debugMessage = "Player left the game in GameEndState. Disconnecting player.";
            LOGGER.fine(debugMessage);
            GameLeftMessage gameLeftMessage = GameLeftMessage.createGameLeftMessage(manager.clientInformation.getClientId(),
                    manager.clientInformation.getClientId(),
                    debugMessage);
            manager.sendMessage(gameLeftMessage);
            manager.disconnect();
        }
    }

    /**
     * Method that is called upon receiving a RequestReplayMessage.
     * Uses the previously created ReplayMessage-template.
     * The clientId will be set accordingly to the client.
     *
     * @param manager SimpleClientManager of the client that tried to request the replay.
     */
    @Override
    public void onRequestReplayMessage(SimpleClientManager manager) {
        LOGGER.fine("Client Requested replay, sending ReplayMessage.");
        // change clientId accordingly
        replay.clientId = manager.clientInformation.getClientId();
        manager.sendMessage(replay);
    }

    /**
     * Will be called upon a player disconnecting in the GameEndState.
     * Will have no effect.
     *
     * @param manager SimpleClientManager of the disconnected player client.
     */
    @Override
    public void onPlayerDisconnect(SimpleClientManager manager) {
        // has no effect
        LOGGER.fine("Player disconnected in GameEndState");
    }

    /**
     * Method, that will be called, when the timer for requesting reconnects runs out.
     * Will stop the server by calling stop() in the MainServerLogic.
     *
     * @see MainServerLogic
     */
    public void onReplayTimerEnd() {
        String replayTimerEnd = "The time period to request replays has ended. Stopping the server.";
        LOGGER.warning(replayTimerEnd);
        ServerShell.print(replayTimerEnd);
        mainServerLogic.stop();
    }

    /**
     * Method for stopping the replayTimer.
     */
    private void stopReplayTimer() {
        try {
            replayTimer.cancel();
            replayTimer.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("Replay timer has already been closed");
        }
    }

    /**
     * Method used to stop the GameEndState. Will stop the replayTimer.
     */
    @Override
    public void stop() {
        LOGGER.warning("GameEndState has been stopped.");
        stopReplayTimer();
    }
}
