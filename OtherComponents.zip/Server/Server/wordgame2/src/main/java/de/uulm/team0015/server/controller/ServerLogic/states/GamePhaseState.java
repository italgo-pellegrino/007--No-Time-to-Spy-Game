package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.GameLogic.GadgetLogic;
import de.uulm.team0015.server.controller.GameLogic.NpcLogic;
import de.uulm.team0015.server.controller.GameLogic.OperationLogic;
import de.uulm.team0015.server.controller.GameLogic.VictoryLogic;
import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.MoveTimerTask;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.NpcTimerTask;
import de.uulm.team0015.server.model.DataTypes.Operations.*;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.DataTypes.Util.State;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;
import de.uulm.team0015.server.model.Messages.Receive.GameOperationMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStatusMessage;
import de.uulm.team0015.server.model.Messages.Send.RequestGameOperationMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.*;
import java.util.logging.Logger;

/**
 * This Class is representing the GamePhaseState
 * While this state is active in the {@link MainServerLogic} it will handle the main game-play by sending request
 * to players, handling their responds or autonomously moving the NPCs.
 * <p>
 * All state changing methods use the stateChangeLock in the MainServerLogic to ensure thread-safeness.
 * <p>
 * This class contains the bridge between the ServerLogic and the GameLogic as well.
 *
 * @author Max Raedler, Tom Weisser
 */
public class GamePhaseState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(GamePhaseState.class.getName());
    private GameStatusMessage lastGameStatusPlayer1;
    private GameStatusMessage lastGameStatusPlayer2;
    public static ArrayList<BaseOperation> lastOperations = new ArrayList<>();
    private ArrayList<Character> playRotation = new ArrayList<>();
    private Character activeCharacter;
    public static volatile int currentRound = 0;
    public static int foggyFieldCount = -1;
    private Timer moveTimer, npcTimer;
    private final long moveTimerLimit;
    private boolean gameOver;

    public static boolean isWiretapsAlreadyUsed = false;

    /**
     * Constructor of the GamePhaseState
     * It will fill up the allCharacter-list in the MainServerLogic and handle the first Character turn.
     */
    public GamePhaseState() {
        super();
        ServerLogger.addHandler(LOGGER);
        
        OperationLogic.setCat(mainServerLogic.cat);

        mainServerLogic.allCharacters.add(mainServerLogic.cat);

        moveTimerLimit = mainServerLogic.initialMatchconfig.getTurnPhaseLimit() * 1000;
        ServerState.activeState = ServerStateEnum.GAME_PHASE_STATE;
        mainServerLogic.serverState = this;
        mainServerLogic.gamePhaseHasStarted = true;

        giveNPCsGadgets();

        mainServerLogic.allCharacters.addAll(mainServerLogic.player1Characters);
        mainServerLogic.allCharacters.addAll(mainServerLogic.player2Characters);
        mainServerLogic.allCharacters.addAll(mainServerLogic.nonPlayerCharacter);

        setupNextRequest();
    }

    /**
     * This is the Core method of the GamePhaseState.
     * It will:
     * - Check if the manager who send a GameOperationMessage is a player and has the turn.
     * - Handle the Operation by calling the GameLogic methods
     * - Handle a retire and picking the next activeCharacter by using finishedOperations()
     * - Check all the winning conditions by using the prepared GameLogic methods.
     * - Broadcast a GameStatus
     * - Check if there is a winner and calls onGameOver()
     * - Handle a new request after checking the AP and MP of the activeCharacter
     *
     * @param manager              SimpleClientManager that sent the GameOperationMessage
     * @param gameOperationMessage The message that was received
     */
    @Override
    public void onGameOperationMessage(SimpleClientManager manager, GameOperationMessage gameOperationMessage) {
        if (!(manager.equals(mainServerLogic.player1) || manager.equals(mainServerLogic.player2))) {
            LOGGER.info(manager.clientInformation.getName() + " Sent an GameOperationMessage but non of his Characters has the turn.");
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "The current Characters is not yours.");
        } else if (!isCurrentCharacterInFactionOfManager(manager)) {
            LOGGER.info(manager.clientInformation.getName() + " Sent an GameOperationMessage but non of his Characters has the turn.");
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "The current Characters is not yours.");
        } else if (!activeCharacter.getCharacterId().equals(gameOperationMessage.operation.getCharacterId())) {
            LOGGER.info(manager.clientInformation.getName() + " Sent an GameOperationMessage, but picked a wrong Character.");
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "The current Characters is not yours.");
        } else {
            killAllTimers(); //At this point it is already ensured that the correct client sends the Message
            switch (gameOperationMessage.operation.getType()) {
                case GADGET_ACTION: {
                    try {
                        GadgetAction gadgetAction = (GadgetAction) gameOperationMessage.operation;
                        try {
                            OperationLogic.gadgetAction(gadgetAction, mainServerLogic.map, mainServerLogic.initialMatchconfig, mainServerLogic.allCharacters,
                                    mainServerLogic.player1Characters, mainServerLogic.player2Characters, mainServerLogic.nonPlayerCharacter, mainServerLogic.cat);
                        } catch (InvalidGadgetException | InvalidActionPointsException | InvalidTargetException | TargetOutOfSightException | TargetOutOfRangeException | TargetBlockedException | TargetOutOfBoundsException | InvalidCharacterException e) {
                            LOGGER.info(e.toString());
                            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, e.toString());
                            return;
                        }
                    } catch (ClassCastException e) {
                        LOGGER.info(manager.clientInformation.getName() + " Sent an invalid GameOperationMessage.");
                        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You sent an invalid GameOperationMessage.");
                        return;
                    }
                }
                break;
                case SPY_ACTION: {
                    try {
                        OperationLogic.operationAction(gameOperationMessage.operation, mainServerLogic.map, mainServerLogic.allCharacters,
                                mainServerLogic.player1Characters, mainServerLogic.player2Characters, mainServerLogic.nonPlayerCharacter,
                                mainServerLogic.initialMatchconfig, mainServerLogic.player1SafeCombinations, mainServerLogic.player2SafeCombinations);
                    } catch (InvalidActionPointsException | InvalidTargetException | TargetOutOfBoundsException | InvalidCharacterException | InvalidOperationException | TargetOutOfRangeException | InvalidSafeCombinationException e) {
                        LOGGER.info(e.toString());
                        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, e.toString());
                        return;
                    }
                }
                break;
                case GAMBLE_ACTION: {
                    try {
                        GambleAction gambleAction = (GambleAction) gameOperationMessage.operation;
                        try {
                            OperationLogic.gambleAction(gambleAction, mainServerLogic.map, mainServerLogic.allCharacters);
                        } catch (InvalidChipAmountException | InvalidTargetException | InvalidActionPointsException | InvalidCharacterException | TargetOutOfBoundsException e) {
                            LOGGER.info(e.toString());
                            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, e.toString());
                            return;
                        }
                    } catch (ClassCastException e) {
                        LOGGER.info(manager.clientInformation.getName() + " Sent an invalid GameOperationMessage.");
                        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You sent an invalid GameOperationMessage.");
                        return;
                    }
                }
                break;
                case PROPERTY_ACTION: {
                    try {
                        PropertyAction propertyAction = (PropertyAction) gameOperationMessage.operation;
                        try {
                            OperationLogic.propertyAction(propertyAction, mainServerLogic.allCharacters, mainServerLogic.map, mainServerLogic.player1Characters,
                                    mainServerLogic.player2Characters, mainServerLogic.initialMatchconfig);
                        } catch (TargetOutOfBoundsException | InvalidTargetException | InvalidPropertyException | InvalidActionPointsException | TargetOutOfSightException | InvalidGadgetException | InvalidCharacterException e) {
                            LOGGER.info(e.toString());
                            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, e.toString());
                            return;
                        }
                    } catch (ClassCastException e) {
                        LOGGER.info(manager.clientInformation.getName() + " Sent an invalid GameOperationMessage.");
                        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You sent an invalid GameOperationMessage.");
                        return;
                    }
                }
                break;
                case MOVEMENT: {
                    try {
                        Movement movement = (Movement) gameOperationMessage.operation;
                        try {
                            OperationLogic.movement(movement, mainServerLogic.map, mainServerLogic.allCharacters);
                        } catch (InvalidMovementPointsException | TargetOutOfBoundsException | InvalidTargetException | InvalidCharacterException e) {
                            LOGGER.info(e.toString());
                            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, e.toString());
                            return;
                        }
                    } catch (ClassCastException e) {
                        LOGGER.info(manager.clientInformation.getName() + " Sent an invalid GameOperationMessage.");
                        onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You sent an invalid GameOperationMessage.");
                        return;
                    }
                }
                break;
                case RETIRE: {
                    gameOperationMessage.operation.setSuccessful(true);
                    lastOperations.add(gameOperationMessage.operation);
                    broadcast();
                    lastOperations.clear();
                    manager.clientInformation.resetStrikes();
                    finishedOperations();
                    return;
                }
                default:
                    LOGGER.info(manager.clientInformation.getName() + " Sent an invalid GameOperationMessage.");
                    onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You sent an invalid GameOperationMessage.");
                    return;
            }

            // GameOperation is valid -> reset strike count
            manager.clientInformation.resetStrikes();

            lastOperations.add(gameOperationMessage.operation);
            broadcast();
            lastOperations.clear();

            if (gameOver) {
                onGameOver();
            } else {
                if (activeCharacter.getAp() > 0 || activeCharacter.getMp() > 0) {
                    LOGGER.fine("A player made his moves sending him a new request for the same Character.");
                    RequestGameOperationMessage requestGameOperationMessage = RequestGameOperationMessage.createRequestGameOperationMessage(activeCharacter.getCharacterId(), manager.clientInformation.getClientId(), "Request for GameOperation");
                    manager.sendMessage(requestGameOperationMessage);
                    startMoveTimer(manager);
                } else {
                    LOGGER.fine("The active Character has no AP or MP left, a new one will be picked.");
                    finishedOperations();
                }
            }
        }
    }

    /**
     * This method is used to give the NPCs the leftover Gadgets.
     */
    private void giveNPCsGadgets() {
        ArrayList<GadgetEnum> leftover = new ArrayList<GadgetEnum>(EnumSet.allOf(GadgetEnum.class));
        leftover.remove(GadgetEnum.DIAMOND_COLLAR);
        leftover.remove(GadgetEnum.COCKTAIL);
        leftover.removeAll(mainServerLogic.player1Gadgets);
        leftover.removeAll(mainServerLogic.player2Gadgets);

        for (GadgetEnum gadgetEnum : leftover) {
            int index = new Random().nextInt(mainServerLogic.nonPlayerCharacter.size());
            Iterator<Character> iterator = mainServerLogic.nonPlayerCharacter.iterator();
            for (int i = 0; i < index; i++) {
                iterator.next();
            }
            Character npc = iterator.next();
            npc.addGadget(gadgetEnum);
        }
    }

    /**
     * This method will check if the activeCharacter is member of the faction of a given manager.
     *
     * @param manager the manager.
     * @return true if the activeCharacter is member of the faction of the given manager false if not.
     */
    public boolean isCurrentCharacterInFactionOfManager(SimpleClientManager manager) {
        if (manager.equals(mainServerLogic.player1)) {
            return activeCharacter.isMemberOfFaction(mainServerLogic.player1Characters);
        } else if (manager.equals(mainServerLogic.player2)) {
            return activeCharacter.isMemberOfFaction(mainServerLogic.player2Characters);
        } else {
            return false;
        }
    }

    /**
     * This method will create a State which is personalized for the participant.
     *
     * @param manager the manager that gets the State.
     * @return State for the manager
     */
    public State createStateForManager(SimpleClientManager manager) {
    	/**
    	 * Änderung am 14.07. : Katze und Hausmeister sollen als Charaktere nicht in der JSon Nachricht mitgeschickt werden
    	 */
    	Set<Character> copy = new HashSet<>();
    	for(Character ch: mainServerLogic.allCharacters) {
    		if( ( mainServerLogic.cat != null && ch.equals(mainServerLogic.cat) ) 
    				|| ( mainServerLogic.janitor != null && ch.equals(mainServerLogic.janitor))) continue;
    		
    		copy.add(ch);
    	}
    	
    	
        if (manager.equals(mainServerLogic.player1)) {
            return new State(currentRound, mainServerLogic.map, mainServerLogic.player1SafeCombinations, copy , mainServerLogic.cat.getCoordinates(), mainServerLogic.janitor.getCoordinates());
        } else if (manager.equals(mainServerLogic.player2)) {
            return new State(currentRound, mainServerLogic.map, mainServerLogic.player2SafeCombinations, copy, mainServerLogic.cat.getCoordinates(), mainServerLogic.janitor.getCoordinates());
        } else {
            LOGGER.severe("A manager who is neither Player1 nor Player2 called onGameOperationMessage where able to change the FieldMap. This is really bad!");
            return null;
        }
    }

    /**
     * This method is broadcasting a specified State foreach player and spectator.
     * This method will add the GameStatusMessage to the messageHistory as well.
     */
    public void broadcast() {
        LOGGER.finer("Broadcasting a new GameStatusMessage");

        gameOver = VictoryLogic.isGameOver(mainServerLogic.cat, mainServerLogic.janitor, mainServerLogic.allCharacters);
        
        /**
         * Zu Beginn einer Runde werden die Aktions- und Bewegungspunkte des activeCharacters ermittelt
         * 
         * Während einer Runde muss für den nächsten active Character in der Liste die Bewegungs- und Aktionspunkte schon im Voraus ermittelt werden, falls diese Liste nicht leer ist
         * (= letzter Charakter in der Liste) 
         */
        /* @deprecaded
         * 
        if (!newRound && !playRotation.isEmpty()) {
        	Character ch = playRotation.get(0);
        	//System.out.println("Character im nächsten Zug:" + ch.getName());
        	ch.setupPoints();
        }
        */
        

        State statePlayer1 = createStateForManager(mainServerLogic.player1);
       
        
        /**
         * Änderung am 12.07 : active Character == null zu Beginn der Runde
         */
        if(activeCharacter != null) {
        	lastGameStatusPlayer1 = GameStatusMessage.createGameStatusMessage(activeCharacter.getCharacterId(), lastOperations, statePlayer1, gameOver, mainServerLogic.clientIdPlayer1, "A new GameStatus");
        }
        else {
        	lastGameStatusPlayer1 = GameStatusMessage.createGameStatusMessage(null, lastOperations, statePlayer1, gameOver, mainServerLogic.clientIdPlayer1, "A new GameStatus");
        }
        
        
        mainServerLogic.player1.sendMessage(lastGameStatusPlayer1);

        State statePlayer2 = createStateForManager(mainServerLogic.player2);
        if(activeCharacter != null) {
        	lastGameStatusPlayer2 = GameStatusMessage.createGameStatusMessage(activeCharacter.getCharacterId(), lastOperations, statePlayer2, gameOver, mainServerLogic.clientIdPlayer2, "A new GameStatus");
        }
        else {
        	lastGameStatusPlayer2 = GameStatusMessage.createGameStatusMessage(null, lastOperations, statePlayer2, gameOver, mainServerLogic.clientIdPlayer2, "A new GameStatus");
        }
        
        
        mainServerLogic.player2.sendMessage(lastGameStatusPlayer2);
        
        /**
         * Dieses Last Game Status Message wird an die Zuschauer geschickt,
         * in diesem soll der Janitor und Katzen Charakter herausgefiltert
         */
        
        /**
    	 * Änderung am 14.07. : Katze und Hausmeister sollen als Charaktere nicht in der JSon Nachricht mitgeschickt werden
    	 */
    	/**
    	 * Filter: Janitor und Cat Character
         */
        HashSet<Character> copy = filterJanitorAndCatCharacter();

        GameStatusMessage lastGameStatusMessage;
        if(activeCharacter != null) {
        	lastGameStatusMessage = GameStatusMessage.createGameStatusMessage(activeCharacter.getCharacterId(), lastOperations,
                new State(currentRound, mainServerLogic.map, null, copy , mainServerLogic.cat.getCoordinates(), mainServerLogic.janitor.getCoordinates()),
                gameOver, null, "A new GameStatus");
        }
        else {
        	lastGameStatusMessage = GameStatusMessage.createGameStatusMessage(null , lastOperations,
                    new State(currentRound, mainServerLogic.map, null, copy , mainServerLogic.cat.getCoordinates(), mainServerLogic.janitor.getCoordinates()),
                    gameOver, null, "A new GameStatus");
        }
        
        
        mainServerLogic.messageHistory.add(lastGameStatusMessage);
        /**
         * Änderung am 20.07.2020: Cat und Janitor sollen aus der Game Status herausgefiltert werden
         */
        mainServerLogic.broadcastToSpectators(lastGameStatusMessage);
    }
    
    private HashSet<Character> filterJanitorAndCatCharacter() {
    	HashSet<Character> copy = new HashSet<>();
    	for(Character ch: mainServerLogic.allCharacters) {
    		if( ( mainServerLogic.cat != null && ch.equals(mainServerLogic.cat) ) 
    				|| ( mainServerLogic.janitor != null && ch.equals(mainServerLogic.janitor))) continue;
    		
    		copy.add(ch);
    	}
    	
    	return copy;
    }
    

    /**
     * This method is used to setup Character turn:
     * It will first pick the next Character or start a new round if needed.
     * In accordance with that it will call the depending logic.
     */
    public void finishedOperations() {
        setupNextRequest();
    }

    /**
     * This method is used to handle a new Character turn:
     * If the Character is a Character of player1 or player2 a new request will be sent to them.
     * If the Character is a NPC it will start the NPC-Timer.
     * If the Character is the Janitor it will execute the Janitor-Logic.
     * If the Character is the Cat it will call the Cat-Logic.
     */
    public void handleNextMove() {
        if (activeCharacter.isMemberOfFaction(mainServerLogic.player1Characters)) {
            RequestGameOperationMessage gameOperationMessage = RequestGameOperationMessage.createRequestGameOperationMessage(activeCharacter.getCharacterId(), mainServerLogic.clientIdPlayer1, "A new GameOperation request");
            mainServerLogic.player1.sendMessage(gameOperationMessage);
            startMoveTimer(mainServerLogic.player1);
        } else if (activeCharacter.isMemberOfFaction(mainServerLogic.player2Characters)) {
            RequestGameOperationMessage gameOperationMessage = RequestGameOperationMessage.createRequestGameOperationMessage(activeCharacter.getCharacterId(), mainServerLogic.clientIdPlayer2, "A new GameOperation request");
            mainServerLogic.player2.sendMessage(gameOperationMessage);
            startMoveTimer(mainServerLogic.player2);
        } else {
            if (activeCharacter.equals(mainServerLogic.cat)) {
                Operation operation = NpcLogic.randomMove(activeCharacter, mainServerLogic.map);
                BaseOperation catOperation = new BaseOperation(OperationEnum.CAT_ACTION, true, operation.getTarget());
                
                
                /**
                 * Änderung am 19.07. : 
                 * Die Operation muss noch mit OperationLogic.movement ausgeführt werden,
                 * um Platz Tausch zu garantieren
                 */
                if (operation.getType().equals(OperationEnum.MOVEMENT)) {
                    Movement movement = (Movement) operation;
                    try {
                    	//System.out.println("Katzenbewegung");
                        OperationLogic.movement(movement, mainServerLogic.map, mainServerLogic.allCharacters);
                    } catch (InvalidMovementPointsException | TargetOutOfBoundsException | InvalidTargetException | InvalidCharacterException e) {
                        LOGGER.severe(e.toString());
                        LOGGER.severe("An NPC made an impossible move! This should never happen!");
                    }
                }
                /**
                 * Änderung am 16.07. : Katzenkoordinaten anpassen -> 19.07. : Erst nach OperationLogic.movement sollen
                 * die Koordinaten der Katze geupdated haben
                 * 
                 * -- Methode wird schon in Operation.movement ausgeführt!!
                 */
                //mainServerLogic.cat.setCoordinates(operation.getTarget());
                /** **/
                
                lastOperations.add(catOperation);
                broadcast();
                lastOperations.clear();
                if (VictoryLogic.isGameOver(mainServerLogic.cat, mainServerLogic.janitor, mainServerLogic.allCharacters)) {
                    onGameOver();
                } else {
                    finishedOperations();
                }
            } else if (activeCharacter.equals(mainServerLogic.janitor)) {
                Point target = NpcLogic.janitor(mainServerLogic.janitor, mainServerLogic.cat, mainServerLogic.map, mainServerLogic.allCharacters, mainServerLogic.removedCharacters, playRotation);
                BaseOperation janitorOperation = new BaseOperation(OperationEnum.JANITOR_ACTION, true, target);
                lastOperations.add(janitorOperation);
                /**
                 * Änderung am 17.07. : Hausmeisterkoordinaten anpassen
                 */
                mainServerLogic.janitor.setCoordinates(target);
                /** **/
                broadcast();
                lastOperations.clear();

                if (VictoryLogic.isGameOver(mainServerLogic.cat, mainServerLogic.janitor, mainServerLogic.allCharacters)) {
                    onGameOver();
                } else {
                    finishedOperations();
                }
            } else {
                startNpcTimer();
            }
        }
    }
    
    
    /**
     * This method will set the new activeCharacter
     * If there is no Character left in this round it will start a new round by calling startNewRound()
     */
    public void setupNextRequest() {
        if (playRotation.size() == 0) {
            LOGGER.fine("The last Character made his turn. A new round will start.");
            startNewRound();
        } else {
            activeCharacter = playRotation.remove(0);
            /**
             * Änderung am 18.07.: 
             * Aufgrund des indeterministischen Verhaltens des PONDEROUSNESS Propertys darf
             * nicht nochmal setUpPoints aufgerufen werden!!
             */
            /*
             * @deprecaded
            if(!newRound && (activeCharacter.hasProperty(PropertyEnum.PONDEROUSNESS) || activeCharacter.hasProperty(PropertyEnum.AGILITY))) {
            	System.out.println("Kein erneutes Setup wegen POUNDEROUSNESS und Agility");
            }
            else {
            	System.out.println("SetUp kann wieder erfolgen");
            	activeCharacter.setupPoints();
            }
            */
            
        	
            /**
             * Bevor die Request Game Operation geschickt wird,
             * soll die Game Status Message geschickt werden.
             * Zu Beginn einer Runde soll eine GameOperation geschickt werden
             * 
             * Änderung am 13.07.
             */
            /*
            if(newRound) {
            	/**deprecaded
            	 * 
            	 *
            	 * Zu Beginn einer neuen Runde, sollen die Aktions- und Bewegunspunkte des activeCharacters bestimmt werden
            	 */
            	//System.out.println("Name des Character zu Beginn der Runde:" + activeCharacter.getName());
            	
            	/**
            	 * Die Aktions- und Bewegungspunkte des nächsten active Characters sollten (zur Sicherheit) vorher bestimmt sein!
            	 * 
            	 * Normalerweise wird sogar bei Inaktivität eine Retire Message geschickt!
            	 /
            	if(!playRotation.isEmpty()) {
            		Character ch = playRotation.get(0);
            		ch.setupPoints();
            	}
            	
            	
            	broadcast();
            	newRound = false;
            }
            */
            
            LOGGER.fine(activeCharacter.getName() + " " + activeCharacter.getCharacterId() + " " + activeCharacter.getCoordinates().toString() + " MP: " + activeCharacter.getMp() + " AP: " + activeCharacter.getAp() + " has the turn now.");
            ServerShell.print("It is " + activeCharacter.getName() + "'s turn.");
            handleNextMove();
        }
    }
    
    

    /**
     * This Method is used to start an new Round.
     * It Will:
     * - Increase the round number.
     * - Remove all foggy fields (if their count is down to zero).
     * - Initialize the Janitor if needed by removing all NPCs, re-adding the cat and placing the Janitor.
     * - Handle the specially handled WireTapsWithEarplugs logic.
     * - Call shuffleRotation().
     */
    public void startNewRound() {
        currentRound += 1;
        ServerShell.print("Round " + currentRound + " has started, shuffling the rotation and waiting for moves.");
        foggyFieldCount -= 1;
        if (foggyFieldCount == 0) {
            Set<Point> foggys = mainServerLogic.map.getFoggyFields();
            for (Point f : foggys) {
                mainServerLogic.map.getField(f).setFoggy(false);
            }
        }
        if (currentRound == mainServerLogic.initialMatchconfig.getRoundLimit()) {
            //Remove all NPCs add the Cat and the Janitor again
            mainServerLogic.removedCharacters.addAll(mainServerLogic.nonPlayerCharacter);

            mainServerLogic.nonPlayerCharacter.clear();
            mainServerLogic.nonPlayerCharacter.add(mainServerLogic.cat);
            mainServerLogic.nonPlayerCharacter.add(mainServerLogic.janitor);

            mainServerLogic.allCharacters.removeAll(mainServerLogic.removedCharacters);
            mainServerLogic.allCharacters.add(mainServerLogic.cat);

            mainServerLogic.janitor.setCoordinates(mainServerLogic.map.getRandomPoint(mainServerLogic.map.getFreeFields(mainServerLogic.allCharacters)));

            mainServerLogic.allCharacters.add(mainServerLogic.janitor);
        }
        mainServerLogic.map.fillBarTables();
        mainServerLogic.map.healCharactersOnBarSeats(mainServerLogic.allCharacters);
        
        /**
         * 05.07.2020: Logik des neuen Gagets Antischnabel-Maske: Jeder Agent, der diese Maske besitzt, bekommt am Anfang jeder Runde +10 Health Points.
         */
        for(Character ch: mainServerLogic.allCharacters) {
        	if(ch.hasGadget(GadgetEnum.ANTI_PLAGUE_MASK)) {
        		ch.getHealed(10);
        	}
        }
        
        
        if (isWiretapsAlreadyUsed) {
            Character characterWhoOwnsWiretaps = Character.getCharacterWithGadgetOfType(mainServerLogic.allCharacters, GadgetEnum.WIRETAP_WITH_EARPLUGS);
            if (characterWhoOwnsWiretaps != null) {
                GadgetLogic.isWireTapWithEarplugsActive(characterWhoOwnsWiretaps.getWireTapWithEarplugs(), mainServerLogic.initialMatchconfig, mainServerLogic.allCharacters);
            }
        }
        shuffleRotation();
        LOGGER.fine("A new round is initialized.");
        
        /*
         * GameStatus-Message zu Beginn jeder Runde, Änderung am 12.07.2020
         * @deprecaded
         */
        //broadcast();
        
        /**
         * Zurücksetzungen der Änderungen vom 12 - 13. 
         * Alternativ Lösung effizienter (19.07.) 
         */
        for(Character ch: mainServerLogic.allCharacters) {
        	//Zu Beginn der Runde werden die Bewegungs- und Aktionspunkte bestimmt
        	ch.setupPoints();
        }
        
        /**
         * Zu Beginn des Spiels soll eine GameStatus Nachricht geschickt werden
         */
        broadcast();
        
        
        /**
         * Dieses Flag wird auf true gesetzt, damit zum Beginn jeder Runde eine gesonderte GameStatus Message gesetzt wird
         * Änderung am 13.07.
         * deprecaded
         */
        //newRound = true;
        
        setupNextRequest();
    }
    
    private boolean newRound;

    /**
     * This Method is creating a new new playRotation by shuffle allCharacters into a new list
     */
    public void shuffleRotation() {
        playRotation = new ArrayList<>(mainServerLogic.allCharacters);
        Collections.shuffle(playRotation);
    }

    /**
     * This Method will swap to a new GamePauseState
     *
     * @param manager SimpleClientManager of the player that tried to pause the game.
     * @param pause   If false the Server won't swap to the GamePauseState, it will run an onFalseMessage process.
     */
    @Override
    public void onPlayerPause(SimpleClientManager manager, boolean pause) {
        if (pause) {
            LOGGER.warning("A player paused the game.");
            killAllTimers();
            new GamePauseState(this);
        } else {
            if (MainServerLogic.strictness) {
                String falseMessage = "A player tried to resume an already running game.";
                LOGGER.info(falseMessage);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, falseMessage);
            } else {
                String problem = "A player tried to resume an already running game. Message might have been delayed. Striking the player.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        }
    }

    /**
     * This Message is used to handle a PlayerDisconnect.
     * It will kill all running timers and swap the Server into the ReconnectState.
     *
     * @param manager SimpleClientManager of the disconnected player client.
     */
    @Override
    public void onPlayerDisconnect(SimpleClientManager manager) {
        killAllTimers();
        new ReconnectState(this, manager);
    }

    /**
     * Method that will be called, when returning to the GamePhaseState from GamePauseState or ReconnectState.
     * Will handle the next move.
     */
    @Override
    public void onReturn() {
    	/**
    	 * Änderung am 15.07. -> Konsistenter Zustandswechsel vom GamePauseState in GamePhaseState
    	 */
    	
    	mainServerLogic.serverState = this;
        ServerState.activeState = ServerStateEnum.GAME_PHASE_STATE;
        
    	/** **/
        ServerShell.print("Returning to the game phase.");
        handleNextMove();
    }

    /**
     * This Method returns the last GameStatusMessage which were send to Player1
     *
     * @return The last GameStatusMessage
     */
    public GameStatusMessage getLastGameStatusMessagePlayer1() {
        return lastGameStatusPlayer1;
    }

    /**
     * This Method returns the last GameStatusMessage which were send to Player2
     *
     * @return The last GameStatusMessage
     */
    public GameStatusMessage getLastGameStatusMessagePlayer2() {
        return lastGameStatusPlayer2;
    }

    /**
     * This Method is called if a MoveTimer of a Manager run out
     * This method will:
     * -Strike the Client
     * -Add a RetireOperation to the next Gamestatus Broadcast
     * -Send a Broadcast
     * -Call finishedOperations() which will swap to the next Character.
     *
     * @param manager SimpleClientManager of the player who failed to make a move.
     */
    @Override
    public synchronized void onMoveTimeout(SimpleClientManager manager) {
        if (activeState == ServerStateEnum.GAME_PHASE_STATE) {
            strikeClient(manager, "You did not make your choice in the given time.");
            if (!manager.isDisconnected()) {
                BaseOperation retireForCharacter = new BaseOperation(OperationEnum.RETIRE, true, activeCharacter.getCoordinates());
                lastOperations.add(retireForCharacter);
                broadcast();
                lastOperations.clear();

                if (gameOver) {
                    onGameOver();
                } else {
                    finishedOperations();
                }
            } else {
                LOGGER.fine("Player received last strike, not sending any more messages.");
            }
        } else {
            LOGGER.fine("Two GamePhase move timers stopped at the same time.");
        }
    }

    /**
     * This Method can be used to correctly start a MoveTimer.
     *
     * @param manager The manager who has the turn.
     */
    private void startMoveTimer(SimpleClientManager manager) {
        killMoveTimer();
        LOGGER.finer("Started timer MoveTimer for " + manager.ipInformation + ".");
        moveTimer = new Timer();
        moveTimer.schedule(new MoveTimerTask(this, manager), moveTimerLimit);
    }

    /**
     * This Method will start an NPC-Timer the given time is randomly picked.
     * You can use this Method to delay NPC-Moves to make them look more realistic.
     */
    private void startNpcTimer() {
        killNpcTimer();
        // Take random value in possible TurnPhaseLimit, but take at least 3 seconds and npcMaxMoveTime seconds max
        int randomMoveTime = new Random().nextInt(mainServerLogic.initialMatchconfig.getTurnPhaseLimit() - 3) + 3;
        if (randomMoveTime > MainServerLogic.npcMaxMoveTime) {
            randomMoveTime = MainServerLogic.npcMaxMoveTime;
        }
        LOGGER.finer("Started NpcTimer for " + randomMoveTime + " seconds.");
        npcTimer = new Timer();
        npcTimer.schedule(new NpcTimerTask(this), (randomMoveTime) * 1000);
    }

    /**
     * This Method can be used to correctly kill all running timers in this state
     */
    private void killAllTimers() {
        killMoveTimer();
        killNpcTimer();
    }

    /**
     * This Method can be used to correctly kill the MoveTimer
     */
    private void killMoveTimer() {
        try {
            moveTimer.cancel();
            moveTimer.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("A move timer has already been closed.");
        }
    }

    /**
     * This Method can be used to correctly kill the NPC-Timer
     */
    private void killNpcTimer() {
        try {
            npcTimer.cancel();
            npcTimer.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("NPC timer has already been closed.");
        }
    }

    /**
     * This Method is called if the NPC-Timer runs out.
     * This Method will execute an NPC-Move, enqueue him to the next Broadcast and decide if the NPC will make another move.
     */
    public void onNpcTimer() {
        mainServerLogic.stateChangeLock.lock();
        if (ServerState.activeState == ServerStateEnum.GAME_PHASE_STATE) {
            if (activeCharacter.getMp() > 0) {
                Operation operation = NpcLogic.randomMove(activeCharacter, mainServerLogic.map);
                if (operation.getType().equals(OperationEnum.MOVEMENT)) {
                    Movement movement = (Movement) operation;
                    try {
                        OperationLogic.movement(movement, mainServerLogic.map, mainServerLogic.allCharacters);
                    } catch (InvalidMovementPointsException | TargetOutOfBoundsException | InvalidTargetException | InvalidCharacterException e) {
                        LOGGER.severe(e.toString());
                        LOGGER.severe("An NPC made an impossible move! This should never happen!");
                    }
                }
                lastOperations.add(operation);
                broadcast();
                lastOperations.clear();
                if (operation.getType().equals(OperationEnum.RETIRE)) {
                    finishedOperations();
                    mainServerLogic.stateChangeLock.unlock();
                    return;
                }
            } else if (activeCharacter.getAp() > 0) {
                Operation operation = NpcLogic.randomAction(activeCharacter, mainServerLogic.map, mainServerLogic.allCharacters, mainServerLogic.initialMatchconfig);
                if (operation.getType().equals(OperationEnum.GAMBLE_ACTION)) {
                    GambleAction gambleAction = (GambleAction) operation;
                    try {
                        OperationLogic.gambleAction(gambleAction, mainServerLogic.map, mainServerLogic.allCharacters);
                    } catch (InvalidChipAmountException | InvalidTargetException | InvalidActionPointsException | InvalidCharacterException | TargetOutOfBoundsException e) {
                        LOGGER.severe(e.toString());
                        LOGGER.severe("An NPC made an impossible gamble action! This should never happen!");
                    }
                } else if (operation.getType().equals(OperationEnum.GADGET_ACTION)) {
                    GadgetAction gadgetAction = (GadgetAction) operation;
                    try {
                        OperationLogic.gadgetAction(gadgetAction, mainServerLogic.map, mainServerLogic.initialMatchconfig, mainServerLogic.allCharacters,
                                mainServerLogic.player1Characters, mainServerLogic.player2Characters, mainServerLogic.nonPlayerCharacter, mainServerLogic.cat);
                    } catch (InvalidGadgetException | InvalidActionPointsException | InvalidTargetException | TargetOutOfSightException | TargetOutOfRangeException | TargetBlockedException | TargetOutOfBoundsException | InvalidCharacterException e) {
                        LOGGER.severe(e.toString());
                        LOGGER.severe("An NPC made an impossible gadget action! This should never happen!");
                    }
                }
                lastOperations.add(operation);
                broadcast();
                lastOperations.clear();
                if (operation.getType().equals(OperationEnum.RETIRE)) {
                    finishedOperations();
                    mainServerLogic.stateChangeLock.unlock();
                    return;
                }
            }
            if (gameOver) {
                onGameOver();
            } else if (activeCharacter.getAp() > 0 || activeCharacter.getMp() > 0) {
                startNpcTimer();
            } else {
                finishedOperations();
            }
        } else {
            LOGGER.fine("NpcTimer has stopped after GameStateChange.");
        }
        mainServerLogic.stateChangeLock.unlock();
    }

    /**
     * This method stops all timers, calculates the winner in the WinCondition and swaps to the GameEndState.
     */
    private void onGameOver() {
        killAllTimers();
        ServerShell.print("The game is over: " + MainServerLogic.winCondition.getVictoryEnum() + ".");
        new GameEndState(MainServerLogic.winCondition.getWinner(mainServerLogic.clientIdPlayer1, mainServerLogic.clientIdPlayer2), MainServerLogic.winCondition.getVictoryEnum());
    }

    /**
     * This Method overrides the Stop() Method so this Sate becomes stoppable as well.
     */
    @Override
    public void stop() {
        killAllTimers();
    }
}
