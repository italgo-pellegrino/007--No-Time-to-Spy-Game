package de.uulm.team0015.server.controller.ServerLogic;

import de.uulm.team0015.server.controller.NetworkLogic.NTTSServerSocket;
import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.states.ConnectionSetupState;
import de.uulm.team0015.server.controller.ServerLogic.states.GamePauseState;
import de.uulm.team0015.server.controller.ServerLogic.states.ServerState;
import de.uulm.team0015.server.controller.ServerLogic.states.ServerStateEnum;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.CharacterInformation;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Scenario;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.WinCondition;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.*;
import de.uulm.team0015.server.model.Messages.MessageContainer;
import de.uulm.team0015.server.model.Messages.Receive.*;
import de.uulm.team0015.server.model.Messages.Send.MetaInformationMessage;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.locks.ReentrantLock;
import java.util.logging.Logger;

/**
 * <p>
 * This will be the heart of the server
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 */
public class MainServerLogic {
    //Static variables
    private final static Logger LOGGER = Logger.getLogger(MainServerLogic.class.getName());
    public final static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");

    //The main ServerSocket the logic is running on
    public NTTSServerSocket nttsServerSocket;

    /*
     * The list of Messages which are required to get the last GameStatus.
     * This list is also used to create a replay at the end of a game
     */
    public ArrayList<MessageContainer> messageHistory;


    //All connected clients who passed the HelloMessage-Process
    public SimpleClientManager player1;
    public SimpleClientManager player2;
    public List<SimpleClientManager> spectators;

    //There Fields are initialized at the very beginning.
    public final Scenario initialScenario;
    /**
     * Dieses Attribut ist ab sofort static, da auf dieses global zugegriffen werden muss,
     * der Zustand ändert sich auch nicht
     * Es gibt keine schreibenden Zugriffe ! Änderung am 19.07
     */
    public static /*final*/ Matchconfig initialMatchconfig;
    
    /**
     * Global um keine Geheimnisse zu bekommen, die über die Tresorindexes hinausgeht
     */
    public static int amountOfSafes;
    
    public final CharacterInformation[] initialCharacterInformation;
    public final UUID sessionID;
    public final UUID clientIdPlayer1;
    public final UUID clientIdPlayer2;

    public boolean gamePhaseHasStarted = false;
    public static WinCondition winCondition = new WinCondition();

    // Replay specific stuff
    public final String gameStart;
    public String gameEnd;

    /*After the setup, before the DecisionPhase starts this Set contains all characters
     * After the DecisionPhase this Set contains all characters which haven't got picked during the DecisionPhase
     * Meaning this Set contains all npcs
     */
    public Set<Character> nonPlayerCharacter;


    //The currently active state of the Server (MainServerLogic)
    public ServerState serverState;

    // Lock that allows pauses or not.
    public ReentrantLock stateChangeLock = new ReentrantLock();

    //The current Game-state
    public FieldMap map;
    private Set<Integer> safes;
    public Character cat;
    public Character janitor;
    /**
     * Änderung am 18.07. : Static damit im VictoryLogic darauf zugegriffen werden kann
     */
    public static Set<Character> player1Characters;
    public static Set<Character> player2Characters;
    public ArrayList<GadgetEnum> player1Gadgets;
    public ArrayList<GadgetEnum> player2Gadgets;
    public Set<Integer> player1SafeCombinations;
    public Set<Integer> player2SafeCombinations;
    public Set<Character> allCharacters;
    public Set<Character> removedCharacters;

    // Preferences, that can be changed by the ServerShell
    public static boolean strictness = false;
    public static int npcMaxMoveTime = 10;
    public static int replayTime = 5;

    /**
     * Starts the NTTSServerSocket
     * Loads the Scenario, Matchconfig, CharacterInformations
     * Defines map, safes, characters, UUID for players and session
     * Characters are placed randomly on the Map
     *
     * @param scenarioLoader    ScenarioLoader holding the scenario
     * @param matchConfigLoader MatchConfigLoader holding the matchConfig
     * @param charactersLoader  CharactersLoader holding the characters
     * @param port              Integer that specifies the port number the server will be running on.
     * @param capacity          The capacity of the socket.
     */
    public MainServerLogic(ScenarioLoader scenarioLoader, MatchConfigLoader matchConfigLoader, CharactersLoader charactersLoader, int port, int capacity) {
        //Logger Hoc
        ServerLogger.addHandler(LOGGER);

        //Load the initials with the given Loaders
        initialScenario = scenarioLoader.load();
        initialMatchconfig = matchConfigLoader.load();
        initialCharacterInformation = charactersLoader.load();
        sessionID = UUID.randomUUID();
        messageHistory = new ArrayList<>();
        clientIdPlayer1 = UUID.randomUUID();
        player1Characters = new HashSet<Character>();
        player1Gadgets = new ArrayList<>();
        clientIdPlayer2 = UUID.randomUUID();
        player2Characters = new HashSet<Character>();
        player2Gadgets = new ArrayList<>();
        spectators = Collections.synchronizedList(new ArrayList<>());
        removedCharacters = new HashSet<>();
        allCharacters = new HashSet<>();
        
        /**
         * Die Listen, die die Geheimnisse der Spieler enthalten, wurde nicht initialisiert
         * Änderung am 17.07.
         */
        player1SafeCombinations = new HashSet<>();
        player2SafeCombinations = new HashSet<>();

        // Replay
        gameStart = DATE_FORMAT.format(new Date(System.currentTimeMillis()));

        if (initialScenario == null || initialMatchconfig == null || initialCharacterInformation == null) {
            LOGGER.severe("Some file was null. This should not happen.");
            stop();
            return;
        } else {
            //Start the setup process
            setup();
            LOGGER.info(map.getMapAsString(nonPlayerCharacter));
        }

        // Set static reference in GameState to this
        ServerState.setMainServerLogic(this);

        // Initialize ConnectionSetupState
        new ConnectionSetupState();

        //Start NTTSServerSocket
        nttsServerSocket = new NTTSServerSocket(port, capacity, this);
        
        /**
         * Die Server Klasse erbt von keiner Thread Instanz mehr, �nderung am 29.06.2020
         * Der Server-Prozess wurde in einer abgewandelten Form gestartet.
         */
        //nttsServerSocket.start();
        //nttsServerSocket.startAcceptingConnections();
        nttsServerSocket.startServer();

        LOGGER.warning("Server is now running on port " + port + ".");
    }

    /**
     * Calls the respective methods to set up a FieldMap and random distribution of characters and safes.
     */
    private void setup() {
        //Always execute setupFieldMap first!
        LOGGER.finer("Setting up FieldMap");
        setupFieldMap();
        LOGGER.finer("Setting up Safes");
        setupSafes();
        LOGGER.finer("Setting up Character");
        setupCharacters();
        /**
         * Hinzugefügt am 16.07. : Die Roulette Tische sollen mit Spielchips befüllt werden
         */
        LOGGER.fine("Setting up Roulette Tables");
        setupRouletteTable();

        //Setup Cat
        cat = new Character(UUID.randomUUID(), "Cat", randomFreeFieldForCharacter(), new HashSet<PropertyEnum>(), new HashSet<Gadget>());
        //Setup Janitor
        janitor = new Character(UUID.randomUUID(), "Janitor", null, new HashSet<PropertyEnum>(), new HashSet<Gadget>());
    }
    
    /**
     * Setup game chips on Roulette Tables
     * 
     * Hinzugefügt am 16.07 
     */
    public void setupRouletteTable() {
    	int lowerLimit, upperLimit;
    	lowerLimit = initialMatchconfig.getMinChipsRoulette();
    	upperLimit = initialMatchconfig.getMaxChipsRoulette();
    	
    	Random rnd = new Random();
    	
    	Field[][] fields = map.getMap();
    	for (Field[] row : fields) {
            for (Field field : row) {
                if (field.getState().equals(FieldStateEnum.ROULETTE_TABLE)) 
                {
                	int amountOfChipsOnRouletteTable = lowerLimit + rnd.nextInt(upperLimit - lowerLimit + 1);
                	field.setChipAmount(amountOfChipsOnRouletteTable);
                }
            }
    	}
    	
    }

    /**
     * Setup the map based on the initScenario
     */
    private void setupFieldMap() {
        Field[][] fields = new Field[initialScenario.getScenario().length][];
        for (int y = 0; y < initialScenario.getScenario().length; y++) {
            FieldStateEnum[] row = initialScenario.getScenario()[y];
            fields[y] = new Field[initialScenario.getScenario()[y].length];
            for (int x = 0; x < row.length; x++) {
                FieldStateEnum fieldStateEnum = initialScenario.getScenario()[y][x];
                Field field = new Field(fieldStateEnum);
                fields[y][x] = field;
            }
        }
        map = new FieldMap(fields);
        LOGGER.finer("FieldMap setup complete!");
    }

    /**
     * Setup the safes based on the map
     */
    private void setupSafes() {
        Field[][] fields = map.getMap();
        safes = new HashSet<>();
        //int number = 1;
        Random rnd = new Random();
        
        /**
         * Anzahl an Safes --global seit 19.07
         */
        amountOfSafes = 0;
        
        
        /**
         * Tresor Nummerierung immer 1, Diamanthalsband fehlt im Tresor
         */
        for (Field[] row : fields) {
            for (Field field : row) {
                if (field.getState().equals(FieldStateEnum.SAFE)) {
                    ++amountOfSafes;
                }
            }
        }
        
        
        
        HashSet<Integer> set = new HashSet<Integer>();
        
        
        for (Field[] row : fields) {
            for (Field field : row) {
                if (field.getState().equals(FieldStateEnum.SAFE)) {
                	int safeIndex;
                	while(true) {
                		safeIndex = rnd.nextInt(amountOfSafes) + 1;
                		if(!set.contains(safeIndex)) {
                			set.add(safeIndex);
                			break;
                		}
                	}
                	
                	safes.add(safeIndex);
                    field.setSafeIndex(safeIndex);
                    
                    /**
                     * Im Tresor mit dem höchsten Indes befindet sich das Diamanthalsband
                     */
                    if(safeIndex == amountOfSafes) {
                    	field.setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
                    }
                }
            }
        }
        LOGGER.finer("Safes setup complete!");
    }

    /**
     * Setup the Characters based on the initCharacterInformations
     * Set the Characters on free fields
     */
    private void setupCharacters() {
        nonPlayerCharacter = new HashSet<>();
        for (CharacterInformation des : initialCharacterInformation) {
            UUID charaterID = des.getCharacterId();
            Set<PropertyEnum> properties = new HashSet<>(des.getFeatures());
            Set<Gadget> gadgets = new HashSet<>();
            String name = des.getName();
            Point point = randomFreeFieldForCharacter();
            if (point == null) {
                LOGGER.severe("The map is not valid to place all characters. This should not happen.");
                stop();
                return;
            }
            Character character = new Character(charaterID, name, point, properties, gadgets);
            nonPlayerCharacter.add(character);
            LOGGER.finer("Created a new Character named: " + name + " and placed him at " + point.toString());
        }
        LOGGER.finer("Character setup complete!");
    }

    /**
     * Picks a random free Point it uses getFullyFreeFields()
     *
     * @return A random free Point
     */
    private Point randomFreeFieldForCharacter() {
        ArrayList<Point> list = getFullyFreeFields();
        if (!list.isEmpty()) {
            Random rand = new Random();
            return list.get(rand.nextInt(list.size()));
        } else {
            return null;
        }
    }

    /**
     * This Method can be used to get a list of free Points to, for example, pick a random one.
     *
     * @return A list free Points on the map Free means: No Charaters, No Gadgets and Type: FieldStateEnum.FREE
     */
    public ArrayList<Point> getFullyFreeFields() {
        ArrayList<Point> freePoints = new ArrayList<>();
        Field[][] fields = map.getMap();
        for (int y = 0; y < fields.length; y++) {
            Field[] row = fields[y];
            for (int x = 0; x < row.length; x++) {
                if (fields[y][x].getState().equals(FieldStateEnum.FREE)) {
                    if (fields[y][x].getGadget() == null) {
                        boolean isAdded = true;
                        for (Character character : nonPlayerCharacter) {
                            int xChar = character.getCoordinates().getX();
                            int yChar = character.getCoordinates().getY();
                            if (x == xChar && y == yChar) {
                                isAdded = false;
                            }
                        }
                        if (isAdded) {
                            freePoints.add(new Point(x, y));
                        }
                    }
                }
            }
        }
        return freePoints;
    }

    /**
     * Call this method in order to shut down the server and logic.
     */
    public void stop() {
        LOGGER.fine("stop()-method in MainServerLogic has been called.");
        nttsServerSocket.close();
        serverState.stop();
    }

    /**
     * Method used for broadcasting messages to all connected clients
     * Already disconnected clients will be ignored by send() method in SimpleClientManager
     * The respective clientId will be set before each send() call.
     *
     * @param message Message object that will be broadcast.
     * @see SimpleClientManager
     */
    public void broadcast(MessageContainer message) {
        LOGGER.fine("Broadcasting " + message.type + "-Message to all.");
        // Set clientId and send to player 1
        message.clientId = player1.clientInformation.getClientId();
        player1.sendMessage(message);
        // Set clientId and send to player 2
        message.clientId = player2.clientInformation.getClientId();
        player2.sendMessage(message);

        broadcastToSpectators(message);
    }

    /**
     * Method used for broadcasting messages to all connected spectator clients
     * Already disconnected clients will be ignored by send() method in SimpleClientManager
     * The respective clientId will be set before each send() call.
     *
     * @param message Message object that will be broadcast.
     * @see SimpleClientManager
     */
    public void broadcastToSpectators(MessageContainer message) {
        LOGGER.fine("Broadcasting " + message.type + "-Message to all spectators.");
        // Set clientId and send to each spectator
        for (SimpleClientManager manager : spectators) {
            message.clientId = manager.clientInformation.getClientId();
            manager.sendMessage(message);
        }
    }

    /**
     * Method that passes a disconnected client on to the active ServerState
     *
     * @param manager SimpleClientManager of the disconnected client
     */
    public void onDisconnect(SimpleClientManager manager) {
        stateChangeLock.lock();
        serverState.onDisconnect(manager);
        stateChangeLock.unlock();
    }

    /**
     * Handle the Receiving of a false message, will lead to disconnecting the client.
     *
     * @param manager       SimpleClientManager that represents the sending client
     * @param errorTypeEnum Enum that represents the type of Error
     * @param debugMessage  Message that will be sent with the ErrorMessage going out to the client
     */
    public void onFalseMessage(SimpleClientManager manager, ErrorTypeEnum errorTypeEnum, String debugMessage) {
        if (manager.clientInformation != null) {
            stateChangeLock.lock();
            LOGGER.config("Received false message by client with IP: " + manager.ipInformation + ". Reason: " + debugMessage);
            serverState.onFalseMessage(manager, errorTypeEnum, debugMessage);
            stateChangeLock.unlock();
        } else {
            LOGGER.info("Client with IP: " + manager.ipInformation + " tried to send an invalid message without being registered, disconnecting client.");
            manager.disconnect();
        }
    }

    /**
     * Handle a GameLeaveMessage by passing it on to the active ServerState
     *
     * @param manager          SimpleClientManager that represents the sending client
     * @param gameLeaveMessage received message
     */
    public void onGameLeaveMessage(SimpleClientManager manager, GameLeaveMessage gameLeaveMessage) {
        if (manager.clientInformation != null) {
            stateChangeLock.lock();
            if (gameLeaveMessage.isValid()) {
                LOGGER.config("Received valid GameLeaveMessage by client with IP: " + manager.ipInformation);
                serverState.onGameLeaveMessage(manager);
            } else {
                LOGGER.config("Received semantically invalid GameLeaveMessage by client with IP: " + manager.ipInformation);
                serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid GameLeaveMessage.");
            }
            stateChangeLock.unlock();
        } else {
            LOGGER.info("Client with IP: " + manager.ipInformation + " tried to send a GameLeaveMessage without being registered, disconnecting client.");
            manager.disconnect();
        }
    }

    /**
     * Handle a GameOperationMessage by passing it on to the active ServerState
     *
     * @param manager              SimpleClientManager that represents the sending client
     * @param gameOperationMessage received message
     */
    public void onGameOperationMessage(SimpleClientManager manager, GameOperationMessage gameOperationMessage) {
        if (manager.clientInformation == null) {
            LOGGER.info("Client with IP: " + manager.ipInformation + " tried to send a GameOperationMessage without being registered, disconnecting client.");
            manager.disconnect();
        } else if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            LOGGER.config("Received GameOperationMessage by spectator with IP: " + manager.ipInformation);
            serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Spectators are not allowed to send GameOperationMessages.");
        } else {
            stateChangeLock.lock();
            if (gameOperationMessage.isValid()) {
                LOGGER.config("Received valid GameOperationMessage by client with IP: " + manager.ipInformation);
                serverState.onGameOperationMessage(manager, gameOperationMessage);
            } else {
                LOGGER.config("Received semantically invalid GameOperationMessage by client with IP: " + manager.ipInformation);
                serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid GameOperationMessage.");
            }
            stateChangeLock.unlock();
        }
    }

    /**
     * Handle a HelloMessage by passing it on to the active ServerState.
     *
     * @param manager      SimpleClientManager that represents the sending client
     * @param helloMessage received message
     */
    public void onHelloMessage(SimpleClientManager manager, HelloMessage helloMessage) {
        if (manager.clientInformation == null) {
            if (helloMessage.isValid()) {
                stateChangeLock.lock();
                LOGGER.config("Received valid HelloMessage by client with IP: " + manager.ipInformation);
                serverState.onHelloMessage(manager, helloMessage);
                stateChangeLock.unlock();
            } else {
                LOGGER.config("Received semantically invalid HelloMessage by client with IP: " + manager.ipInformation + ". Disconnecting client.");
                manager.disconnect();
            }
        } else {
            serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent WelcomeMessage despite being already connected.");
        }
    }

    /**
     * Handle a ItemChoiceMessage by passing it on to the active ServerState
     *
     * @param manager           SimpleClientManager that represents the sending client
     * @param itemChoiceMessage received message
     */
    public void onItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        if (manager.clientInformation == null) {
            LOGGER.info("Client with IP: " + manager.ipInformation + " tried to send an ItemChoiceMessage without being registered, disconnecting client.");
            manager.disconnect();
        } else if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            LOGGER.config("Received ItemChoiceMessage by spectator with IP: " + manager.ipInformation);
            serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Spectators are not allowed to send ItemChoiceMessages.");
        } else {
            stateChangeLock.lock();
            if (itemChoiceMessage.isValid()) {
                LOGGER.config("Received valid ItemChoiceMessage by client with IP: " + manager.ipInformation);
                serverState.onItemChoiceMessage(manager, itemChoiceMessage);
            } else {
                LOGGER.config("Received semantically invalid ItemChoiceMessage by client with IP: " + manager.ipInformation);
                serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid ItemChoiceMessage.");
            }
            stateChangeLock.unlock();
        }
    }

    /**
     * Handle a ReconnectMessage by passing it on to the active ServerState
     * Only allow not connected clients to send ReconnectMessages.
     *
     * @param manager          SimpleClientManager that represents the sending client
     * @param reconnectMessage received message
     */
    public void onReconnectMessage(SimpleClientManager manager, ReconnectMessage reconnectMessage) {
        if (manager.clientInformation == null) {
            stateChangeLock.lock();
            if (reconnectMessage.isValid()) {
                LOGGER.config("Received valid ReconnectMessage by client with IP: " + manager.ipInformation);
                serverState.onReconnectMessage(manager, reconnectMessage);
            } else {
                LOGGER.config("Received semantically invalid ReconnectMessage by client with IP: " + manager.ipInformation + ". Disconnecting client.");
                manager.disconnect();
            }
            stateChangeLock.unlock();
        } else {
            serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent ReconnectMessage despite being already connected.");
        }
    }

    /**
     * Handle a RequestPauseMessage by passing it on to the active ServerState
     * Method is synchronized to prevent inconsistencies in the game state.
     * Accesses a ReentrantLock, that is locked during relevant state changing methods.
     *
     * @param manager                 SimpleClientManager that represents the sending client
     * @param requestGamePauseMessage received message
     */
    public synchronized void onRequestGamePauseMessage(SimpleClientManager manager, RequestGamePauseMessage requestGamePauseMessage) {
        if (manager.clientInformation == null) {
            LOGGER.info("Client with IP: " + manager.ipInformation + " tried to send a RequestGamePauseMessage without being registered, disconnecting client.");
            manager.disconnect();
        } else {
            stateChangeLock.lock();
            if (requestGamePauseMessage.isValid()) {
                LOGGER.config("Received valid RequestGamePauseMessage by client with IP: " + manager.ipInformation);
                serverState.onRequestGamePauseMessage(manager, requestGamePauseMessage);
            } else {
                LOGGER.config("Received semantically invalid RequestGamePauseMessage by client with IP: " + manager.ipInformation);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid RequestGamePauseMessage.");
            }
            stateChangeLock.unlock();
        }
    }

    /**
     * Handle a RequestMetaInformationMessage by sending back MetaInformationMessage
     *
     * @param manager                       SimpleClientManager that represents the sending client
     * @param requestMetaInformationMessage received message
     */
    public void onRequestMetaInformationMessage(SimpleClientManager manager, RequestMetaInformationMessage requestMetaInformationMessage) {
        if (requestMetaInformationMessage.isValid()) {
            if (manager.clientInformation == null) {
                LOGGER.info("Client with IP: " + manager.ipInformation + " tried to send a RequestMetaInformationMessage without being registered, disconnecting client.");
                manager.disconnect();
                return;
            }
            LOGGER.config("Received valid RequestMetaInformationMessageMessage by client with IP: " + manager.ipInformation);
            String[] keys = requestMetaInformationMessage.keys;
            LOGGER.finer("Contained Keys in RequestMetaInformationMessage by: " + manager.ipInformation + " " + Arrays.asList(keys).toString());
            Map<String, Object> information = new HashMap<>();
            for (String key : keys) {
                switch (key) {
                    case "Configuration.Scenario": {
                        information.put("Configuration.Scenario", this.initialScenario);
                        String message = "Added Key: Configuration.Scenario to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Configuration.Matchconfig": {
                        information.put("Configuration.Matchconfig", this.initialMatchconfig);
                        String message = "Added Key: Configuration.Matchconfig to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Configuration.CharacterDescriptions": {
                        information.put("Configuration.CharacterDescriptions", this.initialCharacterInformation);
                        String message = "Added Key: Configuration.CharacterDescriptions to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Faction.Player1": {
                        String message;
                        if (manager.clientInformation.getClientId().equals(this.clientIdPlayer1) || manager.clientInformation.getRole().equals(RoleEnum.SPECTATOR)) {
                            UUID[] characters = player1Characters.stream().map(Character::getCharacterId).toArray(UUID[]::new);
                            information.put("Faction.Player1", characters);
                            message = "Added Key: Faction.Player1 to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        } else {
                            message = "Illegal Arguments: In the RequestMetaInformationMessage received by: " + manager.ipInformation + " the Client is trying to get Metainfo he should not get!";
                            information.put("Faction.Player1", null);
                        }
                        LOGGER.finer(message);
                        break;
                    }
                    case "Faction.Player2": {
                        String message;
                        if (manager.clientInformation.getClientId().equals(this.clientIdPlayer2) || manager.clientInformation.getRole().equals(RoleEnum.SPECTATOR)) {
                            UUID[] characters = player2Characters.stream().map(Character::getCharacterId).toArray(UUID[]::new);
                            information.put("Faction.Player2", characters);
                            message = "Added Key: Faction.Player2 to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        } else {
                            message = "Illegal Arguments: In the RequestMetaInformationMessage received by: " + manager.ipInformation + " the Client is trying to get Metainfo he should not get!";
                            information.put("Faction.Player2", null);
                        }
                        LOGGER.finer(message);
                        break;
                    }
                    case "Faction.Neutral": {
                        String message;
                        if (manager.clientInformation.getRole().equals(RoleEnum.SPECTATOR)) {
                            UUID[] characters = nonPlayerCharacter.stream().map(Character::getCharacterId).toArray(UUID[]::new);
                            information.put("Faction.Neutral", characters);
                            message = "Added Key: Faction.Neutral to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        } else {
                            message = "Illegal Arguments: In the RequestMetaInformationMessage received by: " + manager.ipInformation + " the Client is trying to get Metainfo he should not get!";
                            information.put("Faction.Neutral", null);
                        }
                        LOGGER.finer(message);
                        break;
                    }
                    case "Gadgets.Player1": {
                        String message;
                        if (manager.clientInformation.getClientId().equals(this.clientIdPlayer1) || manager.clientInformation.getRole().equals(RoleEnum.SPECTATOR)) {
                            GadgetEnum[] gadgets = player1Gadgets.toArray(new GadgetEnum[0]);
                            information.put("Gadgets.Player1", gadgets);
                            message = "Added Key: Gadgets.Player1 to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        } else {
                            message = "Illegal Arguments: In the RequestMetaInformationMessage received by: " + manager.ipInformation + " the Client is trying to get Metainfo he should not get!";
                            information.put("Gadgets.Player1", null);
                        }
                        LOGGER.finer(message);
                        break;
                    }
                    case "Gadgets.Player2": {
                        String message;
                        if (manager.clientInformation.getClientId().equals(this.clientIdPlayer2) || manager.clientInformation.getRole().equals(RoleEnum.SPECTATOR)) {
                            GadgetEnum[] gadgets = player2Gadgets.toArray(new GadgetEnum[0]);
                            information.put("Gadgets.Player2", gadgets);
                            message = "Added Key: Gadgets.Player2 to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        } else {
                            message = "Illegal Arguments: In the RequestMetaInformationMessage received by: " + manager.ipInformation + " the Client is trying to get Metainfo he should not get!";
                            information.put("Gadgets.Player2", null);
                        }
                        LOGGER.finer(message);
                        break;
                    }
                    case "Spectator.Count": { //Optional
                        information.put("Spectator.Count", this.spectators.size());
                        String message = "Added Key: Spectator.Count to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Spectator.Names": { //Optional
                        String[] members = spectators.stream().map(x -> x.clientInformation.getName()).sorted().toArray(String[]::new);
                        information.put("Spectator.Names", members);
                        String message = "Added Key: Spectator.Names to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Player.Count": { //Optional
                        int count = 0;
                        if (player1.clientInformation != null) {
                            count += 1;
                        }
                        if (player2.clientInformation != null) {
                            count += 1;
                        }
                        information.put("Player.Count", count);
                        String message = "Added Key: Player.Count to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Player.Names": { //Optional
                        ArrayList<String> names = new ArrayList<>();

                        if (player1 != null) {
                            if (player1.clientInformation != null) {
                                names.add(player1.clientInformation.getName());
                            }
                        }

                        if (player2 != null) {
                            if (player2.clientInformation != null) {
                                names.add(player2.clientInformation.getName());
                            }
                        }

                        information.put("Player.Names", names.toArray(new String[0]));
                        String message = "Added Key: Player.Names to the MetaInformationMessage which is an reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    case "Game.RemainingPauseTime": {
                        int time;
                        if (ServerState.activeState == ServerStateEnum.GAME_PAUSE_STATE) {
                            time = ((GamePauseState) serverState).getRemainingTime();
                        } else {
                            time = 0;
                        }
                        information.put("Game.RemainingPauseTime", time);
                        String message = "Added Key: Game.RemainingPauseTime to the MetaInformationMessage which is a reply to a RequestMetaInformationMessage by: " + manager.ipInformation;
                        LOGGER.finer(message);
                        break;
                    }
                    default: {
                        information.put(key, null);
                        String message = "In the RequestMetaInformationMessage received by: " + manager.ipInformation + " a Key is not recognized! Therefore it will be send back with value null";
                        LOGGER.finer(message);
                        return;
                    }
                }
            }
            try {
                MetaInformationMessage message = new MetaInformationMessage();
                message.information = information;
                message.clientId = manager.clientInformation.getClientId();
                message.creationDate = DATE_FORMAT.format(new Date(System.currentTimeMillis()));
                message.debugMessage = requestMetaInformationMessage.debugMessage;
                message.type = MessageTypeEnum.META_INFORMATION;
                String logmessage = "Created MetaInformationMessage for Client: " + manager.ipInformation;
                LOGGER.fine(logmessage);
                manager.sendMessage(message);
            } catch (NullPointerException e) {
                String logmessage = "Failed to create MetaInformationMessage for Client: " + manager.ipInformation + e.toString();
                LOGGER.severe(logmessage);
            }
        } else {
            String message = "The RequestMetaInformationMessage received by: " + manager.ipInformation + " is invalid!";
            LOGGER.config(message);
            stateChangeLock.lock();
            serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid RequestMetaInformationMessage.");
            stateChangeLock.unlock();
        }
    }

    /**
     * Handle a RequestReplayMessage by passing it on to the active ServerState
     *
     * @param manager              SimpleClientManager that represents the sending client
     * @param requestReplayMessage received message
     */
    public void onRequestReplayMessage(SimpleClientManager manager, RequestReplayMessage requestReplayMessage) {
        if (manager.clientInformation != null) {
            if (requestReplayMessage.isValid()) {
                LOGGER.config("Received valid RequestReplayMessage by client with IP: " + manager.ipInformation);
                serverState.onRequestReplayMessage(manager);
            } else {
                stateChangeLock.lock();
                LOGGER.config("Received semantically invalid RequestReplayMessage by client with IP: " + manager.ipInformation);
                serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid RequestReplayMessage.");
                stateChangeLock.unlock();
            }
        } else {
            LOGGER.warning("Client with IP: " + manager.ipInformation + " tried to send a RequestReplayMessage without being registered, disconnecting client.");
            manager.disconnect();
        }
    }

    /**
     * Handle a RequestReplayMessage by passing it on to the active ServerState
     *
     * @param manager                SimpleClientManager that represents the sending client
     * @param equipmentChoiceMessage received message
     */
    public void onEquipmentChoiceMessage(SimpleClientManager manager, EquipmentChoiceMessage equipmentChoiceMessage) {
        if (manager.clientInformation == null) {
            LOGGER.warning("Client with IP: " + manager.ipInformation + " tried to send an EquipmentChoiceMessage without being registered, disconnecting client.");
            manager.disconnect();
        } else if (manager.clientInformation.getRole() == RoleEnum.SPECTATOR) {
            LOGGER.config("Received EquipmentChoiceMessageMessage by spectator with IP: " + manager.ipInformation);
            serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Spectators are not allowed to send EquipmentChoiceMessageMessages.");
        } else {
            stateChangeLock.lock();
            if (equipmentChoiceMessage.isValid()) {
                LOGGER.config("Received valid EquipmentChoiceMessageMessage by client with IP: " + manager.ipInformation);
                serverState.onEquipmentChoiceMessage(manager, equipmentChoiceMessage);
            } else {
                LOGGER.config("Received semantically invalid EquipmentChoiceMessageMessage by client with IP: " + manager.ipInformation);
                serverState.onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Sent invalid EquipmentChoiceMessage.");
            }
            stateChangeLock.unlock();
        }
    }
}
