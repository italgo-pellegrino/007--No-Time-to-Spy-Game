package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when a character has an invalid amount of action points.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class InvalidActionPointsException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public InvalidActionPointsException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public InvalidActionPointsException(String message) {
        super(message);
    }
}
