package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when the target is invalid.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class InvalidTargetException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public InvalidTargetException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public InvalidTargetException(String message) {
        super(message);
    }
}
