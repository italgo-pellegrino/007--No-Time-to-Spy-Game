package de.uulm.team0015.server.controller.ServerLogic.states;

import de.uulm.team0015.server.controller.NetworkLogic.SimpleClientManager;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.tasks.MoveTimerTask;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.RequestItemChoseMeta;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.Enumerations.ErrorTypeEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Messages.Receive.ItemChoiceMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStartedMessage;
import de.uulm.team0015.server.model.Messages.Send.RequestItemChoiceMessage;
import de.uulm.team0015.server.view.ServerShell;

import java.util.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * This Class is representing the DecisionPhaseState
 * While this state is active in the {@link MainServerLogic} it will handle RequestItemChoiceMessages and ItemChoiceMessages
 * <p>
 * Because this state is based on an asynchronous message flow is always saving the last message and information he send to each player.
 * If a Message is received which is not valid syntactic and semantic the onFalseMessage is called.
 * <p>
 * To ensure thread-safeness we only access the available-list in synchronized methods.
 *
 * @author Max Raedler
 */
public class DecisionPhaseState extends ServerState {
    private final static Logger LOGGER = Logger.getLogger(DecisionPhaseState.class.getName());

    private final List<Character> availableCharacters;
    private final ArrayList<GadgetEnum> availableGadgets;

    private RequestItemChoiceMessage lastRequestToPlayer1;
    private RequestItemChoiceMessage lastRequestToPlayer2;

    private int receivedPicksByPlayer1 = 0;
    private int receivedPicksByPlayer2 = 0;

    private Timer player1MoveTimer, player2MoveTimer;

    private final RequestItemChoseMeta lastMessageMetaToPlayer1;
    private final RequestItemChoseMeta lastMessageMetaToPlayer2;

    private final long moveTimerLimit;

    /**
     * Constructor of the class DecisionPhaseState.
     */
    public DecisionPhaseState() {
        super();
        ServerLogger.addHandler(LOGGER);
        ServerState.activeState = ServerStateEnum.DECISION_PHASE_STATE;
        mainServerLogic.serverState = this;

        LOGGER.warning("Entered the DecisionPhaseState");
        ServerShell.print("The decision Phase has started, distributing requests and waiting for item choices.");

        // Create and broadcast GameStartedMessage to all
        GameStartedMessage gameStartedMessage = GameStartedMessage.createGameStartedMessage(mainServerLogic.clientIdPlayer1,
                mainServerLogic.clientIdPlayer2,
                mainServerLogic.player1.clientInformation.getName(),
                mainServerLogic.player2.clientInformation.getName(),
                mainServerLogic.sessionID,
                null,
                "Both players are connected, the game starts.");
        mainServerLogic.broadcast(gameStartedMessage);
        mainServerLogic.messageHistory.add(gameStartedMessage);

        availableCharacters = Collections.synchronizedList(new ArrayList<>());
        availableCharacters.addAll(mainServerLogic.nonPlayerCharacter);
        availableGadgets = new ArrayList<>(EnumSet.allOf(GadgetEnum.class));
        availableGadgets.remove(GadgetEnum.DIAMOND_COLLAR);
        availableGadgets.remove(GadgetEnum.COCKTAIL);
        lastMessageMetaToPlayer1 = new RequestItemChoseMeta();
        lastMessageMetaToPlayer2 = new RequestItemChoseMeta();

        moveTimerLimit = mainServerLogic.initialMatchconfig.getTurnPhaseLimit() * 1000;

        //The first Request Message foreach player
        RequestItemChoiceMessage initialMessagePlayer1 = createRequest(mainServerLogic.player1);
        mainServerLogic.player1.sendMessage(initialMessagePlayer1);
        startTimerPlayer1();
        lastRequestToPlayer1 = initialMessagePlayer1;

        RequestItemChoiceMessage initialMessagePlayer2 = createRequest(mainServerLogic.player2);
        mainServerLogic.player2.sendMessage(initialMessagePlayer2);
        startTimerPlayer2();
        lastRequestToPlayer2 = initialMessagePlayer2;
        LOGGER.finer("Sent the two initial RequestItemChoiceMessage to both Player-Clients");
    }

    /**
     * Only call this method if you have ensured that the manager is player1 or player2
     * This message will
     * - Remove 2x3 randomly picked items from the available lists
     * - Return a RequestMessage
     * - Change the lastMessageToPlayerX
     * <p>
     * This method is Synchronized, therefore the access on the available pools are thread-safe
     *
     * @param manager The Manger (player-uuid) who will be addressed in this message.
     * @return A new request for this SimpleClientManager
     */
    private synchronized RequestItemChoiceMessage createRequest(SimpleClientManager manager) {
        Random random = new Random();
        //Pick 3 Random Gadgets and Characters
        RequestItemChoiceMessage message;
        if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
            message = createRequestForPlayer(manager, random, lastMessageMetaToPlayer1, Player.PlayerOne);
            LOGGER.finer("Created a new RequestItemChoiceMessage for player1!");
        } else {
            message = createRequestForPlayer(manager, random, lastMessageMetaToPlayer2, Player.PlayerTwo);
            LOGGER.finer("Created a new RequestItemChoiceMessage for player2!");
        }
        return message;
    }
    
    /**
     * Enum, welcher nur in dieser Klasse eine Sicht hat
     * - Gibt an um welchen Player es sich gehandelt
     */
    private enum Player {
    	PlayerOne,
    	PlayerTwo
    }
    

    /**
     * This method will create a new request for the player.
     *
     * @param manager                 The simpleClientManager.
     * @param random                  Java random.
     * @param lastMessageMetaToPlayer The last message to the player
     * @return The requestItemChoiceMessage.
     */
    private RequestItemChoiceMessage createRequestForPlayer(SimpleClientManager manager, Random random, RequestItemChoseMeta lastMessageMetaToPlayer, Player playerEnum) {
        RequestItemChoiceMessage message;
        lastMessageMetaToPlayer.characters.clear();
        lastMessageMetaToPlayer.gadgetEnums.clear();
        
        /**
         * Änderung am 08.07: Falls die maximale Anzahl an z.B. Agenten erreicht wurde, darf der Server nur noch Gadgets schicken und umgekehrt
         */
        if(playerEnum.equals(Player.PlayerOne)) {
        	//Maximale Anzahl an Charakteren ausgewählt
        	if(mainServerLogic.player1Characters.size() == 4) {
        		//Nur Gadgets werden zur Wahl gestellt
        		createOnlyGadgetsChoice(random, lastMessageMetaToPlayer);
        	}
        	//Maximale Anzahl an Gagdets ausgewählt
        	else if(mainServerLogic.player1Gadgets.size() == 6) {
        		//Es werden nur Agenten zur Wahl gestellt
        		createOnlyAgentsChoice(random, lastMessageMetaToPlayer);
        	}
        	else {
        		//Default
        		createDefaultChoice(random, lastMessageMetaToPlayer);
        	}
        }
        else if(playerEnum.equals(Player.PlayerTwo)) {
        	//Maximale Anzahl an Charakteren ausgewählt
        	if(mainServerLogic.player2Characters.size() == 4) {
        		//Nur Gadgets werden zur Wahl gestellt
        		createOnlyGadgetsChoice(random, lastMessageMetaToPlayer);
        	}
        	//Maximale Anzahl an Gagdets ausgewählt
        	else if(mainServerLogic.player2Gadgets.size() == 6) {
        		//Es werden nur Agenten zur Wahl gestellt
        		createOnlyAgentsChoice(random, lastMessageMetaToPlayer);
        	}
        	else {
        		//Default
        		createDefaultChoice(random, lastMessageMetaToPlayer);
        	}
        }
        
        
        ArrayList<UUID> uuidsOfCharacters = (ArrayList<UUID>) lastMessageMetaToPlayer.characters.stream().map(Character::getCharacterId).collect(Collectors.toList());
        List<GadgetEnum> gadgetEnums = lastMessageMetaToPlayer.gadgetEnums;

        message = RequestItemChoiceMessage.createRequestItemChoiceMessage(uuidsOfCharacters, gadgetEnums, manager.clientInformation.getClientId(),
                "This message contains the ItemChoice offers");
        return message;
    }
    
    /**
     * Es gibt insgesamt 3 Möglichkeiten eines Auswahls: Default, Nur Agenten, Nur Gagdets
     */
    
    /**
     * Default Auswahl: 3 Gadgets, 3 Agenten
     * 
     * @param random
     * @param lastMessageMetaToPlayer
     */
    private void createDefaultChoice(Random random, RequestItemChoseMeta lastMessageMetaToPlayer) {
    	for (int i = 0; i < 3; i++) {
            int randomIndex = random.nextInt(availableCharacters.size());
            Character character = availableCharacters.get(randomIndex);
            availableCharacters.remove(character);
            lastMessageMetaToPlayer.characters.add(character);

            randomIndex = random.nextInt(availableGadgets.size());
            GadgetEnum gadgetEnum = availableGadgets.get(randomIndex);
            availableGadgets.remove(gadgetEnum);
            lastMessageMetaToPlayer.gadgetEnums.add(gadgetEnum);
        }
    }
    
    /**
     * Auswahlart: Nur Agenten
     * 
     * @param random
     * @param lastMessageMetaToPlayer
     */
    private void createOnlyAgentsChoice(Random random, RequestItemChoseMeta lastMessageMetaToPlayer) {
    	for (int i = 0; i < 6; i++) {
    		/**
    		 * Falls keine Agenten mehr zur Auswahl stehen, soll aufgehört werden
    		 */
    		if(availableCharacters.size() == 0) return;
    		
            int randomIndex = random.nextInt(availableCharacters.size());
            Character character = availableCharacters.get(randomIndex);
            availableCharacters.remove(character);
            lastMessageMetaToPlayer.characters.add(character);
        }
    }
    
    
    /**
     * Auswahlart: Nur Gadgets
     * 
     * @param random
     * @param lastMessageMetaToPlayer
     */
    private void createOnlyGadgetsChoice(Random random, RequestItemChoseMeta lastMessageMetaToPlayer) {
    	for (int i = 0; i < 6; i++) {
    		/**
   		 	* Falls keine Gadgets mehr zur Auswahl stehen, soll aufgehört werden
   		 	*/
    		if(availableGadgets.size() == 0) return;
    		
            int randomIndex = random.nextInt(availableGadgets.size());
            GadgetEnum gadgetEnum = availableGadgets.get(randomIndex);
            availableGadgets.remove(gadgetEnum);
            lastMessageMetaToPlayer.gadgetEnums.add(gadgetEnum);
        }
    }
    
    
    

    /**
     * This Method is used to leave the current DecisionPhaseState
     * It will check if the players picked enough Characters and then setup a new EquipmentPhaseState
     */
    private void leaveState() {
        stop();
        if (mainServerLogic.player1Characters.size() < 2 || mainServerLogic.player1Characters.size() > 4) {
            onFalseMessage(mainServerLogic.player1, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked too few/many characters");
            return;
        }
        if (mainServerLogic.player2Characters.size() < 2 || mainServerLogic.player2Characters.size() > 4) {
            onFalseMessage(mainServerLogic.player2, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked too few/many characters");
            return;
        }
        mainServerLogic.nonPlayerCharacter = new HashSet<>(availableCharacters);
        LOGGER.warning("Both players made their picks, entering the EquipmentPhaseState now.");
        ServerShell.print("Both players made their choices, entering the equipment phase now.");
        new EquipmentPhaseState();
    }

    /**
     * This Method is handling a ItemChoiceMessage of player1
     * <p>
     * It will check if the message is valid and if the player:
     * - Hasn't picked 8 times yet
     * - Picked a valid item
     * If the player didn't it will call onFalseMessage
     * <p>
     * After ensuring that this method adds the selected Character/Gadget to the player in the MainServerLogic.
     * At last this Method returns the unpicked items to the available pool and sends a freshly generated (through createRequest()) to the Client.
     *
     * @param manager           The Manager who send this message.
     * @param itemChoiceMessage The Message which contains the pick.
     */
    private void onPlayer1ItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        //Validate it
        if (!itemChoiceMessage.isValid()) {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Invalid ItemChoiceMessage!");
            return;
        }

        if (receivedPicksByPlayer1 >= 8) {
            LOGGER.info("Player1 made to many picks");
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You already made your 8 picks");
            return;
        }

        int indexInMeta = 0;
        if (itemChoiceMessage.chosenCharacterId != null) {
            if (mainServerLogic.player1Characters.size() >= 4) {
                LOGGER.info("Player1 picked too many characters, calling onFalseMessage");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked too many characters");
                return;
            }
            boolean requestContainsUUID = false;
            for (Character character : lastMessageMetaToPlayer1.characters) {
                if (character.getCharacterId().equals(itemChoiceMessage.chosenCharacterId)) {
                    requestContainsUUID = true;
                    break;
                }
                indexInMeta++;
            }
            if (!requestContainsUUID) {
                LOGGER.info("Player1 picked the character:" + itemChoiceMessage.chosenCharacterId + " which the server did not offer, calling onFalseMessage");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked a character the server did not offer");
                return;
            }
        } else {
            boolean requestContainsGadgetEnum = false;
            for (GadgetEnum gadgetEnum : lastMessageMetaToPlayer1.gadgetEnums) {
                if (gadgetEnum.equals(itemChoiceMessage.chosenGadget)) {
                    requestContainsGadgetEnum = true;
                    break;
                }
                indexInMeta++;
            }
            if (!requestContainsGadgetEnum) {
                LOGGER.info("Player1 picked a character the server did not offer, calling onFalseMessage");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked a gadget the server did not offer");
                return;
            }
        }
        //Set the Variables remove the Variables from the last message  increment the Number of picks
        if (itemChoiceMessage.chosenCharacterId != null) {
            Character character = lastMessageMetaToPlayer1.characters.get(indexInMeta);
            mainServerLogic.player1Characters.add(character);
            lastMessageMetaToPlayer1.characters.remove(character);
        } else {
            GadgetEnum gadgetEnum = lastMessageMetaToPlayer1.gadgetEnums.get(indexInMeta);
            mainServerLogic.player1Gadgets.add(gadgetEnum);
            lastMessageMetaToPlayer1.gadgetEnums.remove(gadgetEnum);
        }
        //Return the unpicked Characters and GadgetEnums
        availableCharacters.addAll(lastMessageMetaToPlayer1.characters);
        lastMessageMetaToPlayer1.characters.clear();

        availableGadgets.addAll(lastMessageMetaToPlayer1.gadgetEnums);
        lastMessageMetaToPlayer1.gadgetEnums.clear();

        receivedPicksByPlayer1 += 1;

        mainServerLogic.player1.clientInformation.resetStrikes();

        //Respond a new Request to it. Save it as last Message
        if (receivedPicksByPlayer1 < 8) {
            RequestItemChoiceMessage nextMessagePlayer1 = createRequest(mainServerLogic.player1);
            mainServerLogic.player1.sendMessage(nextMessagePlayer1);
            startTimerPlayer1();
            lastRequestToPlayer1 = nextMessagePlayer1;
        }
    }

    /**
     * This Method is handling a ItemChoiceMessage of player2
     * <p>
     * It will check if the message is valid and if the player:
     * - Hasn't picked 8 times yet
     * - Picked a valid item
     * If the player didn't it will call onFalseMessage
     * <p>
     * After ensuring that this method adds the selected Character/Gadget to the player in the MainServerLogic.
     * At last this Method returns the unpicked items to the available pool and sends a freshly generated (through createRequest()) to the Client.
     *
     * @param manager           The Manager who send this message.
     * @param itemChoiceMessage The Message which contains the pick.
     */
    private void onPlayer2ItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        //Validate it
        if (!itemChoiceMessage.isValid()) {
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "Invalid ItemChoiceMessage!");
            return;
        }

        if (receivedPicksByPlayer2 >= 8) {
            LOGGER.info("Player2 made too many picks");
            onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You already made your 8 picks");
            return;
        }

        int indexInMeta = 0;
        if (itemChoiceMessage.chosenCharacterId != null) {
            if (mainServerLogic.player2Characters.size() >= 4) {
                LOGGER.info("Player2 picked too many characters, calling onFalseMessage");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked too many Characters");
                return;
            }
            boolean requestContainsUUID = false;
            for (Character character : lastMessageMetaToPlayer2.characters) {
                if (character.getCharacterId().equals(itemChoiceMessage.chosenCharacterId)) {
                    requestContainsUUID = true;
                    break;
                }
                indexInMeta++;
            }
            if (!requestContainsUUID) {
                LOGGER.info("Player2 picked a character the server did not offer, calling onFalseMessage");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked a character the server did not offer");
                return;
            }
        } else {
            boolean requestContainsGadgetEnum = false;
            for (GadgetEnum gadgetEnum : lastMessageMetaToPlayer2.gadgetEnums) {
                if (gadgetEnum.equals(itemChoiceMessage.chosenGadget)) {
                    requestContainsGadgetEnum = true;
                    break;
                }
                indexInMeta++;
            }
            if (!requestContainsGadgetEnum) {
                LOGGER.info("Player2 picked a gadget the server did not offer, calling onFalseMessage");
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, "You picked a gadget the server did not offer");
                return;
            }
        }
        //Set the Variables remove the Variables from the last message  increment the Number of picks
        if (itemChoiceMessage.chosenCharacterId != null) {
            Character character = lastMessageMetaToPlayer2.characters.get(indexInMeta);
            mainServerLogic.player2Characters.add(character);
            lastMessageMetaToPlayer2.characters.remove(character);
        } else {
            GadgetEnum gadgetEnum = lastMessageMetaToPlayer2.gadgetEnums.get(indexInMeta);
            mainServerLogic.player2Gadgets.add(gadgetEnum);
            lastMessageMetaToPlayer2.gadgetEnums.remove(gadgetEnum);
        }
        //Return the unpicked Characters and GadgetEnums
        availableCharacters.addAll(lastMessageMetaToPlayer2.characters);
        lastMessageMetaToPlayer2.characters.clear();

        availableGadgets.addAll(lastMessageMetaToPlayer2.gadgetEnums);
        lastMessageMetaToPlayer2.gadgetEnums.clear();

        mainServerLogic.player2.clientInformation.resetStrikes();

        receivedPicksByPlayer2 += 1;
        //Respond a new Request to it. Save it as last Message
        if (receivedPicksByPlayer2 < 8) {
            RequestItemChoiceMessage nextMessagePlayer2 = createRequest(mainServerLogic.player2);
            mainServerLogic.player2.sendMessage(nextMessagePlayer2);
            startTimerPlayer2();
            lastRequestToPlayer2 = nextMessagePlayer2;
        }
    }

    /**
     * This Method is handling a ItemChoiceMessage.
     * <p>
     * It will call the onPlayerXItemChoiceMessage according to the ClientId of the manager.
     * This Method resets the corresponding timer as well.
     *
     * @param manager           The Manager who send this message.
     * @param itemChoiceMessage The Message which contains the pick.
     */
    @Override
    public void onItemChoiceMessage(SimpleClientManager manager, ItemChoiceMessage itemChoiceMessage) {
        if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
            player1MoveTimer.cancel();
            player1MoveTimer.purge();
            onPlayer1ItemChoiceMessage(manager, itemChoiceMessage);

        } else if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer2)) {
            player2MoveTimer.cancel();
            player2MoveTimer.purge();
            onPlayer2ItemChoiceMessage(manager, itemChoiceMessage);
        }
        if (receivedPicksByPlayer2 == 8 && receivedPicksByPlayer1 == 8) {
            leaveState();
        }
    }

    /**
     * This Method can be used to correctly start a Player1 MoveTimer.
     */
    private void startTimerPlayer1() {
        LOGGER.finer("Started timer MoveTimer for player1.");
        player1MoveTimer = new Timer();
        player1MoveTimer.schedule(new MoveTimerTask(this, mainServerLogic.player1), moveTimerLimit);
    }

    /**
     * This Method can be used to correctly start a Player2 MoveTimer
     */
    private void startTimerPlayer2() {
        LOGGER.finer("Started timer MoveTimer for player2.");
        player2MoveTimer = new Timer();
        player2MoveTimer.schedule(new MoveTimerTask(this, mainServerLogic.player2), moveTimerLimit);
    }

    /**
     * This Method can be used to correctly kill all running timers in this state
     */
    private void killAllTimers() {
        try {
            player1MoveTimer.cancel();
            player1MoveTimer.purge();
            player2MoveTimer.cancel();
            player2MoveTimer.purge();
        } catch (NullPointerException npe) {
            LOGGER.finer("A timer has already been closed.");
        }
    }

    /**
     * This Method will stop all Timers and swap the serverstate in the {@link MainServerLogic} to a new {@link ReconnectState}.
     *
     * @param manager The manager which disconnects.
     */
    @Override
    void onPlayerDisconnect(SimpleClientManager manager) {
        killAllTimers();
        new ReconnectState(this, manager);
    }

    /**
     * This Method will swap to a new GamePauseState
     *
     * @param manager SimpleClientManager of the player that tried to pause the game.
     * @param pause   If false the Server won't swap to the GamePauseState, it will run an onFalseMessage process.
     */
    @Override
    public void onPlayerPause(SimpleClientManager manager, boolean pause) {
        if (pause) {
            LOGGER.warning("A player paused the game.");
            killAllTimers();
            new GamePauseState(this);
        } else {
            if (MainServerLogic.strictness) {
                String falseMessage = "A player tried to resume an already running game.";
                LOGGER.info(falseMessage);
                onFalseMessage(manager, ErrorTypeEnum.ILLEGAL_MESSAGE, falseMessage);
            } else {
                String problem = "A player tried to resume an already running game. Message might have been delayed. Striking the player.";
                LOGGER.info(problem);
                strikeClient(manager, problem);
            }
        }
    }

    /**
     * This method is called on a MoveTimeout
     * It will:
     * -Strike the Client
     * -Make a random Choice for the Client
     * -Send (if needed) a new random Request
     * -Start a new Timer
     * <p>
     * If the Client already has 4 Characters it will pick a random Gadget.
     * If this were the last choice of the give Client it won't send a new request.
     *
     * @param manager SimpleClientManager who failed to make a move.
     */
    @Override
    public synchronized void onMoveTimeout(SimpleClientManager manager) {
        if (activeState == ServerStateEnum.DECISION_PHASE_STATE) {
            Random random = new Random();
            if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer1)) {
                LOGGER.info("Player1 did not make a choice in the given time. He'll get a Strike and an automated pick");
                strikeClient(manager, "You did not make your choice in the given time.");
                if (!manager.isDisconnected()) {
                    if (mainServerLogic.player1Characters.size() < 4) { //A player can own max. 4 Characters
                        Character character = lastMessageMetaToPlayer1.characters.get(random.nextInt(3));
                        mainServerLogic.player1Characters.add(character);
                        lastMessageMetaToPlayer1.characters.remove(character);
                    } else {
                        GadgetEnum gadgetEnum = lastMessageMetaToPlayer1.gadgetEnums.get(random.nextInt(3));
                        mainServerLogic.player1Gadgets.add(gadgetEnum);
                        lastMessageMetaToPlayer1.gadgetEnums.remove(gadgetEnum);
                    }
                    availableCharacters.addAll(lastMessageMetaToPlayer1.characters);
                    lastMessageMetaToPlayer1.characters.clear();
                    availableGadgets.addAll(lastMessageMetaToPlayer1.gadgetEnums);
                    lastMessageMetaToPlayer1.gadgetEnums.clear();
                    receivedPicksByPlayer1 += 1;
                    if (receivedPicksByPlayer1 < 8) {
                        mainServerLogic.player1.sendMessage(createRequest(manager));
                        startTimerPlayer1();
                    }
                } else {
                    LOGGER.fine("Player received last strike, not sending any more messages.");
                }
            }
            if (manager.clientInformation.getClientId().equals(mainServerLogic.clientIdPlayer2)) {
                LOGGER.info("Player2 did not make a choice in the given time. He'll get a Strike and an automated pick");
                strikeClient(manager, "You did not make your choice in the given time.");
                if (mainServerLogic.player2Characters.size() < 4) { //A player can own max. 4 Characters
                    Character character = lastMessageMetaToPlayer2.characters.get(random.nextInt(3));
                    mainServerLogic.player2Characters.add(character);
                    lastMessageMetaToPlayer2.characters.remove(character);
                } else {
                    GadgetEnum gadgetEnum = lastMessageMetaToPlayer2.gadgetEnums.get(random.nextInt(3));
                    mainServerLogic.player2Gadgets.add(gadgetEnum);
                    lastMessageMetaToPlayer2.gadgetEnums.remove(gadgetEnum);
                }
                availableCharacters.addAll(lastMessageMetaToPlayer2.characters);
                lastMessageMetaToPlayer2.characters.clear();
                availableGadgets.addAll(lastMessageMetaToPlayer2.gadgetEnums);
                lastMessageMetaToPlayer2.gadgetEnums.clear();
                receivedPicksByPlayer2 += 1;
                if (receivedPicksByPlayer2 < 8) {
                    mainServerLogic.player2.sendMessage(createRequest(manager));
                    startTimerPlayer2();
                }
            }
            if (receivedPicksByPlayer2 == 8 && receivedPicksByPlayer1 == 8) {
                leaveState();
            }
        } else {
            LOGGER.fine("Two DecisionPhase move timers stopped at the same time.");
        }
    }

    /**
     * Method that is called, when Server is returning to this state from an interruption(Pause/Reconnect).
     * It will set the active state back to this one.
     * It will retransmit the last request for a player, if he has not made all picks yet.
     */
    @Override
    public void onReturn() {
        LOGGER.warning("Returning to DecisionPhaseState");
        ServerShell.print("Returning to the decision phase.");
        // Reset active state back to this state
        ServerState.activeState = ServerStateEnum.DECISION_PHASE_STATE;
        mainServerLogic.serverState = this;
        // Check if player1 has made all picks yet, if not retransmit last request
        if (receivedPicksByPlayer1 < 8) {
            LOGGER.finer("Player1 has not made all picks yet. Retransmitting last request.");
            startTimerPlayer1();
            mainServerLogic.player1.sendMessage(lastRequestToPlayer1);
        }
        // Check if player2 has made all picks yet, if not retransmit last request
        if (receivedPicksByPlayer2 < 8) {
            LOGGER.finer("Player2 has not made all picks yet. Retransmitting last request.");
            startTimerPlayer2();
            mainServerLogic.player2.sendMessage(lastRequestToPlayer2);
        }
    }

    /**
     * This method will stop the decisionPhaseState.
     */
    @Override
    public void stop() {
        LOGGER.warning("DecisionPhaseState has been stopped.");
        killAllTimers();
    }
}
