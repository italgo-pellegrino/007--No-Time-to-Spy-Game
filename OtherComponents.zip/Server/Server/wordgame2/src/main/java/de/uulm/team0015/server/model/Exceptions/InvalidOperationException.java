package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when a character has an invalid amount of movement points.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class InvalidOperationException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public InvalidOperationException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public InvalidOperationException(String message) {
        super(message);
    }
}
