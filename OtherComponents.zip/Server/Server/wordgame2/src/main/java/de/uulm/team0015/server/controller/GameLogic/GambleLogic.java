package de.uulm.team0015.server.controller.GameLogic;

import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidChipAmountException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;

/**
 * Class to handle the game logic actions for the gamble action.
 *
 * @author Manuel Werner, Simon Demharter
 * @version 1.0
 */
public class GambleLogic {
    /**
     * Method for when a character gambles on a roulette table.
     *
     * @param character Character who gambles.
     * @param map       The board of the game.
     * @param target    The coordinates of the target.
     * @param stake     The amount of chips the character is betting.
     * @return true if the character won, false if not.
     * @throws InvalidTargetException     If the character targets an invalid field.
     * @throws InvalidChipAmountException If the roulette table has not enough chips for that bet.
     */
    public static boolean gambleAction(Character character, FieldMap map, Point target, int stake) throws InvalidTargetException, InvalidChipAmountException {
        // Validate
        map.validateIsNeighbourOfState(character.getCoordinates(), target, FieldStateEnum.ROULETTE_TABLE);
        map.getField(target).validateIsNotDestroyed();
        map.getField(target).validateHasChipAmount(stake);

        double successChance;
        boolean successful;

        // Calculate the win chance
        if (character.hasProperty(PropertyEnum.LUCKY_DEVIL)) {
            successChance = (double) 23 / 37;
        } else if (character.hasProperty(PropertyEnum.JINX)) {
            successChance = (double) 13 / 37;
        } else {
            successChance = (double) 18 / 37;
        }

        if (Math.random() < successChance) {
            successful = true;
        } else {
            // Character has the property tradecraft and no melodie
            if (character.hasProperty(PropertyEnum.TRADECRAFT) && !character.hasGadget(GadgetEnum.MOLEDIE)) {
                successful = Math.random() < successChance;
            } else {
                successful = false;
            }
        }

        // Roulette table is inverted
        if (map.getField(target).isInverted()) {
            successful = !successful;
        }
        if (successful) {
            character.updateChips(stake);
            map.getField(target).updateChips(-stake);
            return true;
        } else {
            character.updateChips(-stake);
            map.getField(target).updateChips(stake);
            return false;
        }
    }
}