package de.uulm.team0015.server.model.Enumerations;

/**
 * Enumeration for the three types of roles which a user can take during a game.
 *
 * @author Simon Demharter, Alexander Preiß
 */
public enum RoleEnum {
    SPECTATOR,
    PLAYER,
    AI
}
