package de.uulm.team0015.server.model.DataTypes.Util;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidActionPointsException;
import de.uulm.team0015.server.model.Exceptions.InvalidChipAmountException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;

/**
 * Class for a field of the board needed for game logic purposes.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class Field {
    private FieldStateEnum state;
    private Gadget gadget;
    private boolean isDestroyed;
    private boolean isInverted;
    private int chipAmount;
    private int safeIndex;
    private boolean isFoggy;
    private boolean isUpdated;

    /**
     * Constructor of the class Field.
     *
     * @param state The type of state for the field.
     */
    public Field(FieldStateEnum state) {
        this.state = state;
        this.gadget = null;
        this.isDestroyed = false;
        this.isInverted = false;
        this.chipAmount = 0;
        this.safeIndex = 0;
        this.isFoggy = false;
        this.isUpdated = false;
    }

    /**
     * Getter for state.
     *
     * @return The type of state for the field.
     */
    public FieldStateEnum getState() {
        return state;
    }

    /**
     * Getter for gadget.
     *
     * @return The gadget if there is one on the field, null if there is no gadget.
     */
    public Gadget getGadget() {
        return gadget;
    }

    /**
     * Method to get the cocktail of the field.
     *
     * @return The cocktail.
     */
    public Cocktail getCocktail() {
        if (gadget.getGadgetEnum().equals(GadgetEnum.COCKTAIL)) {
            return (Cocktail) gadget;
        }
        return null;
    }

    /**
     * Setter for gadget.
     *
     * @param gadget The gadget that is on the field.
     */
    public void setGadget(Gadget gadget) {
        this.gadget = gadget;
    }

    /**
     * Getter for destroyed.
     *
     * @return true if the field is destroyed, false if not.
     */
    public boolean isDestroyed() {
        return isDestroyed;
    }

    /**
     * Setter for destroyed.
     *
     * @param destroyed Whether the field is destroyed or not.
     */
    public void setDestroyed(boolean destroyed) {
        isDestroyed = destroyed;
    }

    /**
     * Getter for inverted.
     *
     * @return true if the field is inverted, false if not.
     */
    public boolean isInverted() {
        return isInverted;
    }

    /**
     * Setter for inverted.
     *
     * @param inverted Whether the field is inverted or not.
     */
    public void setInverted(boolean inverted) {
        isInverted = inverted;
    }

    /**
     * Getter for chipAmount.
     *
     * @return The amount of chips on the field.
     */
    public int getChipAmount() {
        return chipAmount;
    }

    /**
     * Setter for chipAmount.
     *
     * @param chipAmount The amount of chips on the field.
     */
    public void setChipAmount(int chipAmount) {
        this.chipAmount = chipAmount;
    }

    /**
     * Getter for safeIndex.
     *
     * @return The index of the safe.
     */
    public int getSafeIndex() {
        return safeIndex;
    }

    /**
     * Setter for safeIndex.
     *
     * @param safeIndex The index of the safe.
     */
    public void setSafeIndex(int safeIndex) {
        this.safeIndex = safeIndex;
    }

    /**
     * Getter for foggy.
     *
     * @return true if the field is foggy, false if not.
     */
    public boolean isFoggy() {
        return isFoggy;
    }

    /**
     * Setter for foggy.
     *
     * @param foggy Whether the field is foggy or not.
     */
    public void setFoggy(boolean foggy) {
        isFoggy = foggy;
    }

    /**
     * Getter for updated.
     *
     * @return true if the field is updated, false if not.
     */
    public boolean isUpdated() {
        return isUpdated;
    }

    /**
     * Setter for updated.
     *
     * @param updated Whether the field is updated or not.
     */
    public void setUpdated(boolean updated) {
        isUpdated = updated;
    }

    /**
     * Method to validate if the field is of the given state.
     *
     * @param state The type of state.
     * @throws InvalidTargetException If the field is not of the given state.
     */
    public void validateIsState(FieldStateEnum state) throws InvalidTargetException {
        if (!isState(state)) {
            throw new InvalidTargetException("The target field has the wrong state! Expected " + state.toString() + ", but got " + this.state.toString() + ".");
        }
    }

    /**
     * Method to validate if the field is not of the given state.
     *
     * @param state The type of state.
     * @throws InvalidTargetException If the field is of the given state.
     */
    public void validateIsNotState(FieldStateEnum state) throws InvalidTargetException {
        if (isState(state)) {
            throw new InvalidTargetException("The target field has the wrong state! Expected anything but " + state.toString() + ", but got " + this.state.toString() + ".");
        }
    }

    /**
     * Method to validate if the field is accessible.
     *
     * @throws InvalidTargetException If the field is not accessible.
     */
    public void validateIsAccessible() throws InvalidTargetException {
        if (!isAccessible()) {
            throw new InvalidTargetException("The target field is not accessible! Expected " + FieldStateEnum.FREE.toString() + " or " + FieldStateEnum.BAR_SEAT.toString() + ", but got " + state.toString() + ".");
        }
    }

    /**
     * Method to validate if the field has any gadget.
     *
     * @throws InvalidTargetException If there is no gadget on the field.
     */
    public void validateHasGadget() throws InvalidTargetException {
        if (!hasGadget()) {
            throw new InvalidTargetException("There is no gadget on the target field!");
        }
    }

    /**
     * Method to validate if the field has the given gadget.
     *
     * @param gadgetEnum The type of gadget.
     * @throws InvalidTargetException If there is no gadget on the field or the given gadget is not on the field.
     */
    public void validateHasGadgetOfType(GadgetEnum gadgetEnum) throws InvalidTargetException {
        validateHasGadget();
        if (!hasGadgetOfType(gadgetEnum)) {
            throw new InvalidTargetException("The target field has the wrong gadget! Expected " + gadget.getGadgetEnum().toString() + ", but got " + gadgetEnum.toString() + ".");
        }
    }

    /**
     * Method to validate if the target field is not destroyed.
     *
     * @throws InvalidTargetException If the target field is destroyed.
     */
    public void validateIsNotDestroyed() throws InvalidTargetException {
        if (isDestroyed()) {
            throw new InvalidTargetException("The target field is destroyed!");
        }
    }

    /**
     * Method to validate if there are enough chips on the field for a character's bet.
     *
     * @param bet The amount of chips the character wants to bet.
     * @throws InvalidTargetException     If the field is not a roulette table.
     * @throws InvalidChipAmountException If there are not enough chips on the field.
     */
    public void validateHasChipAmount(int bet) throws InvalidChipAmountException, InvalidTargetException {
        validateIsState(FieldStateEnum.ROULETTE_TABLE);
        if ((bet > chipAmount)) {
            throw new InvalidChipAmountException("The target field has not enough chips needed for that bet! Expected at least " + bet + ", but got " + chipAmount + ".");
        }
    }

    /**
     * Method to validate if the field is foggy or not.
     *
     * @throws InvalidActionPointsException If the field is foggy.
     */
    public void validateIsNotFoggy() throws InvalidActionPointsException {
        if (isFoggy()) {
            throw new InvalidActionPointsException("The field is foggy! The character standing on the field can't use any action points!");
        }
    }

    /**
     * Method to check if the field is of the given type.
     *
     * @param state The state of the field.
     * @return true if the given field is of the given type, false if not.
     */
    public boolean isState(FieldStateEnum state) {
        return this.state.equals(state);
    }

    /**
     * Method to check if the field is a valid field to move on to.
     *
     * @return true if the field is accessible, false if it is not.
     */
    public boolean isAccessible() {
        return (isState(FieldStateEnum.FREE) || isState(FieldStateEnum.BAR_SEAT));
    }

    /**
     * Method to update the state of a game field.
     *
     * @param state The new state the field will be updated to.
     */
    public void updateFieldState(FieldStateEnum state) {
        this.state = state;
        setUpdated(true);
    }

    /**
     * Method to check if a gadget is on the field.
     *
     * @return true if the field has a gadget, false if not.
     */
    public boolean hasGadget() {
        return (gadget != null);
    }

    /**
     * Method to check if the given gadget is on the field.
     *
     * @param gadgetEnum The type of the gadget.
     * @return true if the field has the given gadget, false if not.
     */
    public boolean hasGadgetOfType(GadgetEnum gadgetEnum) {
        if (!hasGadget()) {
            return false;
        }
        return gadget.getGadgetEnum().equals(gadgetEnum);
    }

    /**
     * Method to add an amount of chips to the field if it is an roulette table.
     *
     * @param chipAmount The amount of chips to add or remove.
     */
    public void updateChips(int chipAmount) {
        this.chipAmount += chipAmount;
        setUpdated(true);
    }

    /**
     * Method to check if the field has the given safeIndex.
     *
     * @param safeIndex The safe index.
     * @return true if the field has the given safeIndex, false if not.
     */
    public boolean hasSafeIndex(int safeIndex) {
        return this.safeIndex == safeIndex;
    }
}
