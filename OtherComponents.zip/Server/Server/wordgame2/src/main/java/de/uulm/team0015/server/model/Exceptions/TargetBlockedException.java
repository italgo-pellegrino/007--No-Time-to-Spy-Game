package de.uulm.team0015.server.model.Exceptions;

/**
 * Exception for when the target is blocked.
 *
 * @author Simon Demharter, Alexander Preiß, Marcel Rötzer
 * @version 1.0
 * @see Exception
 */
public class TargetBlockedException extends Exception {

    /**
     * Default constructor with no parameters.
     */
    public TargetBlockedException() {
        // No specific parameters
    }

    /**
     * Constructor to create the message when throwing the exception.
     *
     * @param message The message of the exception.
     */
    public TargetBlockedException(String message) {
        super(message);
    }
}
