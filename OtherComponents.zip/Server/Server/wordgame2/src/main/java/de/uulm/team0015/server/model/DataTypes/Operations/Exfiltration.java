package de.uulm.team0015.server.model.DataTypes.Operations;

import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;

import java.util.UUID;

/**
 * Class for the operation when a character reaches 0 health points needed for game logic purposes.
 *
 * @author Simon Demharter, Alexander Preiß
 * @version 1.0
 */
public class Exfiltration extends Operation {
    public /*final*/ Point from;

    /**
     * Constructor of the class Exfiltration.
     *
     * @param type        The type of the operation.
     * @param successful  Whether the operation was successful or not.
     * @param target      The coordinates of the target.
     * @param characterId The id of the character.
     * @param from        The coordinates of the character.
     */
    public Exfiltration(OperationEnum type, boolean successful, Point target, UUID characterId, Point from) {
        super(type, successful, target, characterId);
        this.from = from;
    }

    /**
     * Getter for from.
     *
     * @return The coordinates where the character was when he reached 0 health points.
     */
    public Point getFrom() {
        return from;
    }
}
