package de.uulm.team0015.server.controller.NetworkLogic;

import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.ServerState;
import de.uulm.team0015.server.view.ServerShell;
//import jakarta.websocket.server.ServerContainer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import javax.websocket.CloseReason;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.glassfish.tyrus.server.Server;

/**
 * The NTTSServerSocket class holds a pool of SimpleClients in a ExecutorService.
 * Once a client connects to server (if the max. capacity isn't hit yet) the server will
 * start a SimpleClient for this Client as Thread which is kept in the ExecutorService.
 * <p>
 * To stop the NTTSServerSocket use the .close() Method.
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 */

@ServerEndpoint("/game")
public class NTTSServerSocket extends Thread{
    private final static Logger LOGGER = Logger.getLogger(NTTSServerSocket.class.getName());
    public static int capacity;

    //private ServerSocket ss = null;
    private Server server = null;
    private ExecutorService executorService;
    private static MainServerLogic mainServerLogic;
    public volatile boolean run;
	private static HashMap<Session, SimpleClient> connectionHashmap = new HashMap<Session, SimpleClient>();

    // List SimpleClients
    public static List<SimpleClient> allClients = Collections.synchronizedList(new ArrayList<>());
    
    
    
    
    /**
     * OnOpen Methode wird aufgerufen, wenn sich jmd mit dem WebSocket verbindet
     * 
     * @param session
     */
    @OnOpen
    public void onOpen(Session session) {
    	/**
    	 * Es sollen erst dann Verbindungen angenommen werden, wenn dieses Flag auf true gesetzt wird
    	 */
    	LOGGER.fine("Connected ... " + session.getId());
    	
    	/**
    	 * Bei der WebSocket Klasse wird der Socket durch eine Session dargestellt
    	 * "A Web Socket session represents a conversation between two web socket endpoints."
    	 */
    	
    	final RemoteEndpoint.Basic remote = session.getBasicRemote();
    	
        final SimpleClient newClient = new SimpleClient(remote, session, NTTSServerSocket.mainServerLogic);
        
        
        newClient.setUp();
        
        connectionHashmap.put(session, newClient);

    }

 
    
    
    @OnMessage

    public void onMessage(String message, Session session) {

    	SimpleClient sc = connectionHashmap.get(session);
    	sc.receive(message);
    }

 

    @OnClose

    public void onClose(Session session, CloseReason closeReason) {

        LOGGER.info(String.format("Session %s closed because of %s", session.getId(), closeReason));
        SimpleClient sc = connectionHashmap.get(session);
        sc.setClosed(true);
        SimpleClient.connectedClients -= 1;
        sc.getSimpleClientManager().onDisconnect();
        
    }
    
    
    /**
     * Laut API n�tig
     */
    public NTTSServerSocket() {}
    
    

    /**
     * Constructor for class NTTSServerSocket. Registers logger as well.
     *
     * @param port     The port the Server will run on.
     * @param capacity The maximum number of clients the server will accept.
     * @param logic    The instance of MainServerLogic all SimpleClients will use to process messages.
     */
    public NTTSServerSocket(int port, int capacity, MainServerLogic logic) {
        ServerLogger.addHandler(LOGGER);
        LOGGER.fine("Creating NTTSServerSocket on port: " + port);
        NTTSServerSocket.capacity = capacity;
        run = true;
        NTTSServerSocket.mainServerLogic = logic;
        server = new Server("localhost", port, "/websockets", NTTSServerSocket.class);
        
        /*
         * ExcecutorService nicht nötig
         */
        executorService = Executors.newFixedThreadPool(capacity);
        String correctStart = "The server has been started. Listening on port " + port + ".";
        LOGGER.fine(correctStart);
        ServerShell.print(correctStart);
    }

    /**
     * - �berschrieben 29.06.2020
     * 
     * Use this Method to close the ServerSocket.
     * Closes the connection for each SimpleClient.
     * Stop the java.net.ServerSocket and resets it to so it could be reopened again.
     */
    public synchronized void close() {
            if (run) {
                for (SimpleClient client : allClients) {
                    try {
                    	/**
                    	 * Änderung am 14.07: Freigabe aller registrierten Namen
                    	 */
                    	ServerState.getRegisteredNames().clear();

                        client.close();
                    } catch (IOException ioe) {
                        LOGGER.severe("Failed to close SimpleClient");
                    }
                }
                executorService.shutdownNow();
                closeServer();
                run = false;
                LOGGER.fine("Closed ServerSocket successfully!");
                ServerShell.print("The server has been stopped.");
            } else {
                LOGGER.info("Tried to close NTTSServerSocket, despite being already closed.");
            }
    }


    /**
     * -alternative
     * Diese Methode sorgt daf�r, dass Verbindungen erst akzeptiert werden, wenn diese Methode getriggert wird im MainServerLogic
     
	public void startAcceptingConnections() {
		startAcceptingConnections = true;
	}
     * @throws jakarta.websocket.DeploymentException */
    
    public void startServer() {
    	if(server != null)
			try {
				server.start();
			} catch (javax.websocket.DeploymentException e) {
				LOGGER.severe("Probleme beim Starten des Servers!");
				e.printStackTrace();
		}
    	
    	/**
    	 * Programmausf�hrung darf w�hrend der Server aktiv ist nicht zu Ende gehen
    	 */
    	this.start();
    }
    
    public void run() {
    	/**
    	 * Warten bis Server geschlossen wird
    	 */
    	while(run);
    	closeServer();
    }
    
    public void closeServer(){
    	if(server != null) server.stop();
    }
    
    
    /**
     * Testzwecke
     * 
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
    	NTTSServerSocket ns = new NTTSServerSocket(7007, 5, null);
    	ns.run = true;
    	ns.startServer();
    }

}