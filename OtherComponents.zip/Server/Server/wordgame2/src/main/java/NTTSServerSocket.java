

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Writer;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import javax.websocket.CloseReason;
import javax.websocket.CloseReason.CloseCodes;
import javax.websocket.DeploymentException;
import javax.websocket.Endpoint;
import javax.websocket.MessageHandler;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;
import javax.websocket.server.ServerApplicationConfig;
import javax.websocket.server.ServerEndpoint;
import javax.websocket.server.ServerEndpointConfig;

import org.glassfish.tyrus.server.Server;

/**
 * The NTTSServerSocket class holds a pool of SimpleClients in a ExecutorService.
 * Once a client connects to server (if the max. capacity isn't hit yet) the server will
 * start a SimpleClient for this Client as Thread which is kept in the ExecutorService.
 * <p>
 * To stop the NTTSServerSocket use the .close() Method.
 *
 * @author Max Raedler, Tom Weisser
 * @version 1.0
 */

@ServerEndpoint("/game")
public class NTTSServerSocket {
    private final static Logger LOGGER = Logger.getLogger(NTTSServerSocket.class.getName());
    public static int capacity;

    //private ServerSocket ss = null;
    private Server server = null;
    private ExecutorService executorService;
    //private MainServerLogic mainServerLogic;
    public volatile boolean run;
	private static boolean startAcceptingConnections;

    // List SimpleClients
    //public static List<SimpleClient> allClients = Collections.synchronizedList(new ArrayList<>());
    
    
    /*
     * �berf�hrung in den WebSocket Server,
     * orginaler Code ist auskommentiert unten zu finden
     * 
     */
    
    
    /**
     * OnOpen Methode wird aufgerufen, wenn sich jmd mit dem WebSocket verbindet
     * 
     * @param session
     */
    @OnOpen
    public void onOpen(Session session) {
    	/**
    	 * Es sollen erst dann Verbindungen angenommen werden, wenn dieses Flag auf true gesetzt wird
    	 */
    	while(startAcceptingConnections);
    	
    	LOGGER.fine("Connected ... " + session.getId());
    	
    	/**
    	 * Bei der WebSocket Klasse wird der Socket durch eine Session dargestellt
    	 * "A Web Socket session represents a conversation between two web socket endpoints."
    	 */
    	
    	final RemoteEndpoint.Basic remote = session.getBasicRemote();
    	/**
    	 * Klassischer IO Writer, bei der die Nachricht an den Client geschickt wird
    	 * ... entspricht dem OutputStream der Socket Klasse
    	 */
    	Writer output = null;
    	try {
			output = remote.getSendWriter();
		} catch (IOException e1) {
			LOGGER.severe("IO Exception Problem! Die Session wird beendet");
			try {
				session.close();
			} catch (IOException e) {
				LOGGER.severe("Problem: Beendung der Session nicht m�glich");
			}
		}
    	
    	/**
    	 * Writer -> PrintWriter
    	 */
    	PrintWriter pw = new PrintWriter(output);
    	
    	
    	/**
    	 * MessageHandler.Whole<String> zum Empfangen einer ganzen String Nachricht in der Verbindung
    	 * -> "receive incoming messages during a web socket conversation
    	 * ... entspricht dem InputStream eines Sockets
    	 */
    	MessageHandler messageHandler = null;
    	
    	
    	try {
            //final SimpleClient newClient = new SimpleClient(pw, session, this.mainServerLogic);
            

            messageHandler = new MessageHandler.Whole<String>() {
            	/**
            	 * Logik beim Empfangen einer Nachricht
            	 */
            	public void onMessage(String message){
            		 //newClient.receive(message);
                }
        };
        
        //Die Session erh�lt einen MessageHandler
        session.addMessageHandler(messageHandler);
        //Zuweisung des fertig initialisierten MessageHandlers
        //newClient.setMessageHandler(messageHandler);
        //Excecution
        //executorService.execute(newClient);
        } catch (/*IOException | */ NullPointerException e) {
            LOGGER.warning("Server socket has been closed: " + e.toString());
        }

    }

 
    /*
     M�gliche Art von onMessage Methode beim Server***
     
    @OnMessage

    public String onMessage(String message, Session session) {

        switch (message) {

        case "quit":

            try {

                session.close(new CloseReason(CloseCodes.NORMAL_CLOSURE, "Game ended"));

            } catch (IOException e) {

                throw new RuntimeException(e);

            }

            break;

        }

        return message;

    }
    */

 

    @OnClose

    public void onClose(Session session, CloseReason closeReason) {

        //logger.info(String.format("Session %s closed because of %s", session.getId(), closeReason));

    }
    
    
    /**
     * Laut API n�tig
     */
    public NTTSServerSocket() {}
    
    

    /**
     * Constructor for class NTTSServerSocket. Registers logger as well.
     *
     * @param port     The port the Server will run on.
     * @param capacity The maximum number of clients the server will accept.
     * @param logic    The instance of MainServerLogic all SimpleClients will use to process messages.
     */
    public NTTSServerSocket(int port, int capacity /*, MainServerLogic logic*/) {
        //ServerLogger.addHandler(LOGGER);
        LOGGER.fine("Creating NTTSServerSocket on port: " + port);
        NTTSServerSocket.capacity = capacity;
        run = true;
        //try {
            //this.mainServerLogic = logic;
            server = new Server("localhost", port, "/websockets", NTTSServerSocket.class);
            executorService = Executors.newFixedThreadPool(capacity);
            String correctStart = "The server has been started. Listening on port " + port + ".";
            LOGGER.fine(correctStart);
            //ServerShell.print(correctStart);
            System.out.println("Korrekt Start");
    }

    


    /**
     * -alternative
     * Diese Methode sorgt daf�r, dass Verbindungen erst akzeptiert werden, wenn diese Methode getriggert wird im MainServerLogic
     
	public void startAcceptingConnections() {
		startAcceptingConnections = true;
	}*/
    
    public void startServer(){
    	try {
    		if(server != null) server.start();
		} catch (DeploymentException e) {
			LOGGER.severe("Probleme beim Starten des Servers!");
			e.printStackTrace();
		}
    }
    
    public void closeServer(){
    	if(server != null)server.stop();
    }




//Originaler Code
/*
public class NTTSServerSocket extends Thread {
    private final static Logger LOGGER = Logger.getLogger(NTTSServerSocket.class.getName());
    public static int capacity;

    private ServerSocket ss = null;
    //private Server server = null;
    private ExecutorService executorService;
    private MainServerLogic mainServerLogic;
    public volatile boolean run;

    // List SimpleClients
    public static List<SimpleClient> allClients = Collections.synchronizedList(new ArrayList<>());

    /**
     * Constructor for class NTTSServerSocket. Registers logger as well.
     *
     * @param port     The port the Server will run on.
     * @param capacity The maximum number of clients the server will accept.
     * @param logic    The instance of MainServerLogic all SimpleClients will use to process messages.
     
    public NTTSServerSocket(int port, int capacity, MainServerLogic logic) {
        ServerLogger.addHandler(LOGGER);
        LOGGER.fine("Creating NTTSServerSocket on port: " + port);
        NTTSServerSocket.capacity = capacity;
        run = true;
        try {
            this.mainServerLogic = logic;
            ss = new ServerSocket(port);
            executorService = Executors.newFixedThreadPool(capacity);
            String correctStart = "The server has been started. Listening on port " + port + ".";
            LOGGER.fine(correctStart);
            ServerShell.print(correctStart);
        } catch (IOException e) {
            try {
                ss = new ServerSocket(7007);
                executorService = Executors.newFixedThreadPool(capacity);
                String defaultStart = "Setup on specified port " + port + " failed. Server is now listening on default port 7007.";
                LOGGER.fine(defaultStart);
                ServerShell.print(defaultStart);
            } catch (IOException ioe) {
                LOGGER.severe(e.toString());
            }
        }
    }

    /**
     * Use this Method to close the ServerSocket.
     * Closes the connection for each SimpleClient.
     * Stop the java.net.ServerSocket and resets it to so it could be reopened again.
     
    public synchronized void close() {
        try {
            if (run) {
                for (SimpleClient client : allClients) {
                    try {
                        client.close();
                    } catch (IOException ioe) {
                        LOGGER.severe("Failed to close SimpleClient");
                    }
                }
                executorService.shutdownNow();
                ss.close();
                run = false;
                LOGGER.fine("Closed ServerSocket successfully!");
                ServerShell.print("The server has been stopped.");
            } else {
                LOGGER.info("Tried to close NTTSServerSocket, despite being already closed.");
            }
        } catch (IOException ioe) {
            LOGGER.severe("could not close ServerSocket: " + ioe.toString());
        }
    }

    /**
     * Overrides the run() Method in Thread
     * If the java.net.ServerSocket has been set up correctly this Method will accept connections on it and create SimpleClients for them.
     * All active SimpleClients are kept in the executorService.
     * <p>
     * If the run is set to false this Thread will kill all SimpleClients in the executorService.
     
    @Override
    public void run() {
        if (ss == null) {
            LOGGER.warning("Setup of NTTSServerSocket is incomplete or never called");
        } else {
            LOGGER.info("Setup of NTTSServerSocket is complete. ServerSocket is running on Port: " + ss.getLocalPort());
            while (run) {
                try {
                    SimpleClient newClient = new SimpleClient(ss.accept(), this.mainServerLogic);
                    executorService.execute(newClient);

                } catch (IOException | NullPointerException e) {
                    LOGGER.warning("Server socket has been closed: " + e.toString());
                }
            }
            executorService.shutdownNow();
        }
        LOGGER.info("NTTSServerSocket exited the run() idle and will now stop the Thread.");
    }
}
*/

    public static void main(String[] args) throws IOException {
    	NTTSServerSocket ns = new NTTSServerSocket(7007, 5);
    	ns.startServer();
    	BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    	reader.readLine();
    }
}
