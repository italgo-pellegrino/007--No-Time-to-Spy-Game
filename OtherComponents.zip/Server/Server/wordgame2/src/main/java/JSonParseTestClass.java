import java.util.UUID;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import de.uulm.team0015.server.model.DataTypes.Operations.GadgetAction;
import de.uulm.team0015.server.model.DataTypes.Operations.GambleAction;
import de.uulm.team0015.server.model.DataTypes.Operations.Movement;
import de.uulm.team0015.server.model.DataTypes.Operations.PropertyAction;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Messages.Receive.GameOperationMessage;

public class JSonParseTestClass {

	
	
	public static void main(String[] args) {
		Gson gson = new Gson();
		String jsonMessage1 = "{\"operation\":{\"from\":{\"x\":4,\"y\":8},\"characterId\":\"35fce49c-c7b8-421f-bd69-aaf9b493dbcf\",\"type\":\"MOVEMENT\",\"successful\":false,\"target\":{\"x\":3,\"y\":9}},\"clientId\":\"a6160d59-c824-49e2-a4f4-348249823835\",\"type\":\"GAME_OPERATION\",\"creationDate\":\"14.07.2020 21:27:11.8515337+02:00\",\"debugMessage\":\"\"}";
		String jsonMessage2 = "{\"operation\":{\"from\":{\"x\":0,\"y\":0},\"characterId\":\"00000000-0000-0000-0000-000000000000\",\"type\":\"MOVEMENT\",\"successful\":false,\"target\":{\"x\":0,\"y\":1}},\"clientId\":\"00000000-0000-0000-0000-000000000000\",\"type\":\"GAME_OPERATION\",\"creationDate\":\"2020-07-14T22:56:11.636761+02:00\",\"debugMessage\":\"\"}";
		GameOperationMessage gOp = new GameOperationMessage();
		gOp.operation = new Movement(OperationEnum.MOVEMENT, false, new Point(1,1), UUID.randomUUID(), new Point(1,2));
		gOp.clientId = UUID.randomUUID();
		gOp.creationDate = "";
		gOp.debugMessage = "";
		gOp.type = MessageTypeEnum.GAME_OPERATION;
		String jsonMessage3 = gson.toJson(gOp, GameOperationMessage.class);
		System.out.println(jsonMessage3);
		
		GameOperationMessage gameOperationMessage = gson.fromJson(jsonMessage1, GameOperationMessage.class);
		
		/**
		 * Operation Attribut wird gesondert behandelt wegen JSON Parse Probleme
		 */
		JsonObject object = gson.fromJson(jsonMessage1, JsonObject.class);
		JsonObject OperationObject = object.getAsJsonObject("operation");
		switch(gameOperationMessage.operation.getType()) {
			/**
			 * Folgende Operationen werden durch Operation vollständig spezifiziert
			 */
			case RETIRE:
			break;
			case SPY_ACTION:
			break;
			case GADGET_ACTION:
				GadgetAction gadgetAction = gson.fromJson(OperationObject, GadgetAction.class);
				gameOperationMessage.operation = gadgetAction;
			break;
			case GAMBLE_ACTION:
				GambleAction gambleAction = gson.fromJson(OperationObject, GambleAction.class);
				gameOperationMessage.operation = gambleAction;
			break;
			case PROPERTY_ACTION:
				PropertyAction propertyAction = gson.fromJson(OperationObject, PropertyAction.class);
				gameOperationMessage.operation = propertyAction;
			break;
			case MOVEMENT:
				Movement movement = gson.fromJson(OperationObject, Movement.class);
				gameOperationMessage.operation = movement;
			break;
			/**
			 * Folgende Aktionen werden vom Server erzeugt
			 */
			case CAT_ACTION:
			break;
			case EXFILTRATION:
			break;
			case JANITOR_ACTION:
			break;
		}
		
		
		System.out.println(gameOperationMessage.isValid());
		
	}
}
