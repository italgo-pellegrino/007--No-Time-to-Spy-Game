package Tests.DataTypes;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Class to test the methods of the class Cocktail.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class CocktailTest {

    @Test
    public void testPoison() {
        // Setup
        Cocktail cocktail = new Cocktail();

        // Case 1: Cocktail is being poisoned
        assertFalse(cocktail.isPoisoned());
        cocktail.poison();
        assertTrue(cocktail.isPoisoned());
    }
}
