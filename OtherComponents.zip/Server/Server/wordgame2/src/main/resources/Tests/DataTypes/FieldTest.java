package Tests.DataTypes;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidActionPointsException;
import de.uulm.team0015.server.model.Exceptions.InvalidChipAmountException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Class to test the methods of the class Field.
 *
 * @author Marcel Rötzer
 * @version 1.0
 * @see Field
 */
public class FieldTest {

    @Test
    public void testValidateIsState() throws InvalidTargetException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);
        Field field2 = new Field(FieldStateEnum.FIREPLACE);

        // Case 1: Field is of the state
        field1.validateIsState(FieldStateEnum.FREE);
        field2.validateIsState(FieldStateEnum.FIREPLACE);

        // Case 2: Field is not of the state
        assertThrows(InvalidTargetException.class, () -> field1.validateIsState(FieldStateEnum.FIREPLACE));
        assertThrows(InvalidTargetException.class, () -> field1.validateIsState(FieldStateEnum.ROULETTE_TABLE));
        assertThrows(InvalidTargetException.class, () -> field1.validateIsState(FieldStateEnum.WALL));
        assertThrows(InvalidTargetException.class, () -> field1.validateIsState(FieldStateEnum.BAR_TABLE));
        assertThrows(InvalidTargetException.class, () -> field1.validateIsState(FieldStateEnum.BAR_SEAT));
        assertThrows(InvalidTargetException.class, () -> field1.validateIsState(FieldStateEnum.SAFE));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsState(FieldStateEnum.FREE));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsState(FieldStateEnum.ROULETTE_TABLE));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsState(FieldStateEnum.WALL));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsState(FieldStateEnum.BAR_TABLE));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsState(FieldStateEnum.BAR_SEAT));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsState(FieldStateEnum.SAFE));
    }

    @Test
    public void testValidateIsNotState() throws InvalidTargetException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);
        Field field2 = new Field(FieldStateEnum.FIREPLACE);

        // Case 1: Field is not of the state
        field1.validateIsNotState(FieldStateEnum.FIREPLACE);
        field1.validateIsNotState(FieldStateEnum.ROULETTE_TABLE);
        field1.validateIsNotState(FieldStateEnum.WALL);
        field1.validateIsNotState(FieldStateEnum.BAR_TABLE);
        field1.validateIsNotState(FieldStateEnum.BAR_SEAT);
        field1.validateIsNotState(FieldStateEnum.SAFE);
        field2.validateIsNotState(FieldStateEnum.FREE);
        field2.validateIsNotState(FieldStateEnum.ROULETTE_TABLE);
        field2.validateIsNotState(FieldStateEnum.WALL);
        field2.validateIsNotState(FieldStateEnum.BAR_TABLE);
        field2.validateIsNotState(FieldStateEnum.BAR_SEAT);
        field2.validateIsNotState(FieldStateEnum.SAFE);

        // Case 2: Field is of the state
        assertThrows(InvalidTargetException.class, () -> field1.validateIsNotState(FieldStateEnum.FREE));
        assertThrows(InvalidTargetException.class, () -> field2.validateIsNotState(FieldStateEnum.FIREPLACE));
    }

    @Test
    public void testValidateIsAccessible() throws InvalidTargetException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);
        Field field2 = new Field(FieldStateEnum.BAR_SEAT);
        Field field3 = new Field(FieldStateEnum.FIREPLACE);
        Field field4 = new Field(FieldStateEnum.ROULETTE_TABLE);
        Field field5 = new Field(FieldStateEnum.BAR_TABLE);
        Field field6 = new Field(FieldStateEnum.WALL);
        Field field7 = new Field(FieldStateEnum.SAFE);

        // Case 1: Field is accessible
        field1.validateIsAccessible();
        field2.validateIsAccessible();

        // Case 2: Field is not accessible
        assertThrows(InvalidTargetException.class, field3::validateIsAccessible);
        assertThrows(InvalidTargetException.class, field4::validateIsAccessible);
        assertThrows(InvalidTargetException.class, field5::validateIsAccessible);
        assertThrows(InvalidTargetException.class, field6::validateIsAccessible);
        assertThrows(InvalidTargetException.class, field7::validateIsAccessible);
    }

    @Test
    public void testValidateHasGadget() throws InvalidTargetException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: Field has no gadget
        assertThrows(InvalidTargetException.class, field1::validateHasGadget);

        // Setup change
        field1.setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));

        // Case 2: Field has a gadget
        field1.validateHasGadget();
    }

    @Test
    public void testValidateHasGadgetOfType() throws InvalidTargetException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: Field has no gadget
        assertThrows(InvalidTargetException.class, () -> field1.validateHasGadgetOfType(GadgetEnum.MOLEDIE));

        // Setup change
        field1.setGadget(new Gadget(GadgetEnum.MOLEDIE));

        // Case 2: Field has a gadget of the right type
        field1.validateHasGadgetOfType(GadgetEnum.MOLEDIE);

        // Case 3: Field has a gadget of the wrong type
        assertThrows(InvalidTargetException.class, () -> field1.validateHasGadgetOfType(GadgetEnum.BOWLER_BLADE));
    }

    @Test
    public void testValidateIsNotDestroyed() throws InvalidTargetException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: Field is not destroyed
        field1.validateIsNotDestroyed();

        // Setup change
        field1.setDestroyed(true);

        // Case 2: Field is destroyed
        assertThrows(InvalidTargetException.class, field1::validateIsNotDestroyed);
    }

    @Test
    public void testValidateHasChipAmount() throws InvalidTargetException, InvalidChipAmountException {
        // Setup
        Field field1 = new Field(FieldStateEnum.ROULETTE_TABLE);
        field1.setChipAmount(10);

        // Case 1: Roulette table has the right amount of chips
        field1.validateHasChipAmount(5);

        // Case 2: Roulette table has the wrong amount of chips
        assertThrows(InvalidChipAmountException.class, () -> field1.validateHasChipAmount(15));
    }

    @Test
    public void testValidateIsNotFoggy() throws InvalidActionPointsException {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: Field is not foggy
        field1.validateIsNotFoggy();

        // Setup change
        field1.setFoggy(true);

        // Case 2: Field is foggy
        assertThrows(InvalidActionPointsException.class, field1::validateIsNotFoggy);
    }

    @Test
    public void testIsState() {
        // Setup
        Field field1 = new Field(FieldStateEnum.SAFE);

        // Case 1: Field is of the state
        assertTrue(field1.isState(FieldStateEnum.SAFE));

        // Case 2: Field is not of the state
        assertFalse(field1.isState(FieldStateEnum.FIREPLACE));
    }

    @Test
    public void testIsAccessible() {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);
        Field field2 = new Field(FieldStateEnum.BAR_SEAT);
        Field field3 = new Field(FieldStateEnum.WALL);
        Field field4 = new Field(FieldStateEnum.ROULETTE_TABLE);
        Field field5 = new Field(FieldStateEnum.BAR_TABLE);
        Field field6 = new Field(FieldStateEnum.FIREPLACE);
        Field field7 = new Field(FieldStateEnum.SAFE);

        // Case 1: Field is accessible
        assertTrue(field1.isAccessible());
        assertTrue(field2.isAccessible());

        // Case 2: Field is not accessible
        assertFalse(field3.isAccessible());
        assertFalse(field4.isAccessible());
        assertFalse(field5.isAccessible());
        assertFalse(field6.isAccessible());
        assertFalse(field7.isAccessible());
    }

    @Test
    public void testUpdateFieldState() {
        // Setup
        Field field1 = new Field(FieldStateEnum.WALL);

        // Case 1: Field state did not get updated
        assertFalse(field1.isUpdated());

        // Case 2: Field state got updated
        field1.updateFieldState(FieldStateEnum.FREE);
        assertTrue(field1.isState(FieldStateEnum.FREE));
        assertFalse(field1.isState(FieldStateEnum.WALL));
        assertTrue(field1.isUpdated());
    }

    @Test
    public void testHasGadget() {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: Field has no gadget
        assertFalse(field1.hasGadget());

        // Setup change
        field1.setGadget(new Gadget(GadgetEnum.MOLEDIE));

        // Case 2: Field has a gadget
        assertTrue(field1.hasGadget());
    }

    @Test
    public void testHasGadgetOfType() {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: Field has no gadget
        assertFalse(field1.hasGadgetOfType(GadgetEnum.MOLEDIE));

        // Setup change
        field1.setGadget(new Gadget(GadgetEnum.MOLEDIE));

        // Case 2: Field has a gadget of the right type
        assertTrue(field1.hasGadgetOfType(GadgetEnum.MOLEDIE));

        // Case 3: Field has a gadget of the wrong type
        assertFalse(field1.hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
    }

    @Test
    public void testUpdateChips() {
        // Setup
        Field field1 = new Field(FieldStateEnum.FREE);

        // Case 1: No Chips are added or removed from the roulette table
        assertFalse(field1.isUpdated());

        // Case 2: Chips are added to the roulette table
        field1.updateChips(10);
        assertEquals(10, field1.getChipAmount());
        assertTrue(field1.isUpdated());

        // Case 3: Chips are removed from the roulette table
        field1.updateChips(-5);
        assertEquals(5, field1.getChipAmount());
        assertTrue(field1.isUpdated());
    }

    @Test
    public void testHasSafeIndex() {
        // Setup
        Field field1 = new Field(FieldStateEnum.SAFE);
        field1.setSafeIndex(2);

        // Case 1: Safe is of the right index
        assertTrue(field1.hasSafeIndex(2));

        // Case 2: Safe is of the wrong index
        assertFalse(field1.hasSafeIndex(5));
    }
}
