package Tests.DataTypes;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Class to test the methods of the class FieldMap.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class FieldMapTest {
    private FieldMap map;
    private Set<Character> characters;
    private Character jamesBond;
    private Character drNo;
    private Character q;
    private Character m;
    private Character eve;

    /**
     * Method to create a test setup
     */
    public void setup() {
        // Set up map
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        map = new FieldMap(fields);

        // Set up characters
        jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(4, 5), new HashSet<>(), new HashSet<>());
        q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
    }

    @Test
    public void testValidatePoint() throws TargetOutOfBoundsException {
        // Setup
        setup();

        // Case 1: Valid point
        map.validatePoint(new Point(0, 0));
        map.validatePoint(new Point(2, 3));
        map.validatePoint(new Point(4, 5));

        // Case 2: Coordinates out of bounds
        assertThrows(TargetOutOfBoundsException.class, () -> map.validatePoint(new Point(1, 7)));
        assertThrows(TargetOutOfBoundsException.class, () -> map.validatePoint(new Point(14, 2)));
        assertThrows(TargetOutOfBoundsException.class, () -> map.validatePoint(new Point(16, 23)));

        // Case 3: Negative coordinates
        assertThrows(TargetOutOfBoundsException.class, () -> map.validatePoint(new Point(-1, 2)));
        assertThrows(TargetOutOfBoundsException.class, () -> map.validatePoint(new Point(-4, -5)));
        assertThrows(TargetOutOfBoundsException.class, () -> map.validatePoint(new Point(12, -25)));
    }

    @Test
    public void testValidateFieldHasCharacter() throws InvalidTargetException {
        // Setup
        setup();

        // Case 1: Field has a character
        map.validateFieldHasCharacter(new Point(1, 2), characters);
        map.validateFieldHasCharacter(new Point(2, 3), characters);
        map.validateFieldHasCharacter(new Point(5, 1), characters);

        // Case 2: Field has no character
        assertThrows(InvalidTargetException.class, () -> map.validateFieldHasCharacter(new Point(2, 2), characters));
        assertThrows(InvalidTargetException.class, () -> map.validateFieldHasCharacter(new Point(3, 2), characters));
        assertThrows(InvalidTargetException.class, () -> map.validateFieldHasCharacter(new Point(4, 1), characters));
    }

    @Test
    public void testValidateFieldHasNoCharacter() throws InvalidTargetException {
        // Setup
        setup();

        // Case 1: Field has no character
        map.validateFieldHasNoCharacter(new Point(3, 2), characters);
        map.validateFieldHasNoCharacter(new Point(0, 0), characters);
        map.validateFieldHasNoCharacter(new Point(4, 4), characters);

        // Case 2: Field has a character
        assertThrows(InvalidTargetException.class, () -> map.validateFieldHasNoCharacter(new Point(1, 2), characters));
        assertThrows(InvalidTargetException.class, () -> map.validateFieldHasNoCharacter(new Point(4, 5), characters));
        assertThrows(InvalidTargetException.class, () -> map.validateFieldHasNoCharacter(new Point(5, 1), characters));
    }

    @Test
    public void testValidateIsNeighbour() throws InvalidTargetException {
        // Setup
        setup();

        // Case 1: Neighbour
        map.validateIsNeighbour(new Point(3, 0), new Point(2, 1));
        map.validateIsNeighbour(new Point(5, 1), new Point(4, 0));
        map.validateIsNeighbour(new Point(5, 5), new Point(6, 5));

        // Case 2: Not a neighbour
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbour(new Point(5, 3), new Point(0, 0)));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbour(new Point(4, 4), new Point(2, 2)));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbour(new Point(5, 1), new Point(6, 6)));
    }

    @Test
    public void testValidateIsNeighbourOfState() throws InvalidTargetException {
        // Setup
        setup();

        // Case 1: Neighbour of the right state
        map.validateIsNeighbourOfState(new Point(5, 3), new Point(4, 2), FieldStateEnum.FREE);
        map.validateIsNeighbourOfState(new Point(5, 1), new Point(6, 1), FieldStateEnum.WALL);
        map.validateIsNeighbourOfState(new Point(0, 0), new Point(1, 1), FieldStateEnum.FIREPLACE);

        // Case 2: Not a neighbour
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourOfState(new Point(4, 4), new Point(2, 2), FieldStateEnum.FREE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourOfState(new Point(2, 1), new Point(2, 5), FieldStateEnum.FREE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourOfState(new Point(5, 1), new Point(6, 6), FieldStateEnum.WALL));

        // Case 3: Neighbour of the wrong state
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourOfState(new Point(5, 3), new Point(4, 2), FieldStateEnum.FIREPLACE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourOfState(new Point(2, 5), new Point(2, 4), FieldStateEnum.BAR_SEAT));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourOfState(new Point(2, 3), new Point(3, 2), FieldStateEnum.WALL));
    }

    @Test
    public void testValidateIsNeighbourWithGadgetOfType() throws InvalidTargetException {
        // Setup
        setup();
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(6, 1)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(3, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));

        // Case 1: Neighbour with the right gadget
        map.validateIsNeighbourWithGadgetOfType(new Point(5, 3), new Point(4, 2), GadgetEnum.BOWLER_BLADE);
        map.validateIsNeighbourWithGadgetOfType(new Point(5, 1), new Point(6, 1), GadgetEnum.BOWLER_BLADE);
        map.validateIsNeighbourWithGadgetOfType(new Point(4, 4), new Point(3, 4), GadgetEnum.DIAMOND_COLLAR);

        // Case 2: Not a neighbour
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(5, 3), new Point(0, 0), GadgetEnum.BOWLER_BLADE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(5, 1), new Point(6, 6), GadgetEnum.BOWLER_BLADE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(4, 4), new Point(2, 2), GadgetEnum.DIAMOND_COLLAR));

        // Case 3: Neighbour with no gadget
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(5, 3), new Point(5, 2), GadgetEnum.BOWLER_BLADE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(5, 1), new Point(4, 1), GadgetEnum.BOWLER_BLADE));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(4, 4), new Point(4, 5), GadgetEnum.DIAMOND_COLLAR));

        // Case 4: Neighbour with the wrong gadget
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(5, 3), new Point(4, 2), GadgetEnum.LASER_COMPACT));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(5, 1), new Point(6, 1), GadgetEnum.FOG_TIN));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNeighbourWithGadgetOfType(new Point(4, 4), new Point(3, 4), GadgetEnum.JETPACK));
    }

    @Test
    public void testValidateIsInSight() throws TargetOutOfSightException, InvalidTargetException {
        // Setup
        setup();
        map.getField(new Point(2, 5)).setFoggy(true);
        map.getField(new Point(5, 2)).setFoggy(true);
        map.getField(new Point(2, 3)).setFoggy(true);

        // Case 1: Target in sight
        map.validateIsInSight(new Point(1, 2), new Point(2, 2));
        map.validateIsInSight(new Point(2, 3), new Point(5, 2));
        map.validateIsInSight(new Point(5, 1), new Point(2, 3));

        // Case 2: Target is the character itself
        assertThrows(InvalidTargetException.class, () -> map.validateIsInSight(new Point(1, 2), new Point(1, 2)));
        assertThrows(InvalidTargetException.class, () -> map.validateIsInSight(new Point(5, 1), new Point(5, 1)));
        assertThrows(InvalidTargetException.class, () -> map.validateIsInSight(new Point(4, 5), new Point(4, 5)));

        // Case 3: Target not in sight
        assertThrows(TargetOutOfSightException.class, () -> map.validateIsInSight(new Point(1, 2), new Point(6, 0)));
        assertThrows(TargetOutOfSightException.class, () -> map.validateIsInSight(new Point(4, 5), new Point(2, 4)));
        assertThrows(TargetOutOfSightException.class, () -> map.validateIsInSight(new Point(5, 1), new Point(1, 1)));

        // Case 4: Target not in sight with foggy fields
        assertThrows(TargetOutOfSightException.class, () -> map.validateIsInSight(new Point(1, 5), new Point(4, 5)));
        assertThrows(TargetOutOfSightException.class, () -> map.validateIsInSight(new Point(3, 2), new Point(1, 6)));
        assertThrows(TargetOutOfSightException.class, () -> map.validateIsInSight(new Point(5, 1), new Point(5, 3)));
    }

    @Test
    public void testValidateIsInRange() throws TargetOutOfRangeException, InvalidTargetException {
        // Setup
        setup();

        // Case 1: Target in range
        map.validateIsInRange(new Point(1, 2), new Point(2, 2), 1);
        map.validateIsInRange(new Point(2, 3), new Point(5, 2), 3);
        map.validateIsInRange(new Point(5, 5), new Point(0, 1), 5);

        // Case 2: Target is the character itself
        assertThrows(InvalidTargetException.class, () -> map.validateIsInRange(new Point(1, 2), new Point(1, 2), 1));
        assertThrows(InvalidTargetException.class, () -> map.validateIsInRange(new Point(5, 1), new Point(5, 1), 3));
        assertThrows(InvalidTargetException.class, () -> map.validateIsInRange(new Point(4, 5), new Point(4, 5), 5));

        // Case 3: Target not in range
        assertThrows(TargetOutOfRangeException.class, () -> map.validateIsInRange(new Point(1, 2), new Point(6, 1), 4));
        assertThrows(TargetOutOfRangeException.class, () -> map.validateIsInRange(new Point(4, 5), new Point(1, 4), 2));
        assertThrows(TargetOutOfRangeException.class, () -> map.validateIsInRange(new Point(5, 1), new Point(3, 5), 3));
    }

    @Test
    public void testValidateIsNotBlocked() throws TargetBlockedException, InvalidTargetException {
        // Setup
        setup();

        // Case 1: Target not blocked
        map.validateIsNotBlocked(new Point(1, 2), new Point(3, 2), characters);
        map.validateIsNotBlocked(new Point(4, 5), new Point(1, 5), characters);
        map.validateIsNotBlocked(new Point(1, 5), new Point(4, 6), characters);

        // Case 2: Target is the character itself
        assertThrows(InvalidTargetException.class, () -> map.validateIsNotBlocked(new Point(1, 2), new Point(1, 2), characters));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNotBlocked(new Point(1, 5), new Point(1, 5), characters));
        assertThrows(InvalidTargetException.class, () -> map.validateIsNotBlocked(new Point(2, 3), new Point(2, 3), characters));

        // Case 3: Target blocked with one character
        assertThrows(TargetBlockedException.class, () -> map.validateIsNotBlocked(new Point(4, 5), new Point(5, 0), characters));
        assertThrows(TargetBlockedException.class, () -> map.validateIsNotBlocked(new Point(5, 1), new Point(0, 2), characters));
        assertThrows(TargetBlockedException.class, () -> map.validateIsNotBlocked(new Point(2, 3), new Point(1, 1), characters));

        // Case 4: Target blocked with more than one character
        assertThrows(TargetBlockedException.class, () -> map.validateIsNotBlocked(new Point(4, 5), new Point(0, 1), characters));
        assertThrows(TargetBlockedException.class, () -> map.validateIsNotBlocked(new Point(2, 2), new Point(1, 3), characters));
        assertThrows(TargetBlockedException.class, () -> map.validateIsNotBlocked(new Point(3, 1), new Point(0, 6), characters));
    }

    @Test
    public void testGetField() {
        // Setup
        setup();

        // Case 1: Get the right field
        assertEquals(map.getMap()[0][0], map.getField(new Point(0, 0)));
        assertEquals(map.getMap()[2][5], map.getField(new Point(5, 2)));
        assertEquals(map.getMap()[4][1], map.getField(new Point(1, 4)));
    }

    @Test
    public void testFieldHasCharacter() {
        // Setup
        setup();

        // Case 1: Character on the field
        assertTrue(map.fieldHasCharacter(new Point(1, 2), characters));
        assertTrue(map.fieldHasCharacter(new Point(4, 5), characters));
        assertTrue(map.fieldHasCharacter(new Point(5, 1), characters));

        // Case 2: No Character on the field
        assertFalse(map.fieldHasCharacter(new Point(3, 3), characters));
        assertFalse(map.fieldHasCharacter(new Point(6, 1), characters));
        assertFalse(map.fieldHasCharacter(new Point(3, 6), characters));
    }

    @Test
    public void testGetCharacterOnField() {
        // Setup
        setup();

        // Case 1: Character on the field
        assertEquals(jamesBond, map.getCharacterOnField(new Point(1, 2), characters));
        assertEquals(drNo, map.getCharacterOnField(new Point(4, 5), characters));
        assertEquals(q, map.getCharacterOnField(new Point(2, 3), characters));

        // Case 2: No character on the field
        assertNull(map.getCharacterOnField(new Point(0, 0), characters));
        assertNull(map.getCharacterOnField(new Point(6, 1), characters));
        assertNull(map.getCharacterOnField(new Point(4, 3), characters));
    }

    @Test
    public void testGetTopLeftNeighbour() {
        // Setup
        setup();

        // Case 1: Has a top left neighbour
        assertEquals(new Point(1, 1), map.getTopLeftNeighbour(new Point(2, 2)));
        assertEquals(new Point(4, 5), map.getTopLeftNeighbour(new Point(5, 6)));
        assertEquals(new Point(3, 0), map.getTopLeftNeighbour(new Point(4, 1)));

        // Case 2: Has no top left neighbour
        assertNull(map.getTopLeftNeighbour(new Point(0, 0)));
        assertNull(map.getTopLeftNeighbour(new Point(4, 0)));
        assertNull(map.getTopLeftNeighbour(new Point(0, 6)));
    }

    @Test
    public void testGetTopNeighbour() {
        // Setup
        setup();

        // Case 1: Has a top neighbour
        assertEquals(new Point(5, 3), map.getTopNeighbour(new Point(5, 4)));
        assertEquals(new Point(2, 4), map.getTopNeighbour(new Point(2, 5)));
        assertEquals(new Point(1, 2), map.getTopNeighbour(new Point(1, 3)));

        // Case 2: Has no top neighbour
        assertNull(map.getTopNeighbour(new Point(2, 0)));
        assertNull(map.getTopNeighbour(new Point(4, 0)));
        assertNull(map.getTopNeighbour(new Point(0, 0)));
    }

    @Test
    public void testGetTopRightNeighbour() {
        // Setup
        setup();

        // Case 1: Has a top right neighbour
        assertEquals(new Point(5, 4), map.getTopRightNeighbour(new Point(4, 5)));
        assertEquals(new Point(2, 2), map.getTopRightNeighbour(new Point(1, 3)));
        assertEquals(new Point(3, 0), map.getTopRightNeighbour(new Point(2, 1)));

        // Case 2: Has no top right neighbour
        assertNull(map.getTopRightNeighbour(new Point(0, 0)));
        assertNull(map.getTopRightNeighbour(new Point(3, 0)));
        assertNull(map.getTopRightNeighbour(new Point(6, 5)));
    }

    @Test
    public void testGetRightNeighbour() {
        // Setup
        setup();

        // Case 1: Has a right neighbour
        assertEquals(new Point(1, 5), map.getRightNeighbour(new Point(0, 5)));
        assertEquals(new Point(2, 1), map.getRightNeighbour(new Point(1, 1)));
        assertEquals(new Point(5, 6), map.getRightNeighbour(new Point(4, 6)));

        // Case 2: Has no right neighbour
        assertNull(map.getRightNeighbour(new Point(6, 0)));
        assertNull(map.getRightNeighbour(new Point(6, 3)));
        assertNull(map.getRightNeighbour(new Point(6, 6)));
    }

    @Test
    public void testGetBottomRightNeighbour() {
        // Setup
        setup();

        // Case 1: Has a bottom right neighbour
        assertEquals(new Point(5, 1), map.getBottomRightNeighbour(new Point(4, 0)));
        assertEquals(new Point(2, 3), map.getBottomRightNeighbour(new Point(1, 2)));
        assertEquals(new Point(6, 3), map.getBottomRightNeighbour(new Point(5, 2)));

        // Case 2: Has no bottom right neighbour
        assertNull(map.getBottomRightNeighbour(new Point(6, 4)));
        assertNull(map.getBottomRightNeighbour(new Point(0, 6)));
        assertNull(map.getBottomRightNeighbour(new Point(4, 6)));
    }

    @Test
    public void testGetBottomNeighbour() {
        // Setup
        setup();

        // Case 1: Has a bottom neighbour
        assertEquals(new Point(5, 2), map.getBottomNeighbour(new Point(5, 1)));
        assertEquals(new Point(3, 5), map.getBottomNeighbour(new Point(3, 4)));
        assertEquals(new Point(6, 2), map.getBottomNeighbour(new Point(6, 1)));

        // Case 2: Has no bottom neighbour
        assertNull(map.getBottomNeighbour(new Point(0, 6)));
        assertNull(map.getBottomNeighbour(new Point(2, 6)));
        assertNull(map.getBottomNeighbour(new Point(6, 6)));
    }

    @Test
    public void testGetBottomLeftNeighbour() {
        // Setup
        setup();

        // Case 1: Has a bottom left neighbour
        assertEquals(new Point(4, 2), map.getBottomLeftNeighbour(new Point(5, 1)));
        assertEquals(new Point(3, 5), map.getBottomLeftNeighbour(new Point(4, 4)));
        assertEquals(new Point(1, 6), map.getBottomLeftNeighbour(new Point(2, 5)));

        // Case 2: Has no bottom left neighbour
        assertNull(map.getBottomLeftNeighbour(new Point(0, 5)));
        assertNull(map.getBottomLeftNeighbour(new Point(3, 6)));
        assertNull(map.getBottomLeftNeighbour(new Point(0, 6)));
    }

    @Test
    public void testGetLeftNeighbour() {
        // Setup
        setup();

        // Case 1: Has a left neighbour
        assertEquals(new Point(4, 2), map.getLeftNeighbour(new Point(5, 2)));
        assertEquals(new Point(5, 5), map.getLeftNeighbour(new Point(6, 5)));
        assertEquals(new Point(2, 1), map.getLeftNeighbour(new Point(3, 1)));

        // Case 2: Has no left neighbour
        assertNull(map.getLeftNeighbour(new Point(0, 0)));
        assertNull(map.getLeftNeighbour(new Point(0, 4)));
        assertNull(map.getLeftNeighbour(new Point(0, 6)));
    }

    @Test
    public void testGetNeighbours() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: A field in the middle of the map
        points = new ArrayList<>(map.getNeighbours(new Point(2, 4)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(3, 4));
        expectedPoints.add(new Point(3, 5));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(1, 5));
        expectedPoints.add(new Point(1, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighbours(new Point(3, 1)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 0));
        expectedPoints.add(new Point(3, 0));
        expectedPoints.add(new Point(4, 0));
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(2, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighbours(new Point(5, 5)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(6, 4));
        expectedPoints.add(new Point(6, 5));
        expectedPoints.add(new Point(6, 6));
        expectedPoints.add(new Point(5, 6));
        expectedPoints.add(new Point(4, 6));
        expectedPoints.add(new Point(4, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: A field at an edge of the map
        points = new ArrayList<>(map.getNeighbours(new Point(0, 3)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(0, 2));
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(0, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighbours(new Point(4, 0)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 0));
        expectedPoints.add(new Point(5, 1));
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(3, 0));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighbours(new Point(5, 6)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 5));
        expectedPoints.add(new Point(5, 5));
        expectedPoints.add(new Point(6, 5));
        expectedPoints.add(new Point(6, 6));
        expectedPoints.add(new Point(4, 6));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: A field in a corner of the map
        points = new ArrayList<>(map.getNeighbours(new Point(0, 0)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 0));
        expectedPoints.add(new Point(1, 1));
        expectedPoints.add(new Point(0, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighbours(new Point(6, 0)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 0));
        expectedPoints.add(new Point(6, 1));
        expectedPoints.add(new Point(5, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighbours(new Point(6, 6)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 5));
        expectedPoints.add(new Point(6, 5));
        expectedPoints.add(new Point(5, 6));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
    }

    @Test
    public void testIsNeighbour() {
        // Setup
        setup();

        // Case 1: Neighbour
        assertTrue(map.isNeighbour(new Point(3, 0), new Point(2, 1)));
        assertTrue(map.isNeighbour(new Point(5, 1), new Point(4, 0)));
        assertTrue(map.isNeighbour(new Point(5, 5), new Point(6, 5)));

        // Case 2: Not a neighbour
        assertFalse(map.isNeighbour(new Point(5, 3), new Point(0, 0)));
        assertFalse(map.isNeighbour(new Point(4, 4), new Point(2, 2)));
        assertFalse(map.isNeighbour(new Point(5, 1), new Point(6, 6)));
    }


    @Test
    public void testNeighbourHasCharacter() {
        // Setup
        setup();

        // Case 1: More than one Character on a neighbour field
        assertTrue(map.neighbourHasCharacter(new Point(2, 2), characters));
        assertTrue(map.neighbourHasCharacter(new Point(2, 4), characters));
        assertTrue(map.neighbourHasCharacter(new Point(1, 4), characters));

        // Case 2: One character on a neighbour field
        assertTrue(map.neighbourHasCharacter(new Point(4, 2), characters));
        assertTrue(map.neighbourHasCharacter(new Point(4, 4), characters));
        assertTrue(map.neighbourHasCharacter(new Point(2, 5), characters));

        // Case 3: No character on a neighbour field
        assertFalse(map.neighbourHasCharacter(new Point(3, 1), characters));
        assertFalse(map.neighbourHasCharacter(new Point(5, 3), characters));
        assertFalse(map.neighbourHasCharacter(new Point(6, 4), characters));
    }

    @Test
    public void testGetNeighbourCharacters() {
        // Setup
        setup();
        ArrayList<Character> expectedCharacters;
        ArrayList<Character> characters;

        // Case 1: No Character on neighbour fields
        assertTrue(map.getNeighbourCharacters(new Point(4, 3), this.characters).isEmpty());
        assertTrue(map.getNeighbourCharacters(new Point(0, 0), this.characters).isEmpty());
        assertTrue(map.getNeighbourCharacters(new Point(3, 1), this.characters).isEmpty());

        // Case 2: One character on neighbour fields
        characters = new ArrayList<>(map.getNeighbourCharacters(new Point(3, 3), this.characters));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(q);
        assertEquals(expectedCharacters.size(), characters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getNeighbourCharacters(new Point(2, 5), this.characters));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(m);
        assertEquals(expectedCharacters.size(), characters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getNeighbourCharacters(new Point(4, 1), this.characters));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(eve);
        assertEquals(expectedCharacters.size(), characters.size());
        assertTrue(expectedCharacters.containsAll(characters));

        // Case 3: More than one character on neighbour fields
        characters = new ArrayList<>(map.getNeighbourCharacters(new Point(3, 4), this.characters));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(q);
        expectedCharacters.add(drNo);
        assertEquals(expectedCharacters.size(), characters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getNeighbourCharacters(new Point(1, 4), this.characters));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(q);
        expectedCharacters.add(m);
        assertEquals(expectedCharacters.size(), characters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getNeighbourCharacters(new Point(2, 2), this.characters));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(jamesBond);
        expectedCharacters.add(q);
        assertEquals(expectedCharacters.size(), characters.size());
        assertTrue(expectedCharacters.containsAll(characters));
    }

    @Test
    public void testGetNeighbourCharacterCount() {
        // Setup
        setup();
        Character silva = new Character(UUID.randomUUID(), "Silva", new Point(2, 4), new HashSet<>(), new HashSet<>());
        Character kincade = new Character(UUID.randomUUID(), "Kincade", new Point(2, 5), new HashSet<>(), new HashSet<>());
        characters.add(silva);
        characters.add(kincade);

        // Case 1: More than one Character on a neighbour field
        assertEquals(4, map.getNeighbourCharacterCount(new Point(1, 4), characters));
        assertEquals(3, map.getNeighbourCharacterCount(new Point(1, 3), characters));
        assertEquals(2, map.getNeighbourCharacterCount(new Point(2, 2), characters));

        // Case 2: One character on a neighbour field
        assertEquals(1, map.getNeighbourCharacterCount(new Point(4, 2), characters));
        assertEquals(1, map.getNeighbourCharacterCount(new Point(4, 4), characters));
        assertEquals(1, map.getNeighbourCharacterCount(new Point(1, 1), characters));

        // Case 3: No character on a neighbour field
        assertEquals(0, map.getNeighbourCharacterCount(new Point(3, 1), characters));
        assertEquals(0, map.getNeighbourCharacterCount(new Point(5, 3), characters));
        assertEquals(0, map.getNeighbourCharacterCount(new Point(6, 4), characters));
    }

    @Test
    public void testCheckBabySitter() {
        // Setup
        setup();
        Character silva = new Character(UUID.randomUUID(), "Silva", new Point(3, 5), new HashSet<>(), new HashSet<>());
        Character kincade = new Character(UUID.randomUUID(), "Kincade", new Point(2, 4), new HashSet<>(), new HashSet<>());
        kincade.addProperty(PropertyEnum.BABYSITTER);
        silva.addProperty(PropertyEnum.BABYSITTER);
        characters.add(kincade);
        characters.add(silva);
        Set<Character> charactersPlayerOne = new HashSet<>();
        Set<Character> charactersPlayerTwo = new HashSet<>();
        charactersPlayerOne.add(jamesBond);
        charactersPlayerOne.add(q);
        charactersPlayerOne.add(m);
        charactersPlayerOne.add(kincade);
        charactersPlayerTwo.add(eve);
        charactersPlayerTwo.add(drNo);
        charactersPlayerTwo.add(silva);

        // Case 1: One character of the same faction with the property babysitter
        assertTrue(map.checkBabysitter(m, characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(map.checkBabysitter(q, characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(map.checkBabysitter(drNo, characters, charactersPlayerOne, charactersPlayerTwo));

        // Setup change
        m.addProperty(PropertyEnum.BABYSITTER);
        q.addProperty(PropertyEnum.BABYSITTER);
        jamesBond.addProperty(PropertyEnum.BABYSITTER);
        eve.setCoordinates(new Point(4, 4));
        eve.addProperty(PropertyEnum.BABYSITTER);

        // Case 2: More than one character of the same faction with the property babysitter
        assertTrue(map.checkBabysitter(q, characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(map.checkBabysitter(kincade, characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(map.checkBabysitter(drNo, characters, charactersPlayerOne, charactersPlayerTwo));

        // Setup change
        charactersPlayerOne = new HashSet<>();
        charactersPlayerTwo = new HashSet<>();
        charactersPlayerOne.add(q);
        charactersPlayerOne.add(m);
        charactersPlayerOne.add(silva);
        charactersPlayerOne.add(eve);
        charactersPlayerTwo.add(jamesBond);
        charactersPlayerTwo.add(kincade);
        charactersPlayerTwo.add(drNo);
        eve.removeProperty(PropertyEnum.BABYSITTER);
        q.addProperty(PropertyEnum.BABYSITTER);

        // Case 3: One character of the opposing faction with the property babysitter
        assertFalse(map.checkBabysitter(jamesBond, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(m, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(silva, characters, charactersPlayerOne, charactersPlayerTwo));

        // Case 4: More than one character of the opposing faction with the property babysitter
        assertFalse(map.checkBabysitter(q, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(kincade, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(drNo, characters, charactersPlayerOne, charactersPlayerTwo));

        // Setup change
        silva.removeProperty(PropertyEnum.BABYSITTER);
        kincade.removeProperty(PropertyEnum.BABYSITTER);
        m.removeProperty(PropertyEnum.BABYSITTER);
        jamesBond.removeProperty(PropertyEnum.BABYSITTER);
        q.removeProperty(PropertyEnum.BABYSITTER);
        eve.removeProperty(PropertyEnum.BABYSITTER);

        // Case 5: No character with the property babysitter
        assertFalse(map.checkBabysitter(jamesBond, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(silva, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(q, characters, charactersPlayerOne, charactersPlayerTwo));

        // Setup change
        eve.setCoordinates(new Point(5, 1));
        silva.setCoordinates(new Point(4, 3));

        // Case 6: No character on neighbour fields
        assertFalse(map.checkBabysitter(eve, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(drNo, characters, charactersPlayerOne, charactersPlayerTwo));
        assertFalse(map.checkBabysitter(silva, characters, charactersPlayerOne, charactersPlayerTwo));
    }

    @Test
    public void testGetBabysitters() {
        // Setup
        setup();
        ArrayList<Character> characters;
        ArrayList<Character> expectedCharacters;
        Character silva = new Character(UUID.randomUUID(), "Silva", new Point(3, 5), new HashSet<>(), new HashSet<>());
        Character kincade = new Character(UUID.randomUUID(), "Kincade", new Point(2, 4), new HashSet<>(), new HashSet<>());
        kincade.addProperty(PropertyEnum.BABYSITTER);
        silva.addProperty(PropertyEnum.BABYSITTER);
        this.characters.add(kincade);
        this.characters.add(silva);
        Set<Character> charactersPlayerOne = new HashSet<>();
        Set<Character> charactersPlayerTwo = new HashSet<>();
        charactersPlayerOne.add(jamesBond);
        charactersPlayerOne.add(q);
        charactersPlayerOne.add(m);
        charactersPlayerOne.add(kincade);
        charactersPlayerTwo.add(eve);
        charactersPlayerTwo.add(drNo);
        charactersPlayerTwo.add(silva);

        // Case 1: One character of the same faction with the property babysitter
        characters = new ArrayList<>(map.getBabysitters(m, this.characters, charactersPlayerOne, charactersPlayerTwo));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(kincade);
        assertEquals(characters.size(), expectedCharacters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getBabysitters(q, this.characters, charactersPlayerOne, charactersPlayerTwo));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(kincade);
        assertEquals(characters.size(), expectedCharacters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getBabysitters(drNo, this.characters, charactersPlayerOne, charactersPlayerTwo));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(silva);
        assertEquals(characters.size(), expectedCharacters.size());
        assertTrue(expectedCharacters.containsAll(characters));

        // Setup change
        m.addProperty(PropertyEnum.BABYSITTER);
        q.addProperty(PropertyEnum.BABYSITTER);
        jamesBond.addProperty(PropertyEnum.BABYSITTER);
        eve.setCoordinates(new Point(4, 4));
        eve.addProperty(PropertyEnum.BABYSITTER);

        // Case 2: More than one character of the same faction with the property babysitter
        characters = new ArrayList<>(map.getBabysitters(q, this.characters, charactersPlayerOne, charactersPlayerTwo));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(jamesBond);
        expectedCharacters.add(kincade);
        assertEquals(characters.size(), expectedCharacters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getBabysitters(kincade, this.characters, charactersPlayerOne, charactersPlayerTwo));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(q);
        expectedCharacters.add(m);
        assertEquals(characters.size(), expectedCharacters.size());
        assertTrue(expectedCharacters.containsAll(characters));
        characters = new ArrayList<>(map.getBabysitters(drNo, this.characters, charactersPlayerOne, charactersPlayerTwo));
        expectedCharacters = new ArrayList<>();
        expectedCharacters.add(eve);
        expectedCharacters.add(silva);
        assertEquals(characters.size(), expectedCharacters.size());
        assertTrue(expectedCharacters.containsAll(characters));

        // Setup change
        charactersPlayerOne = new HashSet<>();
        charactersPlayerTwo = new HashSet<>();
        charactersPlayerOne.add(q);
        charactersPlayerOne.add(m);
        charactersPlayerOne.add(silva);
        charactersPlayerOne.add(eve);
        charactersPlayerTwo.add(jamesBond);
        charactersPlayerTwo.add(kincade);
        charactersPlayerTwo.add(drNo);
        eve.removeProperty(PropertyEnum.BABYSITTER);
        q.addProperty(PropertyEnum.BABYSITTER);

        // Case 3: One character of the opposing faction with the property babysitter
        characters = new ArrayList<>(map.getBabysitters(jamesBond, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(m, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(silva, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());

        // Case 4: More than one character of the opposing faction with the property babysitter
        characters = new ArrayList<>(map.getBabysitters(q, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(kincade, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(drNo, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());

        // Setup change
        silva.removeProperty(PropertyEnum.BABYSITTER);
        kincade.removeProperty(PropertyEnum.BABYSITTER);
        m.removeProperty(PropertyEnum.BABYSITTER);
        jamesBond.removeProperty(PropertyEnum.BABYSITTER);
        q.removeProperty(PropertyEnum.BABYSITTER);
        eve.removeProperty(PropertyEnum.BABYSITTER);

        // Case 5: No character with the property babysitter
        characters = new ArrayList<>(map.getBabysitters(jamesBond, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(silva, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(q, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());

        // Setup change
        eve.setCoordinates(new Point(5, 1));
        silva.setCoordinates(new Point(4, 3));

        // Case 6: No character on neighbour fields
        characters = new ArrayList<>(map.getBabysitters(eve, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(drNo, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
        characters = new ArrayList<>(map.getBabysitters(silva, this.characters, charactersPlayerOne, charactersPlayerTwo));
        assertTrue(characters.isEmpty());
    }

    @Test
    public void testGetNeighboursOfState() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: Field in the middle of the map
        points = new ArrayList<>(map.getNeighboursOfState(new Point(2, 4), FieldStateEnum.FREE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(3, 5));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(1, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighboursOfState(new Point(3, 1), FieldStateEnum.WALL));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 0));
        expectedPoints.add(new Point(3, 0));
        expectedPoints.add(new Point(4, 0));
        expectedPoints.add(new Point(2, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighboursOfState(new Point(4, 5), FieldStateEnum.SAFE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: Field at an edge of the map
        points = new ArrayList<>(map.getNeighboursOfState(new Point(6, 2), FieldStateEnum.FREE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 1));
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(5, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighboursOfState(new Point(4, 0), FieldStateEnum.WALL));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 0));
        expectedPoints.add(new Point(5, 0));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighboursOfState(new Point(0, 2), FieldStateEnum.BAR_TABLE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: Field in a corner of the map
        points = new ArrayList<>(map.getNeighboursOfState(new Point(0, 6), FieldStateEnum.FREE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighboursOfState(new Point(6, 0), FieldStateEnum.WALL));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 0));
        expectedPoints.add(new Point(6, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getNeighboursOfState(new Point(0, 0), FieldStateEnum.FIREPLACE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 4: Field with no neighbours of that state
        points = new ArrayList<>(map.getNeighboursOfState(new Point(2, 0), FieldStateEnum.FREE));
        assertTrue(points.isEmpty());
        points = new ArrayList<>(map.getNeighboursOfState(new Point(4, 3), FieldStateEnum.BAR_SEAT));
        assertTrue(points.isEmpty());
        points = new ArrayList<>(map.getNeighboursOfState(new Point(5, 1), FieldStateEnum.ROULETTE_TABLE));
        assertTrue(points.isEmpty());
    }

    @Test
    public void testHasNeighboursOfState() {
        // Setup
        setup();

        // Case 1: Field has more than one neighbour of that state
        assertTrue(map.hasNeighboursOfState(new Point(3, 3), FieldStateEnum.FREE));
        assertTrue(map.hasNeighboursOfState(new Point(5, 1), FieldStateEnum.WALL));
        assertTrue(map.hasNeighboursOfState(new Point(2, 2), FieldStateEnum.BAR_TABLE));

        // Case 2: Field has one neighbour of that state
        assertTrue(map.hasNeighboursOfState(new Point(0, 2), FieldStateEnum.FREE));
        assertTrue(map.hasNeighboursOfState(new Point(2, 2), FieldStateEnum.ROULETTE_TABLE));
        assertTrue(map.hasNeighboursOfState(new Point(4, 4), FieldStateEnum.SAFE));

        // Case 3: Field has no neighbour of that state
        assertFalse(map.hasNeighboursOfState(new Point(6, 6), FieldStateEnum.FREE));
        assertFalse(map.hasNeighboursOfState(new Point(2, 5), FieldStateEnum.SAFE));
        assertFalse(map.hasNeighboursOfState(new Point(5, 3), FieldStateEnum.BAR_SEAT));
    }

    @Test
    public void testGetRandomFreeNeighbour() {
        // Setup
        setup();
        ArrayList<Point> expectedPoints;
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(1, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(4, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));

        // Case 1: Random free neighbour fields
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(4, 3));
        assertTrue(expectedPoints.contains(map.getRandomFreeNeighbour(new Point(3, 4), characters)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(4, 3));
        assertTrue(expectedPoints.contains(map.getRandomFreeNeighbour(new Point(5, 3), characters)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(3, 2));
        assertTrue(expectedPoints.contains(map.getRandomFreeNeighbour(new Point(1, 1), characters)));

        // Case 2: One free neighbour field
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 2));
        assertTrue(expectedPoints.contains(map.getRandomFreeNeighbour(new Point(2, 2), characters)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        assertTrue(expectedPoints.contains(map.getRandomFreeNeighbour(new Point(6, 5), characters)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 2));
        assertTrue(expectedPoints.contains(map.getRandomFreeNeighbour(new Point(6, 1), characters)));

        // Case 3: No free neighbour field
        assertNull(map.getRandomFreeNeighbour(new Point(0, 3), characters));
        assertNull(map.getRandomFreeNeighbour(new Point(5, 6), characters));
        assertNull(map.getRandomFreeNeighbour(new Point(6, 0), characters));
    }

    @Test
    public void testGetNeighboursWithGadget() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(1, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(3, 1)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(4, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        map.getField(new Point(5, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));

        // Case 1: More than one neighbour field with a gadget
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(4, 4));
        points = new ArrayList<>(map.getNeighboursWithGadget(new Point(4, 3)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(4, 2));
        points = new ArrayList<>(map.getNeighboursWithGadget(new Point(3, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(3, 5));
        points = new ArrayList<>(map.getNeighboursWithGadget(new Point(3, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One neighbour field with a gadget
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 3));
        points = new ArrayList<>(map.getNeighboursWithGadget(new Point(1, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 2));
        points = new ArrayList<>(map.getNeighboursWithGadget(new Point(5, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 5));
        points = new ArrayList<>(map.getNeighboursWithGadget(new Point(3, 6)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: No neighbour field with a gadget
        assertTrue(map.getNeighboursWithGadget(new Point(0, 0)).isEmpty());
        assertTrue(map.getNeighboursWithGadget(new Point(1, 5)).isEmpty());
        assertTrue(map.getNeighboursWithGadget(new Point(1, 1)).isEmpty());
    }

    @Test
    public void testGetNeighboursWithGadgetOfType() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(1, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(3, 1)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(4, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        map.getField(new Point(5, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));

        // Case 1: More than one neighbour field a gadget of the right type
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(4, 4));
        points = new ArrayList<>(map.getNeighboursWithGadgetOfType(new Point(4, 3), GadgetEnum.DIAMOND_COLLAR));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(1, 3));
        points = new ArrayList<>(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.COCKTAIL));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        points = new ArrayList<>(map.getNeighboursWithGadgetOfType(new Point(4, 5), GadgetEnum.DIAMOND_COLLAR));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One neighbour field with a gadget of the right type
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 3));
        points = new ArrayList<>(map.getNeighboursWithGadgetOfType(new Point(1, 4), GadgetEnum.COCKTAIL));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 2));
        points = new ArrayList<>(map.getNeighboursWithGadgetOfType(new Point(5, 3), GadgetEnum.BOWLER_BLADE));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        points = new ArrayList<>(map.getNeighboursWithGadgetOfType(new Point(3, 4), GadgetEnum.DIAMOND_COLLAR));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: No neighbour field with the a gadget of the right type
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(4, 5), GadgetEnum.COCKTAIL).isEmpty());
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(1, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 5), GadgetEnum.DIAMOND_COLLAR).isEmpty());

        // Case 4: No neighbour field with a gadget
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(0, 0), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(1, 5), GadgetEnum.COCKTAIL).isEmpty());
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(1, 1), GadgetEnum.DIAMOND_COLLAR).isEmpty());
    }

    @Test
    public void testGetDestroyedNeighbours() {
        // Setup
        setup();
        map.getField(new Point(4, 3)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        map.getField(new Point(3, 3)).setDestroyed(true);
        map.getField(new Point(4, 3)).setDestroyed(true);
        ArrayList<Point> expectedPoints;
        ArrayList<Point> points;

        // Case 1: More than one destroyed neighbour roulette table
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getDestroyedNeighbours(new Point(3, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getDestroyedNeighbours(new Point(4, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getDestroyedNeighbours(new Point(4, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One destroyed neighbour roulette table
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        points = new ArrayList<>(map.getDestroyedNeighbours(new Point(2, 3)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        points = new ArrayList<>(map.getDestroyedNeighbours(new Point(2, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getDestroyedNeighbours(new Point(5, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(3, 3)).setDestroyed(false);
        map.getField(new Point(4, 3)).setDestroyed(false);

        // Case 3: No destroyed neighbour roulette table
        assertTrue(map.getDestroyedNeighbours(new Point(4, 3)).isEmpty());
        assertTrue(map.getDestroyedNeighbours(new Point(2, 2)).isEmpty());
        assertTrue(map.getDestroyedNeighbours(new Point(4, 1)).isEmpty());

        // Case 4: No neighbour roulette table field
        assertTrue(map.getDestroyedNeighbours(new Point(1, 1)).isEmpty());
        assertTrue(map.getDestroyedNeighbours(new Point(6, 3)).isEmpty());
        assertTrue(map.getDestroyedNeighbours(new Point(1, 5)).isEmpty());
    }

    @Test
    public void testGetInvertedNeighbours() {
        // Setup
        setup();
        map.getField(new Point(4, 3)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        map.getField(new Point(3, 3)).setInverted(true);
        map.getField(new Point(4, 3)).setInverted(true);
        ArrayList<Point> expectedPoints;
        ArrayList<Point> points;

        // Case 1: More than one inverted neighbour roulette table
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getInvertedNeighbours(new Point(3, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getInvertedNeighbours(new Point(4, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getInvertedNeighbours(new Point(4, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One inverted neighbour roulette table
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        points = new ArrayList<>(map.getInvertedNeighbours(new Point(2, 3)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        points = new ArrayList<>(map.getInvertedNeighbours(new Point(2, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 3));
        points = new ArrayList<>(map.getInvertedNeighbours(new Point(5, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(3, 3)).setInverted(false);
        map.getField(new Point(4, 3)).setInverted(false);

        // Case 3: No inverted neighbour roulette table
        assertTrue(map.getInvertedNeighbours(new Point(4, 3)).isEmpty());
        assertTrue(map.getInvertedNeighbours(new Point(2, 2)).isEmpty());
        assertTrue(map.getInvertedNeighbours(new Point(4, 1)).isEmpty());

        // Case 4: No neighbour roulette table
        assertTrue(map.getInvertedNeighbours(new Point(1, 1)).isEmpty());
        assertTrue(map.getInvertedNeighbours(new Point(6, 3)).isEmpty());
        assertTrue(map.getInvertedNeighbours(new Point(1, 5)).isEmpty());
    }

    @Test
    public void testGetNeighboursWithSafeIndex() {
        // Setup
        setup();
        map.getField(new Point(4, 4)).updateFieldState(FieldStateEnum.SAFE);
        map.getField(new Point(1, 1)).updateFieldState(FieldStateEnum.SAFE);
        map.getField(new Point(5, 5)).setSafeIndex(1);
        map.getField(new Point(4, 4)).setSafeIndex(2);
        map.getField(new Point(1, 1)).setSafeIndex(3);
        ArrayList<Point> expectedPoints;
        ArrayList<Point> points;

        // Case 1: Neighbour field with the right safe index
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 1));
        points = new ArrayList<>(map.getNeighboursWithSafeIndex(new Point(1, 2), 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        points = new ArrayList<>(map.getNeighboursWithSafeIndex(new Point(3, 5), 2));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 5));
        points = new ArrayList<>(map.getNeighboursWithSafeIndex(new Point(5, 4), 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: No Neighbour field with the right safe index
        assertTrue(map.getNeighboursWithSafeIndex(new Point(4, 5), 3).isEmpty());
        assertTrue(map.getNeighboursWithSafeIndex(new Point(2, 2), 2).isEmpty());
        assertTrue(map.getNeighboursWithSafeIndex(new Point(1, 2), 1).isEmpty());

        // Case 3: No neighbour field with a safe
        assertTrue(map.getNeighboursWithSafeIndex(new Point(2, 4), 1).isEmpty());
        assertTrue(map.getNeighboursWithSafeIndex(new Point(3, 2), 1).isEmpty());
        assertTrue(map.getNeighboursWithSafeIndex(new Point(6, 0), 3).isEmpty());
    }

    @Test
    public void testGetFoggyNeighbours() {
        // Setup
        setup();
        map.getField(new Point(2, 5)).setFoggy(true);
        map.getField(new Point(5, 2)).setFoggy(true);
        map.getField(new Point(2, 3)).setFoggy(true);
        ArrayList<Point> expectedPoints;
        ArrayList<Point> points;

        // Case 1: More than one foggy neighbour field
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(2, 5));
        points = new ArrayList<>(map.getFoggyNeighbours(new Point(2, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(2, 5));
        points = new ArrayList<>(map.getFoggyNeighbours(new Point(1, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(2, 5));
        points = new ArrayList<>(map.getFoggyNeighbours(new Point(3, 4)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One foggy neighbour field
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 3));
        points = new ArrayList<>(map.getFoggyNeighbours(new Point(1, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 2));
        points = new ArrayList<>(map.getFoggyNeighbours(new Point(4, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 5));
        points = new ArrayList<>(map.getFoggyNeighbours(new Point(3, 6)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: No foggy neighbour field
        assertTrue(map.getFoggyNeighbours(new Point(4, 4)).isEmpty());
        assertTrue(map.getFoggyNeighbours(new Point(2, 1)).isEmpty());
        assertTrue(map.getFoggyNeighbours(new Point(6, 5)).isEmpty());
    }

    @Test
    public void testGetAccessibleNeighbours() {
        // Setup
        setup();
        ArrayList<Point> expectedPoints;
        ArrayList<Point> points;

        // Case 1: More than one accessible neighbour field
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(2, 3));
        points = new ArrayList<>(map.getAccessibleNeighbours(new Point(1, 2)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(3, 5));
        points = new ArrayList<>(map.getAccessibleNeighbours(new Point(4, 5)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(2, 4));
        points = new ArrayList<>(map.getAccessibleNeighbours(new Point(2, 3)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One accessible neighbour field
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 2));
        points = new ArrayList<>(map.getAccessibleNeighbours(new Point(0, 1)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 5));
        points = new ArrayList<>(map.getAccessibleNeighbours(new Point(0, 6)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 5));
        points = new ArrayList<>(map.getAccessibleNeighbours(new Point(5, 6)));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: No accessible neighbour field
        assertTrue(map.getAccessibleNeighbours(new Point(0, 0)).isEmpty());
        assertTrue(map.getAccessibleNeighbours(new Point(2, 0)).isEmpty());
        assertTrue(map.getAccessibleNeighbours(new Point(6, 6)).isEmpty());
    }

    @Test
    public void testGetFields() {
        // Setup
        setup();
        ArrayList<Field> fields;
        ArrayList<Field> expectedFields;
        Set<Point> points;

        // Case 1: Coordinates of one field
        points = new HashSet<>();
        points.add(new Point(0, 0));
        fields = new ArrayList<>(map.getFields(points));
        expectedFields = new ArrayList<>();
        expectedFields.add(map.getField(new Point(0, 0)));
        assertEquals(expectedFields.size(), fields.size());
        assertTrue(fields.containsAll(expectedFields));
        points = new HashSet<>();
        points.add(new Point(2, 6));
        fields = new ArrayList<>(map.getFields(points));
        expectedFields = new ArrayList<>();
        expectedFields.add(map.getField(new Point(2, 6)));
        assertEquals(expectedFields.size(), fields.size());
        assertTrue(fields.containsAll(expectedFields));
        points = new HashSet<>();
        points.add(new Point(5, 1));
        fields = new ArrayList<>(map.getFields(points));
        expectedFields = new ArrayList<>();
        expectedFields.add(map.getField(new Point(5, 1)));
        assertEquals(expectedFields.size(), fields.size());
        assertTrue(fields.containsAll(expectedFields));

        // Case 2: Coordinates of more than one field
        points = new HashSet<>();
        points.add(new Point(0, 0));
        points.add(new Point(3, 5));
        points.add(new Point(6, 2));
        fields = new ArrayList<>(map.getFields(points));
        expectedFields = new ArrayList<>();
        expectedFields.add(map.getField(new Point(0, 0)));
        expectedFields.add(map.getField(new Point(3, 5)));
        expectedFields.add(map.getField(new Point(6, 2)));
        assertEquals(expectedFields.size(), fields.size());
        assertTrue(fields.containsAll(expectedFields));
        points = new HashSet<>();
        points.add(new Point(2, 6));
        points.add(new Point(1, 4));
        points.add(new Point(3, 2));
        points.add(new Point(5, 5));
        points.add(new Point(3, 4));
        fields = new ArrayList<>(map.getFields(points));
        expectedFields = new ArrayList<>();
        expectedFields.add(map.getField(new Point(2, 6)));
        expectedFields.add(map.getField(new Point(1, 4)));
        expectedFields.add(map.getField(new Point(3, 2)));
        expectedFields.add(map.getField(new Point(5, 5)));
        expectedFields.add(map.getField(new Point(3, 4)));
        assertEquals(expectedFields.size(), fields.size());
        assertTrue(fields.containsAll(expectedFields));
        points = new HashSet<>();
        points.add(new Point(5, 1));
        points.add(new Point(2, 3));
        points.add(new Point(1, 5));
        points.add(new Point(4, 2));
        points.add(new Point(2, 5));
        points.add(new Point(2, 6));
        points.add(new Point(4, 3));
        points.add(new Point(5, 2));
        points.add(new Point(3, 4));
        points.add(new Point(6, 2));
        fields = new ArrayList<>(map.getFields(points));
        expectedFields = new ArrayList<>();
        expectedFields.add(map.getField(new Point(5, 1)));
        expectedFields.add(map.getField(new Point(2, 3)));
        expectedFields.add(map.getField(new Point(1, 5)));
        expectedFields.add(map.getField(new Point(4, 2)));
        expectedFields.add(map.getField(new Point(2, 5)));
        expectedFields.add(map.getField(new Point(2, 6)));
        expectedFields.add(map.getField(new Point(4, 3)));
        expectedFields.add(map.getField(new Point(5, 2)));
        expectedFields.add(map.getField(new Point(3, 4)));
        expectedFields.add(map.getField(new Point(6, 2)));
        assertEquals(expectedFields.size(), fields.size());
        assertTrue(fields.containsAll(expectedFields));
    }

    @Test
    public void testGetPointsOfMap() {
        // Setup
        setup();
        FieldMap map = this.map;
        Field[][] mapFields;
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: Big map (7x7)
        points = new ArrayList<>(map.getPointsOfMap());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(0, 0));
        expectedPoints.add(new Point(1, 0));
        expectedPoints.add(new Point(2, 0));
        expectedPoints.add(new Point(3, 0));
        expectedPoints.add(new Point(4, 0));
        expectedPoints.add(new Point(5, 0));
        expectedPoints.add(new Point(6, 0));
        expectedPoints.add(new Point(0, 1));
        expectedPoints.add(new Point(1, 1));
        expectedPoints.add(new Point(2, 1));
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(5, 1));
        expectedPoints.add(new Point(6, 1));
        expectedPoints.add(new Point(0, 2));
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(6, 2));
        expectedPoints.add(new Point(0, 3));
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(4, 3));
        expectedPoints.add(new Point(5, 3));
        expectedPoints.add(new Point(6, 3));
        expectedPoints.add(new Point(0, 4));
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(3, 4));
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(6, 4));
        expectedPoints.add(new Point(0, 5));
        expectedPoints.add(new Point(1, 5));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(3, 5));
        expectedPoints.add(new Point(4, 5));
        expectedPoints.add(new Point(5, 5));
        expectedPoints.add(new Point(6, 5));
        expectedPoints.add(new Point(0, 6));
        expectedPoints.add(new Point(1, 6));
        expectedPoints.add(new Point(2, 6));
        expectedPoints.add(new Point(3, 6));
        expectedPoints.add(new Point(4, 6));
        expectedPoints.add(new Point(5, 6));
        expectedPoints.add(new Point(6, 6));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        mapFields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.BAR_TABLE)},
                {new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.BAR_SEAT)}};
        map = new FieldMap(mapFields);

        // Case 2: Small map (3x2)
        points = new ArrayList<>(map.getPointsOfMap());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(0, 0));
        expectedPoints.add(new Point(1, 0));
        expectedPoints.add(new Point(2, 0));
        expectedPoints.add(new Point(0, 1));
        expectedPoints.add(new Point(1, 1));
        expectedPoints.add(new Point(2, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        mapFields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE)},
                {new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE)},
                {new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE)},
                {new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.FREE)}};
        map = new FieldMap(mapFields);

        // Case 3: L-shaped map
        points = new ArrayList<>(map.getPointsOfMap());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(0, 0));
        expectedPoints.add(new Point(1, 0));
        expectedPoints.add(new Point(2, 0));
        expectedPoints.add(new Point(3, 0));
        expectedPoints.add(new Point(0, 1));
        expectedPoints.add(new Point(1, 1));
        expectedPoints.add(new Point(2, 1));
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(0, 2));
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(0, 3));
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(0, 4));
        expectedPoints.add(new Point(1, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
    }

    @Test
    public void testGetFieldsOfState() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one field of the right state on the map
        points = new ArrayList<>(map.getFieldsOfState(FieldStateEnum.FREE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 1));
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(4, 3));
        expectedPoints.add(new Point(5, 3));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(1, 5));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(3, 5));
        expectedPoints.add(new Point(4, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsOfState(FieldStateEnum.WALL));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(0, 0));
        expectedPoints.add(new Point(1, 0));
        expectedPoints.add(new Point(2, 0));
        expectedPoints.add(new Point(3, 0));
        expectedPoints.add(new Point(4, 0));
        expectedPoints.add(new Point(5, 0));
        expectedPoints.add(new Point(6, 0));
        expectedPoints.add(new Point(0, 1));
        expectedPoints.add(new Point(2, 1));
        expectedPoints.add(new Point(6, 1));
        expectedPoints.add(new Point(0, 2));
        expectedPoints.add(new Point(6, 2));
        expectedPoints.add(new Point(0, 3));
        expectedPoints.add(new Point(6, 3));
        expectedPoints.add(new Point(0, 4));
        expectedPoints.add(new Point(3, 4));
        expectedPoints.add(new Point(6, 4));
        expectedPoints.add(new Point(0, 5));
        expectedPoints.add(new Point(6, 5));
        expectedPoints.add(new Point(0, 6));
        expectedPoints.add(new Point(1, 6));
        expectedPoints.add(new Point(2, 6));
        expectedPoints.add(new Point(3, 6));
        expectedPoints.add(new Point(4, 6));
        expectedPoints.add(new Point(5, 6));
        expectedPoints.add(new Point(6, 6));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsOfState(FieldStateEnum.BAR_TABLE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(1, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One field of the right state on the map
        points = new ArrayList<>(map.getFieldsOfState(FieldStateEnum.SAFE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsOfState(FieldStateEnum.ROULETTE_TABLE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsOfState(FieldStateEnum.FIREPLACE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(1, 1)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(3, 3)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(5, 5)).updateFieldState(FieldStateEnum.FREE);

        // Case 3: No field of the right state on the map
        assertTrue(map.getFieldsOfState(FieldStateEnum.SAFE).isEmpty());
        assertTrue(map.getFieldsOfState(FieldStateEnum.ROULETTE_TABLE).isEmpty());
        assertTrue(map.getFieldsOfState(FieldStateEnum.FIREPLACE).isEmpty());
    }

    @Test
    public void testGetFieldsWithGadgets() {
        // Setup
        setup();
        map.getField(new Point(2, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(2, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(3, 1)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(1, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(5, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));

        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one gadget on the map
        points = new ArrayList<>(map.getFieldsWithGadgets());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(5, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(2, 2)).setGadget(null);
        map.getField(new Point(2, 5)).setGadget(null);
        map.getField(new Point(4, 2)).setGadget(null);
        map.getField(new Point(1, 3)).setGadget(null);
        map.getField(new Point(5, 4)).setGadget(null);

        // Case 2: One gadget on the map
        points = new ArrayList<>(map.getFieldsWithGadgets());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(3, 1)).setGadget(null);

        // Case 3: No gadget on the map
        assertTrue(map.getFieldsWithGadgets().isEmpty());
    }

    @Test
    public void testGetFieldsWithGadgetsOfType() {
        // Setup
        setup();
        map.getField(new Point(2, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(2, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(5, 2)).setGadget(new Gadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        map.getField(new Point(3, 1)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(1, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));
        map.getField(new Point(5, 4)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        map.getField(new Point(4, 4)).setGadget(new Gadget(GadgetEnum.ROCKET_PEN));
        map.getField(new Point(3, 2)).setGadget(new Gadget(GadgetEnum.TECHNICOLOUR_PRISM));
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one field with a gadget of the right type on the map
        points = new ArrayList<>(map.getFieldsWithGadgetOfType(GadgetEnum.BOWLER_BLADE));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(4, 2));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsWithGadgetOfType(GadgetEnum.COCKTAIL));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(1, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsWithGadgetOfType(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(3, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 2: One field with a gadget of the right type on the map
        points = new ArrayList<>(map.getFieldsWithGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsWithGadgetOfType(GadgetEnum.ROCKET_PEN));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getFieldsWithGadgetOfType(GadgetEnum.TECHNICOLOUR_PRISM));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 2));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: No field with a gadget of the right type on the map
        assertTrue(map.getFieldsWithGadgetOfType(GadgetEnum.POCKET_LITTER).isEmpty());
        assertTrue(map.getFieldsWithGadgetOfType(GadgetEnum.FOG_TIN).isEmpty());
        assertTrue(map.getFieldsWithGadgetOfType(GadgetEnum.GAS_GLOSS).isEmpty());

        // Setup change
        map.getField(new Point(2, 2)).setGadget(null);
        map.getField(new Point(2, 5)).setGadget(null);
        map.getField(new Point(4, 2)).setGadget(null);
        map.getField(new Point(5, 2)).setGadget(null);
        map.getField(new Point(3, 5)).setGadget(null);
        map.getField(new Point(3, 1)).setGadget(null);
        map.getField(new Point(1, 3)).setGadget(null);
        map.getField(new Point(5, 4)).setGadget(null);
        map.getField(new Point(4, 4)).setGadget(null);
        map.getField(new Point(3, 2)).setGadget(null);

        // Case 4: No field with a gadget on the map
        assertTrue(map.getFieldsWithGadgetOfType(GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(map.getFieldsWithGadgetOfType(GadgetEnum.COCKTAIL).isEmpty());
        assertTrue(map.getFieldsWithGadgetOfType(GadgetEnum.DIAMOND_COLLAR).isEmpty());
    }

    @Test
    public void testGetDestroyedFields() {
        // Setup
        setup();
        map.getField(new Point(5, 4)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        map.getField(new Point(2, 2)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        map.getField(new Point(5, 4)).setDestroyed(true);
        map.getField(new Point(2, 2)).setDestroyed(true);
        map.getField(new Point(3, 3)).setDestroyed(true);
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one destroyed roulette table on the map
        points = new ArrayList<>(map.getDestroyedFields());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(3, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(2, 2)).setDestroyed(false);
        map.getField(new Point(3, 3)).setDestroyed(false);

        // Case 2: One destroyed roulette table on the map
        points = new ArrayList<>(map.getDestroyedFields());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(5, 4)).setDestroyed(false);

        // Case 3: No destroyed roulette table on the map
        assertTrue(map.getDestroyedFields().isEmpty());

        // Setup change
        map.getField(new Point(5, 4)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(2, 2)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(3, 3)).updateFieldState(FieldStateEnum.FREE);

        // Case 4: No roulette table on the map
        assertTrue(map.getDestroyedFields().isEmpty());
    }

    @Test
    public void testGetInvertedFields() {
        // Setup
        setup();
        map.getField(new Point(5, 4)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        map.getField(new Point(2, 2)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        map.getField(new Point(5, 4)).setInverted(true);
        map.getField(new Point(2, 2)).setInverted(true);
        map.getField(new Point(3, 3)).setInverted(true);
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one inverted roulette table on the map
        points = new ArrayList<>(map.getInvertedFields());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(3, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(2, 2)).setInverted(false);
        map.getField(new Point(3, 3)).setInverted(false);

        // Case 2: One inverted roulette table on the map
        points = new ArrayList<>(map.getInvertedFields());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 4));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(5, 4)).setInverted(false);

        // Case 3: No inverted roulette table on the map
        assertTrue(map.getInvertedFields().isEmpty());

        // Setup change
        map.getField(new Point(5, 4)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(2, 2)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(3, 3)).updateFieldState(FieldStateEnum.FREE);

        // Case 4: No roulette table on the map
        assertTrue(map.getDestroyedFields().isEmpty());
    }

    @Test
    public void testGetFoggyFields() {
        // Setup
        setup();
        map.getField(new Point(5, 2)).setFoggy(true);
        map.getField(new Point(2, 3)).setFoggy(true);
        map.getField(new Point(2, 5)).setFoggy(true);
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one foggy field on the map
        points = new ArrayList<>(map.getFoggyFields());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(2, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(5, 2)).setFoggy(false);
        map.getField(new Point(2, 3)).setFoggy(false);

        // Case 2: One foggy field on the map
        points = new ArrayList<>(map.getFoggyFields());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        map.getField(new Point(2, 5)).setFoggy(false);


        // Case 3: No foggy field on the map
        assertTrue(map.getFoggyFields().isEmpty());
    }

    @Test
    public void testGetFreeFields() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: More than one free field on the map
        points = new ArrayList<>(map.getFreeFields(characters));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(2, 2));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(4, 3));
        expectedPoints.add(new Point(5, 3));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(3, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        characters.add(new Character(UUID.randomUUID(), "character22", new Point(2, 2), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character32", new Point(3, 2), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character42", new Point(4, 2), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character52", new Point(5, 2), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character53", new Point(5, 3), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character24", new Point(2, 4), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character44", new Point(4, 4), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character54", new Point(5, 4), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character25", new Point(2, 5), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "character35", new Point(3, 5), new HashSet<>(), new HashSet<>()));

        // Case 2: One free field on the map
        points = new ArrayList<>(map.getFreeFields(characters));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Setup change
        characters.add(new Character(UUID.randomUUID(), "character43", new Point(4, 3), new HashSet<>(), new HashSet<>()));

        // Case 3: No free field on the map
        assertTrue(map.getFreeFields(characters).isEmpty());
    }

    @Test
    public void testIsMapUpdated() {
        // Setup
        setup();
        map.getField(new Point(2, 3)).setUpdated(true);
        map.getField(new Point(5, 1)).setUpdated(true);

        // Case 1: More than one field got updated
        assertTrue(map.isMapUpdated());

        // Setup change
        map.getField(new Point(2, 3)).setUpdated(false);

        // Case 2: One field got updated
        assertTrue(map.isMapUpdated());

        // Setup change
        map.getField(new Point(5, 1)).setUpdated(false);

        // Case 3: No field got updated
        assertFalse(map.isMapUpdated());
    }

    @Test
    public void testGetPointsInBetween() {
        // Setup
        setup();
        ArrayList<Point> points;
        ArrayList<Point> expectedPoints;

        // Case 1: Neighbour field
        assertTrue(map.getPointsInBetween(new Point(0, 0), new Point(1, 0)).isEmpty());
        assertTrue(map.getPointsInBetween(new Point(5, 3), new Point(5, 2)).isEmpty());
        assertTrue(map.getPointsInBetween(new Point(2, 4), new Point(1, 4)).isEmpty());

        // Case 2: Diagonal line of sight
        points = new ArrayList<>(map.getPointsInBetween(new Point(0, 0), new Point(2, 2)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(0, 1));
        expectedPoints.add(new Point(1, 0));
        expectedPoints.add(new Point(1, 1));
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(2, 1));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getPointsInBetween(new Point(4, 3), new Point(5, 4)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 3));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getPointsInBetween(new Point(4, 5), new Point(1, 2)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 5));
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(3, 4));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(2, 2));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));

        // Case 3: Non-diagonal line of sight
        points = new ArrayList<>(map.getPointsInBetween(new Point(2, 1), new Point(4, 2)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(3, 2));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getPointsInBetween(new Point(5, 2), new Point(0, 0)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(3, 1));
        expectedPoints.add(new Point(2, 1));
        expectedPoints.add(new Point(1, 1));
        expectedPoints.add(new Point(1, 0));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
        points = new ArrayList<>(map.getPointsInBetween(new Point(0, 2), new Point(6, 5)));
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 2));
        expectedPoints.add(new Point(1, 3));
        expectedPoints.add(new Point(2, 3));
        expectedPoints.add(new Point(3, 3));
        expectedPoints.add(new Point(3, 4));
        expectedPoints.add(new Point(4, 4));
        expectedPoints.add(new Point(5, 4));
        expectedPoints.add(new Point(5, 5));
        assertEquals(expectedPoints.size(), points.size());
        assertTrue(points.containsAll(expectedPoints));
    }

    @Test
    public void testGetRange() {
        // Setup
        setup();

        // Case 1: Get the right range
        assertEquals(1, map.getRange(new Point(1, 2), new Point(2, 2)));
        assertEquals(3, map.getRange(new Point(2, 3), new Point(5, 2)));
        assertEquals(5, map.getRange(new Point(5, 5), new Point(0, 1)));
    }

    @Test
    public void testIsInSight() {
        // Setup
        setup();
        map.getField(new Point(2, 5)).setFoggy(true);
        map.getField(new Point(5, 2)).setFoggy(true);
        map.getField(new Point(2, 3)).setFoggy(true);

        // Case 1: Target in sight
        assertTrue(map.isInSight(new Point(1, 2), new Point(2, 2)));
        assertTrue(map.isInSight(new Point(2, 3), new Point(5, 2)));
        assertTrue(map.isInSight(new Point(5, 1), new Point(2, 3)));

        // Case 2: Target not in sight without foggy fields
        assertFalse(map.isInSight(new Point(1, 2), new Point(6, 0)));
        assertFalse(map.isInSight(new Point(4, 5), new Point(2, 4)));
        assertFalse(map.isInSight(new Point(5, 1), new Point(1, 1)));

        // Case 3: Target not in sight with foggy fields
        assertFalse(map.isInSight(new Point(1, 5), new Point(4, 5)));
        assertFalse(map.isInSight(new Point(3, 2), new Point(1, 6)));
        assertFalse(map.isInSight(new Point(5, 1), new Point(5, 3)));
    }

    @Test
    public void testIsInRange() {
        // Setup
        setup();

        // Case 1: Target in range
        assertTrue(map.isInRange(new Point(1, 2), new Point(2, 2), 1));
        assertTrue(map.isInRange(new Point(2, 3), new Point(5, 2), 3));
        assertTrue(map.isInRange(new Point(5, 5), new Point(0, 1), 5));

        // Case 2: Target not in range
        assertFalse(map.isInRange(new Point(1, 2), new Point(6, 1), 4));
        assertFalse(map.isInRange(new Point(4, 5), new Point(1, 4), 2));
        assertFalse(map.isInRange(new Point(5, 1), new Point(3, 5), 3));
    }

    @Test
    public void testIsBlocked() {
        // Setup
        setup();

        // Case 1: Target blocked with one character
        assertTrue(map.isBlocked(new Point(4, 5), new Point(5, 0), characters));
        assertTrue(map.isBlocked(new Point(5, 1), new Point(0, 2), characters));
        assertTrue(map.isBlocked(new Point(2, 3), new Point(1, 1), characters));

        // Case 2: Target blocked with more than one character
        assertTrue(map.isBlocked(new Point(4, 5), new Point(0, 1), characters));
        assertTrue(map.isBlocked(new Point(2, 2), new Point(1, 3), characters));
        assertTrue(map.isBlocked(new Point(3, 1), new Point(0, 6), characters));

        // Case 3: Target not blocked
        assertFalse(map.isBlocked(new Point(1, 2), new Point(3, 2), characters));
        assertFalse(map.isBlocked(new Point(4, 5), new Point(1, 5), characters));
        assertFalse(map.isBlocked(new Point(1, 5), new Point(4, 6), characters));
    }

    @Test
    public void testGetRandomPoint() {
        // Setup
        setup();
        Set<Point> points = new HashSet<>();
        points.add(new Point(1, 2));
        points.add(new Point(4, 5));
        points.add(new Point(2, 3));
        points.add(new Point(1, 5));
        points.add(new Point(5, 1));
        Set<Point> expectedPoints = points;

        // Case 1: Random Point
        assertTrue(expectedPoints.contains(map.getRandomPoint(points)));
        assertTrue(expectedPoints.contains(map.getRandomPoint(points)));
        assertTrue(expectedPoints.contains(map.getRandomPoint(points)));

        // Setup change
        points = new HashSet<>();
        points.add(new Point(5, 3));
        Point expectedPoint = new Point(5, 3);

        // Case 2: One Point
        assertEquals(expectedPoint, map.getRandomPoint(points));
        assertEquals(expectedPoint, map.getRandomPoint(points));
        assertEquals(expectedPoint, map.getRandomPoint(points));
    }

    @Test
    public void testFillBarTables() {
        // Setup
        setup();
        map.getField(new Point(4, 4)).updateFieldState(FieldStateEnum.BAR_TABLE);

        // Case 1: Every bar table is empty
        assertFalse(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertFalse(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertFalse(map.getField(new Point(4, 4)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        map.fillBarTables();
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(4, 4)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Setup change
        map.getField(new Point(1, 3)).setGadget(null);

        // Case 2: One or more bar tables are empty
        assertFalse(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(4, 4)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        map.fillBarTables();
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(4, 4)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 3: No bar table is empty
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(4, 4)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        map.fillBarTables();
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(4, 4)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Setup change
        map.getField(new Point(3, 1)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(1, 3)).updateFieldState(FieldStateEnum.FREE);
        map.getField(new Point(4, 4)).updateFieldState(FieldStateEnum.FREE);

        // Case 4: No bar tables on the map
        assertTrue(map.getFieldsOfState(FieldStateEnum.BAR_TABLE).isEmpty());
        map.fillBarTables();
        assertTrue(map.getFieldsOfState(FieldStateEnum.BAR_TABLE).isEmpty());
    }

    @Test
    public void testHealCharactersOnBarSeats() {
        // Setup
        setup();
        m.setCoordinates(new Point(1, 4));
        eve.setCoordinates(new Point(4, 1));
        m.setHp(50);
        eve.setHp(30);
        jamesBond.setHp(80);

        // Case 1: More than one bar seat has a character, more than one character on a bar table is damaged
        assertNotEquals(100, m.getHp());
        assertNotEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        map.healCharactersOnBarSeats(characters);
        assertEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());

        // Setup change
        m.setHp(75);

        // Case 2: More than one bar seat has a character, one character on a bar table is damaged
        assertNotEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        map.healCharactersOnBarSeats(characters);
        assertEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());

        // Case 3: More than one bar seat has a character, no character on a bar table is damaged
        assertEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        map.healCharactersOnBarSeats(characters);
        assertEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());

        // Setup change
        m.setCoordinates(new Point(1, 5));
        eve.setHp(5);
        m.setHp(95);

        // Case 4: One bar seat has a character, one character on a bar table is damaged
        assertNotEquals(100, m.getHp());
        assertNotEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        map.healCharactersOnBarSeats(characters);
        assertNotEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());

        // Case 5: One bar seat has a character, no character on a bar table is damaged
        assertNotEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        map.healCharactersOnBarSeats(characters);
        assertNotEquals(100, m.getHp());
        assertEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());

        // Setup change
        eve.setCoordinates(new Point(5, 1));
        m.setHp(65);
        eve.setHp(80);

        // Case 6: No bar seat has a character
        assertNotEquals(100, m.getHp());
        assertNotEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        map.healCharactersOnBarSeats(characters);
        assertNotEquals(100, m.getHp());
        assertNotEquals(100, eve.getHp());
        assertNotEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
    }
}