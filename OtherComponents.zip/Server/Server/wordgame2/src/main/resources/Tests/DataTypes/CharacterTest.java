package Tests.DataTypes;

import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Gadgets.WireTapWithEarplugs;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;

/**
 * Class to test the methods of the class character.
 *
 * @author Alexander Preiß, Simon Demharter
 * @version 1.0
 */
public class CharacterTest {
    Character character;

    /**
     * Method to create a test setup
     */
    public void setup() {
        character = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
    }

    @Test
    public void testValidateIsCharacter() throws InvalidTargetException {
        // Setup
        setup();

        // Case 1: Target is this character
        character.validateIsCharacter(new Point(0, 0));

        // Case 2: Target is not this character
        assertThrows(InvalidTargetException.class, () -> character.validateIsCharacter(new Point(5, 2)));

        // Setup change
        Character cat = new Character(UUID.randomUUID(), "Cat", new Point(4, 2), new HashSet<>(), new HashSet<>());

        // Case 4: Target is the cat
        cat.validateIsCharacter((new Point(4, 2)));
    }

    @Test
    public void testValidateCharacter() throws InvalidCharacterException {
        // Setup
        setup();
        UUID jamesBondId = UUID.randomUUID();
        UUID drNoId = UUID.randomUUID();
        UUID silvaId = UUID.randomUUID();
        UUID kincadeId = UUID.randomUUID();
        Character jamesBond = new Character(jamesBondId, "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(drNoId, "Dr. No", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character silva = new Character(silvaId, "Silva", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character kincade = new Character(kincadeId, "Kincade", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Set<Character> characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(silva);
        characters.add(kincade);

        // Case 1: Character id exists
        Character.validateCharacter(characters, jamesBondId);
        Character.validateCharacter(characters, drNoId);
        Character.validateCharacter(characters, silvaId);

        // Case 2: Character id does not exist
        assertThrows(InvalidCharacterException.class, () -> Character.validateCharacter(characters, UUID.randomUUID()));
        assertThrows(InvalidCharacterException.class, () -> Character.validateCharacter(characters, UUID.randomUUID()));
        assertThrows(InvalidCharacterException.class, () -> Character.validateCharacter(characters, UUID.randomUUID()));
    }

    @Test
    public void testValidateHasMovementPoints() throws InvalidMovementPointsException {
        // Setup
        setup();
        character.setMp(3);

        // Case 1: Character has more than one movement point
        character.validateHasMovementPoints();

        // Setup change
        character.setMp(1);

        // Case 2: Character has one movement point
        character.validateHasMovementPoints();

        // Setup change
        character.setMp(0);

        // Case 3: Character has no movement points
        assertThrows(InvalidMovementPointsException.class, () -> character.validateHasMovementPoints());
    }


    @Test
    public void testValidateHasActionPoints() throws InvalidActionPointsException {
        // Setup
        setup();
        character.setAp(3);

        // Case 1: Character has more than one action point
        character.validateHasActionPoints();

        // Setup change
        character.setMp(1);

        // Case 2: Character has one action point
        character.validateHasActionPoints();

        // Setup change
        character.setAp(0);

        // Case 3: Character has no action points
        assertThrows(InvalidActionPointsException.class, () -> character.validateHasActionPoints());
    }

    @Test
    public void testValidateHasChipAmount() throws InvalidChipAmountException {
        // Setup
        setup();
        character.updateChips(100);

        // Case 1: Character has the right amount of chips
        character.validateHasChipAmount(25);
        character.validateHasChipAmount(0);
        character.validateHasChipAmount(100);

        // Case 2: Character does not have the right amount of chips
        assertThrows(InvalidChipAmountException.class, () -> character.validateHasChipAmount(125));
        assertThrows(InvalidChipAmountException.class, () -> character.validateHasChipAmount(150));
        assertThrows(InvalidChipAmountException.class, () -> character.validateHasChipAmount(200));
    }

    @Test
    public void testValidateHasProperty() throws InvalidPropertyException {
        // Setup
        setup();
        character.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        character.addProperty(PropertyEnum.BABYSITTER);
        character.addProperty(PropertyEnum.TOUGHNESS);

        // Case 1: Character has the property
        character.validateHasProperty(PropertyEnum.CLAMMY_CLOTHES);
        character.validateHasProperty(PropertyEnum.BABYSITTER);
        character.validateHasProperty(PropertyEnum.TOUGHNESS);

        // Case 2: Character does not have the property
        assertThrows(InvalidPropertyException.class, () -> character.validateHasProperty(PropertyEnum.AGILITY));
        assertThrows(InvalidPropertyException.class, () -> character.validateHasProperty(PropertyEnum.LUCKY_DEVIL));
        assertThrows(InvalidPropertyException.class, () -> character.validateHasProperty(PropertyEnum.BANG_AND_BURN));
    }

    @Test
    public void testValidateHasGadget() throws InvalidGadgetException {
        // Setup
        setup();
        character.addGadget(GadgetEnum.JETPACK);
        character.addGadget(GadgetEnum.COCKTAIL);
        character.addGadget(GadgetEnum.BOWLER_BLADE);

        // Case 1: Character has the gadget
        character.validateHasGadget(GadgetEnum.JETPACK);
        character.validateHasGadget(GadgetEnum.COCKTAIL);
        character.validateHasGadget(GadgetEnum.BOWLER_BLADE);

        // Case 2: Character does not have the gadget
        assertThrows(InvalidGadgetException.class, () -> character.validateHasGadget(GadgetEnum.HAIRDRYER));
        assertThrows(InvalidGadgetException.class, () -> character.validateHasGadget(GadgetEnum.DIAMOND_COLLAR));
        assertThrows(InvalidGadgetException.class, () -> character.validateHasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
    }

    @Test
    public void testValidateHasNoGadgetOfType() throws InvalidGadgetException {
        // Setup
        setup();
        character.addGadget(GadgetEnum.COCKTAIL);
        character.addGadget(GadgetEnum.MOLEDIE);
        character.addGadget(GadgetEnum.ROCKET_PEN);

        // Case 1: Character has no gadget of that type
        character.validateHasNoGadgetOfType(GadgetEnum.TECHNICOLOUR_PRISM);
        character.validateHasNoGadgetOfType(GadgetEnum.HAIRDRYER);
        character.validateHasNoGadgetOfType(GadgetEnum.BOWLER_BLADE);

        // Case 2: Character has a gadget of that type
        assertThrows(InvalidGadgetException.class, () -> character.validateHasNoGadgetOfType(GadgetEnum.COCKTAIL));
        assertThrows(InvalidGadgetException.class, () -> character.validateHasNoGadgetOfType(GadgetEnum.MOLEDIE));
        assertThrows(InvalidGadgetException.class, () -> character.validateHasNoGadgetOfType(GadgetEnum.ROCKET_PEN));
    }

    @Test
    public void testValidateIsNoMemberOfFaction() throws InvalidTargetException {
        // Setup
        setup();
        Set<Character> factionPlayerOne = new HashSet<>();
        Set<Character> factionPlayerTwo = new HashSet<>();
        Character jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character q = new Character(UUID.randomUUID(), "Q", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character m = new Character(UUID.randomUUID(), "M", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character silva = new Character(UUID.randomUUID(), "Silva", new Point(0, 0), new HashSet<>(), new HashSet<>());
        factionPlayerOne.add(jamesBond);
        factionPlayerOne.add(q);
        factionPlayerOne.add(m);
        factionPlayerTwo.add(drNo);
        factionPlayerTwo.add(silva);

        // Case 1: Character is not a member of the faction
        jamesBond.validateIsNoMemberOfFaction(factionPlayerTwo);
        q.validateIsNoMemberOfFaction(factionPlayerTwo);
        silva.validateIsNoMemberOfFaction(factionPlayerOne);

        // Case 2: Character is a member of the faction
        assertThrows(InvalidTargetException.class, () -> jamesBond.validateIsNoMemberOfFaction(factionPlayerOne));
        assertThrows(InvalidTargetException.class, () -> m.validateIsNoMemberOfFaction(factionPlayerOne));
        assertThrows(InvalidTargetException.class, () -> drNo.validateIsNoMemberOfFaction(factionPlayerTwo));
    }

    @Test
    public void testValidateHasSafeCombination() throws InvalidSafeCombinationException {
        // Setup
        setup();
        Set<Integer> playerOneSafeCombinations;
        playerOneSafeCombinations = new HashSet<>();
        playerOneSafeCombinations.add(1);

        // Case 1: Character has the right safe combination
        character.validateHasSafeCombination(1, playerOneSafeCombinations);

        // Case 2: Character has the wrong safe combination
        assertThrows(InvalidSafeCombinationException.class, () -> character.validateHasSafeCombination(2, playerOneSafeCombinations));
    }

    @Test
    public void testGetCharacter() {
        // Setup
        setup();
        UUID jamesBondId = UUID.randomUUID();
        UUID drNoId = UUID.randomUUID();
        UUID silvaId = UUID.randomUUID();
        Character jamesBond = new Character(jamesBondId, "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(drNoId, "Dr. No", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character silva = new Character(silvaId, "Silva", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Set<Character> characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(silva);

        // Case 1: Get the right character
        assertEquals(jamesBond, Character.getCharacter(characters, jamesBondId));
        assertEquals(drNo, Character.getCharacter(characters, drNoId));
        assertEquals(silva, Character.getCharacter(characters, silvaId));
    }

    @Test
    public void testIsOnField() {
        // Setup
        setup();

        // Case 1: Character is on that field
        assertTrue(character.isOnField(new Point(0, 0)));

        // Case 2: Character is not on that field
        assertFalse(character.isOnField(new Point(5, 2)));
    }

    @Test
    public void testUseActionPoint() {
        // Setup
        setup();
        character.setAp(3);

        // Case 1: Character uses action points
        character.useActionPoint();
        assertEquals(2, character.getAp());
        character.useActionPoint();
        assertEquals(1, character.getAp());
        character.useActionPoint();
        assertEquals(0, character.getAp());
    }

    @Test
    public void testUseMovementPoint() {
        // Setup
        setup();
        character.setMp(3);

        // Case 1: Character uses movement points
        character.useMovementPoint();
        assertEquals(2, character.getMp());
        character.useMovementPoint();
        assertEquals(1, character.getMp());
        character.useMovementPoint();
        assertEquals(0, character.getMp());
    }

    @Test
    public void testUpdateIntelligencePoints() {
        // Setup
        setup();
        character.setIp(100);

        // Case 1: Add intelligence points
        character.updateIntelligencePoints(100);
        assertEquals(200, character.getIp());
        character.updateIntelligencePoints(50);
        assertEquals(250, character.getIp());
        character.updateIntelligencePoints(0);
        assertEquals(250, character.getIp());

        // Case 2: Remove intelligence points
        character.updateIntelligencePoints(-100);
        assertEquals(150, character.getIp());
        character.updateIntelligencePoints(0);
        assertEquals(150, character.getIp());
        character.updateIntelligencePoints(-150);
        assertEquals(0, character.getIp());
    }

    @Test
    public void testUpdateChips() {
        // Setup
        setup();

        // Case 1: Add Chips
        character.updateChips(40);
        assertEquals(50, character.getChips());
        character.updateChips(0);
        assertEquals(50, character.getChips());
        character.updateChips(25);
        assertEquals(75, character.getChips());

        // Case 2: Remove Chips
        character.updateChips(-10);
        assertEquals(65, character.getChips());
        character.updateChips(0);
        assertEquals(65, character.getChips());
        character.updateChips(-5);
        assertEquals(60, character.getChips());
    }

    @Test
    public void testTakeDamage() {
        // Setup
        setup();
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        FieldMap map = new FieldMap(fields);
        Character drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character silva = new Character(UUID.randomUUID(), "Silva", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Set<Character> characters = new HashSet<>();
        characters.add(character);
        characters.add(drNo);
        characters.add(silva);
        Set<Character> charactersPlayerOne = new HashSet<>();
        charactersPlayerOne.add(character);
        Set<Character> charactersPlayerTwo = new HashSet<>();
        charactersPlayerTwo.add(drNo);
        charactersPlayerTwo.add(silva);
        ArrayList<Point> expectedPoints;
        MainServerLogic.winCondition.setDamageTakenPlayer1(0);
        MainServerLogic.winCondition.setDamageTakenPlayer2(0);

        // Case 1: Character takes damage
        character.takeDamage(10, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(90, character.getHp());
        assertEquals(10, MainServerLogic.winCondition.getDamageTakenPlayer1());
        drNo.takeDamage(30, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(70, drNo.getHp());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer2());
        silva.takeDamage(20, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(80, silva.getHp());
        assertEquals(50, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 2: Character dies
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        character.takeDamage(90, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(1, character.getHp());
        assertTrue(expectedPoints.contains(character.getCoordinates()));
        assertEquals(100, MainServerLogic.winCondition.getDamageTakenPlayer1());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        drNo.takeDamage(70, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(1, drNo.getHp());
        assertTrue(expectedPoints.contains(drNo.getCoordinates()));
        assertEquals(120, MainServerLogic.winCondition.getDamageTakenPlayer2());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        silva.takeDamage(80, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(1, drNo.getHp());
        assertTrue(expectedPoints.contains(silva.getCoordinates()));
        assertEquals(200, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Setup change
        character.setHp(10);
        drNo.setHp(30);
        silva.setHp(60);

        // Case 3: Character gets overkilled and dies
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        character.takeDamage(50, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(1, character.getHp());
        assertTrue(expectedPoints.contains(character.getCoordinates()));
        assertEquals(110, MainServerLogic.winCondition.getDamageTakenPlayer1());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        drNo.takeDamage(65, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(1, drNo.getHp());
        assertTrue(expectedPoints.contains(drNo.getCoordinates()));
        assertEquals(230, MainServerLogic.winCondition.getDamageTakenPlayer2());
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        silva.takeDamage(90, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(1, silva.getHp());
        assertTrue(expectedPoints.contains(silva.getCoordinates()));
        assertEquals(290, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Setup change
        character.addProperty(PropertyEnum.TOUGHNESS);
        character.setHp(70);
        drNo.addProperty(PropertyEnum.TOUGHNESS);
        drNo.setHp(50);
        silva.addProperty(PropertyEnum.TOUGHNESS);
        silva.setHp(100);

        // Case 4: Character with the property toughness takes damage
        character.takeDamage(20, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(60, character.getHp());
        assertEquals(120, MainServerLogic.winCondition.getDamageTakenPlayer1());
        drNo.takeDamage(40, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(30, drNo.getHp());
        assertEquals(310, MainServerLogic.winCondition.getDamageTakenPlayer2());
        silva.takeDamage(90, map, characters, charactersPlayerOne, charactersPlayerTwo);
        assertEquals(55, silva.getHp());
        assertEquals(355, MainServerLogic.winCondition.getDamageTakenPlayer2());
    }

    @Test
    public void testGetHealed() {
        // Setup
        setup();
        character.setHp(25);

        // Case 1: Character gets healed
        character.getHealed(10);
        assertEquals(35, character.getHp());
        character.getHealed(0);
        assertEquals(35, character.getHp());
        character.getHealed(55);
        assertEquals(90, character.getHp());

        // Case 2: Character gets healed to full life
        character.getHealed(10);
        assertEquals(100, character.getHp());

        // Setup change
        character.setHp(60);

        // Case 3: Character gets overhealed to full life
        character.getHealed(50);
        assertEquals(100, character.getHp());
    }

    @Test
    public void testHasProperty() {
        // Setup
        setup();
        character.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        character.addProperty(PropertyEnum.BABYSITTER);
        character.addProperty(PropertyEnum.TOUGHNESS);

        // Case 1: Character has the property
        assertTrue(character.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(character.hasProperty(PropertyEnum.BABYSITTER));
        assertTrue(character.hasProperty(PropertyEnum.TOUGHNESS));

        // Case 2: Character does not have the property
        assertFalse(character.hasProperty(PropertyEnum.AGILITY));
        assertFalse(character.hasProperty(PropertyEnum.LUCKY_DEVIL));
        assertFalse(character.hasProperty(PropertyEnum.BANG_AND_BURN));
    }

    @Test
    public void testAddProperty() {
        // Setup
        setup();
        character.addProperty(PropertyEnum.TOUGHNESS);
        character.addProperty(PropertyEnum.ROBUST_STOMACH);
        character.addProperty(PropertyEnum.NIMBLENESS);

        // Case 1: Add a property the character does not have
        assertFalse(character.hasProperty(PropertyEnum.AGILITY));
        character.addProperty(PropertyEnum.AGILITY);
        assertTrue(character.hasProperty(PropertyEnum.AGILITY));
        assertFalse(character.hasProperty(PropertyEnum.SLUGGISHNESS));
        character.addProperty(PropertyEnum.SLUGGISHNESS);
        assertTrue(character.hasProperty(PropertyEnum.SLUGGISHNESS));
        assertFalse(character.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        character.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        assertTrue(character.hasProperty(PropertyEnum.CLAMMY_CLOTHES));

        // Case 2: Add a property the character has
        assertTrue(character.hasProperty(PropertyEnum.TOUGHNESS));
        character.addProperty(PropertyEnum.TOUGHNESS);
        assertTrue(character.hasProperty(PropertyEnum.TOUGHNESS));
        assertTrue(character.hasProperty(PropertyEnum.ROBUST_STOMACH));
        character.addProperty(PropertyEnum.ROBUST_STOMACH);
        assertTrue(character.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertTrue(character.hasProperty(PropertyEnum.NIMBLENESS));
        character.addProperty(PropertyEnum.NIMBLENESS);
        assertTrue(character.hasProperty(PropertyEnum.NIMBLENESS));

    }

    @Test
    public void testRemoveProperty() {
        // Setup
        setup();
        character.addProperty(PropertyEnum.TOUGHNESS);
        character.addProperty(PropertyEnum.ROBUST_STOMACH);
        character.addProperty(PropertyEnum.NIMBLENESS);

        // Case 1: Remove a property the character has
        assertTrue(character.hasProperty(PropertyEnum.TOUGHNESS));
        character.removeProperty(PropertyEnum.TOUGHNESS);
        assertFalse(character.hasProperty(PropertyEnum.TOUGHNESS));
        assertTrue(character.hasProperty(PropertyEnum.ROBUST_STOMACH));
        character.removeProperty(PropertyEnum.ROBUST_STOMACH);
        assertFalse(character.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertTrue(character.hasProperty(PropertyEnum.NIMBLENESS));
        character.removeProperty(PropertyEnum.NIMBLENESS);
        assertFalse(character.hasProperty(PropertyEnum.NIMBLENESS));

        // Case 2: Remove a property the character does not have
        assertFalse(character.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        character.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        assertFalse(character.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(character.hasProperty(PropertyEnum.AGILITY));
        character.removeProperty(PropertyEnum.AGILITY);
        assertFalse(character.hasProperty(PropertyEnum.AGILITY));
        assertFalse(character.hasProperty(PropertyEnum.HONEY_TRAP));
        character.removeProperty(PropertyEnum.HONEY_TRAP);
        assertFalse(character.hasProperty(PropertyEnum.HONEY_TRAP));
    }

    @Test
    public void testHasGadget() {
        // Setup
        setup();
        character.addGadget(GadgetEnum.JETPACK);
        character.addGadget(GadgetEnum.COCKTAIL);
        character.addGadget(GadgetEnum.BOWLER_BLADE);

        // Case 1: Character has the gadget
        assertTrue(character.hasGadget(GadgetEnum.JETPACK));
        assertTrue(character.hasGadget(GadgetEnum.COCKTAIL));
        assertTrue(character.hasGadget(GadgetEnum.BOWLER_BLADE));

        // Case 2: Character does not have the gadget
        assertFalse(character.hasGadget(GadgetEnum.HAIRDRYER));
        assertFalse(character.hasGadget(GadgetEnum.DIAMOND_COLLAR));
        assertFalse(character.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
    }

    @Test
    public void testGetGadget() {
        // Setup
        setup();
        Gadget cocktail = new Gadget(GadgetEnum.COCKTAIL);
        Gadget gasGloss = new Gadget(GadgetEnum.GAS_GLOSS);
        Gadget hairdryer = new Gadget(GadgetEnum.HAIRDRYER);
        Set<Gadget> gadgets = new HashSet<>();
        gadgets.add(cocktail);
        gadgets.add(gasGloss);
        gadgets.add(hairdryer);
        Character character = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), gadgets);

        // Case 1: Character has the right gadget
        assertEquals(character.getGadget(GadgetEnum.COCKTAIL), cocktail);
        assertEquals(character.getGadget(GadgetEnum.GAS_GLOSS), gasGloss);
        assertEquals(character.getGadget(GadgetEnum.HAIRDRYER), hairdryer);

        // Setup change
        character.removeGadget(GadgetEnum.COCKTAIL);
        character.removeGadget(GadgetEnum.GAS_GLOSS);
        character.removeGadget(GadgetEnum.HAIRDRYER);

        // Case 2: Character has no gadgets
        assertNull(character.getGadget(GadgetEnum.COCKTAIL));
        assertNull(character.getGadget(GadgetEnum.GAS_GLOSS));
        assertNull(character.getGadget(GadgetEnum.TECHNICOLOUR_PRISM));

        // Case 3: Character has the wrong gadget
        assertNull(character.getGadget(GadgetEnum.MAGNETIC_WATCH));
        assertNull(character.getGadget(GadgetEnum.GRAPPLE));
        assertNull(character.getGadget(GadgetEnum.TECHNICOLOUR_PRISM));
    }

    @Test
    public void testGetCocktail() {
        // Setup
        setup();
        Cocktail cocktail = new Cocktail();
        Set<Gadget> gadgets = new HashSet<>();
        gadgets.add(cocktail);
        Character character = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), gadgets);

        // Case 1: Character has a cocktail
        assertEquals(cocktail, character.getCocktail());

        // Setup change
        character.removeGadget(GadgetEnum.COCKTAIL);

        // Case 2: Character has no gadgets
        assertNull(character.getCocktail());

        // Setup change
        character.addGadget(GadgetEnum.MOTHBALL_POUCH);
        character.addGadget(GadgetEnum.MOLEDIE);

        // Case 3: Character has no cocktail
        assertNull(character.getCocktail());
    }

    @Test
    public void testGetWireTapWithEarplugs() {
        // Setup
        setup();
        WireTapWithEarplugs wireTapWithEarplugs = new WireTapWithEarplugs();
        Set<Gadget> gadgets = new HashSet<>();
        gadgets.add(wireTapWithEarplugs);
        Character character = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), gadgets);

        // Case 1: Character has wireTapWithEarplugs
        assertEquals(wireTapWithEarplugs, character.getWireTapWithEarplugs());

        // Setup change
        character.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);

        // Case 2: Character has no gadgets
        assertNull(character.getWireTapWithEarplugs());

        // Setup change
        character.addGadget(GadgetEnum.MOTHBALL_POUCH);
        character.addGadget(GadgetEnum.MOLEDIE);

        // Case 3: Character has no wireTapWithEarplugs
        assertNull(character.getWireTapWithEarplugs());
    }

    @Test
    public void testGetCharacterWithGadgetOfType() {
        // Setup
        setup();
        Character jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(2, 3), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(2, 3), new HashSet<>(), new HashSet<>());
        Character kincade = new Character(UUID.randomUUID(), "Kincade", new Point(5, 1), new HashSet<>(), new HashSet<>());
        Set<Character> characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(kincade);
        jamesBond.addGadget(GadgetEnum.MOTHBALL_POUCH);
        drNo.addGadget(GadgetEnum.FOG_TIN);
        kincade.addGadget(GadgetEnum.HAIRDRYER);

        // Case 1: There is a character with that gadget
        assertEquals(jamesBond, Character.getCharacterWithGadgetOfType(characters, GadgetEnum.MOTHBALL_POUCH));
        assertEquals(drNo, Character.getCharacterWithGadgetOfType(characters, GadgetEnum.FOG_TIN));
        assertEquals(kincade, Character.getCharacterWithGadgetOfType(characters, GadgetEnum.HAIRDRYER));

        // Case 2: There is no character with that gadget
        assertNull(Character.getCharacterWithGadgetOfType(characters, GadgetEnum.COCKTAIL));
        assertNull(Character.getCharacterWithGadgetOfType(characters, GadgetEnum.TECHNICOLOUR_PRISM));
        assertNull(Character.getCharacterWithGadgetOfType(characters, GadgetEnum.MAGNETIC_WATCH));
    }

    @Test
    public void testAddGadget() {
        // Setup
        setup();
        character.addGadget(GadgetEnum.BOWLER_BLADE);
        character.addGadget(GadgetEnum.GAS_GLOSS);
        character.addGadget(GadgetEnum.GRAPPLE);

        // Case 1: Add a gadget the character does not have
        assertFalse(character.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        character.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        assertTrue(character.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        assertFalse(character.hasGadget(GadgetEnum.CHICKEN_FEED));
        character.addGadget(GadgetEnum.CHICKEN_FEED);
        assertTrue(character.hasGadget(GadgetEnum.CHICKEN_FEED));
        assertFalse(character.hasGadget(GadgetEnum.NUGGET));
        character.addGadget(GadgetEnum.NUGGET);
        assertTrue(character.hasGadget(GadgetEnum.NUGGET));

        // Case 2: Add a gadget the character has
        assertTrue(character.hasGadget(GadgetEnum.BOWLER_BLADE));
        character.addGadget(GadgetEnum.BOWLER_BLADE);
        assertTrue(character.hasGadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(character.hasGadget(GadgetEnum.GAS_GLOSS));
        character.addGadget(GadgetEnum.GAS_GLOSS);
        assertTrue(character.hasGadget(GadgetEnum.GAS_GLOSS));
        assertTrue(character.hasGadget(GadgetEnum.GRAPPLE));
        character.addGadget(GadgetEnum.GRAPPLE);
        assertTrue(character.hasGadget(GadgetEnum.GRAPPLE));
    }

    @Test
    public void testRemoveGadget() {
        // Setup
        setup();
        character.addGadget(GadgetEnum.BOWLER_BLADE);
        character.addGadget(GadgetEnum.GAS_GLOSS);
        character.addGadget(GadgetEnum.GRAPPLE);

        // Case 1: Remove a gadget the character has
        assertTrue(character.hasGadget(GadgetEnum.BOWLER_BLADE));
        character.removeGadget(GadgetEnum.BOWLER_BLADE);
        assertFalse(character.hasGadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(character.hasGadget(GadgetEnum.GAS_GLOSS));
        character.removeGadget(GadgetEnum.GAS_GLOSS);
        assertFalse(character.hasGadget(GadgetEnum.GAS_GLOSS));
        assertTrue(character.hasGadget(GadgetEnum.GRAPPLE));
        character.removeGadget(GadgetEnum.GRAPPLE);
        assertFalse(character.hasGadget(GadgetEnum.GRAPPLE));

        // Case 2: Remove a gadget the character does not have
        assertFalse(character.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        character.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        assertFalse(character.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        assertFalse(character.hasGadget(GadgetEnum.CHICKEN_FEED));
        character.removeGadget(GadgetEnum.CHICKEN_FEED);
        assertFalse(character.hasGadget(GadgetEnum.CHICKEN_FEED));
        assertFalse(character.hasGadget(GadgetEnum.NUGGET));
        character.removeGadget(GadgetEnum.NUGGET);
        assertFalse(character.hasGadget(GadgetEnum.NUGGET));
    }

    @Test
    public void testUseGadget() {
        // Setup
        setup();
        character.addGadget(GadgetEnum.MOTHBALL_POUCH);
        character.addGadget(GadgetEnum.COCKTAIL);
        character.addGadget(GadgetEnum.FOG_TIN);
        character.addGadget(GadgetEnum.ROCKET_PEN);

        // Case 1: Character uses a gadget with more than 1 usages
        character.useGadget(GadgetEnum.MOTHBALL_POUCH);
        assertEquals(4, character.getGadget(GadgetEnum.MOTHBALL_POUCH).getUsages());
        character.useGadget(GadgetEnum.MOTHBALL_POUCH);
        assertEquals(3, character.getGadget(GadgetEnum.MOTHBALL_POUCH).getUsages());
        character.useGadget(GadgetEnum.MOTHBALL_POUCH);
        assertEquals(2, character.getGadget(GadgetEnum.MOTHBALL_POUCH).getUsages());

        // Case 2: Character uses a gadget with only 1 usage
        character.useGadget(GadgetEnum.COCKTAIL);
        assertFalse(character.hasGadget(GadgetEnum.COCKTAIL));
        character.useGadget(GadgetEnum.FOG_TIN);
        assertFalse(character.hasGadget(GadgetEnum.FOG_TIN));
        character.useGadget(GadgetEnum.ROCKET_PEN);
        assertFalse(character.hasGadget(GadgetEnum.ROCKET_PEN));
    }

    @Test
    public void testIsMemberOfFaction() {
        // Setup
        setup();
        Set<Character> factionPlayerOne = new HashSet<>();
        Set<Character> factionPlayerTwo = new HashSet<>();
        Character jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character q = new Character(UUID.randomUUID(), "Q", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character m = new Character(UUID.randomUUID(), "M", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character silva = new Character(UUID.randomUUID(), "Silva", new Point(0, 0), new HashSet<>(), new HashSet<>());
        factionPlayerOne.add(jamesBond);
        factionPlayerOne.add(q);
        factionPlayerOne.add(m);
        factionPlayerTwo.add(drNo);
        factionPlayerTwo.add(silva);

        // Case 1: Character is a member of the faction
        assertTrue(jamesBond.isMemberOfFaction(factionPlayerOne));
        assertTrue(q.isMemberOfFaction(factionPlayerOne));
        assertTrue(silva.isMemberOfFaction(factionPlayerTwo));

        // Case 2: Character is not a member of the faction
        assertFalse(jamesBond.isMemberOfFaction(factionPlayerTwo));
        assertFalse(m.isMemberOfFaction(factionPlayerTwo));
        assertFalse(drNo.isMemberOfFaction(factionPlayerOne));
    }

    @Test
    public void testSetupPoints() {
        // Setup
        setup();

        // Case 1: Character has no properties
        character.setupPoints();
        assertEquals(2, character.getMp());
        assertEquals(1, character.getAp());

        // Setup change
        character.addProperty(PropertyEnum.NIMBLENESS);

        // Case 2: Character has nimbleness
        character.setupPoints();
        assertEquals(3, character.getMp());
        assertEquals(1, character.getAp());

        // Setup change
        character.removeProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SLUGGISHNESS);

        // Case 3: Character has sluggishness
        character.setupPoints();
        assertEquals(1, character.getMp());
        assertEquals(1, character.getAp());

        // Setup change
        character.removeProperty(PropertyEnum.SLUGGISHNESS);
        character.addProperty(PropertyEnum.SPRYNESS);

        // Case 4: Character has spryness
        character.setupPoints();
        assertEquals(2, character.getMp());
        assertEquals(2, character.getAp());

        // Setup change
        character.addProperty(PropertyEnum.NIMBLENESS);

        // Case 5: Character has nimbleness and spryness
        character.setupPoints();
        assertEquals(3, character.getMp());
        assertEquals(2, character.getAp());

        // Setup change
        character.removeProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SLUGGISHNESS);

        // Case 6: Character has sluggishness and spryness
        character.setupPoints();
        assertEquals(1, character.getMp());
        assertEquals(2, character.getAp());

        // Setup change
        character.removeProperty(PropertyEnum.SPRYNESS);
        character.removeProperty(PropertyEnum.SLUGGISHNESS);
        character.addProperty(PropertyEnum.AGILITY);

        // Case 7: Character has agility
        character.setupPoints();
        assertTrue(character.getMp() == 3 && character.getAp() == 1 || character.getMp() == 2 && character.getAp() == 2);

        // Setup change
        character.addProperty(PropertyEnum.NIMBLENESS);

        // Case 8: Character has nimbleness and agility
        character.setupPoints();
        assertTrue(character.getMp() == 4 && character.getAp() == 1 || character.getMp() == 3 && character.getAp() == 2);

        // Setup change
        character.removeProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SLUGGISHNESS);

        // Case 9: Character has sluggishness and agility
        character.setupPoints();
        assertTrue(character.getMp() == 2 && character.getAp() == 1 || character.getMp() == 1 && character.getAp() == 2);

        // Setup change
        character.removeProperty(PropertyEnum.SLUGGISHNESS);
        character.addProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SPRYNESS);

        // Case 10: Character has nimbleness, spryness and agility
        character.setupPoints();
        assertTrue(character.getMp() == 4 && character.getAp() == 2 || character.getMp() == 3 && character.getAp() == 3);

        // Setup change
        character.removeProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SLUGGISHNESS);

        // Case 11: Character has sluggishness, spryness and agility
        character.setupPoints();
        assertTrue(character.getMp() == 2 && character.getAp() == 2 || character.getMp() == 1 && character.getAp() == 3);

        // Setup change
        character.removeProperty(PropertyEnum.SLUGGISHNESS);
        character.removeProperty(PropertyEnum.SPRYNESS);
        character.removeProperty(PropertyEnum.AGILITY);
        character.addProperty(PropertyEnum.PONDEROUSNESS);

        // Case 12: Character has ponderousness
        character.setupPoints();
        assertTrue(character.getMp() == 1 && character.getAp() == 1 || character.getMp() == 2 && character.getAp() == 0);

        // Setup change
        character.addProperty(PropertyEnum.NIMBLENESS);

        // Case 13: Character has nimbleness and ponderousness
        character.setupPoints();
        assertTrue(character.getMp() == 2 && character.getAp() == 1 || character.getMp() == 3 && character.getAp() == 0);

        // Setup change
        character.removeProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SLUGGISHNESS);

        // Case 14: Character has sluggishness and ponderousness
        character.setupPoints();
        assertTrue(character.getMp() == 0 && character.getAp() == 1 || character.getMp() == 1 && character.getAp() == 0);

        // Setup change
        character.removeProperty(PropertyEnum.SLUGGISHNESS);
        character.addProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SPRYNESS);

        // Case 15: Character has nimbleness, spryness and ponderousness
        character.setupPoints();
        assertTrue(character.getMp() == 2 && character.getAp() == 2 || character.getMp() == 3 && character.getAp() == 1);

        // Setup change
        character.removeProperty(PropertyEnum.NIMBLENESS);
        character.addProperty(PropertyEnum.SLUGGISHNESS);

        // Case 16: Character has sluggishness, spryness and ponderousness
        character.setupPoints();
        assertTrue(character.getMp() == 0 && character.getAp() == 2 || character.getMp() == 1 && character.getAp() == 1);
    }

    @Test
    public void testGetRandomCharacter() {
        // Setup
        setup();
        Set<Character> characters = new HashSet<>();
        characters.add(new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "Dr. No", new Point(2, 3), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "Silva", new Point(5, 2), new HashSet<>(), new HashSet<>()));
        characters.add(new Character(UUID.randomUUID(), "Kincade", new Point(3, 1), new HashSet<>(), new HashSet<>()));
        Set<Character> expectedCharacters = characters;

        // Case 1: Random Point
        assertTrue(expectedCharacters.contains(Character.getRandomCharacter(characters)));
        assertTrue(expectedCharacters.contains(Character.getRandomCharacter(characters)));
        assertTrue(expectedCharacters.contains(Character.getRandomCharacter(characters)));

        // Setup change
        characters = new HashSet<>();
        Character expectedCharacter = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
        characters.add(expectedCharacter);

        // Case 2: One Point
        assertEquals(expectedCharacter, Character.getRandomCharacter(characters));
        assertEquals(expectedCharacter, Character.getRandomCharacter(characters));
        assertEquals(expectedCharacter, Character.getRandomCharacter(characters));
    }
}
