package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.VictoryLogic;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Class to test the methods of the class Cocktail.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class VictoryLogicTest {

    @Test
    public void testIsGameOver() {
        // Setup
        Character jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(3, 1), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(5, 2), new HashSet<>(), new HashSet<>());
        Character cat = new Character(UUID.randomUUID(), "Cat", new Point(0, 0), new HashSet<>(), new HashSet<>());
        Character janitor = new Character(UUID.randomUUID(), "Janitor", new Point(4, 4), new HashSet<>(), new HashSet<>());
        Set<Character> allCharacters = new HashSet<>();
        allCharacters.add(jamesBond);
        allCharacters.add(drNo);
        allCharacters.add(cat);
        allCharacters.add(janitor);

        // Case 1: Cat does not have the diamond collar and there are playable characters active
        assertFalse(VictoryLogic.isGameOver(cat, janitor, allCharacters));

        // Setup change
        allCharacters.remove(jamesBond);
        allCharacters.remove(drNo);

        // Case 2: Cat does not have the diamond collar and there no playable characters active
        assertTrue(VictoryLogic.isGameOver(cat, janitor, allCharacters));

        // Setup change
        cat.addGadget(GadgetEnum.DIAMOND_COLLAR);
        allCharacters.add(jamesBond);
        allCharacters.add(drNo);

        // Case 3: Cat has the diamond collar and there are playable characters active
        assertTrue(VictoryLogic.isGameOver(cat, janitor, allCharacters));

        // Setup change
        allCharacters.remove(jamesBond);
        allCharacters.remove(drNo);

        // Case 4: Cat has the diamond collar and there are no playable characters active
        assertTrue(VictoryLogic.isGameOver(cat, janitor, allCharacters));
    }
}
