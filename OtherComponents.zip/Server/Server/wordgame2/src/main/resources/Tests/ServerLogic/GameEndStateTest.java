package Tests.ServerLogic;

import com.google.gson.Gson;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.*;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.Receive.GameLeaveMessage;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Receive.ReconnectMessage;
import de.uulm.team0015.server.model.Messages.Send.GamePauseMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStartedMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import org.junit.Test;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;

import static org.junit.Assert.*;

public class GameEndStateTest {

    /**
     * Test if disconnect to game end state is handled correctly
     */
    @Test
    public void testDisconnectGameEndState() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();
        mainServerLogic.initialMatchconfig.setReconnectLimit(3);
        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert that player1 is disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());

        Thread.sleep(mainServerLogic.initialMatchconfig.getReconnectLimit() * 1000 + 200);
        // Assert that state has switched to GameEndState
        assertTrue(mainServerLogic.serverState instanceof GameEndState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_END_STATE);
        assertFalse(mainServerLogic.gamePhaseHasStarted);

        mainServerLogic.stop();
    }

    /**
     * Test if player leave to game end state is handled correctly
     */
    @Test
    public void testGameLeaveGameEndState() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();
        mainServerLogic.initialMatchconfig.setReconnectLimit(3);
        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);

        GameLeaveMessage gameLeaveMessage = new GameLeaveMessage();
        gameLeaveMessage.clientId = mainServerLogic.clientIdPlayer1;
        gameLeaveMessage.creationDate = "asdfasdf";
        gameLeaveMessage.debugMessage = "Test Game Leave message";
        gameLeaveMessage.type = MessageTypeEnum.GAME_LEAVE;

        String jsonString = gson.toJson(gameLeaveMessage);
        psClient1.println(jsonString);

        Thread.sleep(100);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert that player1 is disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());

        // Assert that state has switched to GameEndState
        assertTrue(mainServerLogic.serverState instanceof GameEndState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_END_STATE);
        assertFalse(mainServerLogic.gamePhaseHasStarted);

        mainServerLogic.stop();
    }


    private static UUID connectNewPlayer(Gson gson, PrintStream ps, BufferedReader buff, MainServerLogic mainServerLogic) throws IOException, InterruptedException {
        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = "asdfasdf";
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "TestPlayer1";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;

        String jsonString = gson.toJson(helloMessage);
        ps.println(jsonString);

        HelloReplyMessage replyMessage = gson.fromJson(buff.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertTrue(replyMessage.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage.clientId.equals(mainServerLogic.clientIdPlayer2));
        return replyMessage.clientId;
    }
}
