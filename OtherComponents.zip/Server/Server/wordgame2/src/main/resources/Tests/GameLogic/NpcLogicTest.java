package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.NpcLogic;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Operations.GadgetAction;
import de.uulm.team0015.server.model.DataTypes.Operations.GambleAction;
import de.uulm.team0015.server.model.DataTypes.Operations.Movement;
import de.uulm.team0015.server.model.DataTypes.Operations.Operation;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import org.junit.Test;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This class contains all the tests for NPCs
 *
 * @author Max Raedler
 */
public class NpcLogicTest {
    private FieldMap map;
    private Set<Character> characters;
    private Character jamesBond;
    private Character drNo;
    private Character q;
    private Character m;
    private Character eve;
    private Matchconfig matchconfig;

    /**
     * Method to create a test setup
     */
    public void setup() {
        // Set up map
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        map = new FieldMap(fields);

        // Set up characters
        jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(4, 5), new HashSet<>(), new HashSet<>());
        q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
        matchconfig = new Matchconfig();
    }

    @Test
    public void testRandomMoveTowardGadget() {
        setup();
        map.getField(new Point(2, 4)).setGadget(new Gadget(GadgetEnum.GRAPPLE));
        Movement movement = (Movement) NpcLogic.randomMove(m, map);
        assertEquals(movement.getCharacterId(), m.getCharacterId());
        assertEquals(movement.getFrom(), m.getCoordinates());
        assertEquals(movement.getTarget(), new Point(2, 4));
        assertEquals(movement.getType(), OperationEnum.MOVEMENT);
    }

    @Test
    public void testRandomMove() {
        setup();
        Movement movement = (Movement) NpcLogic.randomMove(m, map);
        assertEquals(movement.getCharacterId(), m.getCharacterId());
        assertEquals(movement.getFrom(), m.getCoordinates());
        ArrayList<Point> expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(2, 5));
        assertTrue(expectedPoints.contains(movement.getTarget()));
        assertEquals(movement.getType(), OperationEnum.MOVEMENT);
    }

    @Test
    public void testNoMoveIsPossible() {
        setup();
        map.getField(new Point(1, 4)).updateFieldState(FieldStateEnum.FIREPLACE);
        map.getField(new Point(2, 4)).updateFieldState(FieldStateEnum.WALL);
        map.getField(new Point(2, 5)).updateFieldState(FieldStateEnum.WALL);

        Operation movement = NpcLogic.randomMove(m, map);
        assertEquals(movement.getCharacterId(), m.getCharacterId());
        assertEquals(movement.getType(), OperationEnum.RETIRE);
    }

    @Test
    public void testGambleAction() {
        setup();
        map.getField(new Point(3, 3)).setChipAmount(20);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        while (operation.getType() != OperationEnum.GAMBLE_ACTION) {
            operation = NpcLogic.randomAction(q, map, characters, matchconfig);
        }

        GambleAction gambleAction = (GambleAction) operation;

        assertEquals(gambleAction.getCharacterId(), q.getCharacterId());
        assertTrue(gambleAction.getStake() >= 0);
        assertTrue(gambleAction.getStake() <= 10);
        assertEquals(gambleAction.getTarget(), new Point(3, 3));
    }

    @Test
    public void testHairDryer() {
        setup();

        q.addGadget(GadgetEnum.HAIRDRYER);
        q.addProperty(PropertyEnum.CLAMMY_CLOTHES);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        while (operation.getType() != OperationEnum.GADGET_ACTION) {
            operation = NpcLogic.randomAction(q, map, characters, matchconfig);
        }

        GadgetAction gadgetAction = (GadgetAction) operation;
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
        assertEquals(gadgetAction.getGadget(), GadgetEnum.HAIRDRYER);
        assertEquals(gadgetAction.getTarget(), q.getCoordinates());
    }

    @Test
    public void testHairDryerRetire() {
        setup();

        q.addGadget(GadgetEnum.HAIRDRYER);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getCharacterId(), q.getCharacterId());
        assertEquals(operation.getType(), OperationEnum.RETIRE);
    }

    @Test
    public void testTechnicolorPrism() {
        setup();

        q.addGadget(GadgetEnum.TECHNICOLOUR_PRISM);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        while (operation.getType() != OperationEnum.GADGET_ACTION) {
            operation = NpcLogic.randomAction(q, map, characters, matchconfig);
        }

        GadgetAction gadgetAction = (GadgetAction) operation;
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
        assertEquals(gadgetAction.getGadget(), GadgetEnum.TECHNICOLOUR_PRISM);
        assertEquals(gadgetAction.getTarget(), new Point(3, 3));
    }

    @Test
    public void testBowlerBladeWithRange() {
        setup();

        q.addGadget(GadgetEnum.BOWLER_BLADE);
        matchconfig.setBowlerBladeRange(1);
        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getType(), OperationEnum.GADGET_ACTION);

        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.BOWLER_BLADE);
        assertEquals(gadgetAction.getTarget(), new Point(1, 2));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testBowlerBlade() {
        setup();

        q.addGadget(GadgetEnum.BOWLER_BLADE);
        matchconfig.setBowlerBladeRange(100);
        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getType(), OperationEnum.GADGET_ACTION);

        GadgetAction gadgetAction = (GadgetAction) operation;

        ArrayList<Point> possibleTargets = new ArrayList<>();
        possibleTargets.add(eve.getCoordinates());
        possibleTargets.add(m.getCoordinates());
        possibleTargets.add(jamesBond.getCoordinates());
        assertEquals(gadgetAction.getGadget(), GadgetEnum.BOWLER_BLADE);
        assertTrue(possibleTargets.contains(operation.getTarget()));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testPoisonPillsOnField() {
        setup();

        q.addGadget(GadgetEnum.POISON_PILLS);
        map.getField(new Point(2, 4)).setGadget(new Gadget(GadgetEnum.COCKTAIL));

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getType(), OperationEnum.GADGET_ACTION);

        GadgetAction gadgetAction = (GadgetAction) operation;

        while (gadgetAction.getGadget() != GadgetEnum.POISON_PILLS) {
            gadgetAction = (GadgetAction) NpcLogic.randomAction(q, map, characters, matchconfig);
        }

        assertEquals(gadgetAction.getGadget(), GadgetEnum.POISON_PILLS);
        assertEquals(gadgetAction.getTarget(), new Point(2, 4));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testPoisonPillsOnCharacter() {
        setup();

        q.addGadget(GadgetEnum.POISON_PILLS);
        jamesBond.addGadget(GadgetEnum.COCKTAIL);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getType(), OperationEnum.GADGET_ACTION);

        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.POISON_PILLS);
        assertEquals(gadgetAction.getTarget(), jamesBond.getCoordinates());
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testLaserCompactOnField() {
        setup();

        q.addGadget(GadgetEnum.LASER_COMPACT);
        map.getField(new Point(5, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getType(), OperationEnum.GADGET_ACTION);

        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.LASER_COMPACT);
        assertEquals(gadgetAction.getTarget(), new Point(5, 3));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testLaserCompactOnCharacter() {
        setup();

        q.addGadget(GadgetEnum.LASER_COMPACT);
        jamesBond.addGadget(GadgetEnum.COCKTAIL);
        eve.addGadget(GadgetEnum.COCKTAIL);
        drNo.addGadget(GadgetEnum.COCKTAIL);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(operation.getType(), OperationEnum.GADGET_ACTION);

        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.LASER_COMPACT);
        ArrayList<Point> possibleTargets = new ArrayList<>();
        possibleTargets.add(eve.getCoordinates());
        possibleTargets.add(jamesBond.getCoordinates());
        possibleTargets.add(drNo.getCoordinates());
        assertTrue(possibleTargets.contains(operation.getTarget()));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testRocketPen() {
        setup();

        q.addGadget(GadgetEnum.ROCKET_PEN);
        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());

        GadgetAction gadgetAction = (GadgetAction) operation;

        ArrayList<Point> possibleTargets = new ArrayList<>();
        possibleTargets.add(eve.getCoordinates());
        possibleTargets.add(m.getCoordinates());
        possibleTargets.add(jamesBond.getCoordinates());
        assertEquals(gadgetAction.getGadget(), GadgetEnum.ROCKET_PEN);
        assertTrue(possibleTargets.contains(operation.getTarget()));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testGasGlossNoNeighbour() {
        setup();

        eve.addGadget(GadgetEnum.GAS_GLOSS);
        Operation operation = NpcLogic.randomAction(eve, map, characters, matchconfig);

        assertEquals(OperationEnum.RETIRE, operation.getType());

        assertEquals(eve.getCoordinates(), operation.getTarget());
        assertEquals(eve.getCharacterId(), operation.getCharacterId());
    }

    @Test
    public void testGasGloss() {
        setup();
        q.addGadget(GadgetEnum.GAS_GLOSS);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());

        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(GadgetEnum.GAS_GLOSS, gadgetAction.getGadget());
        assertEquals(new Point(1, 2), gadgetAction.getTarget());
        assertEquals(q.getCharacterId(), gadgetAction.getCharacterId());
    }

    @Test
    public void testMothballPouchOutOfRange() {
        setup();

        q.addGadget(GadgetEnum.MOTHBALL_POUCH);
        matchconfig.setMothballPouchRange(1);
        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.RETIRE, operation.getType());
        assertEquals(q.getCharacterId(), operation.getCharacterId());
    }

    @Test
    public void testMothballPouch() {
        setup();

        q.addGadget(GadgetEnum.MOTHBALL_POUCH);
        matchconfig.setMothballPouchRange(10);
        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(GadgetEnum.MOTHBALL_POUCH, gadgetAction.getGadget());
        assertEquals(new Point(1, 1), gadgetAction.getTarget());
        assertEquals(q.getCharacterId(), gadgetAction.getCharacterId());
    }

    @Test
    public void testFogTinOutOfRange() {
        setup();

        eve.addGadget(GadgetEnum.FOG_TIN);
        matchconfig.setFogTinRange(1);
        Operation operation = NpcLogic.randomAction(eve, map, characters, matchconfig);

        assertEquals(OperationEnum.RETIRE, operation.getType());
        assertEquals(eve.getCharacterId(), operation.getCharacterId());
    }

    @Test
    public void testFogTin() {
        setup();

        q.addGadget(GadgetEnum.FOG_TIN);
        matchconfig.setFogTinRange(10);
        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        ArrayList<Point> possibleTargets = new ArrayList<>();
        possibleTargets.add(eve.getCoordinates());
        possibleTargets.add(m.getCoordinates());
        possibleTargets.add(jamesBond.getCoordinates());
        assertEquals(gadgetAction.getGadget(), GadgetEnum.FOG_TIN);
        assertTrue(possibleTargets.contains(operation.getTarget()));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testGrappleOutOfRange() {
        setup();

        map.getField(new Point(5, 3)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));

        drNo.addGadget(GadgetEnum.GRAPPLE);
        matchconfig.setGrappleRange(1);

        Operation operation = NpcLogic.randomAction(drNo, map, characters, matchconfig);

        assertEquals(OperationEnum.RETIRE, operation.getType());
        assertEquals(operation.getCharacterId(), drNo.getCharacterId());
    }

    @Test
    public void testGrapple() {
        setup();

        map.getField(new Point(5, 3)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));

        drNo.addGadget(GadgetEnum.GRAPPLE);
        matchconfig.setGrappleRange(10);

        Operation operation = NpcLogic.randomAction(drNo, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.GRAPPLE);
        assertEquals(gadgetAction.getTarget(), new Point(5, 3));
        assertEquals(gadgetAction.getCharacterId(), drNo.getCharacterId());
    }

    @Test
    public void testJetpack() {
        setup();

        q.addGadget(GadgetEnum.JETPACK);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.JETPACK);
        assertTrue(map.getField(gadgetAction.getTarget()).isState(FieldStateEnum.FREE));
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testCocktailDrinkIfNecessary() {
        setup();

        q.addGadget(GadgetEnum.COCKTAIL);
        q.setHp(60);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.COCKTAIL);
        assertEquals(q.getCoordinates(), gadgetAction.getTarget());
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testCocktailSpill() {
        setup();

        q.addGadget(GadgetEnum.COCKTAIL);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(gadgetAction.getGadget(), GadgetEnum.COCKTAIL);
        assertEquals(jamesBond.getCoordinates(), gadgetAction.getTarget());
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testMoledie() {
        setup();

        q.addGadget(GadgetEnum.MOLEDIE);
        matchconfig.setMoledieRange(10);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;
        ArrayList<Point> possibleTargets = new ArrayList<>();
        possibleTargets.add(eve.getCoordinates());
        possibleTargets.add(m.getCoordinates());
        possibleTargets.add(jamesBond.getCoordinates());
        assertTrue(possibleTargets.contains(gadgetAction.getTarget()));
        assertEquals(GadgetEnum.MOLEDIE, gadgetAction.getGadget());
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testMoledieFirst() {
        setup();

        for (GadgetEnum gadget : GadgetEnum.values()) {
            q.addGadget(gadget);
        }
        q.addProperty(PropertyEnum.CLAMMY_CLOTHES);

        matchconfig.setMoledieRange(10);

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(GadgetEnum.MOLEDIE, gadgetAction.getGadget());
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testTakeCocktail() {
        setup();

        map.getField(new Point(1, 3)).setGadget(new Gadget(GadgetEnum.COCKTAIL));

        Operation operation = NpcLogic.randomAction(q, map, characters, matchconfig);

        assertEquals(OperationEnum.GADGET_ACTION, operation.getType());
        GadgetAction gadgetAction = (GadgetAction) operation;

        assertEquals(GadgetEnum.COCKTAIL, gadgetAction.getGadget());
        assertEquals(new Point(1, 3), gadgetAction.getTarget());
        assertEquals(gadgetAction.getCharacterId(), q.getCharacterId());
    }

    @Test
    public void testJanitor() {
        setup();
        //eve is now cat
        //james bond is now Janitor

        HashSet<Character> removedCharacters = new HashSet<>();

        Point target = NpcLogic.janitor(jamesBond, eve, map, characters, removedCharacters, new ArrayList<>());

        assertEquals(jamesBond.getCoordinates(), target);
        assertEquals(1, removedCharacters.size());
        assertEquals(4, characters.size());
        assertEquals(new Point(2, 3), removedCharacters.toArray(new Character[0])[0].getCoordinates());

        target = NpcLogic.janitor(jamesBond, eve, map, characters, removedCharacters, new ArrayList<>());
        assertEquals(jamesBond.getCoordinates(), target);
        assertEquals(2, removedCharacters.size());
        assertEquals(3, characters.size());
        ArrayList<Point> possibleTargets = new ArrayList<>();
        possibleTargets.add(new Point(4, 5));
        possibleTargets.add(new Point(1, 5));
        assertTrue(Collections.disjoint(possibleTargets, removedCharacters));

        target = NpcLogic.janitor(jamesBond, eve, map, characters, removedCharacters, new ArrayList<>());
        assertEquals(jamesBond.getCoordinates(), target);
        assertEquals(3, removedCharacters.size());
        assertEquals(2, characters.size());
        assertTrue(Collections.disjoint(possibleTargets, removedCharacters));
    }
}
