package Tests.ServerLogic;

import com.google.gson.Gson;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.*;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Receive.ReconnectMessage;
import de.uulm.team0015.server.model.Messages.Send.GamePauseMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStartedMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import org.junit.Test;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;

import static org.junit.Assert.*;

public class ReconnectStateTest {

    /**
     * Test if Player1 disconnect and no reconnect is handled correctly
     */
    @Test
    public void testPlayerOneDisconnectNoReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        mainServerLogic.initialMatchconfig.setReconnectLimit(3);

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert that player1 is disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());

        Thread.sleep(mainServerLogic.initialMatchconfig.getReconnectLimit() * 1000 + 200);
        // Assert that state has switched to GameEndState
        assertTrue(mainServerLogic.serverState instanceof GameEndState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_END_STATE);

        mainServerLogic.stop();
    }


    /**
     * Test if Player1 disconnect and reconnect is handled correctly
     */
    @Test
    public void testPlayerOneDisconnectAndReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert true, that player 1 is disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());

        // Create client and send ReconnectMessage
        Socket socketClient3 = null;
        socketClient3 = new Socket("localhost", 7007);
        OutputStream outClient3 = socketClient3.getOutputStream();
        PrintStream psClient3 = new PrintStream(outClient3, true);
        InputStream inClient3 = socketClient3.getInputStream();
        BufferedReader buffClient3 = new BufferedReader(new InputStreamReader(inClient3, StandardCharsets.UTF_8));

        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient1.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;

        String jsonReconnect = gson.toJson(reconnectMessage);

        psClient3.println(jsonReconnect);

        Thread.sleep(200);


        // Assert that state has switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
        assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
        assertEquals(mainServerLogic.serverState, oldDecisionState);
        // Assert that player one has reconnected
        assertFalse(mainServerLogic.player1.isDisconnected());

        mainServerLogic.stop();
    }


    /**
     * Test if Player2 disconnect and no reconnect is handled correctly
     */
    @Test
    public void testTwoDisconnectNoReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        mainServerLogic.initialMatchconfig.setReconnectLimit(3);

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();
        socketClient2.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert true, that player 1 and 2 are disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());
        assertTrue(mainServerLogic.player2.isDisconnected());

        Thread.sleep(mainServerLogic.initialMatchconfig.getReconnectLimit() * 1000 + 200);
        // Assert that state has switched to GameEndState
        assertTrue(mainServerLogic.serverState instanceof GameEndState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_END_STATE);

        Thread.sleep(1000);
        mainServerLogic.stop();
    }

    /**
     * Test if Two Player disconnect and player 1 reconnect is handled correctly
     */
    @Test
    public void testTwoDisconnectAndPlayerOneReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        mainServerLogic.initialMatchconfig.setReconnectLimit(3);
        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();
        socketClient2.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert true, that player 1 and 2 are disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());
        assertTrue(mainServerLogic.player2.isDisconnected());

        // Create client and send ReconnectMessage
        Socket socketClient3 = null;
        socketClient3 = new Socket("localhost", 7007);
        OutputStream outClient3 = socketClient3.getOutputStream();
        PrintStream psClient3 = new PrintStream(outClient3, true);
        InputStream inClient3 = socketClient3.getInputStream();
        BufferedReader buffClient3 = new BufferedReader(new InputStreamReader(inClient3, StandardCharsets.UTF_8));

        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient1.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;

        String jsonReconnect = gson.toJson(reconnectMessage);

        psClient3.println(jsonReconnect);

        Thread.sleep(200);

        // Assert that state has not switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        // Assert that player one has reconnected and player 2 has not
        assertFalse(mainServerLogic.player1.isDisconnected());
        assertTrue(mainServerLogic.player2.isDisconnected());

        mainServerLogic.stop();
    }

    /**
     * Test if Two Player disconnect and player 2 reconnect is handled correctly
     */
    @Test
    public void testTwoDisconnectAndPlayerTwoReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();
        socketClient2.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert true, that player 1 and 2 are disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());
        assertTrue(mainServerLogic.player2.isDisconnected());

        // Create client and send ReconnectMessage
        Socket socketClient3 = null;
        socketClient3 = new Socket("localhost", 7007);
        OutputStream outClient3 = socketClient3.getOutputStream();
        PrintStream psClient3 = new PrintStream(outClient3, true);
        InputStream inClient3 = socketClient3.getInputStream();
        BufferedReader buffClient3 = new BufferedReader(new InputStreamReader(inClient3, StandardCharsets.UTF_8));

        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player2;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player2 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient2.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;

        String jsonReconnect = gson.toJson(reconnectMessage);

        psClient3.println(jsonReconnect);

        Thread.sleep(200);

        // Assert that state has not switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        // Assert that player two has reconnected and player one has not
        assertFalse(mainServerLogic.player2.isDisconnected());
        assertTrue(mainServerLogic.player1.isDisconnected());

        mainServerLogic.stop();
    }

    /**
     * Test if a Reconnect is handled correctly(both players disconnect and reconnect)
     */
    @Test
    public void testTwoDisconnectAndReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);
        socketClient1.close();
        socketClient2.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());
        // Assert true, that player 1 and 2 are disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());
        assertTrue(mainServerLogic.player2.isDisconnected());

        // Create client1
        Socket socketClient3 = null;
        socketClient3 = new Socket("localhost", 7007);
        OutputStream outClient3 = socketClient3.getOutputStream();
        PrintStream psClient3 = new PrintStream(outClient3, true);
        InputStream inClient3 = socketClient3.getInputStream();
        BufferedReader buffClient3 = new BufferedReader(new InputStreamReader(inClient3, StandardCharsets.UTF_8));

        // Reconnect Player 1
        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient2.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;
        String jsonReconnect = gson.toJson(reconnectMessage);
        psClient3.println(jsonReconnect);

        Thread.sleep(200);
        assertFalse(mainServerLogic.player1.isDisconnected());
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);


        // Create client2
        Socket socketClient4 = null;
        socketClient4 = new Socket("localhost", 7007);
        OutputStream outClient4 = socketClient4.getOutputStream();
        PrintStream psClient4 = new PrintStream(outClient4, true);
        InputStream inClient4 = socketClient4.getInputStream();
        BufferedReader buffClient4 = new BufferedReader(new InputStreamReader(inClient4, StandardCharsets.UTF_8));


        // Reconnect Player 2
        reconnectMessage.clientId = player2;
        reconnectMessage.debugMessage = "Player2 request Reconnect";
        jsonReconnect = gson.toJson(reconnectMessage);
        psClient4.println(jsonReconnect);

        Thread.sleep(200);
        assertFalse(mainServerLogic.player2.isDisconnected());

        // Assert that state has switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
        assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
        assertEquals(mainServerLogic.serverState, oldDecisionState);

        mainServerLogic.stop();
    }

    /**
     * Test if a repeated disconnect and reconnect by player1 is handled correctly.
     */
    @Test
    public void testPlayer1RepeatedDisconnectAndReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);

        // Reconnect message Player 1
        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient2.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;
        String jsonReconnect = gson.toJson(reconnectMessage);

        // Disconnect and Reconnect 5 times
        for (int i = 0; i < 5; i++) {
            socketClient1.close();
            Thread.sleep(200);
            //Assert that the Server is now in the Reconnect state
            assertTrue(mainServerLogic.serverState instanceof ReconnectState);
            assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

            GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
            assertTrue(pauseMessage.isValid());
            // Assert true, that player 1 and 2 are disconnected
            assertTrue(mainServerLogic.player1.isDisconnected());

            socketClient1 = new Socket("localhost", 7007);
            outClient1 = socketClient1.getOutputStream();
            psClient1 = new PrintStream(outClient1, true);
            inClient1 = socketClient1.getInputStream();
            buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

            psClient1.println(jsonReconnect);

            Thread.sleep(200);

            assertFalse(mainServerLogic.player1.isDisconnected());

            // Assert that state has switched back to DecisionPhaseState and that it is the same
            assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
            assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
            assertEquals(mainServerLogic.serverState, oldDecisionState);
        }
        mainServerLogic.stop();
    }

    /**
     * Test if a Reconnect is handled correctly(both players disconnect and reconnect repeatedly)
     */
    @Test
    public void testTwoPlayersRepeatedDisconnectAndReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;

        //Disconnect client 1
        //outClient1.write(-1);

        // Reconnect message Player 1
        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient2.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;
        String jsonReconnect = gson.toJson(reconnectMessage);

        // Disconnect and Reconnect 5 times
        for (int i = 0; i < 5; i++) {
            // Disconnect both clients
            socketClient1.close();
            socketClient2.close();
            Thread.sleep(200);
            //Assert that the Server is now in the Reconnect state
            assertTrue(mainServerLogic.serverState instanceof ReconnectState);
            assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

            // Assert true, that player 1 and 2 are disconnected
            assertTrue(mainServerLogic.player1.isDisconnected());
            assertTrue(mainServerLogic.player2.isDisconnected());

            socketClient1 = new Socket("localhost", 7007);
            outClient1 = socketClient1.getOutputStream();
            psClient1 = new PrintStream(outClient1, true);
            inClient1 = socketClient1.getInputStream();
            buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

            psClient1.println(jsonReconnect);

            Thread.sleep(200);

            assertFalse(mainServerLogic.player1.isDisconnected());

            socketClient1.close();
            Thread.sleep(200);

            //Assert that the Server is now in the Reconnect state
            assertTrue(mainServerLogic.serverState instanceof ReconnectState);
            assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

            // Assert true, that player 1 and 2 are disconnected
            assertTrue(mainServerLogic.player1.isDisconnected());
            assertTrue(mainServerLogic.player2.isDisconnected());

            socketClient2 = new Socket("localhost", 7007);
            outClient2 = socketClient2.getOutputStream();
            psClient2 = new PrintStream(outClient2, true);
            inClient2 = socketClient2.getInputStream();
            buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

            reconnectMessage.clientId = player2;
            jsonReconnect = gson.toJson(reconnectMessage);
            psClient2.println(jsonReconnect);

            Thread.sleep(200);

            assertFalse(mainServerLogic.player2.isDisconnected());

            socketClient1 = new Socket("localhost", 7007);
            outClient1 = socketClient1.getOutputStream();
            psClient1 = new PrintStream(outClient1, true);
            inClient1 = socketClient1.getInputStream();
            buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

            reconnectMessage.clientId = player1;
            jsonReconnect = gson.toJson(reconnectMessage);
            psClient1.println(jsonReconnect);

            Thread.sleep(200);

            assertFalse(mainServerLogic.player1.isDisconnected());

            // Assert that state has switched back to DecisionPhaseState and that it is the same
            assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
            assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
            assertEquals(mainServerLogic.serverState, oldDecisionState);
        }
        mainServerLogic.stop();
    }


    private static UUID connectNewPlayer(Gson gson, PrintStream ps, BufferedReader buff, MainServerLogic mainServerLogic) throws IOException, InterruptedException {
        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = "asdfasdf";
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "TestPlayer1";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;

        String jsonString = gson.toJson(helloMessage);
        ps.println(jsonString);

        HelloReplyMessage replyMessage = gson.fromJson(buff.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertTrue(replyMessage.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage.clientId.equals(mainServerLogic.clientIdPlayer2));
        return replyMessage.clientId;
    }
}
