package Tests.ServerLogic;

import com.google.gson.Gson;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.*;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Enumerations.VictoryEnum;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Receive.ItemChoiceMessage;
import de.uulm.team0015.server.model.Messages.Receive.ReconnectMessage;
import de.uulm.team0015.server.model.Messages.Send.*;
import org.junit.Test;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;

import static org.junit.Assert.*;

public class DecisionPhaseStateTest {

    /**
     * Test if Both Players receive a correct GameStartedMessage
     */
    @Test
    public void testBothPlayersReceivedStart() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Socket socketPlayer1;
        socketPlayer1 = new Socket("localhost", 7007);
        OutputStream outPlayer1 = socketPlayer1.getOutputStream();
        PrintStream psPlayer1 = new PrintStream(outPlayer1, true);
        InputStream inPlayer1 = socketPlayer1.getInputStream();
        BufferedReader buffPlayer1 = new BufferedReader(new InputStreamReader(inPlayer1, StandardCharsets.UTF_8));
        Gson gson = new Gson();

        Socket socketPlayer2;
        socketPlayer2 = new Socket("localhost", 7007);
        OutputStream outPlayer2 = socketPlayer2.getOutputStream();
        PrintStream psPlayer2 = new PrintStream(outPlayer2, true);
        InputStream inPlayer2 = socketPlayer2.getInputStream();
        BufferedReader buffPlayer2 = new BufferedReader(new InputStreamReader(inPlayer2, StandardCharsets.UTF_8));

        setupConnection(gson, psPlayer1, buffPlayer1, psPlayer2, buffPlayer2, mainServerLogic);
        //Assert that the DecisionPhase is active
        assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
        assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);

        GameStartedMessage gameStartedMessage1 = gson.fromJson(buffPlayer1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessage2 = gson.fromJson(buffPlayer2.readLine(), GameStartedMessage.class);

        assertTrue(gameStartedMessage1.isValid());
        assertTrue(gameStartedMessage2.isValid());

        assertTrue(gameStartedMessage1.clientId.equals(mainServerLogic.clientIdPlayer1) || gameStartedMessage1.clientId.equals(mainServerLogic.clientIdPlayer2));
        assertEquals(gameStartedMessage1.playerOneId, mainServerLogic.clientIdPlayer1);
        assertEquals(gameStartedMessage1.playerTwoId, mainServerLogic.clientIdPlayer2);
        assertTrue(gameStartedMessage1.playerOneName.equals("TestPlayer1") || gameStartedMessage1.playerOneName.equals("TestPlayer2"));
        assertTrue(gameStartedMessage1.playerTwoName.equals("TestPlayer1") || gameStartedMessage1.playerTwoName.equals("TestPlayer2"));
        assertTrue(gameStartedMessage1.clientId.equals(mainServerLogic.clientIdPlayer1) || gameStartedMessage1.clientId.equals(mainServerLogic.clientIdPlayer2));
        assertEquals(gameStartedMessage1.sessionId, mainServerLogic.sessionID);

        assertTrue(gameStartedMessage2.clientId.equals(mainServerLogic.clientIdPlayer1) || gameStartedMessage2.clientId.equals(mainServerLogic.clientIdPlayer2));
        assertEquals(gameStartedMessage2.playerOneId, mainServerLogic.clientIdPlayer1);
        assertEquals(gameStartedMessage2.playerTwoId, mainServerLogic.clientIdPlayer2);
        assertTrue(gameStartedMessage1.playerOneName.equals("TestPlayer1") || gameStartedMessage1.playerOneName.equals("TestPlayer2"));
        assertTrue(gameStartedMessage1.playerTwoName.equals("TestPlayer1") || gameStartedMessage1.playerTwoName.equals("TestPlayer2"));
        assertEquals(gameStartedMessage2.sessionId, mainServerLogic.sessionID);

        outPlayer1.write(-1);
        outPlayer2.write(-1);
        mainServerLogic.stop();
    }


    /**
     * Test if the auto-pick function is working
     */
    @Test
    public void testAutoPickCharacter() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();
        //Throw away First offer
        buffClient1.readLine();
        buffClient2.readLine();

        //Wait for Strike
        StrikeMessage player1Strike1 = gson.fromJson(buffClient1.readLine(), StrikeMessage.class);
        StrikeMessage player2Strike1 = gson.fromJson(buffClient2.readLine(), StrikeMessage.class);

        assertTrue(player1Strike1.isValid());
        assertTrue(player1Strike1.isValid());

        assertEquals(player1Strike1.clientId, player1);
        assertEquals(player1Strike1.strikeNr, 1);
        assertEquals(player1Strike1.strikeMax, mainServerLogic.initialMatchconfig.getStrikeMaximum());

        assertEquals(player2Strike1.clientId, player2);
        assertEquals(player2Strike1.strikeNr, 1);
        assertEquals(player2Strike1.strikeMax, mainServerLogic.initialMatchconfig.getStrikeMaximum());

        //Give the Server a little bit time to process
        Thread.sleep(100);

        //Check if the picks are made
        assertEquals(1, mainServerLogic.player1Characters.size());
        assertEquals(1, mainServerLogic.player2Characters.size());
        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }


    /**
     * Test if the auto-pick function is working
     */
    @Test
    public void testAutoPickGadgets() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();

        //Let both Clients to their pick
        for (int i = 0; i < 4; i++) {
            randomCharacterChoice(gson, psClient1, buffClient1, player1);
            randomCharacterChoice(gson, psClient2, buffClient2, player2);
        }

        //Throw away Offers
        buffClient1.readLine();
        buffClient2.readLine();

        //Wait for Strike
        StrikeMessage player1Strike1 = gson.fromJson(buffClient1.readLine(), StrikeMessage.class);
        StrikeMessage player2Strike1 = gson.fromJson(buffClient2.readLine(), StrikeMessage.class);

        assertTrue(player1Strike1.isValid());
        assertTrue(player2Strike1.isValid());

        assertEquals(player1Strike1.clientId, player1);
        assertEquals(player1Strike1.strikeNr, 1);
        assertEquals(player1Strike1.strikeMax, mainServerLogic.initialMatchconfig.getStrikeMaximum());

        assertEquals(player2Strike1.clientId, player2);
        assertEquals(player2Strike1.strikeNr, 1);
        assertEquals(player2Strike1.strikeMax, mainServerLogic.initialMatchconfig.getStrikeMaximum());

        //Give the Server a little bit time to process
        Thread.sleep(100);

        //Check if the picks are made
        assertEquals(1, mainServerLogic.player1Gadgets.size());
        assertEquals(1, mainServerLogic.player2Gadgets.size());
        assertEquals(4, mainServerLogic.player1Characters.size());
        assertEquals(4, mainServerLogic.player2Characters.size());
        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if the strikes are reset on a correct pick
     */
    @Test
    public void testStrikeReset() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();
        //Throw away First offer
        buffClient1.readLine();
        buffClient2.readLine();

        //Wait for Strike
        StrikeMessage player1Strike1 = gson.fromJson(buffClient1.readLine(), StrikeMessage.class);
        StrikeMessage player2Strike1 = gson.fromJson(buffClient2.readLine(), StrikeMessage.class);

        assertTrue(player1Strike1.isValid());
        assertTrue(player1Strike1.isValid());

        assertEquals(player1Strike1.clientId, player1);
        assertEquals(player1Strike1.strikeNr, 1);
        assertEquals(player1Strike1.strikeMax, mainServerLogic.initialMatchconfig.getStrikeMaximum());

        assertEquals(player2Strike1.clientId, player2);
        assertEquals(player2Strike1.strikeNr, 1);
        assertEquals(player2Strike1.strikeMax, mainServerLogic.initialMatchconfig.getStrikeMaximum());

        randomCharacterChoice(gson, psClient1, buffClient1, player1);
        randomCharacterChoice(gson, psClient2, buffClient2, player2);
        //Give the Server a little bit time to process
        Thread.sleep(100);
        assertEquals(0, mainServerLogic.player1.clientInformation.getNumberOfStrikes());
        assertEquals(0, mainServerLogic.player2.clientInformation.getNumberOfStrikes());
        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if invalid picks lead to a game end
     */
    @Test
    public void testInvalidPickByPlayer1() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();
        //Throw away First offer
        buffClient2.readLine();

        String requestItemChoice;
        requestItemChoice = buffClient1.readLine();
        RequestItemChoiceMessage itemChoiceMessage = gson.fromJson(requestItemChoice, RequestItemChoiceMessage.class);

        assertTrue(itemChoiceMessage.isValid());

        ItemChoiceMessage itemChoiceMessage1 = new ItemChoiceMessage();
        itemChoiceMessage1.type = MessageTypeEnum.ITEM_CHOICE;
        itemChoiceMessage1.clientId = player1;
        itemChoiceMessage1.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        itemChoiceMessage1.debugMessage = "Test itemChoice message";
        itemChoiceMessage1.chosenCharacterId = UUID.randomUUID();
        itemChoiceMessage1.chosenGadget = null;
        String itemChoiceMessage1AsString = gson.toJson(itemChoiceMessage1);
        psClient1.println(itemChoiceMessage1AsString);

        Thread.sleep(100);

        ErrorMessage errorMessageOnClient1 = gson.fromJson(buffClient1.readLine(), ErrorMessage.class);
        assertTrue(errorMessageOnClient1.isValid());

        GameLeftMessage gameLeftMessageOnClient2 = gson.fromJson(buffClient2.readLine(), GameLeftMessage.class);
        assertTrue(gameLeftMessageOnClient2.isValid());
        assertEquals(mainServerLogic.clientIdPlayer1, gameLeftMessageOnClient2.leftUserId);

        StatisticsMessage statisticsMessageOnClient2 = gson.fromJson(buffClient2.readLine(), StatisticsMessage.class);
        assertTrue(gameLeftMessageOnClient2.isValid());
        assertEquals(VictoryEnum.VICTORY_BY_KICK, statisticsMessageOnClient2.reason);
        assertEquals(mainServerLogic.clientIdPlayer2, statisticsMessageOnClient2.winner);

        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if invalid picks lead to a game end
     */
    @Test
    public void testInvalidPickByPlayer2() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();
        //Throw away First offer
        buffClient1.readLine();

        String requestItemChoice;
        requestItemChoice = buffClient2.readLine();
        RequestItemChoiceMessage itemChoiceMessage = gson.fromJson(requestItemChoice, RequestItemChoiceMessage.class);

        assertTrue(itemChoiceMessage.isValid());

        ItemChoiceMessage itemChoiceMessage1 = new ItemChoiceMessage();
        itemChoiceMessage1.type = MessageTypeEnum.ITEM_CHOICE;
        itemChoiceMessage1.clientId = player1;
        itemChoiceMessage1.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        itemChoiceMessage1.debugMessage = "Test itemChoice message";
        itemChoiceMessage1.chosenCharacterId = null;
        itemChoiceMessage1.chosenGadget = GadgetEnum.DIAMOND_COLLAR;
        String itemChoiceMessage1AsString = gson.toJson(itemChoiceMessage1);
        psClient2.println(itemChoiceMessage1AsString);

        Thread.sleep(100);

        ErrorMessage errorMessageOnClient2 = gson.fromJson(buffClient2.readLine(), ErrorMessage.class);
        assertTrue(errorMessageOnClient2.isValid());

        GameLeftMessage gameLeftMessageOnClient1 = gson.fromJson(buffClient1.readLine(), GameLeftMessage.class);
        assertTrue(gameLeftMessageOnClient1.isValid());
        assertEquals(mainServerLogic.clientIdPlayer2, gameLeftMessageOnClient1.leftUserId);

        StatisticsMessage statisticsMessageOnClient1 = gson.fromJson(buffClient1.readLine(), StatisticsMessage.class);
        assertTrue(gameLeftMessageOnClient1.isValid());
        assertEquals(VictoryEnum.VICTORY_BY_KICK, statisticsMessageOnClient1.reason);
        assertEquals(mainServerLogic.clientIdPlayer1, statisticsMessageOnClient1.winner);

        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if a Client picks too many characters
     */
    @Test
    public void testPlayer1PickTooMayCharacters() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();

        //Let both Clients to their pick
        for (int i = 0; i < 4; i++) {
            randomCharacterChoice(gson, psClient1, buffClient1, player1);
            randomCharacterChoice(gson, psClient2, buffClient2, player2);
        }

        //Client1 is picking too many characters
        randomCharacterChoice(gson, psClient1, buffClient1, player1);
        buffClient2.readLine();

        Thread.sleep(100);

        ErrorMessage errorMessageOnClient1 = gson.fromJson(buffClient1.readLine(), ErrorMessage.class);
        assertTrue(errorMessageOnClient1.isValid());
        assertEquals("You picked too many characters", errorMessageOnClient1.debugMessage);

        GameLeftMessage gameLeftMessageOnClient2 = gson.fromJson(buffClient2.readLine(), GameLeftMessage.class);
        assertTrue(gameLeftMessageOnClient2.isValid());
        assertEquals(mainServerLogic.clientIdPlayer1, gameLeftMessageOnClient2.leftUserId);

        StatisticsMessage statisticsMessageOnClient2 = gson.fromJson(buffClient2.readLine(), StatisticsMessage.class);
        assertEquals(VictoryEnum.VICTORY_BY_KICK, statisticsMessageOnClient2.reason);
        assertEquals(mainServerLogic.clientIdPlayer2, statisticsMessageOnClient2.winner);

        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if a Client picks too many characters
     */
    @Test
    public void testPlayer2PickTooMayCharacters() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();

        //Let both Clients to their pick
        for (int i = 0; i < 4; i++) {
            randomCharacterChoice(gson, psClient1, buffClient1, player1);
            randomCharacterChoice(gson, psClient2, buffClient2, player2);
        }

        //Client1 is picking too many characters
        randomCharacterChoice(gson, psClient2, buffClient2, player2);
        buffClient1.readLine();

        Thread.sleep(100);

        ErrorMessage errorMessageOnClient2 = gson.fromJson(buffClient2.readLine(), ErrorMessage.class);
        assertTrue(errorMessageOnClient2.isValid());
        assertEquals("You picked too many Characters", errorMessageOnClient2.debugMessage);

        GameLeftMessage gameLeftMessageOnClient1 = gson.fromJson(buffClient1.readLine(), GameLeftMessage.class);
        assertTrue(gameLeftMessageOnClient1.isValid());
        assertEquals(mainServerLogic.clientIdPlayer2, gameLeftMessageOnClient1.leftUserId);

        StatisticsMessage statisticsMessageOnClient1 = gson.fromJson(buffClient1.readLine(), StatisticsMessage.class);
        assertEquals(VictoryEnum.VICTORY_BY_KICK, statisticsMessageOnClient1.reason);
        assertEquals(mainServerLogic.clientIdPlayer1, statisticsMessageOnClient1.winner);

        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if a Client picks too many characters
     */
    @Test
    public void testPickTooFewCharacters() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();


        randomCharacterChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);
        randomGadgetChoice(gson, psClient1, buffClient1, player1);

        for (int i = 0; i < 4; i++) {
            randomCharacterChoice(gson, psClient2, buffClient2, player2);
        }
        for (int i = 0; i < 4; i++) {
            randomGadgetChoice(gson, psClient2, buffClient2, player2);
        }

        ErrorMessage errorMessage = gson.fromJson(buffClient1.readLine(), ErrorMessage.class);
        assertTrue(errorMessage.isValid());

        GameLeftMessage gameLeftMessageOnClient2 = gson.fromJson(buffClient2.readLine(), GameLeftMessage.class);
        assertTrue(gameLeftMessageOnClient2.isValid());
        assertEquals(mainServerLogic.clientIdPlayer1, gameLeftMessageOnClient2.leftUserId);

        StatisticsMessage statisticsMessageOnClient2 = gson.fromJson(buffClient2.readLine(), StatisticsMessage.class);
        assertEquals(VictoryEnum.VICTORY_BY_KICK, statisticsMessageOnClient2.reason);
        assertEquals(mainServerLogic.clientIdPlayer2, statisticsMessageOnClient2.winner);

        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if a pick sequence runs through and the new state is the EquipmentPhaseState
     */
    @Test
    public void testFullSequence() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();

        for (int i = 0; i < 4; i++) {
            randomCharacterChoice(gson, psClient1, buffClient1, player1);
            randomCharacterChoice(gson, psClient2, buffClient2, player2);
        }
        for (int i = 0; i < 4; i++) {
            randomGadgetChoice(gson, psClient1, buffClient1, player1);
            randomGadgetChoice(gson, psClient2, buffClient2, player2);
        }

        Thread.sleep(100);

        assertEquals(4, mainServerLogic.player1Characters.size());
        assertEquals(4, mainServerLogic.player1Gadgets.size());
        assertEquals(4, mainServerLogic.player2Characters.size());
        assertEquals(4, mainServerLogic.player2Gadgets.size());

        assertTrue(mainServerLogic.nonPlayerCharacter.size() >= 2);

        assertTrue(mainServerLogic.serverState instanceof EquipmentPhaseState);

        psClient1.write(-1);
        psClient2.write(-1);
        mainServerLogic.stop();
    }

    /**
     * Test if a GamePause request is handled correctly.
     */
    @Test
    public void testGamePause() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();

        mainServerLogic.stop();
    }

    /**
     * Test if a Reconnect is handled correctly
     */
    @Test
    public void testReconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //locally safe a linked to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;


        socketClient1.close();

        Thread.sleep(300);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        GamePauseMessage pauseMessage = gson.fromJson(buffClient2.readLine(), GamePauseMessage.class);
        assertTrue(pauseMessage.isValid());

        Socket socketClient3;
        socketClient3 = new Socket("localhost", 7007);
        OutputStream outClient3 = socketClient3.getOutputStream();
        PrintStream psClient3 = new PrintStream(outClient3, true);

        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient1.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;

        String jsonReconnect = gson.toJson(reconnectMessage);

        psClient3.println(jsonReconnect);

        Thread.sleep(100);

        assertFalse(mainServerLogic.player1.isDisconnected());

        assertSame(mainServerLogic.serverState, oldDecisionState);

        mainServerLogic.stop();
    }


    /**
     * IMPORTANT INFO: We can only assert that each HelloMessage got a UUID we can not assert that the first HelloMessage gets the UUID of Player1
     * WHY? Because we can not ensure that the first HelloMessage we sent will take the lock first ... the second Message, can of course takeover the lock
     * due to delays while processing the first HelloMessage (classical threading problem).
     *
     * @param gson            The used Parser
     * @param ps1             PrintStream of player one
     * @param buff1           BufferedReader of player one
     * @param ps2             PrintStream of player two
     * @param buff2           BufferedReader of player two
     * @param mainServerLogic an instance of the MainServerLogic
     * @throws IOException          this exception could occur
     * @throws InterruptedException this exception could occur
     */
    private static void setupConnection(Gson gson, PrintStream ps1, BufferedReader buff1, PrintStream ps2, BufferedReader buff2, MainServerLogic mainServerLogic) throws IOException, InterruptedException {
        HelloMessage helloMessage1 = new HelloMessage();
        helloMessage1.clientId = null;
        helloMessage1.creationDate = "";
        helloMessage1.debugMessage = "Test hello message";
        helloMessage1.name = "TestPlayer1";
        helloMessage1.role = RoleEnum.PLAYER;
        helloMessage1.type = MessageTypeEnum.HELLO;

        String jsonString = gson.toJson(helloMessage1);
        ps1.println(jsonString);

        Thread.sleep(500);

        HelloMessage helloMessage2 = new HelloMessage();
        helloMessage2.clientId = null;
        helloMessage2.creationDate = "";
        helloMessage2.debugMessage = "16.11.1922 10:34:46";
        helloMessage2.name = "TestPlayer2";
        helloMessage2.role = RoleEnum.PLAYER;
        helloMessage2.type = MessageTypeEnum.HELLO;


        jsonString = gson.toJson(helloMessage2);
        ps2.println(jsonString);

        HelloReplyMessage replyMessage1 = gson.fromJson(buff1.readLine(), HelloReplyMessage.class);
        HelloReplyMessage replyMessage2 = gson.fromJson(buff2.readLine(), HelloReplyMessage.class);

        assertTrue(replyMessage1.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage1.clientId.equals(mainServerLogic.clientIdPlayer2));
        assertTrue(replyMessage2.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage2.clientId.equals(mainServerLogic.clientIdPlayer2));
        assertNotEquals(replyMessage1.clientId, replyMessage2.clientId);

        Thread.sleep(500);
    }

    private static UUID connectNewPlayer(Gson gson, PrintStream ps, BufferedReader buff, MainServerLogic mainServerLogic) throws IOException {
        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = "";
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "TestPlayer1";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;

        String jsonString = gson.toJson(helloMessage);
        ps.println(jsonString);

        HelloReplyMessage replyMessage = gson.fromJson(buff.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertTrue(replyMessage.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage.clientId.equals(mainServerLogic.clientIdPlayer2));
        return replyMessage.clientId;
    }

    private static void randomCharacterChoice(Gson gson, PrintStream ps, BufferedReader buff, UUID clientID) throws IOException {
        String requestItemChoice;
        requestItemChoice = buff.readLine();
        RequestItemChoiceMessage itemChoiceMessage = gson.fromJson(requestItemChoice, RequestItemChoiceMessage.class);

        assertTrue(itemChoiceMessage.isValid());

        ItemChoiceMessage itemChoiceMessage1 = new ItemChoiceMessage();
        itemChoiceMessage1.type = MessageTypeEnum.ITEM_CHOICE;
        itemChoiceMessage1.clientId = clientID;
        itemChoiceMessage1.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        itemChoiceMessage1.debugMessage = "Test itemChoice message";
        itemChoiceMessage1.chosenCharacterId = itemChoiceMessage.offeredCharacterIds.get(0);
        itemChoiceMessage1.chosenGadget = null;
        String itemChoiceMessage1AsString = gson.toJson(itemChoiceMessage1);
        ps.println(itemChoiceMessage1AsString);
    }

    private static void randomGadgetChoice(Gson gson, PrintStream ps, BufferedReader buff, UUID clientID) throws IOException {
        String requestItemChoice;
        requestItemChoice = buff.readLine();
        RequestItemChoiceMessage itemChoiceMessage = gson.fromJson(requestItemChoice, RequestItemChoiceMessage.class);

        assertTrue(itemChoiceMessage.isValid());

        ItemChoiceMessage itemChoiceMessage1 = new ItemChoiceMessage();
        itemChoiceMessage1.type = MessageTypeEnum.ITEM_CHOICE;
        itemChoiceMessage1.clientId = clientID;
        itemChoiceMessage1.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        itemChoiceMessage1.debugMessage = "Test itemChoice message";
        itemChoiceMessage1.chosenCharacterId = null;
        itemChoiceMessage1.chosenGadget = itemChoiceMessage.offeredGadgets.get(0);
        String itemChoiceMessage1AsString = gson.toJson(itemChoiceMessage1);
        ps.println(itemChoiceMessage1AsString);
    }
}
