package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.GambleLogic;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidChipAmountException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;


/**
 * Class to test the methods for the class GambleLogic.
 *
 * @author Marcel Rötzer
 * @version 1.0
 */
public class GambleLogicTest {
    private FieldMap map;
    private Set<Character> characters;
    private Character jamesBond;
    private Character drNo;
    private Character q;
    private Character m;
    private Character eve;
    private Set<Character> charactersPlayer1;
    private Set<Character> charactersPlayer2;
    private Matchconfig matchconfig;

    /**
     * Method to create a test setup
     */
    public void setup() {
        // Set up map
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        map = new FieldMap(fields);

        // Set up characters
        jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(4, 5), new HashSet<>(), new HashSet<>());
        q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
        matchconfig = new Matchconfig();
        charactersPlayer1 = new HashSet<>();
        //charactersPlayer1.add(jamesBond);
        charactersPlayer2 = new HashSet<>();
        //charactersPlayer2.add(eve);
    }

    @Test
    public void testGambleAction() throws InvalidTargetException, InvalidChipAmountException {
        // Setup
        setup();

        // Case 1: Q targets Point (2/2): no neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> GambleLogic.gambleAction(q, map, new Point(1, 1), 5));

        // Case 2: Q targets Point (2/2): neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> GambleLogic.gambleAction(q, map, new Point(2, 2), 5));

        // Case 3: Q targets Point (3/3): neighbour / roulette-table / destroyed
        map.getField(new Point(3, 3)).setDestroyed(true);
        assertThrows(InvalidTargetException.class, () -> GambleLogic.gambleAction(q, map, new Point(3, 3), 5));

        // Case 4: Q targets Point (3/3): neighbour / roulette-table / not destroyed / false chip amount
        map.getField(new Point(3, 3)).setDestroyed(false);
        map.getField(new Point(3, 3)).setChipAmount(3);
        assertThrows(InvalidChipAmountException.class, () -> GambleLogic.gambleAction(q, map, new Point(3, 3), 5));

        // Case 5: Q targets Point (3/3): neighbour / roulette-table / not destroyed / correct chip amount
        map.getField(new Point(3, 3)).setChipAmount(10);
        // If gamble successful:
        if (GambleLogic.gambleAction(q, map, new Point(3, 3), 5)) {
            assertEquals(15, q.getChips());
            assertEquals(5, map.getField(new Point(3, 3)).getChipAmount());
        }
        // If gamble not successful:
        else {
            assertEquals(5, q.getChips());
            assertEquals(15, map.getField(new Point(3, 3)).getChipAmount());
        }

        int tries = 100;

        // Case 6: Success chance / no gadget / no property
        map.getField(new Point(3, 3)).setChipAmount(tries);
        double success = 0;
        for (int i = 0; i < tries; i++) {
            if (GambleLogic.gambleAction(q, map, new Point(3, 3), 1)) {
                success = success + 1.0;
            }
        }

        // Case 7: Success chance / tradecraft / no property
        q.addProperty(PropertyEnum.TRADECRAFT);
        map.getField(new Point(3, 3)).setChipAmount(tries);
        double success1 = 0;
        for (int i = 0; i < tries; i++) {
            if (GambleLogic.gambleAction(q, map, new Point(3, 3), 1)) {
                success1 = success1 + 1.0;
            }
        }

        // Case 8: Success chance / tradecraft / lucky devil
        q.addProperty(PropertyEnum.LUCKY_DEVIL);
        map.getField(new Point(3, 3)).setChipAmount(tries);
        double success2 = 0;
        for (int i = 0; i < tries; i++) {
            if (GambleLogic.gambleAction(q, map, new Point(3, 3), 1)) {
                success2 = success2 + 1.0;
            }
        }

        // Case 9: Success chance / no tradecraft / jinx
        q.removeProperty(PropertyEnum.TRADECRAFT);
        q.removeProperty(PropertyEnum.LUCKY_DEVIL);
        q.addProperty(PropertyEnum.JINX);
        map.getField(new Point(3, 3)).setChipAmount(tries);
        double success3 = 0;
        for (int i = 0; i < tries; i++) {
            if (GambleLogic.gambleAction(q, map, new Point(3, 3), 1)) {
                success3 = success3 + 1.0;
            }
        }

        // Case 10: Success chance / no tradecraft / no properties / inverted roulette table
        q.removeProperty(PropertyEnum.JINX);
        map.getField(new Point(3, 3)).setInverted(true);
        map.getField(new Point(3, 3)).setChipAmount(tries);
        double success4 = 0;
        for (int i = 0; i < tries; i++) {
            if (GambleLogic.gambleAction(q, map, new Point(3, 3), 1)) {
                success4 = success4 + 1.0;
            }
        }
    }
}
