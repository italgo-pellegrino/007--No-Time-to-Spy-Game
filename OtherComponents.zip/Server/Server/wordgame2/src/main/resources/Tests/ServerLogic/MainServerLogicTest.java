package Tests.ServerLogic;

import com.google.gson.Gson;
import de.uulm.team0015.server.controller.ServerLogger;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.EquipmentPhaseState;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.MessageContainer;
import de.uulm.team0015.server.model.Messages.Receive.EquipmentChoiceMessage;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Receive.ItemChoiceMessage;
import de.uulm.team0015.server.model.Messages.Receive.RequestMetaInformationMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import de.uulm.team0015.server.model.Messages.Send.MetaInformationMessage;
import de.uulm.team0015.server.model.Messages.Send.RequestEquipmentChoiceMessage;
import de.uulm.team0015.server.model.Messages.Send.RequestItemChoiceMessage;
import org.junit.Test;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.logging.Level;

import static org.junit.Assert.*;

public class MainServerLogicTest {
    private static UUID player1;

    @Test
    public void testOnRequestMetaInformationMessage() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        ServerLogger.setLevel(Level.FINEST);
        Gson gson = new Gson();

        Socket socketClient1;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        setupGamePhase(gson, psClient1, psClient2, buffClient1, buffClient2, mainServerLogic);

        RequestMetaInformationMessage requestMetaInformationMessage = new RequestMetaInformationMessage();
        requestMetaInformationMessage.clientId = player1;
        requestMetaInformationMessage.creationDate = "";
        String[] keys = new String[11];
        keys[0] = "Configuration.Scenario";
        keys[1] = "Configuration.Matchconfig";
        keys[2] = "Configuration.CharacterDescriptions";
        keys[3] = "Faction.Player1";
        keys[4] = "Gadgets.Player1";
        keys[5] = "Gadgets.Player2";
        keys[6] = "Spectator.Count";
        keys[7] = "Spectator.Names";
        keys[8] = "Player.Count";
        keys[9] = "Player.Names";
        keys[10] = "Game.RemainingPauseTime";
        requestMetaInformationMessage.keys = keys;
        requestMetaInformationMessage.debugMessage = "Request by player";
        requestMetaInformationMessage.type = MessageTypeEnum.REQUEST_META_INFORMATION;
        psClient1.println(gson.toJson(requestMetaInformationMessage));

        String received = buffClient1.readLine();
        MessageContainer container = gson.fromJson(received, MessageContainer.class);
        if (container.type.equals(MessageTypeEnum.META_INFORMATION)) {
            MetaInformationMessage metaInformationMessage = gson.fromJson(received, MetaInformationMessage.class);
            assertEquals(2.0, metaInformationMessage.information.get("Player.Count"));
            assertNotNull(metaInformationMessage.information.get("Configuration.Scenario"));
            assertNotNull(metaInformationMessage.information.get("Configuration.Matchconfig"));
            assertNotNull(metaInformationMessage.information.get("Configuration.CharacterDescriptions"));
            assertNotNull(metaInformationMessage.information.get("Faction.Player1"));
            assertNotNull(metaInformationMessage.information.get("Gadgets.Player1"));
            assertNull(metaInformationMessage.information.get("Gadgets.Player2"));
            assertEquals(0.0, metaInformationMessage.information.get("Spectator.Count"));
            assertNotNull(metaInformationMessage.information.get("Spectator.Names"));
            assertTrue(((ArrayList<String>) metaInformationMessage.information.get("Player.Names")).contains("TestPlayer1"));
            assertTrue(((ArrayList<String>) metaInformationMessage.information.get("Player.Names")).contains("TestPlayer2"));
        }
        mainServerLogic.stop();
    }

    /**
     * This method sets the server to the GamePhaseState with two players which both made their picks
     */
    private static void setupGamePhase(Gson gson, PrintStream psClient1, PrintStream psClient2, BufferedReader buffClient1, BufferedReader buffClient2, MainServerLogic mainServerLogic) throws IOException, InterruptedException {

        player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic, "TestPlayer1");
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic, "TestPlayer2");
        Thread.sleep(100);
        //Throw away GameStartedMessage
        buffClient1.readLine();
        buffClient2.readLine();

        for (int i = 0; i < 4; i++) {
            randomCharacterChoice(gson, psClient1, buffClient1, player1);
            randomCharacterChoice(gson, psClient2, buffClient2, player2);
        }
        for (int i = 0; i < 4; i++) {
            randomGadgetChoice(gson, psClient1, buffClient1, player1);
            randomGadgetChoice(gson, psClient2, buffClient2, player2);
        }

        Thread.sleep(100);

        assertEquals(4, mainServerLogic.player1Characters.size());
        assertEquals(4, mainServerLogic.player1Gadgets.size());
        assertEquals(4, mainServerLogic.player2Characters.size());
        assertEquals(4, mainServerLogic.player2Gadgets.size());

        assertTrue(mainServerLogic.nonPlayerCharacter.size() >= 2);

        assertTrue(mainServerLogic.serverState instanceof EquipmentPhaseState);

        RequestEquipmentChoiceMessage requestEquipmentChoiceMessage1 = gson.fromJson(buffClient1.readLine(), RequestEquipmentChoiceMessage.class);
        RequestEquipmentChoiceMessage requestEquipmentChoiceMessage2 = gson.fromJson(buffClient2.readLine(), RequestEquipmentChoiceMessage.class);

        makeEquipmentChoice(requestEquipmentChoiceMessage1, psClient1, player1, gson);
        Thread.sleep(50);
        makeEquipmentChoice(requestEquipmentChoiceMessage2, psClient2, player2, gson);

        buffClient1.readLine();
        buffClient1.readLine();
    }


    private static void makeEquipmentChoice(RequestEquipmentChoiceMessage equipmentChoiceMessage, PrintStream ps, UUID clientId, Gson gson) {
        Map<UUID, Set<GadgetEnum>> equipment = new HashMap<>();
        Random random = new Random();

        for (int i = 0; i < equipmentChoiceMessage.chosenCharacterIds.size() - 1; i++) {
            UUID character = equipmentChoiceMessage.chosenCharacterIds.get(i);
            Set<GadgetEnum> gadgetEnums = new HashSet<>();
            if (equipmentChoiceMessage.chosenGadgets.size() > 0) {
                int gadgetIndex = random.nextInt(equipmentChoiceMessage.chosenGadgets.size());
                gadgetEnums.add(equipmentChoiceMessage.chosenGadgets.get(gadgetIndex));
                equipmentChoiceMessage.chosenGadgets.remove(gadgetIndex);
            }
            equipment.put(character, gadgetEnums);
        }

        Set<GadgetEnum> gadgetEnums = new HashSet<>(equipmentChoiceMessage.chosenGadgets);

        equipment.put(equipmentChoiceMessage.chosenCharacterIds.get(equipmentChoiceMessage.chosenCharacterIds.size() - 1), gadgetEnums);

        EquipmentChoiceMessage choiceMessage = new EquipmentChoiceMessage();
        choiceMessage.type = MessageTypeEnum.EQUIPMENT_CHOICE;
        choiceMessage.clientId = clientId;
        choiceMessage.creationDate = "";
        choiceMessage.debugMessage = "Test Equipment message";
        choiceMessage.equipment = equipment;
        String equipmentChoiceMessage1AsString = gson.toJson(choiceMessage);
        ps.println(equipmentChoiceMessage1AsString);
    }

    private static UUID connectNewPlayer(Gson gson, PrintStream ps, BufferedReader buff, MainServerLogic mainServerLogic, String name) throws IOException {
        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = "";
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = name;
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;

        String jsonString = gson.toJson(helloMessage);
        ps.println(jsonString);

        HelloReplyMessage replyMessage = gson.fromJson(buff.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertTrue(replyMessage.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage.clientId.equals(mainServerLogic.clientIdPlayer2));
        return replyMessage.clientId;
    }

    private static void randomCharacterChoice(Gson gson, PrintStream ps, BufferedReader buff, UUID clientID) throws IOException {
        String requestItemChoice;
        requestItemChoice = buff.readLine();
        RequestItemChoiceMessage itemChoiceMessage = gson.fromJson(requestItemChoice, RequestItemChoiceMessage.class);

        assertTrue(itemChoiceMessage.isValid());

        ItemChoiceMessage itemChoiceMessage1 = new ItemChoiceMessage();
        itemChoiceMessage1.type = MessageTypeEnum.ITEM_CHOICE;
        itemChoiceMessage1.clientId = clientID;
        itemChoiceMessage1.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        itemChoiceMessage1.debugMessage = "Test itemChoice message";
        itemChoiceMessage1.chosenCharacterId = itemChoiceMessage.offeredCharacterIds.get(0);
        itemChoiceMessage1.chosenGadget = null;
        String itemChoiceMessage1AsString = gson.toJson(itemChoiceMessage1);
        ps.println(itemChoiceMessage1AsString);
    }

    private static void randomGadgetChoice(Gson gson, PrintStream ps, BufferedReader buff, UUID clientID) throws IOException {
        String requestItemChoice;
        requestItemChoice = buff.readLine();
        RequestItemChoiceMessage itemChoiceMessage = gson.fromJson(requestItemChoice, RequestItemChoiceMessage.class);

        assertTrue(itemChoiceMessage.isValid());

        ItemChoiceMessage itemChoiceMessage1 = new ItemChoiceMessage();
        itemChoiceMessage1.type = MessageTypeEnum.ITEM_CHOICE;
        itemChoiceMessage1.clientId = clientID;
        itemChoiceMessage1.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        itemChoiceMessage1.debugMessage = "Test itemChoice message";
        itemChoiceMessage1.chosenCharacterId = null;
        itemChoiceMessage1.chosenGadget = itemChoiceMessage.offeredGadgets.get(0);
        String itemChoiceMessage1AsString = gson.toJson(itemChoiceMessage1);
        ps.println(itemChoiceMessage1AsString);
    }
}
