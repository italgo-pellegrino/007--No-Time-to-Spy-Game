package Tests.SetupLogic;

import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * Test for the ScenarioLoader
 */
public class MatchConfigLoaderTest {

    @Test
    public void testMatchConfigLoader() {
        MatchConfigLoader loader = new MatchConfigLoader();
        Matchconfig matchconfig = loader.load();

        assertTrue(matchconfig.getGrappleHitChance() < 1);
        assertTrue(matchconfig.getGrappleHitChance() > 0);

        assertTrue(matchconfig.getBowlerBladeHitChance() < 1);
        assertTrue(matchconfig.getBowlerBladeHitChance() > 0);

        assertTrue(matchconfig.getLaserCompactHitChance() < 1);
        assertTrue(matchconfig.getLaserCompactHitChance() > 0);

        assertTrue(matchconfig.getWiretapWithEarplugsFailChance() < 1);
        assertTrue(matchconfig.getWiretapWithEarplugsFailChance() > 0);

        assertTrue(matchconfig.getMirrorSwapChance() < 1);
        assertTrue(matchconfig.getMirrorSwapChance() > 0);

        assertTrue(matchconfig.getCocktailDodgeChance() < 1);
        assertTrue(matchconfig.getCocktailDodgeChance() > 0);

        assertTrue(matchconfig.getSpySuccessChance() < 1);
        assertTrue(matchconfig.getSpySuccessChance() > 0);

        assertTrue(matchconfig.getBabysitterSuccessChance() < 1);
        assertTrue(matchconfig.getBabysitterSuccessChance() > 0);

        assertTrue(matchconfig.getObservationSuccessChance() < 1);
        assertTrue(matchconfig.getObservationSuccessChance() > 0);
    }
}
