package Tests.SetupLogic;

import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.CharacterInformation;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * This class contains a test for hte CharactersLoader
 */
public class CharactersLoaderTest {

    @Test
    public void testCharactersLoader() {
        CharactersLoader loader = new CharactersLoader();
        CharacterInformation[] characterInformation = loader.load();

        for (CharacterInformation information : characterInformation) {
            assertNotNull(information.getCharacterId());
            assertNotNull(information.getDescription());
            assertNotNull(information.getFeatures());
            assertNotNull(information.getGender());
            assertTrue(information.getName().length() >= 3);
        }

    }
}
