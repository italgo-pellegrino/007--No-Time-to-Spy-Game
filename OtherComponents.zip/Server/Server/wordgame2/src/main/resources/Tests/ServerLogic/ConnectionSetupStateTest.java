package Tests.ServerLogic;

import com.google.gson.Gson;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.ConnectionSetupState;
import de.uulm.team0015.server.controller.ServerLogic.states.ServerState;
import de.uulm.team0015.server.controller.ServerLogic.states.ServerStateEnum;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import org.junit.Test;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;

import static org.junit.Assert.*;

public class ConnectionSetupStateTest {

    /**
     * This Test checks if the initial Serverstate is a ConnectionSetupState.
     */
    @Test
    public void testInitialState() {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        assertTrue(mainServerLogic.serverState instanceof ConnectionSetupState);
        assertEquals(ServerState.activeState, ServerStateEnum.CONNECTION_SETUP_STATE);
        mainServerLogic.stop();
    }

    /**
     * This Test checks a client registration is working correctly for Player1.
     */
    @Test
    public void testPlayer1Connection() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);

        assertNull(mainServerLogic.player1);

        Socket socket = null;
        socket = new Socket("localhost", 7007);
        OutputStream raus = socket.getOutputStream();
        PrintStream ps = new PrintStream(raus, true);
        InputStream rein = socket.getInputStream();
        BufferedReader buff = new BufferedReader(new InputStreamReader(rein, StandardCharsets.UTF_8));
        Gson gson = new Gson();

        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "Klaus";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;


        String jsonString = gson.toJson(helloMessage);
        ps.println(jsonString);

        //Wait till the Server processed the Message
        Thread.sleep(1000);

        //Assert that the player is registered
        assertNotNull(mainServerLogic.player1);
        //Assert that the Client got a valid message with a UUID and the Server has the same UUID for this Client
        HelloReplyMessage replyMessage = gson.fromJson(buff.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertEquals(replyMessage.clientId, mainServerLogic.clientIdPlayer1);
        raus.close();
        mainServerLogic.stop();
    }

    /**
     * This Test checks a client registration is working for both Players
     * and if the Server swaps to the DecisionPhaseState.
     */
    @Test
    public void testPlayer2Connection() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);

        assertNull(mainServerLogic.player1);

        Socket socketPlayer1 = null;
        socketPlayer1 = new Socket("localhost", 7007);
        OutputStream rausPlayer1 = socketPlayer1.getOutputStream();
        PrintStream psPlayer1 = new PrintStream(rausPlayer1, true);
        InputStream reinPlayer1 = socketPlayer1.getInputStream();
        BufferedReader buffPlayer1 = new BufferedReader(new InputStreamReader(reinPlayer1, StandardCharsets.UTF_8));
        Gson gson = new Gson();

        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "TestPlayer1";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;


        String jsonString = gson.toJson(helloMessage);
        psPlayer1.println(jsonString);

        //Wait till the Server processed the Message
        Thread.sleep(500);

        //Assert that the player is registered
        assertNotNull(mainServerLogic.player1);
        assertEquals(mainServerLogic.player1.clientInformation.getName(), "TestPlayer1");
        //Assert that the Client got a valid message with a UUID and the Server has the same UUID for this Client
        HelloReplyMessage replyMessage = gson.fromJson(buffPlayer1.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertEquals(replyMessage.clientId, mainServerLogic.clientIdPlayer1);

        Socket socketPlayer2 = null;
        socketPlayer2 = new Socket("localhost", 7007);
        OutputStream rausPlayer2 = socketPlayer2.getOutputStream();
        PrintStream psPlayer2 = new PrintStream(rausPlayer2, true);
        InputStream reinPlayer2 = socketPlayer2.getInputStream();
        BufferedReader buffPlayer2 = new BufferedReader(new InputStreamReader(reinPlayer2, StandardCharsets.UTF_8));

        HelloMessage helloMessage2 = new HelloMessage();
        helloMessage2.clientId = null;
        helloMessage2.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        helloMessage2.debugMessage = "Test hello message";
        helloMessage2.name = "TestPlayer2";
        helloMessage2.role = RoleEnum.PLAYER;
        helloMessage2.type = MessageTypeEnum.HELLO;


        jsonString = gson.toJson(helloMessage2);
        psPlayer2.println(jsonString);

        //Wait till the Server processed the Message
        Thread.sleep(500);

        //Assert that the player is registered
        assertNotNull(mainServerLogic.player2);
        assertEquals(mainServerLogic.player2.clientInformation.getName(), "TestPlayer2");
        //Assert that the Client got a valid message with a UUID and the Server has the same UUID for this Client
        HelloReplyMessage replyMessage2 = gson.fromJson(buffPlayer2.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage2.isValid());
        assertEquals(replyMessage2.clientId, mainServerLogic.clientIdPlayer2);

        rausPlayer1.close();
        rausPlayer2.close();
        mainServerLogic.stop();
    }

    /**
     * This Test checks if the slot for Player1 is freed after a disconnect.
     */
    @Test
    public void testClient1Disconnect() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);

        assertNull(mainServerLogic.player1);

        Socket socketPlayer1 = null;
        socketPlayer1 = new Socket("localhost", 7007);
        OutputStream rausPlayer1 = socketPlayer1.getOutputStream();
        PrintStream psPlayer1 = new PrintStream(rausPlayer1, true);
        InputStream reinPlayer1 = socketPlayer1.getInputStream();
        BufferedReader buffPlayer1 = new BufferedReader(new InputStreamReader(reinPlayer1, StandardCharsets.UTF_8));
        Gson gson = new Gson();

        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "TestPlayer1";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;


        String jsonString = gson.toJson(helloMessage);
        psPlayer1.println(jsonString);

        //Wait till the Server processed the Message
        Thread.sleep(500);

        assertNotNull(mainServerLogic.player1);
        assertEquals(mainServerLogic.player1.clientInformation.getName(), "TestPlayer1");

        psPlayer1.close();
        buffPlayer1.close();
        socketPlayer1.close();


        Thread.sleep(500);

        assertNull(mainServerLogic.player1);
        mainServerLogic.stop();
    }

}
