package Tests.ServerLogic;

import com.google.gson.Gson;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.*;
import de.uulm.team0015.server.controller.SetupLogic.CharactersLoader;
import de.uulm.team0015.server.controller.SetupLogic.MatchConfigLoader;
import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.Enumerations.MessageTypeEnum;
import de.uulm.team0015.server.model.Enumerations.RoleEnum;
import de.uulm.team0015.server.model.Messages.Receive.HelloMessage;
import de.uulm.team0015.server.model.Messages.Receive.ReconnectMessage;
import de.uulm.team0015.server.model.Messages.Receive.RequestGamePauseMessage;
import de.uulm.team0015.server.model.Messages.Send.GamePauseMessage;
import de.uulm.team0015.server.model.Messages.Send.GameStartedMessage;
import de.uulm.team0015.server.model.Messages.Send.HelloReplyMessage;
import org.junit.Test;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class GamePauseStateTest {

    /**
     * Test if a Reconnect is handled correctly
     */
    @Test
    public void testPlayerOnePauseAndTimer() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;


        //Set pauseLimit to 10
        mainServerLogic.initialMatchconfig.setPauseLimit(10);

        // Pause Game with Client 1
        RequestGamePauseMessage requestGamePauseMessage = new RequestGamePauseMessage();
        requestGamePauseMessage.clientId = player1;
        requestGamePauseMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        requestGamePauseMessage.debugMessage = "Player1 request Pause";
        requestGamePauseMessage.gamePause = true;
        requestGamePauseMessage.type = MessageTypeEnum.REQUEST_GAME_PAUSE;
        String jsonRequestGamePauseMessage = gson.toJson(requestGamePauseMessage);
        psClient1.println(jsonRequestGamePauseMessage);


        Thread.sleep(100);

        // Read gamePause
        GamePauseMessage gamePauseMessageClient1 = gson.fromJson(buffClient1.readLine(), GamePauseMessage.class);
        assertTrue(gamePauseMessageClient1.isValid());

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof GamePauseState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_PAUSE_STATE);

        // Wait until pause timer is over
        Thread.sleep(mainServerLogic.initialMatchconfig.getPauseLimit() * 1000 + 100);

        // Assert that state has switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
        assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
        assertEquals(mainServerLogic.serverState, oldDecisionState);

        mainServerLogic.stop();
    }

    @Test
    public void testPlayerOnePauseAndUnpause() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;


        //Set pauseLimit to 10
        mainServerLogic.initialMatchconfig.setPauseLimit(10);

        // Pause Game with Client 1
        RequestGamePauseMessage requestGamePauseMessage = new RequestGamePauseMessage();
        requestGamePauseMessage.clientId = player1;
        requestGamePauseMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        requestGamePauseMessage.debugMessage = "Player1 request Pause";
        requestGamePauseMessage.gamePause = true;
        requestGamePauseMessage.type = MessageTypeEnum.REQUEST_GAME_PAUSE;
        String jsonRequestGamePauseMessage = gson.toJson(requestGamePauseMessage);
        psClient1.println(jsonRequestGamePauseMessage);


        Thread.sleep(100);

        // Read gamePause
        GamePauseMessage gamePauseMessageClient1 = gson.fromJson(buffClient1.readLine(), GamePauseMessage.class);
        assertTrue(gamePauseMessageClient1.isValid());

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof GamePauseState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_PAUSE_STATE);

        requestGamePauseMessage.gamePause = false;
        jsonRequestGamePauseMessage = gson.toJson(requestGamePauseMessage);
        psClient1.println(jsonRequestGamePauseMessage);

        Thread.sleep(150);

        // Assert that state has switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
        assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
        assertEquals(mainServerLogic.serverState, oldDecisionState);

        mainServerLogic.stop();
    }

    /**
     * Tests pausing, connecting and reconnecting while pausing and checks if timer has been paused correctly
     *
     * @throws IOException
     * @throws InterruptedException
     */
    @Test
    public void testPlayerOnePauseAndReconnectAndTimer() throws IOException, InterruptedException {
        MainServerLogic mainServerLogic = new MainServerLogic(new ScenarioLoader(), new MatchConfigLoader(), new CharactersLoader(), 7007, 33);
        Gson gson = new Gson();

        Socket socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        OutputStream outClient1 = socketClient1.getOutputStream();
        PrintStream psClient1 = new PrintStream(outClient1, true);
        InputStream inClient1 = socketClient1.getInputStream();
        BufferedReader buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        Socket socketClient2 = null;
        socketClient2 = new Socket("localhost", 7007);
        OutputStream outClient2 = socketClient2.getOutputStream();
        PrintStream psClient2 = new PrintStream(outClient2, true);
        InputStream inClient2 = socketClient2.getInputStream();
        BufferedReader buffClient2 = new BufferedReader(new InputStreamReader(inClient2, StandardCharsets.UTF_8));

        UUID player1 = connectNewPlayer(gson, psClient1, buffClient1, mainServerLogic);
        Thread.sleep(500);
        UUID player2 = connectNewPlayer(gson, psClient2, buffClient2, mainServerLogic);
        Thread.sleep(100);
        //Throw away GameStartedMessage
        GameStartedMessage gameStartedMessageClient1 = gson.fromJson(buffClient1.readLine(), GameStartedMessage.class);
        GameStartedMessage gameStartedMessageClient2 = gson.fromJson(buffClient2.readLine(), GameStartedMessage.class);
        //localy safe a linkt to the decision state
        DecisionPhaseState oldDecisionState = (DecisionPhaseState) mainServerLogic.serverState;


        //Set pauseLimit to 10
        mainServerLogic.initialMatchconfig.setPauseLimit(10);

        // Pause Game with Client 1
        RequestGamePauseMessage requestGamePauseMessage = new RequestGamePauseMessage();
        requestGamePauseMessage.clientId = player1;
        requestGamePauseMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        requestGamePauseMessage.debugMessage = "Player1 request Pause";
        requestGamePauseMessage.gamePause = true;
        requestGamePauseMessage.type = MessageTypeEnum.REQUEST_GAME_PAUSE;
        String jsonRequestGamePauseMessage = gson.toJson(requestGamePauseMessage);
        psClient1.println(jsonRequestGamePauseMessage);


        Thread.sleep(100);

        // Read gamePause
        GamePauseMessage gamePauseMessageClient1 = gson.fromJson(buffClient1.readLine(), GamePauseMessage.class);
        assertTrue(gamePauseMessageClient1.isValid());

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof GamePauseState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_PAUSE_STATE);
        GamePauseState oldGamePauseState = (GamePauseState) mainServerLogic.serverState;

        Thread.sleep(20);
        int oldTime = oldGamePauseState.getRemainingTime();

        socketClient1.close();

        Thread.sleep(100);

        //Assert that the Server is now in the Reconnect state
        assertTrue(mainServerLogic.serverState instanceof ReconnectState);
        assertEquals(ServerState.activeState, ServerStateEnum.RECONNECT_STATE);

        // Assert true, that player 1 is disconnected
        assertTrue(mainServerLogic.player1.isDisconnected());

        // Create client and send ReconnectMessage
        socketClient1 = null;
        socketClient1 = new Socket("localhost", 7007);
        outClient1 = socketClient1.getOutputStream();
        psClient1 = new PrintStream(outClient1, true);
        inClient1 = socketClient1.getInputStream();
        buffClient1 = new BufferedReader(new InputStreamReader(inClient1, StandardCharsets.UTF_8));

        ReconnectMessage reconnectMessage = new ReconnectMessage();
        reconnectMessage.clientId = player1;
        reconnectMessage.creationDate = MainServerLogic.DATE_FORMAT.format(new Date(System.currentTimeMillis()));
        reconnectMessage.debugMessage = "Player1 request Reconnect";
        reconnectMessage.sessionId = gameStartedMessageClient1.sessionId;
        reconnectMessage.type = MessageTypeEnum.RECONNECT;

        String jsonReconnect = gson.toJson(reconnectMessage);

        Thread.sleep(3000);
        psClient1.println(jsonReconnect);

        Thread.sleep(50);


        // Assert that state has switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof GamePauseState);
        assertEquals(ServerState.activeState, ServerStateEnum.GAME_PAUSE_STATE);
        assertEquals(mainServerLogic.serverState, oldGamePauseState);
        // Check if timer has same time
        assertEquals(oldTime, ((GamePauseState) mainServerLogic.serverState).getRemainingTime());

        requestGamePauseMessage.gamePause = false;
        jsonRequestGamePauseMessage = gson.toJson(requestGamePauseMessage);
        psClient1.println(jsonRequestGamePauseMessage);

        Thread.sleep(100);

        // Assert that state has switched back to DecisionPhaseState and that it is the same
        assertTrue(mainServerLogic.serverState instanceof DecisionPhaseState);
        assertEquals(ServerState.activeState, ServerStateEnum.DECISION_PHASE_STATE);
        assertEquals(mainServerLogic.serverState, oldDecisionState);

        mainServerLogic.stop();
    }

    private static UUID connectNewPlayer(Gson gson, PrintStream ps, BufferedReader buff, MainServerLogic mainServerLogic) throws IOException, InterruptedException {
        HelloMessage helloMessage = new HelloMessage();
        helloMessage.clientId = null;
        helloMessage.creationDate = "asdfasdf";
        helloMessage.debugMessage = "Test hello message";
        helloMessage.name = "TestPlayer1";
        helloMessage.role = RoleEnum.PLAYER;
        helloMessage.type = MessageTypeEnum.HELLO;

        String jsonString = gson.toJson(helloMessage);
        ps.println(jsonString);

        HelloReplyMessage replyMessage = gson.fromJson(buff.readLine(), HelloReplyMessage.class);
        assertTrue(replyMessage.isValid());
        assertTrue(replyMessage.clientId.equals(mainServerLogic.clientIdPlayer1) || replyMessage.clientId.equals(mainServerLogic.clientIdPlayer2));
        return replyMessage.clientId;
    }
}
