package Tests.DataTypes;

import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Class to test the methods of the class Gadget.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class GadgetTest {

    @Test
    public void testUse() {
        // Setup
        Gadget poisonPills = new Gadget(GadgetEnum.POISON_PILLS, 5);
        Gadget moledie = new Gadget(GadgetEnum.MOLEDIE, 1);

        // Case 1: Gadget with more than on usages is being used.
        assertEquals(5, poisonPills.getUsages());
        poisonPills.use();
        assertEquals(4, poisonPills.getUsages());

        // Case 2: Gadget with one usage is being used.
        assertEquals(1, moledie.getUsages());
        moledie.use();
        assertEquals(0, moledie.getUsages());
    }
}
