package Tests.SetupLogic;

import de.uulm.team0015.server.controller.SetupLogic.ScenarioLoader;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Scenario;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Test for the ScenarioLoader
 */
public class ScenarioLoaderTest {

    @Test
    public void testScenarioLoader() {
        ScenarioLoader loader = new ScenarioLoader();
        Scenario scenario = loader.load();
        FieldStateEnum[][] map = scenario.getScenario();
        assertEquals(FieldStateEnum.WALL, map[0][0]);
        assertEquals(FieldStateEnum.WALL, map[1][0]);
        assertEquals(FieldStateEnum.WALL, map[2][0]);
        assertEquals(FieldStateEnum.WALL, map[3][0]);
        assertEquals(FieldStateEnum.WALL, map[4][0]);
        assertEquals(FieldStateEnum.WALL, map[5][0]);
        assertEquals(FieldStateEnum.WALL, map[6][0]);
        assertEquals(FieldStateEnum.WALL, map[7][0]);
        assertEquals(FieldStateEnum.WALL, map[8][0]);
        assertEquals(FieldStateEnum.WALL, map[9][0]);
        assertEquals(FieldStateEnum.WALL, map[10][0]);

        assertEquals(FieldStateEnum.WALL, map[0][0]);
        assertEquals(FieldStateEnum.FIREPLACE, map[1][1]);
        assertEquals(FieldStateEnum.FREE, map[2][1]);
        assertEquals(FieldStateEnum.BAR_TABLE, map[3][1]);
        assertEquals(FieldStateEnum.BAR_SEAT, map[4][1]);
        assertEquals(FieldStateEnum.FREE, map[5][1]);
        assertEquals(FieldStateEnum.SAFE, map[6][1]);
        assertEquals(FieldStateEnum.WALL, map[7][1]);
        assertEquals(FieldStateEnum.SAFE, map[8][1]);
        assertEquals(FieldStateEnum.WALL, map[9][1]);
        assertEquals(FieldStateEnum.WALL, map[10][1]);

        assertEquals(FieldStateEnum.WALL, map[0][2]);
        assertEquals(FieldStateEnum.WALL, map[1][2]);
        assertEquals(FieldStateEnum.FREE, map[2][2]);
        assertEquals(FieldStateEnum.FREE, map[3][2]);
        assertEquals(FieldStateEnum.FREE, map[4][2]);
        assertEquals(FieldStateEnum.FREE, map[5][2]);
        assertEquals(FieldStateEnum.FREE, map[6][2]);
        assertEquals(FieldStateEnum.WALL, map[7][2]);
        assertEquals(FieldStateEnum.FREE, map[8][2]);
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map[9][2]);
        assertEquals(FieldStateEnum.WALL, map[10][2]);

        assertEquals(FieldStateEnum.WALL, map[0][3]);
        assertEquals(FieldStateEnum.BAR_TABLE, map[1][3]);
        assertEquals(FieldStateEnum.FREE, map[2][3]);
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map[3][3]);
        assertEquals(FieldStateEnum.WALL, map[4][3]);
        assertEquals(FieldStateEnum.FREE, map[5][3]);
        assertEquals(FieldStateEnum.FREE, map[6][3]);
        assertEquals(FieldStateEnum.FREE, map[7][3]);
        assertEquals(FieldStateEnum.FREE, map[8][3]);
        assertEquals(FieldStateEnum.FREE, map[9][3]);
        assertEquals(FieldStateEnum.WALL, map[10][3]);

        assertEquals(FieldStateEnum.WALL, map[0][4]);
        assertEquals(FieldStateEnum.BAR_SEAT, map[1][4]);
        assertEquals(FieldStateEnum.FREE, map[2][4]);
        assertEquals(FieldStateEnum.FREE, map[3][4]);
        assertEquals(FieldStateEnum.FREE, map[4][4]);
        assertEquals(FieldStateEnum.BAR_TABLE, map[5][4]);
        assertEquals(FieldStateEnum.WALL, map[6][4]);
        assertEquals(FieldStateEnum.BAR_SEAT, map[7][4]);
        assertEquals(FieldStateEnum.FREE, map[8][4]);
        assertEquals(FieldStateEnum.FREE, map[9][4]);
        assertEquals(FieldStateEnum.WALL, map[10][4]);

        assertEquals(FieldStateEnum.WALL, map[0][5]);
        assertEquals(FieldStateEnum.FREE, map[1][5]);
        assertEquals(FieldStateEnum.FREE, map[2][5]);
        assertEquals(FieldStateEnum.FREE, map[3][5]);
        assertEquals(FieldStateEnum.FREE, map[4][5]);
        assertEquals(FieldStateEnum.BAR_SEAT, map[5][5]);
        assertEquals(FieldStateEnum.WALL, map[6][5]);
        assertEquals(FieldStateEnum.BAR_TABLE, map[7][5]);
        assertEquals(FieldStateEnum.SAFE, map[8][5]);
        assertEquals(FieldStateEnum.SAFE, map[9][5]);
        assertEquals(FieldStateEnum.WALL, map[10][5]);

        assertEquals(FieldStateEnum.WALL, map[0][6]);
        assertEquals(FieldStateEnum.WALL, map[1][6]);
        assertEquals(FieldStateEnum.WALL, map[2][6]);
        assertEquals(FieldStateEnum.WALL, map[3][6]);
        assertEquals(FieldStateEnum.WALL, map[4][6]);
        assertEquals(FieldStateEnum.WALL, map[5][6]);
        assertEquals(FieldStateEnum.WALL, map[6][6]);
        assertEquals(FieldStateEnum.WALL, map[7][6]);
        assertEquals(FieldStateEnum.WALL, map[8][6]);
        assertEquals(FieldStateEnum.WALL, map[9][6]);
        assertEquals(FieldStateEnum.WALL, map[10][6]);
    }
}
