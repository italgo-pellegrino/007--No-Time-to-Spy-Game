package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.OperationLogic;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.Operations.*;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.OperationEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.*;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Class to test the methods of the class character.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class OperationLogicTest {
    private FieldMap map;
    private Set<Character> characters;
    private Character jamesBond;
    private Character drNo;
    private Character q;
    private Character m;
    private Character eve;
    private Character cat;
    private Set<Character> charactersPlayerOne;
    private Set<Character> charactersPlayerTwo;
    private Set<Character> charactersNpc;
    private Set<Integer> playerOneSafeCombinations;
    private Set<Integer> playerTwoSafeCombinations;
    private Matchconfig matchconfig;
    GadgetAction gadgetAction;
    GambleAction gambleAction;
    PropertyAction propertyAction;
    Movement movement;
    Operation operation;
    Exfiltration exfiltration;

    /**
     * Method to create a test setup
     */
    public void setup() {
        // Set up map
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        map = new FieldMap(fields);

        // Set up characters
        jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(4, 5), new HashSet<>(), new HashSet<>());
        q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        cat = new Character(UUID.randomUUID(), "Cat", new Point(2, 2), new HashSet<>(), new HashSet<>());

        characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
        characters.add(cat);
        matchconfig = new Matchconfig();
        charactersPlayerOne = new HashSet<>();
        charactersPlayerOne.add(jamesBond);
        charactersPlayerTwo = new HashSet<>();
        charactersPlayerTwo.add(eve);
        charactersNpc = new HashSet<>();
        charactersNpc.add(cat);
        playerOneSafeCombinations = new HashSet<>();
        playerTwoSafeCombinations = new HashSet<>();
    }

    @Test
    public void testGadgetAction() throws InvalidCharacterException, InvalidTargetException, TargetBlockedException, InvalidActionPointsException, TargetOutOfSightException, TargetOutOfBoundsException, TargetOutOfRangeException, InvalidGadgetException {
        // Setup
        setup();

        // Case 1: Character is not a valid character
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), UUID.randomUUID(), GadgetEnum.HAIRDRYER);
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat));

        // Setup change
        map.getField(new Point(1, 2)).setFoggy(true);

        // Case 2: Character is standing on a foggy field
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.HAIRDRYER);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat));

        // Setup change
        map.getField(new Point(1, 2)).setFoggy(false);

        // Case 3: Character has no action points
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.HAIRDRYER);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat));

        // Setup change
        jamesBond.setAp(25);
        drNo.setAp(25);
        q.setAp(25);
        m.setAp(25);
        eve.setAp(25);

        // Case 4: Character has the wrong gadget
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.HAIRDRYER);
        assertThrows(InvalidGadgetException.class, () -> OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat));

        // Setup change
        jamesBond.addGadget(GadgetEnum.HAIRDRYER);
        jamesBond.addGadget(GadgetEnum.MOLEDIE);
        q.addGadget(GadgetEnum.TECHNICOLOUR_PRISM);
        drNo.addGadget(GadgetEnum.BOWLER_BLADE);
        m.addGadget(GadgetEnum.BOWLER_BLADE);
        jamesBond.addGadget(GadgetEnum.POISON_PILLS);
        eve.addGadget(GadgetEnum.LASER_COMPACT);
        m.addGadget(GadgetEnum.ROCKET_PEN);
        jamesBond.addGadget(GadgetEnum.GAS_GLOSS);
        jamesBond.addGadget(GadgetEnum.MOTHBALL_POUCH);
        drNo.addGadget(GadgetEnum.FOG_TIN);
        eve.addGadget(GadgetEnum.GRAPPLE);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        eve.addGadget(GadgetEnum.JETPACK);
        q.addGadget(GadgetEnum.CHICKEN_FEED);
        jamesBond.addGadget(GadgetEnum.NUGGET);
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        q.addGadget(GadgetEnum.DIAMOND_COLLAR);
        q.addGadget(GadgetEnum.COCKTAIL);

        // Case 5: Character executes a valid hairdryer gadget action
        assertEquals(25, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), jamesBond.getCharacterId(), GadgetEnum.HAIRDRYER);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(jamesBond.hasGadget(GadgetEnum.HAIRDRYER));
        assertEquals(24, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setMoledieRange(5);

        // Case 6: Character executes a valid moledie gadget action
        assertEquals(24, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(3, 2), jamesBond.getCharacterId(), GadgetEnum.MOLEDIE);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.MOLEDIE));
        assertEquals(23, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Case 7: Character executes a valid technicolorPrism gadget action
        assertEquals(25, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(3, 3), q.getCharacterId(), GadgetEnum.TECHNICOLOUR_PRISM);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.TECHNICOLOUR_PRISM));
        assertEquals(24, q.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setBowlerBladeHitChance(1);
        matchconfig.setBowlerBladeRange(4);
        matchconfig.setBowlerBladeDamage(5);

        // Case 8: Character executes a valid successful bowlerBlade gadget action
        assertEquals(25, drNo.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(5, 1), drNo.getCharacterId(), GadgetEnum.BOWLER_BLADE);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.BOWLER_BLADE));
        assertEquals(24, drNo.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setBowlerBladeHitChance(0);

        // Case 9: Character executes a valid unsuccessful bowlerBlade gadget action
        assertEquals(25, m.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(4, 5), m.getCharacterId(), GadgetEnum.BOWLER_BLADE);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.BOWLER_BLADE));
        assertEquals(24, m.getAp());
        assertFalse(gadgetAction.isSuccessful());

        // Setup change
        map.getField(new Point(1, 3)).setGadget(new Cocktail());

        // Case 10: Character executes a valid poisonPills gadget action with poisonPills having 5 usages
        assertEquals(23, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 3), jamesBond.getCharacterId(), GadgetEnum.POISON_PILLS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(jamesBond.hasGadget(GadgetEnum.POISON_PILLS));
        assertEquals(4, jamesBond.getGadget(GadgetEnum.POISON_PILLS).getUsages());
        assertEquals(22, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        jamesBond.getGadget(GadgetEnum.POISON_PILLS).use();
        jamesBond.getGadget(GadgetEnum.POISON_PILLS).use();
        jamesBond.getGadget(GadgetEnum.POISON_PILLS).use();

        // Case 11: Character executes a valid poisonPills gadget action with poisonPills having 1 usage
        assertEquals(22, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 3), jamesBond.getCharacterId(), GadgetEnum.POISON_PILLS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.POISON_PILLS));
        assertEquals(21, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        map.getField(new Point(3, 1)).setGadget(new Cocktail());
        matchconfig.setLaserCompactHitChance(1);

        // Case 12: Character executes a valid successful laserCompact gadget action
        assertEquals(25, eve.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(3, 1), eve.getCharacterId(), GadgetEnum.LASER_COMPACT);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(eve.hasGadget(GadgetEnum.LASER_COMPACT));
        assertEquals(24, eve.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        map.getField(new Point(3, 1)).setGadget(new Cocktail());
        matchconfig.setLaserCompactHitChance(0);

        // Case 13: Character executes a valid unsuccessful laserCompact gadget action
        assertEquals(24, eve.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(3, 1), eve.getCharacterId(), GadgetEnum.LASER_COMPACT);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(eve.hasGadget(GadgetEnum.LASER_COMPACT));
        assertEquals(23, eve.getAp());
        assertFalse(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setRocketPenDamage(25);

        // Case 14: Character executes a valid rocketPen gadget action
        assertEquals(24, m.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), m.getCharacterId(), GadgetEnum.ROCKET_PEN);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(m.hasGadget(GadgetEnum.ROCKET_PEN));
        assertEquals(23, m.getAp());
        assertTrue(gadgetAction.isSuccessful());

        //  Setup change
        matchconfig.setGasGlossDamage(15);

        // Case 15: Character executes a valid successful gasGloss gadget action
        assertEquals(21, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.GAS_GLOSS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.GAS_GLOSS));
        assertEquals(20, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setBabysitterSuccessChance(1);
        jamesBond.addGadget(GadgetEnum.GAS_GLOSS);
        m.addProperty(PropertyEnum.BABYSITTER);
        m.setCoordinates(new Point(1, 3));
        charactersPlayerTwo.add(q);
        charactersPlayerTwo.add(m);

        // Case 16: Character executes a valid unsuccessful gasGloss gadget action
        assertEquals(20, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.GAS_GLOSS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.GAS_GLOSS));
        assertEquals(19, jamesBond.getAp());
        assertFalse(gadgetAction.isSuccessful());

        // Setup change
        m.setCoordinates(new Point(1, 5));
        matchconfig.setMothballPouchDamage(5);
        matchconfig.setMothballPouchRange(2);

        // Case 17: Character executes a valid mothballPouch gadget action with mothballPouch having 5 usages
        assertEquals(19, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 1), jamesBond.getCharacterId(), GadgetEnum.MOTHBALL_POUCH);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(jamesBond.hasGadget(GadgetEnum.MOTHBALL_POUCH));
        assertEquals(4, jamesBond.getGadget(GadgetEnum.MOTHBALL_POUCH).getUsages());
        assertEquals(18, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        jamesBond.getGadget(GadgetEnum.MOTHBALL_POUCH).use();
        jamesBond.getGadget(GadgetEnum.MOTHBALL_POUCH).use();
        jamesBond.getGadget(GadgetEnum.MOTHBALL_POUCH).use();

        // Case 18: Character executes a valid mothballPouch gadget action with mothballPouch having 1 usage
        assertEquals(18, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 1), jamesBond.getCharacterId(), GadgetEnum.MOTHBALL_POUCH);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.MOTHBALL_POUCH));
        assertEquals(17, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setFogTinRange(2);

        // Case 19: Character executes a valid fogTin gadget action
        assertEquals(24, drNo.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(4, 3), drNo.getCharacterId(), GadgetEnum.FOG_TIN);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.FOG_TIN));
        assertEquals(23, drNo.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        map.getField(new Point(3, 1)).setGadget(new Cocktail());
        matchconfig.setGrappleHitChance(1);
        matchconfig.setGrappleRange(5);

        // Case 20: Character executes a valid successful grapple gadget action
        assertEquals(23, eve.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(3, 1), eve.getCharacterId(), GadgetEnum.GRAPPLE);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(eve.hasGadget(GadgetEnum.GRAPPLE));
        assertEquals(22, eve.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        map.getField(new Point(3, 1)).setGadget(new Cocktail());
        matchconfig.setGrappleHitChance(0);

        // Case 21: Character executes a valid unsuccessful grapple gadget action
        assertEquals(22, eve.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(3, 1), eve.getCharacterId(), GadgetEnum.GRAPPLE);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(eve.hasGadget(GadgetEnum.GRAPPLE));
        assertEquals(21, eve.getAp());
        assertFalse(gadgetAction.isSuccessful());

        // Case 22: Character executes a valid jetpack gadget action
        assertEquals(21, eve.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(5, 4), eve.getCharacterId(), GadgetEnum.JETPACK);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(eve.hasGadget(GadgetEnum.JETPACK));
        assertEquals(20, eve.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setWiretapWithEarplugsFailChance(1);

        // Case 23: Character executes a valid wireTapWithEarplugs gadget action
        assertEquals(17, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.WIRETAP_WITH_EARPLUGS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(jamesBond.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        assertEquals(16, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Case 24: Character executes a valid chickenFeed gadget action
        assertEquals(24, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), q.getCharacterId(), GadgetEnum.CHICKEN_FEED);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(q.hasGadget(GadgetEnum.CHICKEN_FEED));
        assertEquals(23, q.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Case 25: Character executes a valid nugget gadget action
        assertEquals(16, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 3), jamesBond.getCharacterId(), GadgetEnum.NUGGET);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.NUGGET));
        assertEquals(15, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup chang
        matchconfig.setMirrorSwapChance(1);

        // Case 26: Character executes a valid successful mirrorOfWilderness gadget action
        assertEquals(23, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), q.getCharacterId(), GadgetEnum.MIRROR_OF_WILDERNESS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertEquals(22, q.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        charactersPlayerOne.remove(q);
        charactersPlayerTwo.add(q);
        matchconfig.setMirrorSwapChance(0);
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);

        // Case 27: Character executes a valid unsuccessful mirrorOfWilderness gadget action
        assertEquals(22, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), q.getCharacterId(), GadgetEnum.MIRROR_OF_WILDERNESS);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertEquals(21, q.getAp());
        assertFalse(gadgetAction.isSuccessful());

        // Case 28: Character executes a valid diamondCollar gadget action
        assertEquals(21, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(2, 2), q.getCharacterId(), GadgetEnum.DIAMOND_COLLAR);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(q.hasGadget(GadgetEnum.DIAMOND_COLLAR));
        assertEquals(20, q.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Case 29: Character wants to pick up a cocktail but already has a cocktail
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 3), q.getCharacterId(), GadgetEnum.COCKTAIL);
        assertThrows(InvalidGadgetException.class, () -> OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat));

        // Case 30: Character executes a valid cocktail gadget action picking up a cocktail
        assertEquals(15, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 3), jamesBond.getCharacterId(), GadgetEnum.COCKTAIL);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertTrue(jamesBond.hasGadget(GadgetEnum.COCKTAIL));
        assertEquals(14, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setCocktailHp(15);

        // Case 31: Character executes a valid successful cocktail gadget action drinking the cocktail
        assertEquals(14, jamesBond.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), jamesBond.getCharacterId(), GadgetEnum.COCKTAIL);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(jamesBond.hasGadget(GadgetEnum.COCKTAIL));
        assertEquals(13, jamesBond.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setCocktailDodgeChance(0);

        // Case 32: Character executes a valid successful cocktail gadget action spilling the cocktail
        assertEquals(20, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), q.getCharacterId(), GadgetEnum.COCKTAIL);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));
        assertEquals(19, q.getAp());
        assertTrue(gadgetAction.isSuccessful());

        // Setup change
        matchconfig.setCocktailDodgeChance(1);
        q.addGadget(GadgetEnum.COCKTAIL);
        charactersPlayerOne.remove(jamesBond);
        charactersPlayerTwo.add(jamesBond);
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 33 Character executes a valid unsuccessful cocktail gadget action spilling the cocktail
        assertEquals(19, q.getAp());
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), q.getCharacterId(), GadgetEnum.COCKTAIL);
        OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat);
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));
        assertEquals(18, q.getAp());
        assertFalse(gadgetAction.isSuccessful());

        // Case 34: Gadget does not exist
        gadgetAction = new GadgetAction(OperationEnum.GADGET_ACTION, false, new Point(1, 2), q.getCharacterId(), GadgetEnum.COCKTAIL);
        assertThrows(InvalidGadgetException.class, () -> OperationLogic.gadgetAction(gadgetAction, map, matchconfig, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, cat));
    }

    @Test
    public void testGambleAction() throws InvalidActionPointsException, InvalidTargetException, InvalidChipAmountException, InvalidCharacterException, TargetOutOfBoundsException {
        // Setup
        setup();
        jamesBond.setCoordinates(new Point(3, 2));
        matchconfig.setMinChipsRoulette(0);
        matchconfig.setMaxChipsRoulette(100);
        map.getField(new Point(3, 3)).setChipAmount(100);

        // Case 1: Character is not a valid character
        gambleAction = new GambleAction(OperationEnum.GAMBLE_ACTION, false, new Point(3, 3), UUID.randomUUID(), 10);
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.gambleAction(gambleAction, map, characters));

        // Case 2: Character targets a field which is out of bounds
        gambleAction = new GambleAction(OperationEnum.GAMBLE_ACTION, false, new Point(7, 3), jamesBond.getCharacterId(), 10);
        assertThrows(TargetOutOfBoundsException.class, () -> OperationLogic.gambleAction(gambleAction, map, characters));

        // Setup change
        map.getField(new Point(3, 2)).setFoggy(true);

        // Case 3: Character is standing on a foggy field
        gambleAction = new GambleAction(OperationEnum.GAMBLE_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), 10);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.gambleAction(gambleAction, map, characters));

        // Setup change
        map.getField(new Point(3, 2)).setFoggy(false);

        // Case 4: Character has no action points
        gambleAction = new GambleAction(OperationEnum.GAMBLE_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), 10);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.gambleAction(gambleAction, map, characters));

        // Setup change
        jamesBond.setAp(2);

        // Case 5: Character has not enough chips
        gambleAction = new GambleAction(OperationEnum.GAMBLE_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), 20);
        assertThrows(InvalidChipAmountException.class, () -> OperationLogic.gambleAction(gambleAction, map, characters));

        // Case 6: Character executes a valid gamble action
        assertEquals(2, jamesBond.getAp());
        gambleAction = new GambleAction(OperationEnum.GAMBLE_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), 10);
        OperationLogic.gambleAction(gambleAction, map, characters);
        assertEquals(1, jamesBond.getAp());
        assertTrue(gambleAction.isSuccessful() || !gambleAction.isSuccessful());
    }

    @Test
    public void testPropertyAction() throws InvalidTargetException, InvalidCharacterException, InvalidActionPointsException, TargetOutOfSightException, TargetOutOfBoundsException, InvalidPropertyException, InvalidGadgetException {
        // Setup
        setup();
        jamesBond.setCoordinates(new Point(3, 2));
        jamesBond.addProperty(PropertyEnum.BANG_AND_BURN);
        jamesBond.addProperty(PropertyEnum.OBSERVATION);

        // Case 1: Character is not a valid character
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), UUID.randomUUID(), PropertyEnum.BANG_AND_BURN);
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), UUID.randomUUID(), PropertyEnum.OBSERVATION);
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));

        // Case 2: Character targets a field which is out of bounds
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(7, 3), jamesBond.getCharacterId(), PropertyEnum.BANG_AND_BURN);
        assertThrows(TargetOutOfBoundsException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(7, 3), jamesBond.getCharacterId(), PropertyEnum.OBSERVATION);
        assertThrows(TargetOutOfBoundsException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));

        // Setup change
        map.getField(new Point(3, 2)).setFoggy(true);

        // Case 3: Character is standing on a foggy field
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), PropertyEnum.BANG_AND_BURN);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), PropertyEnum.OBSERVATION);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));

        // Setup change
        map.getField(new Point(3, 2)).setFoggy(false);

        // Case 4: Character has no action points
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), PropertyEnum.BANG_AND_BURN);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), PropertyEnum.OBSERVATION);
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));

        // Setup change
        jamesBond.setAp(4);
        // Case 5: Character executes a valid property action with the property bangAndBurn
        assertEquals(4, jamesBond.getAp());
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), PropertyEnum.BANG_AND_BURN);
        OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig);
        assertEquals(3, jamesBond.getAp());
        assertTrue(propertyAction.isSuccessful());

        // Setup change
        matchconfig.setObservationSuccessChance(100);

        // Case 6: Character executes a valid successful property action with the property observation
        assertEquals(3, jamesBond.getAp());
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(5, 1), jamesBond.getCharacterId(), PropertyEnum.OBSERVATION);
        OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig);
        assertEquals(2, jamesBond.getAp());
        assertTrue(propertyAction.isSuccessful());

        // Setup change
        matchconfig.setObservationSuccessChance(0);

        // Case 7: Character executes a valid unsuccessful property action with the property observation
        assertEquals(2, jamesBond.getAp());
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(5, 1), jamesBond.getCharacterId(), PropertyEnum.OBSERVATION);
        OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig);
        assertEquals(1, jamesBond.getAp());
        assertFalse(propertyAction.isSuccessful());

        // Case 8: Property action does not exist
        propertyAction = new PropertyAction(OperationEnum.PROPERTY_ACTION, false, new Point(3, 3), jamesBond.getCharacterId(), PropertyEnum.ROBUST_STOMACH);
        assertThrows(InvalidPropertyException.class, () -> OperationLogic.propertyAction(propertyAction, characters, map, charactersPlayerOne, charactersPlayerTwo, matchconfig));

    }

    @Test
    public void testMovement() throws InvalidTargetException, InvalidMovementPointsException, InvalidCharacterException, TargetOutOfBoundsException {
        // Setup
        setup();
        jamesBond.setCoordinates(new Point(4, 3));

        // Case 1: Character is not a valid character
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(4, 2), UUID.randomUUID(), new Point(4, 3));
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.movement(movement, map, characters));

        // Case 2: Character targets a field which is out of bounds
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(7, 3), jamesBond.getCharacterId(), new Point(4, 3));
        assertThrows(TargetOutOfBoundsException.class, () -> OperationLogic.movement(movement, map, characters));

        // Case 3: Character has no movement points
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(4, 2), jamesBond.getCharacterId(), new Point(4, 3));
        assertThrows(InvalidMovementPointsException.class, () -> OperationLogic.movement(movement, map, characters));

        // Setup change
        jamesBond.setMp(3);

        // Case 4: Character targets a field which is not a neighbour
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(2, 2), jamesBond.getCharacterId(), new Point(4, 3));
        assertThrows(InvalidTargetException.class, () -> OperationLogic.movement(movement, map, characters));

        // Case 5: Character targets a field which is not accessible
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(3, 4), jamesBond.getCharacterId(), new Point(4, 3));
        assertThrows(InvalidTargetException.class, () -> OperationLogic.movement(movement, map, characters));

        // Case 6: Character executes a valid movement action with no character on the target field
        assertEquals(3, jamesBond.getMp());
        assertEquals(new Point(4, 3), jamesBond.getCoordinates());
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(4, 4), jamesBond.getCharacterId(), new Point(4, 3));
        OperationLogic.movement(movement, map, characters);
        assertEquals(new Point(4, 4), jamesBond.getCoordinates());
        assertEquals(2, jamesBond.getMp());

        // Case 7: Character executes a valid movement action with a character on the target field
        assertEquals(2, jamesBond.getMp());
        assertEquals(new Point(4, 4), jamesBond.getCoordinates());
        assertEquals(new Point(4, 5), drNo.getCoordinates());
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(4, 5), jamesBond.getCharacterId(), new Point(4, 4));
        OperationLogic.movement(movement, map, characters);
        assertEquals(new Point(4, 5), jamesBond.getCoordinates());
        assertEquals(new Point(4, 4), drNo.getCoordinates());
        assertEquals(1, jamesBond.getMp());
        assertTrue(movement.isSuccessful());

        // Setup change
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));

        // Case 8: Character executes a valid movement action with a gadget on the target field
        assertEquals(1, jamesBond.getMp());
        assertEquals(new Point(4, 5), jamesBond.getCoordinates());
        movement = new Movement(OperationEnum.MOVEMENT, false, new Point(3, 5), jamesBond.getCharacterId(), new Point(4, 4));
        OperationLogic.movement(movement, map, characters);
        assertTrue(jamesBond.hasGadget(GadgetEnum.BOWLER_BLADE));
        assertEquals(new Point(3, 5), jamesBond.getCoordinates());
        assertEquals(0, jamesBond.getMp());
        assertTrue(movement.isSuccessful());
    }

    @Test
    public void testOperationAction() throws InvalidTargetException, InvalidCharacterException, InvalidActionPointsException, TargetOutOfBoundsException, TargetOutOfRangeException, InvalidSafeCombinationException, InvalidOperationException {
        // Setup
        setup();
        jamesBond.setCoordinates(new Point(4, 4));
        charactersNpc.add(jamesBond);

        // Case 1: Character is not a valid character
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(5, 5), UUID.randomUUID());
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations));
        operation = new Operation(OperationEnum.RETIRE, false, new Point(4, 5), UUID.randomUUID());
        assertThrows(InvalidCharacterException.class, () -> OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations));

        // Case 2: Character executes a valid retire action
        assertEquals(new Point(4, 5), drNo.getCoordinates());
        operation = new Operation(OperationEnum.RETIRE, false, new Point(5, 5), drNo.getCharacterId());
        OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations);
        assertEquals(new Point(4, 5), drNo.getCoordinates());
        assertTrue(operation.isSuccessful());

        // Case 3: Character targets a field which is out of bounds
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(7, 3), drNo.getCharacterId());
        assertThrows(TargetOutOfBoundsException.class, () -> OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations));

        // Setup change
        map.getField(new Point(4, 5)).setFoggy(true);

        // Case 4: Character is standing on a foggy field
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(4, 5), drNo.getCharacterId());
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations));

        // Setup change
        map.getField(new Point(4, 5)).setFoggy(false);

        // Case 5: Character has no action points
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(4, 5), drNo.getCharacterId());
        assertThrows(InvalidActionPointsException.class, () -> OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations));

        // Setup change
        drNo.setAp(3);

        // Case 6: Character executes a valid operation action on a safe
        assertEquals(3, drNo.getAp());
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(5, 5), drNo.getCharacterId());
        OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations);
        assertEquals(2, drNo.getAp());

        // Setup change
        matchconfig.setSpySuccessChance(100);

        // Case 7: Character executes a valid successful operation action on a character
        assertEquals(2, drNo.getAp());
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(4, 4), drNo.getCharacterId());
        OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations);
        assertEquals(1, drNo.getAp());
        assertTrue(operation.isSuccessful());

        // Setup change
        matchconfig.setSpySuccessChance(0);

        // Case 8: Character executes a valid unsuccessful operation action on a character
        assertEquals(1, drNo.getAp());
        operation = new Operation(OperationEnum.SPY_ACTION, false, new Point(4, 4), drNo.getCharacterId());
        OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations);
        assertEquals(0, drNo.getAp());
        assertFalse(operation.isSuccessful());

        // Case 9: Operation does not exist
        operation = new Operation(OperationEnum.GAMBLE_ACTION, false, new Point(4, 5), jamesBond.getCharacterId());
        assertThrows(InvalidOperationException.class, () -> OperationLogic.operationAction(operation, map, characters, charactersPlayerOne, charactersPlayerTwo, charactersNpc, matchconfig, playerOneSafeCombinations, playerTwoSafeCombinations));

    }

    @Test
    public void testExfiltration() {
        // Setup
        setup();
        ArrayList<Point> expectedPoints;

        // Case 1: Free bar seats on the map and the character does not have the diamond collar
        exfiltration = new Exfiltration(OperationEnum.EXFILTRATION, false, null, jamesBond.getCharacterId(), new Point(1, 2));
        OperationLogic.exfiltration(exfiltration, map, characters);
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(1, 4));
        assertTrue(expectedPoints.contains(jamesBond.getCoordinates()));
        assertEquals(1, jamesBond.getHp());
        assertTrue(exfiltration.isSuccessful());

        // Setup change
        jamesBond.addGadget(GadgetEnum.DIAMOND_COLLAR);
        jamesBond.setCoordinates(new Point(1, 2));

        // Case 2: Free bar seats on the map and the character has the diamond collar
        exfiltration = new Exfiltration(OperationEnum.EXFILTRATION, false, null, jamesBond.getCharacterId(), new Point(1, 2));
        OperationLogic.exfiltration(exfiltration, map, characters);
        expectedPoints = new ArrayList<>();
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(1, 4));
        assertTrue(map.getField(new Point(1, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(expectedPoints.contains(jamesBond.getCoordinates()));
        assertEquals(1, jamesBond.getHp());
        assertTrue(exfiltration.isSuccessful());

        // Setup change
        jamesBond.setCoordinates(new Point(4, 1));
        m.setCoordinates(new Point(4, 2));

        // Case 3: No free bar seats on the map
        exfiltration = new Exfiltration(OperationEnum.EXFILTRATION, false, null, drNo.getCharacterId(), new Point(4, 5));
        OperationLogic.exfiltration(exfiltration, map, characters);
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(1, 4));
        assertTrue(expectedPoints.contains(drNo.getCoordinates()));
        expectedPoints.clear();
        expectedPoints.add(new Point(1, 4));
        expectedPoints.add(new Point(4, 1));
        expectedPoints.add(new Point(3, 2));
        expectedPoints.add(new Point(4, 2));
        expectedPoints.add(new Point(5, 2));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(2, 4));
        expectedPoints.add(new Point(2, 5));
        expectedPoints.add(new Point(1, 5));
        assertTrue(expectedPoints.contains(jamesBond.getCoordinates()));
        assertTrue(expectedPoints.contains(m.getCoordinates()));
        assertEquals(1, drNo.getHp());
        assertTrue(exfiltration.isSuccessful());
    }
}
