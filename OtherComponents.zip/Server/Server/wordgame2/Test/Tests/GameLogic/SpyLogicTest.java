package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.SpyLogic;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidSafeCombinationException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfRangeException;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Class to test the methods of the character.class.
 *
 * @author Alexander Preiß, Simon Demharter
 * @version 1.0
 */
public class SpyLogicTest {

    @Test
    public void testSpyLogic() throws TargetOutOfRangeException, InvalidTargetException, InvalidSafeCombinationException {
        // Setup
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        FieldMap map = new FieldMap(fields);
        Character jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        Character drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(2, 5), new HashSet<>(), new HashSet<>());
        Character q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        Character m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        Character eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        Set<Character> characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
        Set<Character> charactersPlayerOne = new HashSet<>();
        charactersPlayerOne.add(jamesBond);
        Set<Character> charactersPlayerTwo = new HashSet<>();
        charactersPlayerTwo.add(drNo);
        Set<Character> charactersNPC = new HashSet<>();
        charactersNPC.add(q);
        charactersNPC.add(m);
        charactersNPC.add(eve);
        Set<Integer> playerOneSafeCombinations = new HashSet<>();
        Set<Integer> playerTwoSafeCombinations = new HashSet<>();
        Matchconfig matchconfig = new Matchconfig();
        matchconfig.setSpySuccessChance(100);
        matchconfig.setSecretToIpFactor(100);

        // Case 1: Character of faction one successfully spies on a NPC character
        assertEquals(0, jamesBond.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(0, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(100, jamesBond.getIp());
        assertTrue(playerOneSafeCombinations.contains(1));
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(0, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(200, jamesBond.getIp());
        assertTrue(playerOneSafeCombinations.contains(2));
        assertEquals(2, playerOneSafeCombinations.size());
        assertEquals(0, playerTwoSafeCombinations.size());

        // Case 2: Character of faction two successfully spies on a NPC character
        assertEquals(0, drNo.getIp());
        assertEquals(2, playerOneSafeCombinations.size());
        assertEquals(0, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(100, drNo.getIp());
        assertTrue(playerTwoSafeCombinations.contains(1));
        assertEquals(2, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(200, drNo.getIp());
        assertTrue(playerTwoSafeCombinations.contains(2));
        assertEquals(2, playerOneSafeCombinations.size());
        assertEquals(2, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.addProperty(PropertyEnum.TRADECRAFT);
        drNo.addProperty(PropertyEnum.TRADECRAFT);

        // Case 3: Character of faction one with the property tradeCraft successfully spies on a NPC character
        assertEquals(200, jamesBond.getIp());
        assertEquals(2, playerOneSafeCombinations.size());
        assertEquals(2, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(300, jamesBond.getIp());
        assertTrue(playerOneSafeCombinations.contains(3));
        assertEquals(3, playerOneSafeCombinations.size());
        assertEquals(2, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertTrue(playerOneSafeCombinations.contains(4));
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(2, playerTwoSafeCombinations.size());

        // Case 4: Character of faction two the property tradeCraft successfully spies on a NPC character
        assertEquals(200, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(2, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(300, drNo.getIp());
        assertTrue(playerTwoSafeCombinations.contains(3));
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(3, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertTrue(playerTwoSafeCombinations.contains(4));
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.removeProperty(PropertyEnum.TRADECRAFT);
        matchconfig.setSpySuccessChance(0);

        // Case 5: Character fails to spy on a NPC character
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Case 6: Character with the property tradeCraft fails to spy on a NPC character
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        drNo.removeProperty(PropertyEnum.TRADECRAFT);
        drNo.addProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES);

        // Case 7: Character with the property clammyClothes or constantClammyClothes fails to spy on a NPC character
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertEquals(400, drNo.getIp());
        assertFalse(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.addProperty(PropertyEnum.TRADECRAFT);
        drNo.addProperty(PropertyEnum.TRADECRAFT);

        // Case 8: Character with the property tradeCraft and clammyClothes or constantClammyClothes fails to spy on a NPC character
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertEquals(400, drNo.getIp());
        assertFalse(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(drNo, map, new Point(1, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Setup change
        drNo.setCoordinates(new Point(2, 2));
        jamesBond.removeProperty(PropertyEnum.TRADECRAFT);
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        drNo.removeProperty(PropertyEnum.TRADECRAFT);
        drNo.removeProperty(PropertyEnum.CONSTANT_CLAMMY_CLOTHES);

        // Case 9: Character wants to spy on a character of the opposing faction
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertFalse(SpyLogic.spyLogic(jamesBond, map, new Point(2, 2), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, jamesBond.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Setup change
        drNo.setCoordinates(new Point(2, 5));

        // Case 10: Character wants to spy on a character that is not a neighbour
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());
        assertThrows(InvalidTargetException.class, () -> SpyLogic.spyLogic(drNo, map, new Point(2, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(400, drNo.getIp());
        assertEquals(4, playerOneSafeCombinations.size());
        assertEquals(4, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.setCoordinates(new Point(5, 4));
        drNo.setCoordinates(new Point(4, 5));
        map.getField(new Point(2, 1)).setSafeIndex(2);
        map.getField(new Point(5, 5)).setSafeIndex(1);
        matchconfig.setSecretToIpFactor(10);
        playerOneSafeCombinations.clear();
        playerOneSafeCombinations.add(1);
        playerTwoSafeCombinations.clear();
        playerTwoSafeCombinations.add(1);

        // Case 11: Character of faction one without the property flapsAndSeals successfully spies on a safe without the diamond collar
        assertEquals(400, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(5, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(410, jamesBond.getIp());
        assertTrue(playerOneSafeCombinations.contains(2));
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 12: Character of faction two without the property flapsAndSeals successfully spies on a safe without the diamond collar
        assertEquals(400, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(5, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(410, drNo.getIp());
        assertTrue(playerTwoSafeCombinations.contains(2));
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.setCoordinates(new Point(2, 2));
        drNo.setCoordinates(new Point(3, 2));

        // Case 13: Character of faction one without the property flapsAndSeals successfully spies on a safe with the diamond collar
        assertEquals(410, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(2, 1), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(420, jamesBond.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 14: Character of faction two without the property flapsAndSeals successfully spies on a safe with the diamond collar
        assertEquals(410, drNo.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(2, 1), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(420, drNo.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(0, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.setCoordinates(new Point(3, 4));
        jamesBond.addProperty(PropertyEnum.FLAPS_AND_SEALS);
        drNo.addProperty(PropertyEnum.FLAPS_AND_SEALS);
        drNo.setCoordinates(new Point(3, 5));
        playerOneSafeCombinations.clear();
        playerOneSafeCombinations.add(1);
        playerTwoSafeCombinations.clear();
        playerTwoSafeCombinations.add(1);

        // Case 15: Character of faction one with the property flapsAndSeals successfully spies on a safe without the diamond collar
        assertEquals(420, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(5, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(430, jamesBond.getIp());
        assertTrue(playerOneSafeCombinations.contains(2));
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 16: Character of faction two with the property flapsAndSeals successfully spies on a safe without the diamond collar
        assertEquals(420, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(5, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(430, drNo.getIp());
        assertTrue(playerTwoSafeCombinations.contains(2));
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.setCoordinates(new Point(4, 2));
        drNo.setCoordinates(new Point(4, 3));

        // Case 17: Character of faction one with the property flapsAndSeals successfully spies on a safe with the diamond collar
        assertEquals(430, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(jamesBond, map, new Point(2, 1), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, jamesBond.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 18: Character of faction two with the property flapsAndSeals successfully spies on a safe with the diamond collar
        assertEquals(430, drNo.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertTrue(SpyLogic.spyLogic(drNo, map, new Point(2, 1), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, drNo.getIp());
        assertEquals(0, playerOneSafeCombinations.size());
        assertEquals(0, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.setCoordinates(new Point(2, 2));
        drNo.setCoordinates(new Point(4, 2));
        jamesBond.removeProperty(PropertyEnum.FLAPS_AND_SEALS);
        playerOneSafeCombinations.add(1);
        playerTwoSafeCombinations.add(1);

        // Case 19: Character of faction one has the wrong safe combination
        assertEquals(440, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertThrows(InvalidSafeCombinationException.class, () -> SpyLogic.spyLogic(jamesBond, map, new Point(2, 1), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 20: Character of faction two has the wrong safe combination
        assertEquals(440, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertThrows(InvalidSafeCombinationException.class, () -> SpyLogic.spyLogic(drNo, map, new Point(2, 1), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Setup change
        jamesBond.setCoordinates(new Point(5, 3));

        // Case 21: Character without the property flapsAndSeals targets a field out of range
        assertEquals(440, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertThrows(InvalidTargetException.class, () -> SpyLogic.spyLogic(jamesBond, map, new Point(5, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 22: Character with the property flapsAndSeals targets a field out of range
        assertEquals(440, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertThrows(TargetOutOfRangeException.class, () -> SpyLogic.spyLogic(drNo, map, new Point(5, 5), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());

        // Case 23: Target field is no safe or has no character
        assertEquals(440, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertThrows(InvalidTargetException.class, () -> SpyLogic.spyLogic(jamesBond, map, new Point(4, 3), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, jamesBond.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertEquals(440, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
        assertThrows(InvalidTargetException.class, () -> SpyLogic.spyLogic(drNo, map, new Point(5, 4), characters, charactersPlayerOne, charactersPlayerTwo, charactersNPC, playerOneSafeCombinations, playerTwoSafeCombinations, matchconfig));
        assertEquals(440, drNo.getIp());
        assertEquals(1, playerOneSafeCombinations.size());
        assertEquals(1, playerTwoSafeCombinations.size());
    }
}
