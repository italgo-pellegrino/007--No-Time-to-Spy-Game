package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.GadgetLogic;
import de.uulm.team0015.server.controller.ServerLogic.MainServerLogic;
import de.uulm.team0015.server.controller.ServerLogic.states.GamePhaseState;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Cocktail;
import de.uulm.team0015.server.model.DataTypes.Gadgets.Gadget;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import de.uulm.team0015.server.model.Exceptions.TargetBlockedException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfRangeException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfSightException;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Class to test the methods og the class GadgetLogic
 *
 * @author Alexander Preiß
 * @version 1.0
 */
public class GadgetLogicTest {
    private FieldMap map;
    private Set<Character> characters;
    private Character jamesBond;
    private Character drNo;
    private Character q;
    private Character m;
    private Character eve;
    private Set<Character> charactersPlayer1;
    private Set<Character> charactersPlayer2;
    private Set<Character> charactersNPC;
    private Matchconfig matchconfig;

    /**
     * Method to create a test setup
     */
    public void setup() {
        // Set up map
        Field[][] fields = new Field[][]{
        		{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        map = new FieldMap(fields);

        // Set up characters
        jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(4, 5), new HashSet<>(), new HashSet<>());
        q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
        matchconfig = new Matchconfig();
        charactersPlayer1 = new HashSet<>();
        charactersPlayer2 = new HashSet<>();
        charactersNPC = new HashSet<>();
    }


    @Test
    public void testHairdryer() throws InvalidTargetException {
        // Setup
        setup();
        jamesBond.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        jamesBond.addGadget(GadgetEnum.HAIRDRYER);

        // Case 1: jamesBond targets himself with clammy clothes
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.hairdryer(jamesBond, jamesBond.getCoordinates(), map, characters));
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));

        // Case 2: james Bond targets himself without clammy clothes
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.hairdryer(jamesBond, jamesBond.getCoordinates(), map, characters));
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));

        // Case 3: jamesBond targets invalid field; no character/neighbour
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.hairdryer(jamesBond, new Point(5, 5), map, characters));

        // Case 4: jamesBond targets invalid field; character/no neighbour
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.hairdryer(jamesBond, new Point(5, 1), map, characters));

        // Case 5: jamesBond targets valid field; character/neighbour; with clammy clothes
        q.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        assertTrue(q.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.hairdryer(jamesBond, new Point(2, 3), map, characters));
        assertFalse(q.hasProperty(PropertyEnum.CLAMMY_CLOTHES));

        // Case 6: jamesBond targets valid field; character/neighbour; without clammy clothes
        assertFalse(q.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.hairdryer(jamesBond, new Point(2, 3), map, characters));
        assertFalse(q.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
    }

    @Test
    public void testRocketPen() throws TargetOutOfSightException, InvalidTargetException {
        setup();
        eve.addGadget(GadgetEnum.ROCKET_PEN); // BOOM
        matchconfig.setRocketPenDamage(40);
        // Case 1: targets not in sight: Point (2,5)
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.rocketPen(eve, new Point(2, 5), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 2: targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.rocketPen(eve, eve.getCoordinates(), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 3: targets in sight: Point (1,2)
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 0)).getState());
        assertEquals(FieldStateEnum.FIREPLACE, map.getField(new Point(1, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 2)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(1, 3)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(1, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 0)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(3, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 2)).getState());
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(3, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 0)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(4, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 4)).getState());
        assertEquals(FieldStateEnum.SAFE, map.getField(new Point(5, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 6)).getState());

        assertEquals(100, jamesBond.getHp());
        assertEquals(100, q.getHp());
        assertTrue(GadgetLogic.rocketPen(eve, new Point(1, 2), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));
        assertEquals(60, jamesBond.getHp());
        assertEquals(60, q.getHp());

        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(0, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(0, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(0, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 0)).getState());
        assertEquals(FieldStateEnum.FIREPLACE, map.getField(new Point(1, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 2)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(1, 3)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(1, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 0)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(3, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 2)).getState());
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(3, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 0)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(4, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 4)).getState());
        assertEquals(FieldStateEnum.SAFE, map.getField(new Point(5, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 6)).getState());


        // Case 4: targets in sight: Point (4,4)
        setup();
        matchconfig.setRocketPenDamage(40);

        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 0)).getState());
        assertEquals(FieldStateEnum.FIREPLACE, map.getField(new Point(1, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 2)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(1, 3)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(1, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 0)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(3, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 2)).getState());
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(3, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 0)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(4, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 4)).getState());
        assertEquals(FieldStateEnum.SAFE, map.getField(new Point(5, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 6)).getState());

        assertTrue(GadgetLogic.rocketPen(eve, new Point(4, 4), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 0)).getState());
        assertEquals(FieldStateEnum.FIREPLACE, map.getField(new Point(1, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 2)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(1, 3)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(1, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 0)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(3, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 2)).getState());
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(3, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 0)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(4, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 4)).getState());
        assertEquals(FieldStateEnum.SAFE, map.getField(new Point(5, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 6)).getState());

        assertEquals(60, drNo.getHp());

        // Case 5: targets not in sight: Point (1,5)
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.rocketPen(eve, new Point(1, 1), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 6: targets in sight: Point (2,3)
        setup();
        matchconfig.setRocketPenDamage(70);
        assertEquals(100, q.getHp());
        assertEquals(100, jamesBond.getHp());

        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 0)).getState());
        assertEquals(FieldStateEnum.FIREPLACE, map.getField(new Point(1, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 2)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(1, 3)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(1, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 0)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(3, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 2)).getState());
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(3, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 0)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(4, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 4)).getState());
        assertEquals(FieldStateEnum.SAFE, map.getField(new Point(5, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 6)).getState());

        assertTrue(GadgetLogic.rocketPen(eve, new Point(2, 3), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(0, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 0)).getState());
        assertEquals(FieldStateEnum.FIREPLACE, map.getField(new Point(1, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 2)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(1, 3)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(1, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(1, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(1, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(2, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(2, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 0)).getState());
        assertEquals(FieldStateEnum.BAR_TABLE, map.getField(new Point(3, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 2)).getState());
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(3, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(3, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(3, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 0)).getState());
        assertEquals(FieldStateEnum.BAR_SEAT, map.getField(new Point(4, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 4)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(4, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(4, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 0)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 1)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 2)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 3)).getState());
        assertEquals(FieldStateEnum.FREE, map.getField(new Point(5, 4)).getState());
        assertEquals(FieldStateEnum.SAFE, map.getField(new Point(5, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(5, 6)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 0)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 1)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 2)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 3)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 4)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 5)).getState());
        assertEquals(FieldStateEnum.WALL, map.getField(new Point(6, 6)).getState());

        assertEquals(30, q.getHp());
        assertEquals(30, jamesBond.getHp());
    }

    @Test
    public void testTechnicolourPrism() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.TECHNICOLOUR_PRISM);
        eve.addGadget(GadgetEnum.TECHNICOLOUR_PRISM);
        jamesBond.addGadget(GadgetEnum.TECHNICOLOUR_PRISM);

        // Case 1: eve targets Point (4/1): neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.technicolorPrism(eve, new Point(4, 1), map));

        // Case 2: eve targets Point (3,3): no neighbour / roulette-table
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.technicolorPrism(eve, new Point(3, 3), map));

        // Case 3: Q targets Point (3,3): neighbour / roulette-table
        assertFalse(map.getField(new Point(3, 3)).isInverted());
        assertTrue(GadgetLogic.technicolorPrism(q, new Point(3, 3), map));
        assertTrue(map.getField(new Point(3, 3)).isInverted());

        // Case 4: jamesBond targets Point(1,1): neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.technicolorPrism(jamesBond, new Point(1, 1), map));

        // Case 5: jamesBond targets Point(2,2): neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.technicolorPrism(jamesBond, new Point(2, 2), map));

        // case 6: drNo target Point(4,4), set (4,4) Roulette-Table: neighbour / roulette-table
        drNo.addGadget(GadgetEnum.TECHNICOLOUR_PRISM);
        map.getField(new Point(4, 4)).updateFieldState(FieldStateEnum.ROULETTE_TABLE);
        assertEquals(FieldStateEnum.ROULETTE_TABLE, map.getField(new Point(4, 4)).getState());
        assertFalse(map.getField(new Point(4, 4)).isInverted());
        assertTrue(GadgetLogic.technicolorPrism(drNo, new Point(4, 4), map));
        assertTrue(map.getField(new Point(4, 4)).isInverted());
    }

    @Test
    public void testMoledie() throws TargetOutOfRangeException, TargetOutOfSightException, InvalidTargetException {
        setup();
        eve.addGadget(GadgetEnum.MOLEDIE);
        matchconfig.setMoledieRange(3);

        // Case 1: eve targets Point(2,5): not in range / not in sight / no wall
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.moledie(eve, new Point(2, 5), map, characters, matchconfig));

        // Case 2: eve targets Point(1,1): no in range / not in sight/ no wall
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.moledie(eve, new Point(1, 1), map, characters, matchconfig));

        // Case 3: eve targets Point(1,4): not in range / in sight / no wall
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.moledie(eve, new Point(1, 4), map, characters, matchconfig));

        // Case 4: eve target Point(2,2): in range / in sight / no wall
        assertFalse(jamesBond.hasGadget(GadgetEnum.MOLEDIE));
        assertFalse(q.hasGadget(GadgetEnum.MOLEDIE));
        assertTrue(GadgetLogic.moledie(eve, new Point(2, 2), map, characters, matchconfig));
        assertTrue((q.hasGadget(GadgetEnum.MOLEDIE) && !jamesBond.hasGadget(GadgetEnum.MOLEDIE)) || (!q.hasGadget(GadgetEnum.MOLEDIE) && jamesBond.hasGadget(GadgetEnum.MOLEDIE)));

        // Case 5: eve targets Point(2,1): in range / in sight / wall
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.moledie(eve, new Point(2, 1), map, characters, matchconfig));

        // Case 6: jamesBond targets himself: in range/ in sight/ no wall (not possible)
        jamesBond.addGadget(GadgetEnum.MOLEDIE);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.moledie(jamesBond, new Point(1, 2), map, characters, matchconfig));

        // Case 7: jamesBond targets Point(2,5): in range / in sight / no wall
        setup();
        matchconfig.setMoledieRange(3);
        jamesBond.addGadget(GadgetEnum.MOLEDIE);
        assertFalse(m.hasGadget(GadgetEnum.MOLEDIE));
        assertTrue(GadgetLogic.moledie(jamesBond, new Point(2, 5), map, characters, matchconfig));
        assertTrue(m.hasGadget(GadgetEnum.MOLEDIE));
    }

    @Test
    public void testJetpack() throws InvalidTargetException {
        setup();
        jamesBond.addGadget(GadgetEnum.JETPACK);

        // Case 1: jamesBond targets Point(5,5): safe field / not character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(5, 5), map, characters));

        // Case 2: jamesBond targets Point(3,4): wall field / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(3, 4), map, characters));

        // Case 3: jamesBond targets Point(3,3): roulette field / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(3, 3), map, characters));

        // Case 4: jamesBond targets Point(1,1): fireplace field / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(1, 1), map, characters));

        // Case 5: jamesBond targets Point(1,3): bar-table field / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(1, 3), map, characters));

        // Case 6: jamesBond targets Point(1,4): bar-seat field / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(1, 4), map, characters));

        // Case 7: jamesBond targets himself: free field / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(1, 2), map, characters));

        // Case 8: jamesBond targets Point(4,5): free field / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(4, 5), map, characters));

        // Case 9: jamesBond targets Point(1,5): free field / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.jetpack(jamesBond, new Point(1, 5), map, characters));

        // Case 10: jamesBond targets Point(5/4): free field / no character
        assertEquals(new Point(1, 2), jamesBond.getCoordinates());
        assertTrue(GadgetLogic.jetpack(jamesBond, new Point(5, 4), map, characters));
        assertEquals(new Point(5, 4), jamesBond.getCoordinates());

        // Case 11: jamesBond targets Point(2/4): free field / no character
        assertEquals(new Point(5, 4), jamesBond.getCoordinates());
        assertTrue(GadgetLogic.jetpack(jamesBond, new Point(2, 4), map, characters));
        assertEquals(new Point(2, 4), jamesBond.getCoordinates());
    }

    @Test
    public void testLaserCompact() throws TargetOutOfSightException, InvalidTargetException {
        setup();
        map.fillBarTables();
        q.addGadget(GadgetEnum.COCKTAIL);
        eve.addGadget(GadgetEnum.LASER_COMPACT);
        m.addGadget(GadgetEnum.COCKTAIL);
        map.getField(new Point(1, 3)).setGadget(new Cocktail());
        matchconfig.setLaserCompactHitChance(1);

        // Case 1: eve targets Point(4,4): in sight / no cocktail
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.laserCompact(eve, new Point(4, 4), map, characters, matchconfig));

        // Case 2: eve targets Point(4,5): in sight / no cocktail
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.laserCompact(eve, new Point(4, 5), map, characters, matchconfig));

        // Case 3: eve targets Point(1,5): no sight / cocktail
        /**
         * Sichtlinie wird nicht blockiert, weil die Felder (Nicht diejenigen, die nur an der Ecke tangiert wird keine Felder sind, die die Sichtlinie blockieren
         * Änderung am 10.07.
         */
        //assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.laserCompact(eve, new Point(1, 5), map, characters, matchconfig));

        // Case 4: eve targets Point(2,5): no sight/ no cocktail
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.laserCompact(eve, new Point(2, 5), map, characters, matchconfig));

        // Case 5: eve targets Point(1,3): in sight / cocktail / bar-table / hit chance 100%
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(GadgetLogic.laserCompact(eve, new Point(1, 3), map, characters, matchconfig));
        assertFalse(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 6: eve targets Point(2,3): in sight / cocktail / character / hit chance 100%
        assertTrue(q.hasGadget(GadgetEnum.COCKTAIL));
        assertTrue(GadgetLogic.laserCompact(eve, new Point(2, 3), map, characters, matchconfig));
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 7:  eve targets Point(1,3): in sight / cocktail / bar-table / hit chance 0%
        matchconfig.setLaserCompactHitChance(0);
        map.getField(new Point(1, 3)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertFalse(GadgetLogic.laserCompact(eve, new Point(1, 3), map, characters, matchconfig));
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 6: eve targets Point(2,3): in sight / cocktail / character / hit chance 100%
        q.addGadget(GadgetEnum.COCKTAIL);
        assertTrue(q.hasGadget(GadgetEnum.COCKTAIL));
        assertFalse(GadgetLogic.laserCompact(eve, new Point(2, 3), map, characters, matchconfig));
        assertTrue(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 7: eve targets herself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.laserCompact(eve, new Point(5, 1), map, characters, matchconfig));

        // Case 8: drNo targets Point(5,1): in sight / cocktail / character / hit chance 100%
        matchconfig.setLaserCompactHitChance(1);
        drNo.addGadget(GadgetEnum.LASER_COMPACT);
        eve.addGadget(GadgetEnum.COCKTAIL);
        assertTrue(eve.hasGadget(GadgetEnum.COCKTAIL));
        assertTrue(GadgetLogic.laserCompact(drNo, new Point(5, 1), map, characters, matchconfig));
        assertFalse(eve.hasGadget(GadgetEnum.COCKTAIL));

        // Case 9: drNo targets Point(1,5): in sight / cocktail / character / hit chance 0%
        m.addGadget(GadgetEnum.COCKTAIL);
        matchconfig.setLaserCompactHitChance(0);
        assertTrue(m.hasGadget(GadgetEnum.COCKTAIL));
        assertFalse(GadgetLogic.laserCompact(drNo, new Point(1, 5), map, characters, matchconfig));
        assertTrue(m.hasGadget(GadgetEnum.COCKTAIL));
    }

    @Test
    public void testFogTin() throws TargetOutOfRangeException, TargetOutOfSightException, InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.FOG_TIN);
        matchconfig.setFogTinRange(2);

        // Case 1: q targets himself: not possible
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.fogTin(q, new Point(2, 3), map, matchconfig));

        // Case 2: q targets Point(4,5): no sight / in range / no wall
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.fogTin(q, new Point(4, 5), map, matchconfig));

        // Case 3: q targets Point(5,5): no sight / no range / no wall
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.fogTin(q, new Point(5, 5), map, matchconfig));

        // Case 4: q targets Point(5,6): no sight / no range / wall
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.fogTin(q, new Point(5, 6), map, matchconfig));

        // Case 5: q targets Point(3,4): in sight / in range / wall
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.fogTin(q, new Point(3, 4), map, matchconfig));

        // Case 6: q targets Point(4,2): in sight / in range / no wall


        assertFalse(map.getField(new Point(0, 0)).isFoggy());
        assertFalse(map.getField(new Point(0, 1)).isFoggy());
        assertFalse(map.getField(new Point(0, 2)).isFoggy());
        assertFalse(map.getField(new Point(0, 3)).isFoggy());
        assertFalse(map.getField(new Point(0, 4)).isFoggy());
        assertFalse(map.getField(new Point(0, 5)).isFoggy());
        assertFalse(map.getField(new Point(0, 6)).isFoggy());
        assertFalse(map.getField(new Point(1, 0)).isFoggy());
        assertFalse(map.getField(new Point(1, 1)).isFoggy());
        assertFalse(map.getField(new Point(1, 2)).isFoggy());
        assertFalse(map.getField(new Point(1, 3)).isFoggy());
        assertFalse(map.getField(new Point(1, 4)).isFoggy());
        assertFalse(map.getField(new Point(1, 5)).isFoggy());
        assertFalse(map.getField(new Point(1, 6)).isFoggy());
        assertFalse(map.getField(new Point(2, 0)).isFoggy());
        assertFalse(map.getField(new Point(2, 1)).isFoggy());
        assertFalse(map.getField(new Point(2, 2)).isFoggy());
        assertFalse(map.getField(new Point(2, 3)).isFoggy());
        assertFalse(map.getField(new Point(2, 4)).isFoggy());
        assertFalse(map.getField(new Point(2, 5)).isFoggy());
        assertFalse(map.getField(new Point(2, 6)).isFoggy());
        assertFalse(map.getField(new Point(3, 0)).isFoggy());
        assertFalse(map.getField(new Point(3, 1)).isFoggy());
        assertFalse(map.getField(new Point(3, 2)).isFoggy());
        assertFalse(map.getField(new Point(3, 3)).isFoggy());
        assertFalse(map.getField(new Point(3, 4)).isFoggy());
        assertFalse(map.getField(new Point(3, 5)).isFoggy());
        assertFalse(map.getField(new Point(3, 6)).isFoggy());
        assertFalse(map.getField(new Point(4, 0)).isFoggy());
        assertFalse(map.getField(new Point(4, 1)).isFoggy());
        assertFalse(map.getField(new Point(4, 2)).isFoggy());
        assertFalse(map.getField(new Point(4, 3)).isFoggy());
        assertFalse(map.getField(new Point(4, 4)).isFoggy());
        assertFalse(map.getField(new Point(4, 5)).isFoggy());
        assertFalse(map.getField(new Point(4, 6)).isFoggy());
        assertFalse(map.getField(new Point(5, 0)).isFoggy());
        assertFalse(map.getField(new Point(5, 1)).isFoggy());
        assertFalse(map.getField(new Point(5, 2)).isFoggy());
        assertFalse(map.getField(new Point(5, 3)).isFoggy());
        assertFalse(map.getField(new Point(5, 4)).isFoggy());
        assertFalse(map.getField(new Point(5, 5)).isFoggy());
        assertFalse(map.getField(new Point(5, 6)).isFoggy());
        assertFalse(map.getField(new Point(6, 0)).isFoggy());
        assertFalse(map.getField(new Point(6, 1)).isFoggy());
        assertFalse(map.getField(new Point(6, 2)).isFoggy());
        assertFalse(map.getField(new Point(6, 3)).isFoggy());
        assertFalse(map.getField(new Point(6, 4)).isFoggy());
        assertFalse(map.getField(new Point(6, 5)).isFoggy());
        assertFalse(map.getField(new Point(6, 6)).isFoggy());

        assertTrue(GadgetLogic.fogTin(q, new Point(4, 2), map, matchconfig));

        assertFalse(map.getField(new Point(0, 0)).isFoggy());
        assertFalse(map.getField(new Point(0, 1)).isFoggy());
        assertFalse(map.getField(new Point(0, 2)).isFoggy());
        assertFalse(map.getField(new Point(0, 3)).isFoggy());
        assertFalse(map.getField(new Point(0, 4)).isFoggy());
        assertFalse(map.getField(new Point(0, 5)).isFoggy());
        assertFalse(map.getField(new Point(0, 6)).isFoggy());
        assertFalse(map.getField(new Point(1, 0)).isFoggy());
        assertFalse(map.getField(new Point(1, 1)).isFoggy());
        assertFalse(map.getField(new Point(1, 2)).isFoggy());
        assertFalse(map.getField(new Point(1, 3)).isFoggy());
        assertFalse(map.getField(new Point(1, 4)).isFoggy());
        assertFalse(map.getField(new Point(1, 5)).isFoggy());
        assertFalse(map.getField(new Point(1, 6)).isFoggy());
        assertFalse(map.getField(new Point(2, 0)).isFoggy());
        assertFalse(map.getField(new Point(2, 1)).isFoggy());
        assertFalse(map.getField(new Point(2, 2)).isFoggy());
        assertFalse(map.getField(new Point(2, 3)).isFoggy());
        assertFalse(map.getField(new Point(2, 4)).isFoggy());
        assertFalse(map.getField(new Point(2, 5)).isFoggy());
        assertFalse(map.getField(new Point(2, 6)).isFoggy());
        assertFalse(map.getField(new Point(3, 0)).isFoggy());
        assertTrue(map.getField(new Point(3, 1)).isFoggy());
        assertTrue(map.getField(new Point(3, 2)).isFoggy());
        assertTrue(map.getField(new Point(3, 3)).isFoggy());
        assertFalse(map.getField(new Point(3, 4)).isFoggy());
        assertFalse(map.getField(new Point(3, 5)).isFoggy());
        assertFalse(map.getField(new Point(3, 6)).isFoggy());
        assertFalse(map.getField(new Point(4, 0)).isFoggy());
        assertTrue(map.getField(new Point(4, 1)).isFoggy());
        assertTrue(map.getField(new Point(4, 2)).isFoggy());
        assertTrue(map.getField(new Point(4, 3)).isFoggy());
        assertFalse(map.getField(new Point(4, 4)).isFoggy());
        assertFalse(map.getField(new Point(4, 5)).isFoggy());
        assertFalse(map.getField(new Point(4, 6)).isFoggy());
        assertFalse(map.getField(new Point(5, 0)).isFoggy());
        assertTrue(map.getField(new Point(5, 1)).isFoggy());
        assertTrue(map.getField(new Point(5, 2)).isFoggy());
        assertTrue(map.getField(new Point(5, 3)).isFoggy());
        assertFalse(map.getField(new Point(5, 4)).isFoggy());
        assertFalse(map.getField(new Point(5, 5)).isFoggy());
        assertFalse(map.getField(new Point(5, 6)).isFoggy());
        assertFalse(map.getField(new Point(6, 0)).isFoggy());
        assertFalse(map.getField(new Point(6, 1)).isFoggy());
        assertFalse(map.getField(new Point(6, 2)).isFoggy());
        assertFalse(map.getField(new Point(6, 3)).isFoggy());
        assertFalse(map.getField(new Point(6, 4)).isFoggy());
        assertFalse(map.getField(new Point(6, 5)).isFoggy());
        assertFalse(map.getField(new Point(6, 6)).isFoggy());

        assertEquals(3, GamePhaseState.foggyFieldCount);

        // Case 7: jamesBond targets Point(3/2): in sight / in range / no wall (safe field)
        setup();
        jamesBond.addGadget(GadgetEnum.FOG_TIN);
        map.getField(new Point(3, 2)).isState(FieldStateEnum.SAFE);
        matchconfig.setFogTinRange(5);

        assertFalse(map.getField(new Point(0, 0)).isFoggy());
        assertFalse(map.getField(new Point(0, 1)).isFoggy());
        assertFalse(map.getField(new Point(0, 2)).isFoggy());
        assertFalse(map.getField(new Point(0, 3)).isFoggy());
        assertFalse(map.getField(new Point(0, 4)).isFoggy());
        assertFalse(map.getField(new Point(0, 5)).isFoggy());
        assertFalse(map.getField(new Point(0, 6)).isFoggy());
        assertFalse(map.getField(new Point(1, 0)).isFoggy());
        assertFalse(map.getField(new Point(1, 1)).isFoggy());
        assertFalse(map.getField(new Point(1, 2)).isFoggy());
        assertFalse(map.getField(new Point(1, 3)).isFoggy());
        assertFalse(map.getField(new Point(1, 4)).isFoggy());
        assertFalse(map.getField(new Point(1, 5)).isFoggy());
        assertFalse(map.getField(new Point(1, 6)).isFoggy());
        assertFalse(map.getField(new Point(2, 0)).isFoggy());
        assertFalse(map.getField(new Point(2, 1)).isFoggy());
        assertFalse(map.getField(new Point(2, 2)).isFoggy());
        assertFalse(map.getField(new Point(2, 3)).isFoggy());
        assertFalse(map.getField(new Point(2, 4)).isFoggy());
        assertFalse(map.getField(new Point(2, 5)).isFoggy());
        assertFalse(map.getField(new Point(2, 6)).isFoggy());
        assertFalse(map.getField(new Point(3, 0)).isFoggy());
        assertFalse(map.getField(new Point(3, 1)).isFoggy());
        assertFalse(map.getField(new Point(3, 2)).isFoggy());
        assertFalse(map.getField(new Point(3, 3)).isFoggy());
        assertFalse(map.getField(new Point(3, 4)).isFoggy());
        assertFalse(map.getField(new Point(3, 5)).isFoggy());
        assertFalse(map.getField(new Point(3, 6)).isFoggy());
        assertFalse(map.getField(new Point(4, 0)).isFoggy());
        assertFalse(map.getField(new Point(4, 1)).isFoggy());
        assertFalse(map.getField(new Point(4, 2)).isFoggy());
        assertFalse(map.getField(new Point(4, 3)).isFoggy());
        assertFalse(map.getField(new Point(4, 4)).isFoggy());
        assertFalse(map.getField(new Point(4, 5)).isFoggy());
        assertFalse(map.getField(new Point(4, 6)).isFoggy());
        assertFalse(map.getField(new Point(5, 0)).isFoggy());
        assertFalse(map.getField(new Point(5, 1)).isFoggy());
        assertFalse(map.getField(new Point(5, 2)).isFoggy());
        assertFalse(map.getField(new Point(5, 3)).isFoggy());
        assertFalse(map.getField(new Point(5, 4)).isFoggy());
        assertFalse(map.getField(new Point(5, 5)).isFoggy());
        assertFalse(map.getField(new Point(5, 6)).isFoggy());
        assertFalse(map.getField(new Point(6, 0)).isFoggy());
        assertFalse(map.getField(new Point(6, 1)).isFoggy());
        assertFalse(map.getField(new Point(6, 2)).isFoggy());
        assertFalse(map.getField(new Point(6, 3)).isFoggy());
        assertFalse(map.getField(new Point(6, 4)).isFoggy());
        assertFalse(map.getField(new Point(6, 5)).isFoggy());
        assertFalse(map.getField(new Point(6, 6)).isFoggy());

        assertTrue(GadgetLogic.fogTin(jamesBond, new Point(3, 2), map, matchconfig));

        assertFalse(map.getField(new Point(0, 0)).isFoggy());
        assertFalse(map.getField(new Point(0, 1)).isFoggy());
        assertFalse(map.getField(new Point(0, 2)).isFoggy());
        assertFalse(map.getField(new Point(0, 3)).isFoggy());
        assertFalse(map.getField(new Point(0, 4)).isFoggy());
        assertFalse(map.getField(new Point(0, 5)).isFoggy());
        assertFalse(map.getField(new Point(0, 6)).isFoggy());
        assertFalse(map.getField(new Point(1, 0)).isFoggy());
        assertFalse(map.getField(new Point(1, 1)).isFoggy());
        assertFalse(map.getField(new Point(1, 2)).isFoggy());
        assertFalse(map.getField(new Point(1, 3)).isFoggy());
        assertFalse(map.getField(new Point(1, 4)).isFoggy());
        assertFalse(map.getField(new Point(1, 5)).isFoggy());
        assertFalse(map.getField(new Point(1, 6)).isFoggy());
        assertFalse(map.getField(new Point(2, 0)).isFoggy());
        assertTrue(map.getField(new Point(2, 1)).isFoggy());
        assertTrue(map.getField(new Point(2, 2)).isFoggy());
        assertTrue(map.getField(new Point(2, 3)).isFoggy());
        assertFalse(map.getField(new Point(2, 4)).isFoggy());
        assertFalse(map.getField(new Point(2, 5)).isFoggy());
        assertFalse(map.getField(new Point(2, 6)).isFoggy());
        assertFalse(map.getField(new Point(3, 0)).isFoggy());
        assertTrue(map.getField(new Point(3, 1)).isFoggy());
        assertTrue(map.getField(new Point(3, 2)).isFoggy());
        assertTrue(map.getField(new Point(3, 3)).isFoggy());
        assertFalse(map.getField(new Point(3, 4)).isFoggy());
        assertFalse(map.getField(new Point(3, 5)).isFoggy());
        assertFalse(map.getField(new Point(3, 6)).isFoggy());
        assertFalse(map.getField(new Point(4, 0)).isFoggy());
        assertTrue(map.getField(new Point(4, 1)).isFoggy());
        assertTrue(map.getField(new Point(4, 2)).isFoggy());
        assertTrue(map.getField(new Point(4, 3)).isFoggy());
        assertFalse(map.getField(new Point(4, 4)).isFoggy());
        assertFalse(map.getField(new Point(4, 5)).isFoggy());
        assertFalse(map.getField(new Point(4, 6)).isFoggy());
        assertFalse(map.getField(new Point(5, 0)).isFoggy());
        assertFalse(map.getField(new Point(5, 1)).isFoggy());
        assertFalse(map.getField(new Point(5, 2)).isFoggy());
        assertFalse(map.getField(new Point(5, 3)).isFoggy());
        assertFalse(map.getField(new Point(5, 4)).isFoggy());
        assertFalse(map.getField(new Point(5, 5)).isFoggy());
        assertFalse(map.getField(new Point(5, 6)).isFoggy());
        assertFalse(map.getField(new Point(6, 0)).isFoggy());
        assertFalse(map.getField(new Point(6, 1)).isFoggy());
        assertFalse(map.getField(new Point(6, 2)).isFoggy());
        assertFalse(map.getField(new Point(6, 3)).isFoggy());
        assertFalse(map.getField(new Point(6, 4)).isFoggy());
        assertFalse(map.getField(new Point(6, 5)).isFoggy());
        assertFalse(map.getField(new Point(6, 6)).isFoggy());
    }

    @Test
    public void testPoisenPills() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.POISON_PILLS);
        q.addGadget(GadgetEnum.COCKTAIL);
        jamesBond.addGadget(GadgetEnum.COCKTAIL);
        map.getField(new Point(1, 3)).setGadget(new Cocktail());

        // Case 1: q targets Point(5,1): no neighbour / no cocktail
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.poisonPills(q, new Point(5, 1), map, characters));

        // Case 2: q targets himself: not possible
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.poisonPills(q, new Point(2, 3), map, characters));

        // Case 3: q targets Point(3,3): neighbour / no cocktail
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.poisonPills(q, new Point(3, 3), map, characters));

        // Case 4: q targets Point(1,5): no neighbour / cocktail
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.poisonPills(q, new Point(1, 5), map, characters));

        // Case 5: q targets Point(1,2): neighbour / cocktail / character
        assertFalse(jamesBond.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.poisonPills(q, new Point(1, 2), map, characters));
        assertTrue(jamesBond.getCocktail().isPoisoned());

        // Case 6: q targets Point(1,3): neighbour / cocktail / field (bar-table)
        assertFalse(map.getField(new Point(1, 3)).getCocktail().isPoisoned());
        assertTrue(GadgetLogic.poisonPills(q, new Point(1, 3), map, characters));
        assertTrue(map.getField(new Point(1, 3)).getCocktail().isPoisoned());
    }
    
    /**
     * 
     * Überarbeitung am 19.07.: Übergabe des Diamanthalsbandes ist nicht konsistent mit dem Lastenheft!
     */
    @Test
    public void testDiamondCollar() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.DIAMOND_COLLAR);
        matchconfig.setCatIp(100);
        Character cat = new Character(UUID.randomUUID(), "Cat", new Point(5, 3), new HashSet<>(), new HashSet<>());

        // Case 1: q targets Point(5/5): no neighbour / no cat / no character
        //assertThrows(InvalidTargetException.class, () -> GadgetLogic.diamondCollar(q, new Point(5, 5), map, characters, cat, matchconfig));

        // Case 2: q targets Point(2,4): neighbour / no cat / no character
        //assertThrows(InvalidTargetException.class, () -> GadgetLogic.diamondCollar(q, new Point(2, 4), map, characters, cat, matchconfig));

        // Case 3: q targets Point(1,2): neighbour / no cat / character
        //assertThrows(InvalidTargetException.class, () -> GadgetLogic.diamondCollar(q, new Point(1, 2), map, characters, cat, matchconfig));

        // Case 4: q targets Point(1,2): no neighbour / cat / character
        //assertThrows(InvalidTargetException.class, () -> GadgetLogic.diamondCollar(q, new Point(5, 3), map, characters, cat, matchconfig));

        // Case 5: q targets point(1,2): neighbour / cat / character / no wiretap
        cat.setCoordinates(new Point(2, 2));
        assertFalse(cat.hasGadget(GadgetEnum.DIAMOND_COLLAR));
        //assertTrue(GadgetLogic.diamondCollar(q, new Point(2, 2), map, characters, cat, matchconfig));
        assertTrue(cat.hasGadget(GadgetEnum.DIAMOND_COLLAR));
        assertEquals(100, q.getIp());

        // Case 6: q targets Point(2,2): neighbour / cat / character / wiretap active
        q.setIp(0);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);
        cat.removeGadget(GadgetEnum.DIAMOND_COLLAR);
        assertFalse(cat.hasGadget(GadgetEnum.DIAMOND_COLLAR));
        //assertTrue(GadgetLogic.diamondCollar(q, new Point(2, 2), map, characters, cat, matchconfig));
        assertTrue(cat.hasGadget(GadgetEnum.DIAMOND_COLLAR));
        assertEquals(100, q.getIp());
        assertEquals(100, jamesBond.getIp());

        // Case 7: q targets himself: not possible
        //assertThrows(InvalidTargetException.class, () -> GadgetLogic.diamondCollar(q, new Point(2, 3), map, characters, cat, matchconfig));

        // Case 8: q targets Point(4,5): no neighbour / no cat / character
        //assertThrows(InvalidTargetException.class, () -> GadgetLogic.diamondCollar(q, new Point(4, 5), map, characters, cat, matchconfig));
    }

    @Test
    public void testWiretapWithEarplugs() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);

        // Case 1: q targets himself: not possible
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(2, 3), map, characters));

        // Case 2: q targets Point(5,3): no neighbour / no character / not in use
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(5, 3), map, characters));

        // Case 3: q targets Point(2,5): no neighbour/ no character / in use
        q.getWireTapWithEarplugs().setupWireTapWithEarplugs(jamesBond);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(2, 5), map, characters));

        // Case 4: q targets Point(1,5) : no neighbour / character / not in use
        q.getWireTapWithEarplugs().setWorking(false);
        q.getWireTapWithEarplugs().setActiveOn(null);
        q.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(2, 5), map, characters));

        // Case 5: q targets Point(1,5): no neighbour / character / in use
        q.getWireTapWithEarplugs().setupWireTapWithEarplugs(jamesBond);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(1, 5), map, characters));

        // Case 6: q targets Point(2,2): neighbour / no character / not in use
        q.getWireTapWithEarplugs().setWorking(false);
        q.getWireTapWithEarplugs().setActiveOn(null);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(2, 2), map, characters));

        // Case 7: q targets Point(2,2): neighbour / no character / in use
        q.getWireTapWithEarplugs().setupWireTapWithEarplugs(jamesBond);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(2, 2), map, characters));

        // Case 8: q targets Point(1,2): neighbour / character / not in use
        q.getWireTapWithEarplugs().setWorking(false);
        q.getWireTapWithEarplugs().setActiveOn(null);
        assertNotEquals(jamesBond.getCharacterId(), q.getWireTapWithEarplugs().getActiveOn());
        assertTrue(GadgetLogic.wiretapWithEarplugs(q, new Point(1, 2), map, characters));
        assertEquals(jamesBond.getCharacterId(), q.getWireTapWithEarplugs().getActiveOn());
        assertTrue(GamePhaseState.isWiretapsAlreadyUsed);

        // Case 9: q targets Point(1,2): neighbour / character / in use
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.wiretapWithEarplugs(q, new Point(1, 2), map, characters));
    }

    @Test
    public void testCheckHasWiretapWithEarpglus() {
        setup();

        // Case 1: jamesBond gets Ip and no one has the gadget: nothing happens
        GadgetLogic.checkHasWireTapWithEarplugs(jamesBond, characters, 10);

        // Case 2: jamesBond gets ip and someone has the gadget, but its not active
        q.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        GadgetLogic.checkHasWireTapWithEarplugs(jamesBond, characters, 10);
        assertEquals(0, q.getIp());

        // Case 3: jamesBond gets ip and someone has the gadget, the gadget is active but not on jamesBond
        q.getWireTapWithEarplugs().setupWireTapWithEarplugs(m);
        GadgetLogic.checkHasWireTapWithEarplugs(jamesBond, characters, 10);
        assertEquals(0, q.getIp());

        // Case 4: jamesBond gets ip and someone has the gadget, the gadget is active on jamesBond
        q.getWireTapWithEarplugs().setupWireTapWithEarplugs(jamesBond);
        GadgetLogic.checkHasWireTapWithEarplugs(jamesBond, characters, 10);
        assertEquals(10, q.getIp());
    }

    @Test
    public void testIsWiretapWithEarplugsActive() {
        setup();
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        matchconfig.setWiretapWithEarplugsFailChance(1);

        // Case 1: Gadget is not active : nothing happens
        assertFalse(GadgetLogic.isWireTapWithEarplugsActive(jamesBond.getWireTapWithEarplugs(), matchconfig, characters));
        assertFalse(jamesBond.getWireTapWithEarplugs().isWorking());

        // Case 2: Gadget is active and 100& fail chance
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(m);
        assertTrue(jamesBond.getWireTapWithEarplugs().isWorking());
        assertFalse(GadgetLogic.isWireTapWithEarplugsActive(jamesBond.getWireTapWithEarplugs(), matchconfig, characters));
        assertFalse(jamesBond.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        assertFalse(GamePhaseState.isWiretapsAlreadyUsed);

        // Case 3: Gadget is active and 0% fail chance (stays active)
        matchconfig.setWiretapWithEarplugsFailChance(0);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(m);
        assertTrue(jamesBond.getWireTapWithEarplugs().isWorking());
        assertTrue(GadgetLogic.isWireTapWithEarplugsActive(jamesBond.getWireTapWithEarplugs(), matchconfig, characters));
        assertTrue(jamesBond.hasGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS));
        assertTrue(jamesBond.getWireTapWithEarplugs().isWorking());
        assertEquals(m.getCharacterId(), jamesBond.getWireTapWithEarplugs().getActiveOn());
    }

    @Test
    public void testChickenFeed() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.CHICKEN_FEED);
        m.setCoordinates(new Point(2, 2));
        eve.setCoordinates(new Point(2, 4));
        charactersPlayer1.add(jamesBond);
        charactersPlayer1.add(q);
        charactersPlayer2.add(m);
        // jamesBond Player1, m Player2, q Player1, eve NPC

        // q player1
        // Case 1: q targets himself: not possible
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2));

        // Case 2: q targets Point(4,5): no neighbour / character / NPC
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(4, 5), map, characters, charactersPlayer1, charactersPlayer2));

        // Case 3: q targets Point(4,5): no neighbour / character / same faction
        charactersPlayer1.add(drNo);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(4, 5), map, characters, charactersPlayer1, charactersPlayer2));

        // Case 4: q targets Point(4,5): no neighbour / character / enemy faction
        charactersPlayer1.remove(drNo);
        charactersPlayer2.add(drNo);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(4, 5), map, characters, charactersPlayer1, charactersPlayer2));

        // Case 5: q targets Point(5,4): no neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(5, 4), map, characters, charactersPlayer1, charactersPlayer2));

        // Case 6: q targets Point(3,3): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(3, 3), map, characters, charactersPlayer1, charactersPlayer2));

        // q player1 / jamesBond player1
        // Case 7: q targets Point(1,2): neighbour / character / same faction / q has less IP
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer1));
        jamesBond.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, jamesBond.getIp());
        assertEquals(0, q.getIp());

        // Case 8: q targets Point(1,2): neighbour / character / same faction / q has same IP
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer1));
        jamesBond.setIp(100);
        q.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, jamesBond.getIp());
        assertEquals(100, q.getIp());

        // Case 9: q targets Point(1,2): neighbour / character / same faction / q more IP
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer1));
        jamesBond.setIp(100);
        q.setIp(120);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, jamesBond.getIp());
        assertEquals(120, q.getIp());

        // q player1 / target player2
        // Case 10: q targets Points(2,2): neighbour / character / enemy faction / q has same IP / q has no wiretap
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(m.isMemberOfFaction(charactersPlayer2));
        q.setIp(100);
        m.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());

        // Case 11: q targets Points(2,2): neighbour / character / enemy faction / q has more IP / q has no wiretap
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(m.isMemberOfFaction(charactersPlayer2));
        q.setIp(120);
        m.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());

        // Case 12: q targets Points(2,2): neighbour / character / enemy faction / q has less IP / q has no wiretap
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(m.isMemberOfFaction(charactersPlayer2));
        q.setIp(80);
        m.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());

        // Case 13: q targets Points(2,2): neighbour / character / enemy faction / q has less IP / q has wiretap active on himself
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(m.isMemberOfFaction(charactersPlayer2));
        drNo.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        drNo.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);
        drNo.setIp(0);
        assertTrue(drNo.getWireTapWithEarplugs().isWorking());
        assertEquals(q.getCharacterId(), drNo.getWireTapWithEarplugs().getActiveOn());
        q.setIp(80);
        m.setIp(100);
        GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2);
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());
        assertEquals(20, drNo.getIp());


        // q player2 / target player1
        // Case 14: q targets Points(2,2): neighbour / character / enemy faction / q has same IP / q has no wiretap
        charactersPlayer1.remove(q);
        charactersPlayer2.add(q);
        charactersPlayer2.remove(m);
        charactersPlayer1.add(m);
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(m.isMemberOfFaction(charactersPlayer1));
        q.setIp(100);
        m.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());

        // Case 15: q targets Points(2,2): neighbour / character / enemy faction / q has more IP / q has no wiretap
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(m.isMemberOfFaction(charactersPlayer1));
        q.setIp(120);
        m.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());

        // Case 16: q targets Points(2,2): neighbour / character / enemy faction / q has less IP / q has no wiretap
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(m.isMemberOfFaction(charactersPlayer1));
        q.setIp(80);
        m.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());

        // Case 17: q targets Points(2,2): neighbour / character / enemy faction / q has less IP / q has wiretap active on himself
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(m.isMemberOfFaction(charactersPlayer1));
        drNo.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        drNo.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);
        drNo.setIp(0);
        assertTrue(drNo.getWireTapWithEarplugs().isWorking());
        assertEquals(q.getCharacterId(), drNo.getWireTapWithEarplugs().getActiveOn());
        q.setIp(80);
        m.setIp(100);
        GadgetLogic.chickenFeed(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2);
        assertEquals(100, m.getIp());
        assertEquals(100, q.getIp());
        assertEquals(20, drNo.getIp());

        // q player2 / james player2
        // Case 18: q targets Point(1,2): neighbour / character / same faction / q has less IP
        charactersPlayer1.remove(jamesBond);
        charactersPlayer2.add(jamesBond);
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer2));
        q.setIp(0);
        jamesBond.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, jamesBond.getIp());
        assertEquals(0, q.getIp());

        // Case 19: q targets Point(1,2): neighbour / character / same faction / q has same IP
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer2));
        jamesBond.setIp(100);
        q.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, jamesBond.getIp());
        assertEquals(100, q.getIp());

        // Case 20: q targets Point(1,2): neighbour / character / same faction / q more IP
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer2));
        jamesBond.setIp(100);
        q.setIp(120);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, jamesBond.getIp());
        assertEquals(120, q.getIp());

        // q player 2 / target NPC
        // Case 21: q targets Point(2,4): neighbour / character / NPC
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(eve.isMemberOfFaction(charactersPlayer2));
        assertFalse(eve.isMemberOfFaction(charactersPlayer1));
        q.setIp(100);
        eve.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, q.getIp());
        assertEquals(100, eve.getIp());

        // Case 22: q targets himself: not possible
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.chickenFeed(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2));

        // q player 1 / target NPC
        // Case 23: q targets Point(2,4): neighbour / character / NPC
        charactersPlayer2.remove(q);
        charactersPlayer1.add(q);
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertFalse(eve.isMemberOfFaction(charactersPlayer2));
        assertFalse(eve.isMemberOfFaction(charactersPlayer1));
        q.setIp(100);
        eve.setIp(100);
        assertTrue(GadgetLogic.chickenFeed(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(100, q.getIp());
        assertEquals(100, eve.getIp());
    }

    @Test
    public void testNugget() throws InvalidTargetException {
        // setup player1
        setup();
        q.addGadget(GadgetEnum.NUGGET);
        charactersPlayer1.add(q);
        charactersPlayer2.add(jamesBond);
        charactersNPC.add(drNo);
        charactersPlayer1.add(m);
        drNo.setCoordinates(new Point(2, 2));
        m.setCoordinates(new Point(2, 4));

        // Cases for player1
        // Case 1: q targets Point(3,3): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(3, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 2: q targets Point(4,4): no neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(4, 4), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 3: q targets Point(1,5): no neighbour / character <- wayne which faction since no neighbour
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(1, 5), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 4: q targets Point(1,2): neighbour / character / player2

        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertFalse(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertFalse(jamesBond.isMemberOfFaction(charactersPlayer1));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer2));
        assertFalse(jamesBond.isMemberOfFaction(charactersNPC));

        assertTrue(GadgetLogic.nugget(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertFalse(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertFalse(jamesBond.isMemberOfFaction(charactersPlayer1));
        assertTrue(jamesBond.isMemberOfFaction(charactersPlayer2));
        assertFalse(jamesBond.isMemberOfFaction(charactersNPC));

        assertTrue(jamesBond.hasGadget(GadgetEnum.NUGGET));

        // Case 5: q targets Point(2,4): neighbour / character / player1
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 6: q targets Point(2,2): neighbour / character / npc
        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertFalse(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertFalse(drNo.isMemberOfFaction(charactersPlayer1));
        assertFalse(drNo.isMemberOfFaction(charactersPlayer2));
        assertTrue(drNo.isMemberOfFaction(charactersNPC));

        assertTrue(GadgetLogic.nugget(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        assertTrue(q.isMemberOfFaction(charactersPlayer1));
        assertFalse(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertTrue(drNo.isMemberOfFaction(charactersPlayer1));
        assertFalse(drNo.isMemberOfFaction(charactersPlayer2));
        assertFalse(drNo.isMemberOfFaction(charactersNPC));

        // Case 7: q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Cases for player 2
        setup();
        q.addGadget(GadgetEnum.NUGGET);
        charactersPlayer2.add(q);
        charactersPlayer2.add(jamesBond);
        charactersNPC.add(drNo);
        charactersPlayer1.add(m);
        drNo.setCoordinates(new Point(2, 2));
        m.setCoordinates(new Point(2, 4));

        // Case 8: q targets Point(3,3): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(3, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 9: q targets Point(4,4): no neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(4, 4), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 10: q targets Point(1,5): no neighbour / character <- wayne which faction since no neighbour
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(1, 5), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 11: q targets Point(1,2): neighbour / character / player2
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        // Case 12: q targets Point(2,4): neighbour / character / player1
        assertFalse(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertTrue(m.isMemberOfFaction(charactersPlayer1));
        assertFalse(m.isMemberOfFaction(charactersPlayer2));
        assertFalse(m.isMemberOfFaction(charactersNPC));

        assertTrue(GadgetLogic.nugget(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        assertFalse(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertTrue(m.isMemberOfFaction(charactersPlayer1));
        assertFalse(m.isMemberOfFaction(charactersPlayer2));
        assertFalse(m.isMemberOfFaction(charactersNPC));

        assertTrue(m.hasGadget(GadgetEnum.NUGGET));

        // Case 13: q targets Point(2,2): neighbour / character / npc
        assertFalse(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertFalse(drNo.isMemberOfFaction(charactersPlayer1));
        assertFalse(drNo.isMemberOfFaction(charactersPlayer2));
        assertTrue(drNo.isMemberOfFaction(charactersNPC));

        assertTrue(GadgetLogic.nugget(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

        assertFalse(q.isMemberOfFaction(charactersPlayer1));
        assertTrue(q.isMemberOfFaction(charactersPlayer2));
        assertFalse(q.isMemberOfFaction(charactersNPC));
        assertFalse(drNo.isMemberOfFaction(charactersPlayer1));
        assertTrue(drNo.isMemberOfFaction(charactersPlayer2));
        assertFalse(drNo.isMemberOfFaction(charactersNPC));

        // Case 14: q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.nugget(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC));

    }

    @Test
    public void testMothballPouch() throws TargetOutOfRangeException, TargetOutOfSightException, InvalidTargetException {
        setup();
        matchconfig.setMothballPouchDamage(40);
        matchconfig.setMothballPouchRange(1);
        q.addGadget(GadgetEnum.MOTHBALL_POUCH);

        // Case 1: q targets Point(1,1): not in range / in sight / fireplace
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.mothballPouch(q, new Point(1, 1), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 2: q targets Point(5,1): not in range / in sight / no fireplace
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mothballPouch(q, new Point(5, 1), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 3: q targets Point(5,5): not in range / not in sight / no fireplace
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mothballPouch(q, new Point(5, 5), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 4: q targets Point(5,5): not in range / not in sight / fireplace
        map.getField(new Point(5, 5)).updateFieldState(FieldStateEnum.FIREPLACE);
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.mothballPouch(q, new Point(5, 5), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 5: q targets Point(5,5): in range / not in sight / fireplace
        matchconfig.setMothballPouchRange(300);
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.mothballPouch(q, new Point(5, 5), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 6: q targets Point(4,5): in range / not in sight / no fireplace
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mothballPouch(q, new Point(4, 5), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 7: q targets Point(4,2): in range / in sight / no fireplace
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mothballPouch(q, new Point(4, 5), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

        // Case 8: q targets Point(1,1): in range / in sight / fireplace
        assertEquals(100, jamesBond.getHp());
        assertTrue(GadgetLogic.mothballPouch(q, new Point(1, 1), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));
        assertEquals(60, jamesBond.getHp());

        // Case 9 : q targets Point(4,1): in range / in sight / fireplace
        map.getField(new Point(4, 1)).updateFieldState(FieldStateEnum.FIREPLACE);
        assertEquals(100, eve.getHp());
        assertTrue(GadgetLogic.mothballPouch(q, new Point(4, 1), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));
        assertEquals(60, eve.getHp());
        // Case 10: target himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mothballPouch(q, new Point(2, 3), map, characters, matchconfig, charactersPlayer1, charactersPlayer2));

    }

    @Test
    public void testPickupCocktail() throws InvalidTargetException {
        setup();

        // Case 1: q targets Point(1,3): neighbour / cocktail on table
        map.getField(new Point(1, 3)).setGadget(new Cocktail());
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));
        assertTrue(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        assertTrue(GadgetLogic.pickupCocktail(q, map, new Point(1, 3)));

        assertTrue(q.hasGadget(GadgetEnum.COCKTAIL));
        assertFalse(map.getField(new Point(1, 3)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 2: q targets himself
        q.removeGadget(GadgetEnum.COCKTAIL);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.pickupCocktail(q, map, new Point(2, 3)));
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 3: q targets Point(3,3): neighbour / no cocktail
        q.removeGadget(GadgetEnum.COCKTAIL);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.pickupCocktail(q, map, new Point(2, 3)));
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 4: q targets Point(5,5): no neighbour / no cocktail
        q.removeGadget(GadgetEnum.COCKTAIL);
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.pickupCocktail(q, map, new Point(5, 5)));
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 5: q targets Point(3,1): no neighbour / cocktail
        q.removeGadget(GadgetEnum.COCKTAIL);
        map.getField(new Point(3, 1)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(3, 1)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.pickupCocktail(q, map, new Point(3, 1)));
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));
    }

    @Test
    public void testMirrorOfWilderness() throws InvalidTargetException {
        setup();

        // setup Player1
        matchconfig.setMirrorSwapChance(1);
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        m.setCoordinates(new Point(2, 2));
        drNo.setCoordinates(new Point(2, 4));
        charactersPlayer1.add(q);
        charactersPlayer1.add(jamesBond);
        charactersPlayer2.add(m);
        charactersNPC.add(drNo);

        // Case 1: q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 2: q targets Point(5,3): no neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(5, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 3: q targets Point(5,1): no neighbour / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(5, 1), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 4: q targets Point(3,2): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(3, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 5: q targets Point(1,2): neighbour / character / jamesBond factionPlayer1
        jamesBond.setIp(100);
        q.setIp(0);

        assertTrue(GadgetLogic.mirrorOfWilderness(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(0, jamesBond.getIp());
        assertEquals(100, q.getIp());
        assertTrue(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // Case 6: q targets Point(2,2):  neighbour / character / m factionPlayer2 / hit yes / wiretap no
        m.setIp(100);
        q.setIp(0);
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);

        assertTrue(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(0, m.getIp());
        assertEquals(100, q.getIp());
        assertFalse(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // Case 7: q targets Point(2,2): neighbour / character / m factionPlayer2 / hit yes / wiretap yes
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);

        jamesBond.setIp(0);
        m.setIp(100);
        q.setIp(0);

        assertTrue(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(0, m.getIp());
        assertEquals(100, q.getIp());
        assertEquals(100, jamesBond.getIp());
        assertFalse(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // Case 8: q targets Point(2,2): neighbour/ character / m factionPlayer2 / hit no / wiretap no
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        jamesBond.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        matchconfig.setMirrorSwapChance(0);

        jamesBond.setIp(0);
        m.setIp(100);
        q.setIp(0);

        assertFalse(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(100, m.getIp());
        assertEquals(0, q.getIp());
        assertEquals(0, jamesBond.getIp());

        // Case 9: q targets Point(2,2): neighbour / character / m factionPlayer2/ hit no / wiretap yes

        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        jamesBond.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);
        matchconfig.setMirrorSwapChance(0);

        jamesBond.setIp(0);
        m.setIp(100);
        q.setIp(0);

        assertFalse(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(100, m.getIp());
        assertEquals(0, q.getIp());
        assertEquals(0, jamesBond.getIp());

        // Case 8: q targets Point(2,4): neighbour / character / drNo factionNPC
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        drNo.setIp(100);
        q.setIp(0);

        assertFalse(GadgetLogic.mirrorOfWilderness(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(100, drNo.getIp());
        assertEquals(0, q.getIp());
        assertTrue(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // setup player2
        setup();

        matchconfig.setMirrorSwapChance(1);
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        m.setCoordinates(new Point(2, 2));
        drNo.setCoordinates(new Point(2, 4));
        charactersPlayer2.add(q);
        charactersPlayer2.add(jamesBond);
        charactersPlayer1.add(m);
        charactersNPC.add(drNo);

        // Case 9: q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 10: q targets Point(5,3): no neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(5, 3), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 11: q targets Point(5,1): no neighbour / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(5, 1), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 12: q targets Point(3,2): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.mirrorOfWilderness(q, new Point(3, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        // Case 13: q targets Point(1,2): neighbour / character / jamesBond factionPlayer2
        jamesBond.setIp(100);
        q.setIp(0);

        assertTrue(GadgetLogic.mirrorOfWilderness(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(0, jamesBond.getIp());
        assertEquals(100, q.getIp());
        assertTrue(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // Case 14: q targets Point(2,2):  neighbour / character / m factionPlayer1 / hit yes / wiretap no
        m.setIp(100);
        q.setIp(0);
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);

        assertTrue(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(0, m.getIp());
        assertEquals(100, q.getIp());
        assertFalse(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // Case 15: q targets Point(2,2): neighbour / character / m factionPlayer1 / hit yes / wiretap yes
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);

        jamesBond.setIp(0);
        m.setIp(100);
        q.setIp(0);

        assertTrue(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(0, m.getIp());
        assertEquals(100, q.getIp());
        assertEquals(100, jamesBond.getIp());
        assertFalse(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));

        // Case 16: q targets Point(2,2): neighbour/ character / m factionPlayer1 / hit no / wiretap no
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        jamesBond.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        matchconfig.setMirrorSwapChance(0);

        jamesBond.setIp(0);
        m.setIp(100);
        q.setIp(0);

        assertFalse(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(100, m.getIp());
        assertEquals(0, q.getIp());
        assertEquals(0, jamesBond.getIp());

        // Case 17: q targets Point(2,2): neighbour / character / m factionPlayer1 / hit no / wiretap yes

        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        jamesBond.removeGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.addGadget(GadgetEnum.WIRETAP_WITH_EARPLUGS);
        jamesBond.getWireTapWithEarplugs().setupWireTapWithEarplugs(q);
        matchconfig.setMirrorSwapChance(0);

        jamesBond.setIp(0);
        m.setIp(100);
        q.setIp(0);

        assertFalse(GadgetLogic.mirrorOfWilderness(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(100, m.getIp());
        assertEquals(0, q.getIp());
        assertEquals(0, jamesBond.getIp());


        // Case 18: q targets Point(2,4): neighbour / character / drNo factionNPC
        q.addGadget(GadgetEnum.MIRROR_OF_WILDERNESS);
        drNo.setIp(100);
        q.setIp(0);

        assertFalse(GadgetLogic.mirrorOfWilderness(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2, charactersNPC, matchconfig));

        assertEquals(100, drNo.getIp());
        assertEquals(0, q.getIp());
        assertTrue(q.hasGadget(GadgetEnum.MIRROR_OF_WILDERNESS));
    }

    @Test
    public void testGrapple() throws TargetOutOfRangeException, TargetOutOfSightException, InvalidTargetException {
        setup();
        matchconfig.setGrappleRange(1);
        matchconfig.setGrappleHitChance(1);
        q.addGadget(GadgetEnum.GRAPPLE);

        // Case 1: Q targets himself: not possible
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.grapple(q, new Point(2, 3), map, matchconfig));

        // Case 2: Q targets Point(5,5): not in range / no sight / no gadget
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 5), map, matchconfig));

        // Case 3: Q targets Point(5,5): not in range / no sight / gadget cocktail
        map.getField(new Point(5, 5)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 5), map, matchconfig));
        assertTrue(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        map.getField(new Point(5, 5)).setGadget(null);
        assertFalse(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 4: Q targets Point(5,5):not in range / no sight / gadget diamondCollar
        map.getField(new Point(5, 5)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 5), map, matchconfig));
        assertTrue(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        map.getField(new Point(5, 5)).setGadget(null);
        assertFalse(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));

        // Case 5: Q targets Point(5,5):not in range / no sight / gadget bowlerBlade
        map.getField(new Point(5, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 5), map, matchconfig));
        assertTrue(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(5, 5)).setGadget(null);
        assertFalse(map.getField(new Point(5, 5)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));

        // Case 6: Q targets Point(5,2): not in range / in sight / no gadget
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 5), map, matchconfig));

        // Case 7: Q targets Point(5,2): not in range / in sight / gadget cocktail
        map.getField(new Point(5, 2)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 2), map, matchconfig));
        assertTrue(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        map.getField(new Point(5, 2)).setGadget(null);
        assertFalse(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 8: Q targets Point(5,2):not in range / in sight / gadget diamondCollar
        map.getField(new Point(5, 2)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 2), map, matchconfig));
        assertTrue(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        map.getField(new Point(5, 2)).setGadget(null);
        assertFalse(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));

        // Case 9: Q targets Point(5,2):not in range / in sight / gadget bowlerBlade
        map.getField(new Point(5, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.grapple(q, new Point(5, 2), map, matchconfig));
        assertTrue(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(5, 2)).setGadget(null);
        assertFalse(map.getField(new Point(5, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));

        // Case 10: Q targets Point(3,5):in range / no sight / no gadget
        matchconfig.setGrappleRange(2);
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.grapple(q, new Point(3, 5), map, matchconfig));

        // Case 11: Q targets Point(3,5):in range / no sight / gadget Cocktail
        map.getField(new Point(3, 5)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.grapple(q, new Point(3, 5), map, matchconfig));
        assertTrue(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        map.getField(new Point(3, 5)).setGadget(null);
        assertFalse(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.COCKTAIL));

        // Case 12: Q targets Point(3,5):in range / no sight / gadget diamondCollar
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.grapple(q, new Point(3, 5), map, matchconfig));
        assertTrue(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        map.getField(new Point(3, 5)).setGadget(null);
        assertFalse(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));

        // Case 13: Q targets Point(3,5):in range / no sight / gadget bowlerBlade
        map.getField(new Point(3, 5)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.grapple(q, new Point(3, 5), map, matchconfig));
        assertTrue(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        map.getField(new Point(3, 5)).setGadget(null);
        assertFalse(map.getField(new Point(3, 5)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));

        // Case 14: Q targets Point(4,2):in range / in sight / no gadget
        assertFalse(map.getField(new Point(4, 2)).hasGadget());
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertFalse(map.getField(new Point(4, 2)).hasGadget());

        // Case 15: Q targets Point(4,2): in range / in sight / gadget Cocktail
        map.getField(new Point(4, 2)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertFalse(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertTrue(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 16: Q targets Point(4,2):in range / no sight / gadget diamondCollar
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertFalse(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(q.hasGadget(GadgetEnum.DIAMOND_COLLAR));

        // Case 17: Q targets Point(4,2):in range / no sight / gadget bowlerBlade
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertTrue(GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertFalse(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertTrue(q.hasGadget(GadgetEnum.BOWLER_BLADE));

        // hit chance = 0%
        matchconfig.setGrappleHitChance(0);
        q.removeGadget(GadgetEnum.DIAMOND_COLLAR);
        q.removeGadget(GadgetEnum.COCKTAIL);
        q.removeGadget(GadgetEnum.BOWLER_BLADE);

        // Case 18: Q targets Point(4,2): in range / in sight / gadget Cocktail
        map.getField(new Point(4, 2)).setGadget(new Cocktail());
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertFalse(GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.COCKTAIL));
        assertFalse(q.hasGadget(GadgetEnum.COCKTAIL));

        // Case 19: Q targets Point(4,2):in range / no sight / gadget diamondCollar
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.DIAMOND_COLLAR));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertFalse(GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.DIAMOND_COLLAR));
        assertFalse(q.hasGadget(GadgetEnum.DIAMOND_COLLAR));


        // Case 20: Q targets Point(4,2):in range / no sight / gadget bowlerBlade
        map.getField(new Point(4, 2)).setGadget(new Gadget(GadgetEnum.BOWLER_BLADE));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertFalse(GadgetLogic.grapple(q, new Point(4, 2), map, matchconfig));
        assertTrue(map.getField(new Point(4, 2)).hasGadgetOfType(GadgetEnum.BOWLER_BLADE));
        assertFalse(q.hasGadget(GadgetEnum.BOWLER_BLADE));
    }

    @Test
    public void testDrinkCocktail() {
        setup();

        MainServerLogic.winCondition.setDamageTakenPlayer1(0);
        MainServerLogic.winCondition.setDamageTakenPlayer2(0);
        MainServerLogic.winCondition.setDrankCocktailsPlayer1(0);
        MainServerLogic.winCondition.setDrankCocktailsPlayer2(0);

        q.addGadget(GadgetEnum.COCKTAIL);
        matchconfig.setCocktailHp(20);

        // Case 1: Q targets himself: cocktail / not poisoned / no robust stomach / no faction

        q.setHp(50);
        assertFalse(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertFalse(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(70, q.getHp());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());


        // Case 2: Q targets himself: cocktail / not poisoned / robust stomach / no faction
        q.setHp(40);
        matchconfig.setCocktailHp(20);
        q.addProperty(PropertyEnum.ROBUST_STOMACH);
        assertTrue(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertFalse(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(80, q.getHp());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());

        // Case 3: Q targets himself: cocktail / poisoned / no robust stomach / no faction
        q.setHp(40);
        matchconfig.setCocktailHp(20);
        q.removeProperty(PropertyEnum.ROBUST_STOMACH);
        q.getCocktail().poison();
        assertFalse(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertTrue(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(20, q.getHp());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 4: Q targets himself: cocktail / poisoned / robust stomach / no faction
        q.setHp(40);
        matchconfig.setCocktailHp(20);
        q.addProperty(PropertyEnum.ROBUST_STOMACH);
        q.getCocktail().poison();
        assertTrue(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertTrue(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(30, q.getHp());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer2());

        //Player1
        // Case 5: Q targets himself: cocktail / not poisoned / no robust stomach / factionPlayer1
        q.setHp(50);
        charactersPlayer1.add(q);
        q.removeGadget(GadgetEnum.COCKTAIL);
        q.addGadget(GadgetEnum.COCKTAIL);
        q.removeProperty(PropertyEnum.ROBUST_STOMACH);
        assertFalse(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertFalse(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(70, q.getHp());
        assertEquals(1, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());

        // Case 6: Q targets himself: cocktail / poisoned / no robust stomach / factionPlayer1
        q.setHp(50);
        assertFalse(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        q.getCocktail().poison();
        assertTrue(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(30, q.getHp());
        assertEquals(2, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(20, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 7: Q targets himself: cocktail / poisoned / robust stomach / factionPlayer1
        q.setHp(50);
        q.addProperty(PropertyEnum.ROBUST_STOMACH);
        assertTrue(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertTrue(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(40, q.getHp());
        assertEquals(3, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 8:Q targets himself: cocktail / not poisoned / robust stomach / factionPlayer1
        q.setHp(50);
        q.removeGadget(GadgetEnum.COCKTAIL);
        q.addGadget(GadgetEnum.COCKTAIL);
        assertTrue(q.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertFalse(q.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(q, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(90, q.getHp());
        assertEquals(4, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer2());

        //Player2
        // Case 9: JamesBond targets himself: cocktail / not poisoned / no robust stomach / factionPlayer1
        charactersPlayer2.add(jamesBond);
        jamesBond.setHp(50);
        jamesBond.removeGadget(GadgetEnum.COCKTAIL);
        jamesBond.addGadget(GadgetEnum.COCKTAIL);
        jamesBond.removeProperty(PropertyEnum.ROBUST_STOMACH);
        assertFalse(jamesBond.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertFalse(jamesBond.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(jamesBond, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(70, jamesBond.getHp());
        assertEquals(4, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(1, MainServerLogic.winCondition.getDrankCocktailsPlayer2());

        // Case 10: JamesBond targets himself: cocktail / poisoned / no robust stomach / factionPlayer1
        jamesBond.setHp(50);
        assertFalse(jamesBond.hasProperty(PropertyEnum.ROBUST_STOMACH));
        jamesBond.getCocktail().poison();
        assertTrue(jamesBond.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(jamesBond, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(30, jamesBond.getHp());
        assertEquals(4, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(2, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(20, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 11: JamesBond targets himself: cocktail / poisoned / robust stomach / factionPlayer1
        jamesBond.setHp(50);
        jamesBond.addProperty(PropertyEnum.ROBUST_STOMACH);
        assertTrue(jamesBond.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertTrue(jamesBond.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(jamesBond, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(40, jamesBond.getHp());
        assertEquals(4, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(3, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 12: JamesBond targets himself: cocktail / not poisoned / robust stomach / factionPlayer1
        jamesBond.setHp(50);
        jamesBond.removeGadget(GadgetEnum.COCKTAIL);
        jamesBond.addGadget(GadgetEnum.COCKTAIL);
        assertTrue(jamesBond.hasProperty(PropertyEnum.ROBUST_STOMACH));
        assertFalse(jamesBond.getCocktail().isPoisoned());
        assertTrue(GadgetLogic.drinkCocktail(jamesBond, map, matchconfig, characters, charactersPlayer1, charactersPlayer2));
        assertEquals(90, jamesBond.getHp());
        assertEquals(4, MainServerLogic.winCondition.getDrankCocktailsPlayer1());
        assertEquals(4, MainServerLogic.winCondition.getDrankCocktailsPlayer2());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(30, MainServerLogic.winCondition.getDamageTakenPlayer2());
    }

    @Test
    public void testSpillCocktail() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.COCKTAIL);
        drNo.setCoordinates(new Point(2, 2));
        matchconfig.setCocktailDodgeChance(1);
        matchconfig.setBabysitterSuccessChance(0);
        matchconfig.setHoneyTrapSuccessChance(0);
        MainServerLogic.winCondition.setSpilledCocktailsPlayer1(0);
        MainServerLogic.winCondition.setSpilledCocktailsPlayer2(0);


        // Case 1: Q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.spillCocktail(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 2: Q targets Point(3,3): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.spillCocktail(q, new Point(3, 3), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 3: Q targets Point(4,5): no neighbour / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.spillCocktail(q, new Point(4, 5), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 4: Q targets Point(1,2): neighbour / character / no honeytrap / no hit (100% dodge)
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));

        // Case 5: Q targets Point(1,2): neighbour / character / no honeytrap / hit (0% dodge)
        matchconfig.setCocktailDodgeChance(0);
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 6: Q targets Point(1,2): neighbour / character / no honeytrap / babysitter (no success)
        charactersPlayer1.add(jamesBond);
        charactersPlayer1.add(drNo);
        drNo.addProperty(PropertyEnum.BABYSITTER);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 7: Q targets Point(1,2): neighbour / character / no honeytrap / babysitter (success)
        matchconfig.setBabysitterSuccessChance(1);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        drNo.removeProperty(PropertyEnum.BABYSITTER);

        // Case 8: Q targets Point(1,2): neighbour / character / honeytrap (no success) / hit
        jamesBond.addProperty(PropertyEnum.HONEY_TRAP);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 9: Q targets Point(1,2): neighbour / character / honeytrap (success) / hit
        matchconfig.setHoneyTrapSuccessChance(1);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(drNo.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(drNo.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        drNo.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 10: Q targets Point(1,2): neighbour / character / honeytrap (success but no new target possible) / hit
        matchconfig.setHoneyTrapSuccessChance(1);
        drNo.setCoordinates(new Point(4, 5));

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(drNo.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(drNo.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        drNo.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        jamesBond.removeProperty(PropertyEnum.HONEY_TRAP);

        // Tests for babysitter stuff faction2
        // Case 11: Q targets Point(1,2): neighbour / character / babysitter (no success)
        charactersPlayer1.remove(jamesBond);
        charactersPlayer1.remove(drNo);
        charactersPlayer2.add(jamesBond);
        charactersPlayer2.add(drNo);
        drNo.addProperty(PropertyEnum.BABYSITTER);
        drNo.setCoordinates(new Point(2, 2));
        matchconfig.setBabysitterSuccessChance(0);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 12: Q targets Point(1,2): neighbour / character / babysitter (success)
        matchconfig.setBabysitterSuccessChance(1);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertFalse(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
        drNo.removeProperty(PropertyEnum.BABYSITTER);

        // Test if spillCocktails gets counted correctly.
        // Case 13: Player1
        charactersPlayer1.add(q);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertEquals(1, MainServerLogic.winCondition.getSpilledCocktailsPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getSpilledCocktailsPlayer2());
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 14: Player2
        charactersPlayer1.remove(q);
        charactersPlayer2.add(q);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertEquals(1, MainServerLogic.winCondition.getSpilledCocktailsPlayer1());
        assertEquals(1, MainServerLogic.winCondition.getSpilledCocktailsPlayer2());
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 15: NPC
        charactersPlayer2.remove(q);

        assertFalse(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertTrue(GadgetLogic.spillCocktail(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertTrue(jamesBond.hasProperty(PropertyEnum.CLAMMY_CLOTHES));
        assertEquals(1, MainServerLogic.winCondition.getSpilledCocktailsPlayer1());
        assertEquals(1, MainServerLogic.winCondition.getSpilledCocktailsPlayer2());
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);
    }

    @Test
    public void testBowlerBlade() throws TargetBlockedException, TargetOutOfSightException, InvalidTargetException, TargetOutOfRangeException {
        // Setup
        setup();
        map.getField(new Point(3, 3)).updateFieldState(FieldStateEnum.FREE);
        drNo.setCoordinates(new Point(2, 2));
        jamesBond.setCoordinates(new Point(3, 3));
        matchconfig.setBowlerBladeDamage(10);
        matchconfig.setBowlerBladeRange(2);
        matchconfig.setBowlerBladeHitChance(0);

        // Case 1: Q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.bowlerBlade(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 2: Q targets Point(4,5): not in sight / not blocked / in range / no character
        assertThrows(TargetOutOfSightException.class, () -> GadgetLogic.bowlerBlade(q, new Point(4, 5), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 3: Q targets Point(2,1): in sight / blocked / in range / no character
        assertThrows(TargetBlockedException.class, () -> GadgetLogic.bowlerBlade(q, new Point(2, 1), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 4: Q targets Point(2,6): in sight / not blocked / not in range / no character
        assertThrows(TargetOutOfRangeException.class, () -> GadgetLogic.bowlerBlade(q, new Point(2, 6), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 5: Q targets Point(2,4): in sight / not blocked / in range / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.bowlerBlade(q, new Point(2, 4), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 6: Q targets Point(2,2): no hit (0% hit chance)
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertFalse(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(100, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup change
        matchconfig.setBowlerBladeHitChance(1);
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(1, 2)).setGadget(null);

        // Case 7: Q targets Point(2,2): hit (100% hit chance)
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(90, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup change
        drNo.addProperty(PropertyEnum.HONEY_TRAP);
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(1, 2)).setGadget(null);
        matchconfig.setHoneyTrapSuccessChance(0);

        // Case 8: Q targets Point(2,2): honeytrap no success
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(80, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup change
        jamesBond.setCoordinates(new Point(4, 5));
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(1, 2)).setGadget(null);
        matchconfig.setBowlerBladeRange(1);
        matchconfig.setHoneyTrapSuccessChance(1);

        // Case 9: Q targets Point(2,2): honeytrap success / no other target possible
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(70, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup change
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(1, 2)).setGadget(null);
        map.getField(new Point(3, 3)).setGadget(null);
        jamesBond.setCoordinates(new Point(3, 3));

        // Case 10: Q targets Point(2,2): honeytrap success / other target
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(90, jamesBond.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(3, 3), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(4, 2)).setGadget(null);
        map.getField(new Point(4, 3)).setGadget(null);
        map.getField(new Point(4, 4)).setGadget(null);
        map.getField(new Point(2, 4)).setGadget(null);
        drNo.removeProperty(PropertyEnum.HONEY_TRAP);
        drNo.addGadget(GadgetEnum.MAGNETIC_WATCH);

        // Case 11: Q targets Point(2,2): target has magnetic watch
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertFalse(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(70, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup change
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(1, 2)).setGadget(null);
        drNo.removeGadget(GadgetEnum.MAGNETIC_WATCH);
        jamesBond.addProperty(PropertyEnum.BABYSITTER);
        charactersPlayer1.add(drNo);
        charactersPlayer1.add(jamesBond);
        charactersPlayer2.add(q);
        matchconfig.setBabysitterSuccessChance(1);

        // Case 12 Q targets Point(2,2): babysitter success
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertFalse(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(90, jamesBond.getHp());
        assertEquals(70, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());

        // Setup change
        map.getField(new Point(3, 2)).setGadget(null);
        map.getField(new Point(1, 2)).setGadget(null);
        matchconfig.setBabysitterSuccessChance(0);

        // Case 13: Q targets Point(2,2): babysitter no success
        assertTrue(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
        assertTrue(GadgetLogic.bowlerBlade(q, new Point(2, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(60, drNo.getHp());
        assertFalse(map.getNeighboursWithGadgetOfType(new Point(2, 2), GadgetEnum.BOWLER_BLADE).isEmpty());
    }

    @Test
    public void testGasGloss() throws InvalidTargetException {
        setup();
        q.addGadget(GadgetEnum.GAS_GLOSS);
        drNo.setCoordinates(new Point(2, 2));
        matchconfig.setGasGlossDamage(50);
        matchconfig.setBabysitterSuccessChance(0);
        matchconfig.setHoneyTrapSuccessChance(0);

        // Case 1: Q targets himself
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.gasGloss(q, new Point(2, 3), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 2: Q targets Point(3,3): neighbour / no character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.gasGloss(q, new Point(3, 3), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 3: Q targets Point(4,5): no neighbour / character
        assertThrows(InvalidTargetException.class, () -> GadgetLogic.gasGloss(q, new Point(4, 5), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 4: Q targets Point(1,2): neighbour / character / no honeytrap
        jamesBond.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());

        // Case 5: Q targets Point(1,2): neighbour / character / no honeytrap / babysitter (no success)
        charactersPlayer1.add(jamesBond);
        charactersPlayer1.add(drNo);
        drNo.addProperty(PropertyEnum.BABYSITTER);

        jamesBond.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());

        // Case 6: Q targets Point(1,2): neighbour / character / no honeytrap / babysitter (success)
        matchconfig.setBabysitterSuccessChance(1);

        jamesBond.setHp(100);
        assertFalse(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(100, jamesBond.getHp());
        drNo.removeProperty(PropertyEnum.BABYSITTER);

        // Case 7: Q targets Point(1,2): neighbour / character / honeytrap (no success)
        jamesBond.addProperty(PropertyEnum.HONEY_TRAP);

        jamesBond.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());

        // Case 8: Q targets Point(1,2): neighbour / character / honeytrap (success)
        matchconfig.setHoneyTrapSuccessChance(1);

        jamesBond.setHp(100);
        drNo.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(100, jamesBond.getHp());
        assertEquals(50, drNo.getHp());

        // Case 9: Q targets Point(1,2): neighbour / character / honeytrap (success but no new target possible) / hit
        matchconfig.setHoneyTrapSuccessChance(1);
        drNo.setCoordinates(new Point(4, 5));

        jamesBond.setHp(100);
        drNo.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        jamesBond.removeProperty(PropertyEnum.HONEY_TRAP);

        // Tests for babysitter stuff faction2
        // Case 10: Q targets Point(1,2): neighbour / character / babysitter (no success)
        charactersPlayer1.remove(jamesBond);
        charactersPlayer1.remove(drNo);
        charactersPlayer2.add(jamesBond);
        charactersPlayer2.add(drNo);
        drNo.addProperty(PropertyEnum.BABYSITTER);
        drNo.setCoordinates(new Point(2, 2));
        matchconfig.setBabysitterSuccessChance(0);

        jamesBond.setHp(100);
        drNo.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());
        assertEquals(100, drNo.getHp());

        // Case 11: Q targets Point(1,2): neighbour / character / babysitter (success)
        matchconfig.setBabysitterSuccessChance(1);

        jamesBond.setHp(100);
        drNo.setHp(100);
        assertFalse(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(100, jamesBond.getHp());
        assertEquals(100, drNo.getHp());
        drNo.removeProperty(PropertyEnum.BABYSITTER);

        // Test if takeDamage gets counted correctly.
        // Case 12: Player1
        MainServerLogic.winCondition.setDamageTakenPlayer1(0);
        MainServerLogic.winCondition.setDamageTakenPlayer2(0);

        charactersPlayer1.add(jamesBond);

        jamesBond.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());
        assertEquals(50, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(0, MainServerLogic.winCondition.getDamageTakenPlayer2());

        // Case 13: Player2
        charactersPlayer1.remove(jamesBond);
        charactersPlayer2.add(jamesBond);

        jamesBond.setHp(100);
        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());
        assertEquals(50, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(50, MainServerLogic.winCondition.getDamageTakenPlayer2());
        jamesBond.removeProperty(PropertyEnum.CLAMMY_CLOTHES);

        // Case 14: NPC
        charactersPlayer2.remove(jamesBond);

        jamesBond.setHp(100);

        assertTrue(GadgetLogic.gasGloss(q, new Point(1, 2), map, characters, charactersPlayer1, charactersPlayer2, matchconfig));
        assertEquals(50, jamesBond.getHp());
        assertEquals(50, MainServerLogic.winCondition.getDamageTakenPlayer1());
        assertEquals(50, MainServerLogic.winCondition.getDamageTakenPlayer2());
    }
}
