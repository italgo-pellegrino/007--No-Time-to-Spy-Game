package Tests.GameLogic;

import de.uulm.team0015.server.controller.GameLogic.PropertyLogic;
import de.uulm.team0015.server.model.DataTypes.ServerOnly.Matchconfig;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Field;
import de.uulm.team0015.server.model.DataTypes.Util.FieldMap;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Enumerations.FieldStateEnum;
import de.uulm.team0015.server.model.Enumerations.GadgetEnum;
import de.uulm.team0015.server.model.Enumerations.PropertyEnum;
import de.uulm.team0015.server.model.Exceptions.InvalidGadgetException;
import de.uulm.team0015.server.model.Exceptions.InvalidPropertyException;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import de.uulm.team0015.server.model.Exceptions.TargetOutOfSightException;
import org.junit.Test;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Class to test the methods for the class PropertyLogic.
 *
 * @author Marcel Rötzer
 * @version 1.0
 */
public class PropertyLogicTest {
    private FieldMap map;
    private Set<Character> characters;
    private Character jamesBond;
    private Character drNo;
    private Character q;
    private Character m;
    private Character eve;
    private Set<Character> charactersPlayer1;
    private Set<Character> charactersPlayer2;
    private Matchconfig matchconfig;

    /**
     * Method to create a test setup
     */
    public void setup() {
        // Set up map
        Field[][] fields = new Field[][]{{new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FIREPLACE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.ROULETTE_TABLE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.BAR_SEAT), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.FREE), new Field(FieldStateEnum.SAFE), new Field(FieldStateEnum.WALL)},
                {new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL), new Field(FieldStateEnum.WALL)}};
        map = new FieldMap(fields);

        // Set up characters
        jamesBond = new Character(UUID.randomUUID(), "James Bond", new Point(1, 2), new HashSet<>(), new HashSet<>());
        drNo = new Character(UUID.randomUUID(), "Dr. No", new Point(4, 5), new HashSet<>(), new HashSet<>());
        q = new Character(UUID.randomUUID(), "Q", new Point(2, 3), new HashSet<>(), new HashSet<>());
        m = new Character(UUID.randomUUID(), "M", new Point(1, 5), new HashSet<>(), new HashSet<>());
        eve = new Character(UUID.randomUUID(), "Eve", new Point(5, 1), new HashSet<>(), new HashSet<>());
        characters = new HashSet<>();
        characters.add(jamesBond);
        characters.add(drNo);
        characters.add(q);
        characters.add(m);
        characters.add(eve);
        matchconfig = new Matchconfig();
        charactersPlayer1 = new HashSet<>();
        charactersPlayer1.add(drNo);
        charactersPlayer2 = new HashSet<>();
    }

    @Test
    public void testBangAndBurn() throws InvalidTargetException, InvalidPropertyException {
        // Setup
        setup();

        // Case 1: Q targets Point (2/2): no neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> PropertyLogic.bangAndBurn(q, map, new Point(1, 1)));

        // Case 2: Q targets Point (2/2): neighbour / no roulette-table
        assertThrows(InvalidTargetException.class, () -> PropertyLogic.bangAndBurn(q, map, new Point(2, 2)));

        // Case 3: Q targets Point (3/3): neighbour / roulette-table / Q has no bangAndBurn
        assertThrows(InvalidPropertyException.class, () -> PropertyLogic.bangAndBurn(q, map, new Point(3, 3)));

        // Case 4: Q targets Point (3/3): neighbour / roulette-table / Q has bangAndBurn
        q.addProperty(PropertyEnum.BANG_AND_BURN);
        assertFalse(map.getField(new Point(3, 3)).isDestroyed());
        assertTrue(PropertyLogic.bangAndBurn(q, map, new Point(3, 3)));
        assertTrue(map.getField(new Point(3, 3)).isDestroyed());
    }

    @Test
    public void testObservation() throws InvalidGadgetException, TargetOutOfSightException, InvalidTargetException, InvalidPropertyException {
        // Setup
        setup();

        // Case 1: Dr. No targets Point (3/3): no character on target
        assertThrows(InvalidTargetException.class, () -> PropertyLogic.observation(drNo, map, new Point(3, 3), characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 2: Dr. No targets Point (1/5): character M on target field / no property observation
        assertThrows(InvalidPropertyException.class, () -> PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 3: Dr. No targets Point (2/3): character Q on target field / not in sight / property observation
        drNo.addProperty(PropertyEnum.OBSERVATION);
        assertThrows(TargetOutOfSightException.class, () -> PropertyLogic.observation(drNo, map, new Point(2, 3), characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 4: Dr. No targets Point (2/3): character Q on target field / in sight / property observation / gadget moledie
        drNo.addGadget(GadgetEnum.MOLEDIE);
        assertThrows(InvalidGadgetException.class, () -> PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig));
        drNo.removeGadget(GadgetEnum.MOLEDIE);

        // Case 5: Dr. No targets Point (1/5): character M on target / in sight / property observation / target has pocket litter
        m.addGadget(GadgetEnum.POCKET_LITTER);
        assertFalse(PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig));
        m.removeGadget(GadgetEnum.POCKET_LITTER);

        // Case 6: Dr. No (player1) targets Point (1/5): character M (npc) on target / in sight / property observation
        assertFalse(PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig));

        // Case 7: Dr. No (player1) targets Point (1/5): character M (player1) on target / in sight / property observation
        charactersPlayer1.add(m);
        assertFalse(PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig));
        charactersPlayer1.remove(m);

        // Set observationSuccessChance to 50%
        matchconfig.setObservationSuccessChance(0.50);
        int tries = 100;

        // Case 8: Dr. No (player1) targets Point (1/5): character M (player2) on target / in sight / property observation / no tradecraft
        charactersPlayer2.add(m);
        double success = 0;
        for (int i = 0; i < tries; i++) {
            if (PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig)) {
                success = success + 1.0;
            }
        }

        // Case 9: Dr. No (player1) targets Point (1/5): character M (player2) on target / in sight / property observation / tradecraft
        drNo.addProperty(PropertyEnum.TRADECRAFT);
        double success1 = 0.0;
        for (int i = 0; i < tries; i++) {
            if (PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig)) {
                success1 = success1 + 1.0;
            }
        }

        // Case 10: Dr. No (player1) targets Point (1/5): character M (player2) on target / in sight / property observation / tradecraft / clammy clothes
        drNo.addProperty(PropertyEnum.CLAMMY_CLOTHES);
        double success2 = 0.0;
        for (int i = 0; i < tries; i++) {
            if (PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig)) {
                success2 = success2 + 1.0;
            }
        }

        // Case 11: Dr. No (player1) targets Point (1/5): character M (player2) on target / in sight / property observation / no tradecraft / clammy clothes
        drNo.removeProperty(PropertyEnum.TRADECRAFT);
        double success3 = 0.0;
        for (int i = 0; i < tries; i++) {
            if (PropertyLogic.observation(drNo, map, new Point(1, 5), characters, charactersPlayer1, charactersPlayer2, matchconfig)) {
                success3 = success3 + 1.0;
            }
        }
    }
}
