package Tests.DataTypes;

import de.uulm.team0015.server.model.DataTypes.Gadgets.WireTapWithEarplugs;
import de.uulm.team0015.server.model.DataTypes.Util.Character;
import de.uulm.team0015.server.model.DataTypes.Util.Point;
import de.uulm.team0015.server.model.Exceptions.InvalidTargetException;
import org.junit.Test;

import java.util.HashSet;
import java.util.UUID;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Class to test the methods of the class WireTapWithEarplugs.
 *
 * @author Simon Demharter
 * @version 1.0
 */
public class WireTapWithEarplugsTest {

    @Test
    public void testValidateIsNotInUse() throws InvalidTargetException {
        // Setup
        WireTapWithEarplugs wireTapWithEarplugs = new WireTapWithEarplugs();

        // Case 1: WireTapWithEarplugs is not in use
        wireTapWithEarplugs.validateIsNotInUse();

        // Setup change
        Character character = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());
        wireTapWithEarplugs.setupWireTapWithEarplugs(character);

        // Case 2: WireTapWithEarplugs is in use
        assertThrows(InvalidTargetException.class, wireTapWithEarplugs::validateIsNotInUse);
    }

    @Test
    public void testSetupWireTapWithEarplugs() {
        // Setup
        WireTapWithEarplugs wireTapWithEarplugs = new WireTapWithEarplugs();
        Character character = new Character(UUID.randomUUID(), "James Bond", new Point(0, 0), new HashSet<>(), new HashSet<>());

        // Case 1: WireTapWithEarplugs is set on another character
        assertFalse(wireTapWithEarplugs.isWorking());
        assertNull(wireTapWithEarplugs.getActiveOn());
        wireTapWithEarplugs.setupWireTapWithEarplugs(character);
        assertTrue(wireTapWithEarplugs.isWorking());
        assertEquals(character.getCharacterId(), wireTapWithEarplugs.getActiveOn());
    }
}
