Bisheriger Stand von Akin und Jonas:

Fehlt : tisch mit leerem getr�nk
Fehlt : tisch mit vollem getr�nk

Stuhl (erstmal nur den einzelnen stuhl oben links verwenden)

Fehlt: Spieler

Katze :-

wand (�bergangsl�sung existiert schon) (vieleicht noch unterschiedliche w�nde mit spielautomat,plakat...) 

Fehlt: hausmeister (?)

Roulette mit unterschiedlichen ausrichtungen (notwendig?) 
(entsprechende graphik noch auf die oberfl�che des Bartisch legen. (oder braucht man ein neues sprite das beides zusammenfasst?))

Kamin: freistehend und in die wand intigriert. jeweils 2 graphiken um feuer flackern zu simulieren




�nderung am 31.03.2020 von Salih:
- Freies Feld: 2 Bilder -> steht zur Diskussion
- F�r die Wand im Casino: 2 Bilder -> steht zur Diskussion
- Quelle: Asset store

�nderung am 13.04.2020 von Salih:
- Bild mit Nummer f�r die Durchnummerierung der Tresore
- Bild des Diamanthalsbandes
- Bild vom Tisch mit Cocktail, Bemerkung: Bodenfl�che sollte entfernt werden

�nderung am 14.04.2020 von Salih:
- Sprite Sheet mit Trinkanimation des Agenten
- Sprite Sheet mit Kamin Explosion und Explosionsbilder aus dem git Assets store
- Vorschlag: Benutzung nur eines einzelnen Kamin Asstes

�nderung am 15.04.2020 von Salih:
- Cocktail versch�tten Animations-Sprite Sheet mit Richtungsabh�ngigkeit
- F�hnanimation
- Bemerkung: nur ein Sprite, bei Bedarf k�nnen noch weitere hinzugef�gt werden