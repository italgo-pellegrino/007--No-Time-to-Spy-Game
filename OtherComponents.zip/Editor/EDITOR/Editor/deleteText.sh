rm -rf *.txt
