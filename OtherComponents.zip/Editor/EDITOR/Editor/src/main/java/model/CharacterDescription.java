package model;

import java.util.List;

/**
 * @author Jonas Frei
 */


public class CharacterDescription {
   public String name;
   public String desc;
   public  Gender gender;
   public  List<PropertyEnum> features;
}
