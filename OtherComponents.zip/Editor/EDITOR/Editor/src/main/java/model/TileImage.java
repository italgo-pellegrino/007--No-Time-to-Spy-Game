package model;

import javafx.scene.image.Image;

public class TileImage {
    public static Image floorImage = new Image("sprites/floor.png", 40, 40, true, false);
    public static Image wallImage = new Image("sprites/wall.png", 40, 40, true, false);
    public static Image chairImage = new Image("sprites/chair.png", 40, 40, true, false);
    public static Image fireplaceImage = new Image("sprites/fireplace.png", 40, 40, true, false);
    public static Image safeImage = new Image("sprites/safe.png", 40, 40, true, false);
    public static Image rouletteTableImage = new Image("sprites/roulettetable.png", 40, 40, true, false);
    public static Image tableImage = new Image("sprites/table.png", 40, 40, true, false);
    public static Image emptyImage = new Image("sprites/empty.png", 40, 40, true, false);
}
