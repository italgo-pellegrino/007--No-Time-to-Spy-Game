package model;


/**
 * @author Jonas Frei
 */

public class Matchconfig {

 /* Gadget: Moledie */
 public Integer moledieRange;

 /* Gadget: BowlerBlade */
 public Integer bowlerBladeRange;
 public  Double bowlerBladeHitChance;
 public Integer bowlerBladeDamage;

 /* Gadget: LaserCompact */
 public Double laserCompactHitChance;

 /* Gadget: RocketPen */
 public Integer rocketPenDamage;

 /* Gadget: GasGloss */
 public Integer gasGlossDamage;

 /* Gadget: MothballPouch */
 public Integer mothballPouchRange;
 public Integer mothballPouchDamage;

 /* Gadget: FogTin */
 public Integer fogTinRange;

 /* Gadget: Grapple */
 public Integer grappleRange;
 public Double grappleHitChance;

 /* Gadget: WiretapWithEarplugs */
 public Double wiretapWithEarplugsFailChance;

 /* Gadget: Mirror */
 public Double mirrorSwapChance;

 /* Gadget: Cocktail */
 public Double cocktailDodgeChance;
 public Integer cocktailHp;



 /* Aktionen */
 public Double spySuccessChance;
 public Double babysitterSuccessChance;
 public Double honeyTrapSuccessChance;
 public Double observationSuccessChance;



 /* Spielfaktoren */
 public Integer chipsToIpFaktor;
 public Integer secretToIpFactor;
 public Integer minChipsRoulette;
 public Integer maxChipsRoulette;
 public Integer roundLimit;
 public Integer turnPhaseLimit;
 public Integer catIp;
 public Integer strikeMaximum;
 public Integer pauseLimit;
 public Integer reconnectLimit;




 public Matchconfig() {

       moledieRange=new Integer(0);//[0-MAX_INT]

       /* Gadget: BowlerBlade */
       bowlerBladeRange =new Integer(0);;//[0-MAX_INT]
       bowlerBladeHitChance =new Double(0.00);//[0.00-1.00]
       bowlerBladeDamage =new Integer(0);//[0-MAX_INT]

       /* Gadget: LaserCompact */
       laserCompactHitChance =new Double(0.00);;//[0.00-1.00]

       /* Gadget: RocketPen */
       rocketPenDamage =new Integer(0);//[0-MAX_INT]

       /* Gadget: GasGloss */
       gasGlossDamage =new Integer(0);//[0-MAX_INT]

       /* Gadget: MothballPouch */
       mothballPouchRange =new Integer(0);//[0-MAX_INT]
       mothballPouchDamage =new Integer(0);//[0-MAX_INT]

       /* Gadget: FogTin */
       fogTinRange =new Integer(0);//[0-MAX_INT]

       /* Gadget: Grapple */
       grappleRange =new Integer(0);//[0-MAX_INT]

       grappleHitChance =new Double(0.00);;//[0.00-1.00]

       /* Gadget: WiretapWithEarplugs */
       wiretapWithEarplugsFailChance =new Double(0.00);//[0.00-1.00]

       /* Gadget: Mirror */
       mirrorSwapChance =new Double(0.00);//[0.00-1.00]

       /* Gadget: Cocktail */
       cocktailDodgeChance =new Double(0.00);//[0.00-1.00]
       cocktailHp =new Integer(0);//[0-MAX_INT]


       /* Aktionen *///////////////////////////////////////////////////
       spySuccessChance =new Double(0.00);//[0.00-1.00]
       babysitterSuccessChance =new Double(0.00);//[0.00-1.00]
       honeyTrapSuccessChance =new Double(0.00);//[0.00-1.00]
       observationSuccessChance =new Double(0.00);//[0.00-1.00]



       /* Spielfaktoren */////////////////////////////////////////////
       chipsToIpFaktor =new Integer(0);//[0-MAX_INT]
       secretToIpFactor =new Integer(0);
       minChipsRoulette =new Integer(0);
       maxChipsRoulette =new Integer(0);
       roundLimit =new Integer(0);//[0-MAX_INT]
       turnPhaseLimit =new Integer(0);//[0-MAX_INT]
       catIp =new Integer(0);//[0-MAX_INT]
       strikeMaximum =new Integer(0);//[0-MAX_INT]
       pauseLimit=new Integer(0);
       reconnectLimit=new Integer(0);

      }
        
        
        
        
        
        
}
