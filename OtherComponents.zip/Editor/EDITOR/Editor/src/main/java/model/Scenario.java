package model;


/**
 * @author Akin Kula
 */

public class Scenario {
    public FieldStateEnum scenario[][];
}
