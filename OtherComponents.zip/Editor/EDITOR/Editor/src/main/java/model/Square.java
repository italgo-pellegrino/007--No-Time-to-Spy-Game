package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * @author Akin Kula
 * for graphics testing purposes
 */


public class Square {
    public int x;
    public int y;
    public int w;
    public int h;
    public Color cs;
    public Color cf;


    public Square(int x, int y, int w, int h, Color c){
       this(x,y,w,h,c,c);
    }

    public Square(int x, int y, int w, int h, Color cs, Color cf){
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.cs = cs;
        this.cf = cf;
    }


    public void draw(GraphicsContext gc){
        gc.setStroke(cs);
        gc.setFill(cf);
        gc.fillPolygon(new double[]{x, x+w, x+w, x}, new double[]{y, y, y+h, y+h}, 4);
    }
}
