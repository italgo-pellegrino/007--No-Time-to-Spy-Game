package model;

import java.net.URL;

/**
 * @author Akin Kula
 */

public class ScenePair {
    public String title;
    public URL path;

    public ScenePair(String title, URL path){
        this.title = title;
        this.path = path;
    }
}
