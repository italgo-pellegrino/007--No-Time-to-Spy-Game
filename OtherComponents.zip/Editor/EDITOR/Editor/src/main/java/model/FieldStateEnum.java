package model;

/**
 * @author Akin Kula
 */


public enum FieldStateEnum {
    BAR_TABLE,
    ROULETTE_TABLE,
    WALL,
    FREE,
    BAR_SEAT,
    SAFE,
    FIREPLACE
}
