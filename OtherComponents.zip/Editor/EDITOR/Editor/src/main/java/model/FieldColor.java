package model;

import javafx.scene.image.Image;

/**
 * @author Akin Kula
 */



public class FieldColor {
    public FieldStateEnum fieldStateEnum;
    public Image image;

    public FieldColor(FieldStateEnum fieldStateEnum, Image image){
        this.fieldStateEnum = fieldStateEnum;
        this.image = image;
    }
}
