package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

/**
 * @author Akin Kula
 * grid implementation of scenario editor
 */


public class Grid {


    public int gridSize;
    public Color c = Color.BLACK;
    public int width = 1200*2;
    public int height = 800*2;


    public Grid(int gridSize){

        this.gridSize = gridSize;

    }

    public Grid(int gridSize, int sizeX, int sizeY){
        this.gridSize = gridSize;
        this.width = sizeX * gridSize;
        this.height = sizeY * gridSize;
    }

    /**
     * set grid size
     * @param sizeX
     * @param sizeY
     */
    public void resize(int sizeX, int sizeY){
        this.width = sizeX * gridSize;
        this.height = sizeY * gridSize;
    }


    /**
     * called inside the render routine to draw the grid graphics on GraphicContext gc
     * @param gc
     * @param scale
     * @param offsetX
     * @param offsetY
     */
    public void draw(GraphicsContext gc, double scale, int offsetX, int offsetY){
        gc.setStroke(this.c);
        gc.setLineWidth(1);
        //make vertical strokes
        for(int x=0;x<(width/gridSize)+1;x++){
            int xl1 = (int)(x * gridSize * scale);
            int yl1 = 0;
            int xl2 = xl1;
            int yl2 = (int)(height*scale);
            gc.strokeLine(xl1+ offsetX, yl1 + offsetY, xl2 + offsetX, yl2 + offsetY);
        }
        //make horizontal strokes
        for(int y=0;y<(height/gridSize)+1;y++){
            int xl1 = 0;
            int yl1 = (int)(y * gridSize * scale);
            int xl2 = (int)(width*scale);
            int yl2 = yl1;
            gc.strokeLine(xl1 + offsetX, yl1 + offsetY, xl2 + offsetX, yl2 + offsetY);
        }
    }
}
