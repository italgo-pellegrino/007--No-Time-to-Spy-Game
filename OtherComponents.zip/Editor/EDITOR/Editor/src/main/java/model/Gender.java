package model;


/**
 * @author Jonas Frei
 */

public enum Gender {

    MALE,
    FEMALE,
    DIVERSE

}
