package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.net.URL;


/**
 * @author Akin Kula
 * this Class contains the data of the current file
 */

public class ScenarioMap {

    public int size_x;
    public int size_y;
    int width = 100;
    int height =100;
    public FieldColor matrix[][];


    public ScenarioMap(int size_x, int size_y){
        Image floorImage = new Image("sprites/floor.png", 40, 40, true, false);
        FieldColor floorColor = new FieldColor(FieldStateEnum.FREE, floorImage);
        this.size_x = size_x;
        this.size_y = size_y;
        matrix = new FieldColor[size_y][size_x];
        for(int y=0;y<matrix.length;y++){
            for(int x=0;x<matrix[y].length;x++) {
                    setFieldEnum(x, y, floorColor);
                }
            }
    }

    /**
     * resize the scenario map
     * @param new_x
     * @param new_y
     */
    public void resize(int new_x, int new_y){
        Image floorImage = new Image("sprites/floor.png", 40, 40, true, false);
        FieldColor floorColor = new FieldColor(FieldStateEnum.FREE, floorImage);
        FieldColor[][] new_matrix = new FieldColor[new_y][new_x];

        for(int y=0;y<new_y;y++){
            for(int x=0;x<new_x;x++){
                try{
                    new_matrix[y][x] = this.matrix[y][x];
                }
                catch(ArrayIndexOutOfBoundsException e){
                    new_matrix[y][x] = floorColor;
                }
                System.out.println("x:" + x + " y:" + y);
            }
        }
        matrix = new_matrix;
        this.size_x = new_x;
        this.size_y = new_y;
    }

    /**
     * set a field on a specific position
     * @param x
     * @param y
     * @param fieldEnum
     */
    public void setFieldEnum(int x, int y, FieldColor fieldEnum){
        if(x>=0 && x < this.width && y>=0 && y < this.height){
            this.matrix[y][x] = fieldEnum;
        }
    }

    /**
     * draw the Scenario Map on a specific GraphicsContext
     * @param gc
     * @param scale
     * @param offsetX
     * @param offsetY
     * @param gridSize
     */
    public void draw(GraphicsContext gc, double scale, int offsetX, int offsetY, int gridSize){
        for(int y=0;y<size_y;y++){
            for(int x=0;x<size_x;x++){
                try{
                    if(matrix[y][x] == null){
                        continue;
                    }
                    gc.drawImage(matrix[y][x].image, offsetX + scale*(x*gridSize),offsetY + scale*(y*gridSize), scale*gridSize, scale*gridSize);
                }
                catch(ArrayIndexOutOfBoundsException e){
                    continue;
                }
            }
        }
    }


}
