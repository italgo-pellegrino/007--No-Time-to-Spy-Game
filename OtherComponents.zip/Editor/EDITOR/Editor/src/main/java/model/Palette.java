package model;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

import java.util.ArrayList;

/**
 * @author Akin Kula
 * ColorPalette for scenario editor
 */


public class Palette {

    ArrayList<FieldColor> fields;


    Color selectorColor = Color.RED;

    int chosenColor = 0;

    int cols;

    public int gridSize;

    public int width;
    public int height;


    /**
     * get current color
     * @return
     */
    public FieldColor getChosenFieldColor(){
        System.out.println("got color:" + chosenColor);
        return this.fields.get(chosenColor);
    }


    public Palette(ArrayList<FieldColor> fields, int cols, int gridSize){
        this.fields = fields;
        this.cols = cols;
        this.gridSize = gridSize;
        this.width = cols * gridSize;
        this.height = (fields.size()/ cols) * gridSize;
        System.out.println("palette width: " + this.width + " height: " + this.height);
    }

    /**
     * Select color depending on graphical position and cols
     * @param x
     * @param y
     */
    public void select(int x, int y){
        //calculate select no.
        int sno = y * cols + x;
        chosenColor = sno;
    }


    /**
     * draw the palette inside a GraphicsContext gc
     * @param gc
     */
    public void draw(GraphicsContext gc){
        draw(gc, 1.0, 0, 0, this.gridSize);
    }

    /**
     * draw the palette inside a GraphicsContext gc
     * @param gc
     */
    public void draw(GraphicsContext gc, double scale, int offsetX, int offsetY, int gridSize){
        int pX = cols;
        int pY = fields.size()/cols;
        int field_id = 0;
        for(int y=0;y<pY;y++) {
            for (int x = 0; x < pX; x++) {
                gc.drawImage(fields.get(field_id).image, offsetX + scale * (x * gridSize), offsetY + scale * (y * gridSize), scale * gridSize, scale * gridSize);
                field_id++;
            }
        }
        //render selector
        int sgX = chosenColor % cols;
        int sgY = chosenColor / cols;
        gc.setFill(Color.TRANSPARENT);
        gc.setStroke(this.selectorColor);
        gc.strokeRect(sgX*gridSize, sgY*gridSize, gridSize, gridSize);
    }
}
