package model.scenes;

import javafx.scene.control.Alert;

public class NoValidFileNameDialog extends Alert {

    public NoValidFileNameDialog() {
        super(AlertType.WARNING);
        this.setTitle("Error");
        this.setHeaderText("Filename not valid! (3-24)");
    }
}
