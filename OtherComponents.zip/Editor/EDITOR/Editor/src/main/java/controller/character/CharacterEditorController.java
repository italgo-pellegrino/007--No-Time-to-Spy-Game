package controller.character;

import com.google.gson.Gson;
import controller.DesktopLauncher;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.CharacterDescription;
import model.Gender;
import model.PropertyEnum;
import model.SceneEnum;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;


/**
 *This class contains the backend-logic  of the characterEditor
 *
 * @author Jonas Frei
 */
public class CharacterEditorController {

    ArrayList<CharacterDescription> characterDescriptionList =new ArrayList<CharacterDescription>();
    CharacterDescription[] oldFile;
    CharacterDescription[] newFile;
    FileWriter writer;

    int index;//index of the current selected character

    private int i=0;//playercounter for the player generator

    Boolean eventFlag=false;


    ObservableList<String> nameList;//list of names in the file
    @FXML
    ListView characterlLV;//GUI element which shows the items of the nameList
    @FXML
    Label characterFileNameL;// shows the name of the file


    /////////FXML imports for the character config(right side)\\\\\\\\\\
    @FXML
    TextField name;
    @FXML
    ChoiceBox<Gender> genderCB;
    @FXML
    TextArea description;
    @FXML
    CheckBox nimblenessCB;
    @FXML
    CheckBox sluggishnessCB;
    @FXML
    CheckBox ponderousnessCB;
    @FXML
    CheckBox sprynessCB;
    @FXML
    CheckBox agilityCB;
    @FXML
    CheckBox luckydevilCB;
    @FXML
    CheckBox jinxCB ;
    @FXML
    CheckBox clammyClothesCB;
    @FXML
    CheckBox constantClammyClothesCB;
    @FXML
    CheckBox robustStomachCB ;
    @FXML
    CheckBox thoughnessCB;
    @FXML
    CheckBox babysitterCB;
    @FXML
    CheckBox honeytrapCB;
    @FXML
    CheckBox bangandburnCB;
    @FXML
    CheckBox flapsandsealsCB ;
    @FXML
    CheckBox tradecraftCB;
    @FXML
    CheckBox observationCB;


    /**
     * This function initalizes the GUI, which contains:
     * -Initalize variables
     * -load a file / create JamesBond in a new file
     * -Show the first Character on the right side
     *
     * @author Jonas Frei
     */

    public void initialize(){

        //init gender chooser
        genderCB.getItems().setAll(Gender.values());

        //init nameList
        nameList= FXCollections.observableArrayList();

        //show filename
        characterFileNameL.setText(DesktopLauncher.file.getName());


        //////////NEW FILE///////////////
        if(DesktopLauncher.isNewFile){
            //Add James Bond to character description
            CharacterDescription james=new CharacterDescription();
            james.name=     "James Bond";
            james.gender=   Gender.MALE;
            james.desc=     "007 hat keine Zeit zu sterben.";
            james.features =new ArrayList<>();
            james.features.add(PropertyEnum.NIMBLENESS);

            characterDescriptionList.add(james);
            nameList.add(characterDescriptionList.get(0).name);
        }
        //////LOAD FILE//////////////
        else{
            //load characters to ArrayList and nameList
            try {
                Gson gson=new Gson();
                Reader reader=new FileReader(DesktopLauncher.file);

                oldFile=gson.fromJson(reader,CharacterDescription[].class);
                characterDescriptionList =new ArrayList<CharacterDescription>();
                characterDescriptionList.addAll(Arrays.asList(oldFile));

                for(CharacterDescription c:oldFile){
                    nameList.add(c.name);
                }
            }
            catch(IOException e){
                System.out.println("File nicht gefunden");
                DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
            }
        }

        characterToCheckbox(index);//show the first character on the right side
        characterlLV.setItems(nameList);//Add the names of the characters to the List on the left side
    }


    /**
     * shows the character at <index> on the right side
     * @param index Index of character whose properties are shown on the right side*
     * @author Jonas Frei
     **/
    private void characterToCheckbox(int index){

        eventFlag=true; // ignore the textinput event (important for checkboxToCharacter(index))

        name.setText(characterDescriptionList.get(index).name);
        genderCB.setValue(characterDescriptionList.get(index).gender);
        description.setText(characterDescriptionList.get(index).desc);

        nimblenessCB.setSelected(   characterDescriptionList.get(index).features.contains(PropertyEnum.NIMBLENESS));
        sluggishnessCB.setSelected( characterDescriptionList.get(index).features.contains(PropertyEnum.SLUGGISHNESS));
        ponderousnessCB.setSelected( characterDescriptionList.get(index).features.contains(PropertyEnum.PONDEROUSNESS));
        sprynessCB.setSelected(     characterDescriptionList.get(index).features.contains(PropertyEnum.SPRYNESS));
        agilityCB.setSelected(      characterDescriptionList.get(index).features.contains(PropertyEnum.AGILITY));
        luckydevilCB.setSelected(   characterDescriptionList.get(index).features.contains(PropertyEnum.LUCKY_DEVIL));
        jinxCB.setSelected(         characterDescriptionList.get(index).features.contains(PropertyEnum.JINX));
        clammyClothesCB.setSelected(characterDescriptionList.get(index).features.contains(PropertyEnum.CLAMMY_CLOTHES));
        constantClammyClothesCB.setSelected(characterDescriptionList.get(index).features.contains(PropertyEnum.CONSTANT_CLAMMY_CLOTHES));
        robustStomachCB.setSelected(characterDescriptionList.get(index).features.contains(PropertyEnum.ROBUST_STOMACH));
        thoughnessCB.setSelected(   characterDescriptionList.get(index).features.contains(PropertyEnum.TOUGHNESS));
        babysitterCB.setSelected(   characterDescriptionList.get(index).features.contains(PropertyEnum.BABYSITTER));
        honeytrapCB.setSelected(    characterDescriptionList.get(index).features.contains(PropertyEnum.HONEY_TRAP));
        bangandburnCB.setSelected(  characterDescriptionList.get(index).features.contains(PropertyEnum.BANG_AND_BURN));
        flapsandsealsCB.setSelected(characterDescriptionList.get(index).features.contains(PropertyEnum.FLAPS_AND_SEALS));
        tradecraftCB.setSelected(   characterDescriptionList.get(index).features.contains(PropertyEnum.TRADECRAFT));
        observationCB.setSelected(  characterDescriptionList.get(index).features.contains(PropertyEnum.OBSERVATION));


        eventFlag=false;
    }


    /**
     * This function saves the changes of the character at <index>
     *     Gets the values of the checkboxes and textfields and puts them into the characterDescriptionList
     *     at <index>
     *
     * @param index
     * @author Jonas Frei
     */
    private void checkboxToCharacterList(int index){

        if(!eventFlag) {
            String nameToCheck = name.getText();
            //check name
            if (true) {//name is ok
                characterDescriptionList.get(index).name = nameToCheck;
                nameList.set(index, nameToCheck);
            }
            else {//name is not ok
                //TODO: do Something
            }
            //save values
            characterDescriptionList.get(index).gender = genderCB.getValue();
            characterDescriptionList.get(index).desc = description.getText();


            characterDescriptionList.get(index).features.clear();

            if(nimblenessCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.NIMBLENESS);
            if(sluggishnessCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.SLUGGISHNESS);
            if(ponderousnessCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.PONDEROUSNESS);
            if(sprynessCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.SPRYNESS);
            if(agilityCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.AGILITY);
            if(luckydevilCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.LUCKY_DEVIL);
            if(jinxCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.JINX);
            if(clammyClothesCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.CLAMMY_CLOTHES);
            if(constantClammyClothesCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.CONSTANT_CLAMMY_CLOTHES);
            if(robustStomachCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.ROBUST_STOMACH);
            if(thoughnessCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.TOUGHNESS);
            if(babysitterCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.BABYSITTER);
            if(honeytrapCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.HONEY_TRAP);
            if(bangandburnCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.BANG_AND_BURN);
            if(flapsandsealsCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.FLAPS_AND_SEALS);
            if(tradecraftCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.TRADECRAFT);
            if(observationCB.isSelected())
                characterDescriptionList.get(index).features.add(PropertyEnum.OBSERVATION);
        }
    }



    /**
     * This function is triggered by the create-Button
     * and creats a new player with default values
     *
     * @autor Jonas Frei
     */
    @FXML
    private void onButtonCreate(){
        //create player with default values
        nameList.add("Spieler"+i);
        CharacterDescription characterDescription=new CharacterDescription();
        characterDescription.name="Spieler"+i;
        characterDescription.desc="";
        characterDescription.gender=Gender.MALE;
        characterDescription.features =new ArrayList<PropertyEnum>();

        characterDescriptionList.add(characterDescription);
        i++;
    }


    /**
     * This function is triggerd by the delete-Button
     * and deletes the character at the current index
     *
     * @author Jonas Frei
     */
    @FXML
    private void onButtonDelete(){
       //one player is always in the list
        if(nameList.size()>1) {
            nameList.remove(index);
            characterDescriptionList.remove(index);
            index=index-1;
            characterToCheckbox(index);
        }
    }


    /**
     * Triggered by the close-Button
     * Change the scene to the Menu without saving
     *
     * @author Jonas Frei
     */
    @FXML
    private void onButtonClose(){

        try{
            writer.close();
        }
        catch(Exception e){
            //nothing to catch because there was no active writer
        }
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
    }


    /**
     * Triggered by the save-Button.
     * saves the game
     *
     * @author Jonas Frei
     */
    @FXML
    private void onButtonSave(){

        checkboxToCharacterList(index);//saves the current opened character
        newFile=new CharacterDescription[characterDescriptionList.size()];
        characterDescriptionList.toArray(newFile);


        //Init Writer
        try {
            writer = new FileWriter(DesktopLauncher.file);
        }
        catch(IOException e){
            DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
        }

        //write the file
        Gson gson = new Gson();
        try{
            writer.write(gson.toJson(newFile));
            writer.flush();
        }
        catch(IOException e){
            System.out.println(e);
        }

    }


    /**
     * This function is triggerd by the characterlLV
     * and changes the index and the shown character
     *
     * @author Jonas Frei
     */
    @FXML
    private void onMouseClicked(){
        //save properties
        checkboxToCharacterList(index);//save character at old index

        //Show properties
        if (characterlLV.getSelectionModel().getSelectedIndex() >= 0) {
            index= characterlLV.getSelectionModel().getSelectedIndex();
            characterToCheckbox(index );
        }
    }



    @FXML
    private void characterUpdate(){
    }

}