package controller.character;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import model.SceneEnum;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Backend logic of FileLoaderCharacter.fxml
 * @author Jonas Frei
 */
public class FileLoaderCharacterController {

    @FXML
    ListView<String> characterFileLoaderLV;


    /**
     * This method shows all saved character Files
     *
     * @author Jonas Frei
     */
    public void initialize(){
        try {
            characterFileLoaderLV.setItems(FileController.getFiles(DesktopLauncher.characterPath));
        }
        catch(IOException e){
            //do nothing
        }
    }


    @FXML
    private void onButtonBack(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_CHARACTER);
    }


    /**
     * This method set the File variable from the desktopLauncher to the selected file and change the scene.
     * @author Jonas Frei
     */
    @FXML
    private void onButtonLoad(){

        DesktopLauncher.isNewFile=false;// important for the init in the character controller
        DesktopLauncher.file=new File(DesktopLauncher.characterPath+characterFileLoaderLV.getSelectionModel().getSelectedItem());

        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.CHARACTER_EDITOR);
    }
}
