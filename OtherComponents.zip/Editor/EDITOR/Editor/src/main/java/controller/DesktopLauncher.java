package controller;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.SceneEnum;
import model.ScenePair;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;


/**
 * @author Akin Kula
 * This class is called when starting the application
 */
public class DesktopLauncher extends Application {

    public static Stage stage;

    public static final int WINDOW_WIDTH = 600;
    public static final int WINDOW_HEIGHT = 400;
    public static URL path;

    public static HashMap<SceneEnum, ScenePair> sceneMap;


    public static File file;
    public static Boolean isNewFile=false;
    public static String characterPath  ="characterFiles\\";
    public static String partyPath      ="partyFiles\\";
    public static String scenarioPath  ="scenarioFiles\\";


    /**
     * Main function which starts the javafx window
     * @param args
     */
    public static void main(String[] args) {

        launch(args);
    }



    @Override
    public void start(Stage stage) {
        this.stage = stage;
        //scenes
        sceneMap = new HashMap<>();
        sceneMap.put(SceneEnum.MENU, new ScenePair("NT2S Editor", getClass().getClassLoader().getResource("Menu.fxml")));

        sceneMap.put(SceneEnum.FILECHOOSER_PARTY, new ScenePair("Partiekonfiguration: Filechooser", getClass().getClassLoader().getResource("FileChooserParty.fxml")));
        sceneMap.put(SceneEnum.FILECREATION_PARTY, new ScenePair("Partiekonfiguration: Filecreation", getClass().getClassLoader().getResource("FileCreationParty.fxml")));
        sceneMap.put(SceneEnum.FILELOADER_PARTY, new ScenePair("Partiekonfiguration: Fileloading", getClass().getClassLoader().getResource("FileLoaderParty.fxml")));

        sceneMap.put(SceneEnum.FILECHOOSER_CHARACTER, new ScenePair("Charakterkonfiguration: Filechooser", getClass().getClassLoader().getResource("FileChooserCharacter.fxml")));
        sceneMap.put(SceneEnum.FILECREATION_CHARACTER, new ScenePair("Charakterkonfiguration: Filecreation", getClass().getClassLoader().getResource("FileCreationCharacter.fxml")));
        sceneMap.put(SceneEnum.FILELOADER_CHARACTER, new ScenePair("Charakterkonfiguration: Fileloading", getClass().getClassLoader().getResource("FileLoaderCharacter.fxml")));

        sceneMap.put(SceneEnum.FILECHOOSER_SCENARIO, new ScenePair("Szenario: Filechooser", getClass().getClassLoader().getResource("FileChooserScenario.fxml")));
        sceneMap.put(SceneEnum.FILECREATION_SCENARIO, new ScenePair("Szenario: Filecreation", getClass().getClassLoader().getResource("FileCreationScenario.fxml")));
        sceneMap.put(SceneEnum.FILELOADER_SCENARIO, new ScenePair("Szenario: Fileloading", getClass().getClassLoader().getResource("FileLoaderScenario.fxml")));

        sceneMap.put(SceneEnum.CHARACTER_EDITOR, new ScenePair("Character Editor", getClass().getClassLoader().getResource("CharacterEditor.fxml")));
        sceneMap.put(SceneEnum.SCENARIO_EDITOR, new ScenePair("Scenario Editor", getClass().getClassLoader().getResource("ScenarioEditor.fxml")));
        sceneMap.put(SceneEnum.PARTY_EDITOR, new ScenePair("Party Editor", getClass().getClassLoader().getResource("PartyEditor.fxml")));//NEW

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent t) {
                Platform.exit();
                System.exit(0);
            }
        });
        Parent root = null;
        try {
            root = FXMLLoader.load(getClass().getClassLoader().getResource("Menu.fxml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
        scene.getStylesheets().add(String.valueOf(getClass().getClassLoader().getResource("style.css")));
        DesktopLauncher.stage.setScene(scene);

        try{
            changeSceneBySceneEnum(SceneEnum.MENU);
            stage.setResizable(false);
            stage.show();

        }
        catch(Exception e){
            e.printStackTrace();
        }
    }


    /**
     * With this function you can easily change the scene
     * @param title
     * @param path
     */
    public static void changeScene(String title, URL path){
        try {
            Parent root = FXMLLoader.load(path);
            stage.getScene().setRoot(root);
            DesktopLauncher.stage.setTitle(title);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Change the scene to a known scene from sceneMap
     * @param name
     */
    public static void changeSceneBySceneEnum(SceneEnum name){
        ScenePair scenePair = sceneMap.get(name);
        changeScene(scenePair.title, scenePair.path);
    }

}
