package controller.party;

import com.google.gson.Gson;
import controller.DesktopLauncher;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.Matchconfig;
import model.SceneEnum;

import java.io.*;


/**
 * Backend Logic of Party editor.fxml
 *
 *
 * @author Jonas Frei
 */
public class PartyEditorController {

    Writer writer;

    Matchconfig matchconfig;


    @FXML
    Button partySaveB;
    @FXML
    Button partyCloseB;
    @FXML
    Label partyFileNameL;



    //Gadgets///////////////////////////////////////////
    /* Gadget: Moledie */
    @FXML
    TextField Moledie_RangeTF;//[0-MAX_INT]

    /* Gadget: BowlerBlade */
    @FXML
    TextField BowlerBlade_RangeTF;//[0-MAX_INT]
    @FXML
    TextField BowlerBlade_HitChanceTF;//[0.00-1.00]
    @FXML
    TextField BowlerBlade_DamageTF;//[0-MAX_INT]

    /* Gadget: LaserCompact */
    @FXML
    TextField LaserCompact_HitChanceTF;//[0.00-1.00]

    /* Gadget: RocketPen */
    @FXML
    TextField RocketPen_DamageTF;//[0-MAX_INT]

    /* Gadget: GasGloss */
    @FXML
    TextField GasGloss_DamageTF;//[0-MAX_INT]

    /* Gadget: MothballPouch */
    @FXML
    TextField MothballPouch_RangeTF;//[0-MAX_INT]
    @FXML
    TextField MothballPouch_DamageTF;//[0-MAX_INT]

    /* Gadget: FogTin */
    @FXML
    TextField FogTin_RangeTF;//[0-MAX_INT]

    /* Gadget: Grapple */
    @FXML
    TextField Grapple_RangeTF;//[0-MAX_INT]

    @FXML
    TextField Grapple_HitChanceTF;//[0.00-1.00]

    /* Gadget: WiretapWithEarplugs */
    @FXML
    TextField WiretapWithEarplugs_FailChanceTF;//[0.00-1.00]

    /* Gadget: Mirror */
    @FXML
    TextField Mirror_SwapChanceTF;//[0.00-1.00]

    /* Gadget: Cocktail */
    @FXML
    TextField Cocktail_DodgeChanceTF;//[0.00-1.00]
    @FXML
    TextField Cocktail_HpTF;//[0-MAX_INT]


    /* Aktionen *///////////////////////////////////////////////////
    @FXML
    TextField Spy_SuccessChanceTF;//[0.00-1.00]
    @FXML
    TextField Babysitter_SuccessChanceTF;//[0.00-1.00]
    @FXML
    TextField HoneyTrap_SuccessChanceTF;//[0.00-1.00]
    @FXML
    TextField Observation_SuccessChanceTF;//[0.00-1.00]


    /* Spielfaktoren */////////////////////////////////////////////
    @FXML
    TextField ChipsToIpFaktorTF;//[0-MAX_INT]
    @FXML
    TextField SecretToIpFactorTF;
    @FXML
    TextField MinChipsRouletteTF;
    @FXML
    TextField MaxChipsRouletteTF;
    @FXML
    TextField RoundLimitTF;//[0-MAX_INT]
    @FXML
    TextField TurnPhaseLimitTF;//[0-MAX_INT]
    @FXML
    TextField CatIpTF;//[0-MAX_INT]
    @FXML
    TextField StrikeMaximumTF;//[0-MAX_INT]
    @FXML
    TextField Pause_LimitTF;
    @FXML
    TextField ReconnectLimitTF;

    /**
     * Initialize the GUI and set the saved values/default values in the textFields
     *
     * @author Jonas Frei
     */
    public void initialize() {

        partyFileNameL.setText(DesktopLauncher.file.getName());

        if (DesktopLauncher.isNewFile) {
            matchconfig = new Matchconfig();
            //Init Writer
            try {
                writer = new FileWriter(DesktopLauncher.file);
            } catch (IOException e) {
                DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
            }
        }
        //LOAD FILE
        else {
            try {
                matchconfig=new Matchconfig();
                Gson gson = new Gson();
                Reader reader = new FileReader(DesktopLauncher.file);
                matchconfig = gson.fromJson(reader, Matchconfig.class);

            }
            catch (IOException e) {
                System.out.println("File nicht gefunden");
                //TODO: do something
            }
        }

        textFieldInitialize();
        textFieldListenerInitialize();
    }


    /**
     * triggered by  save-Button
     * saves all changes to the current file
     * @author Jonas Frei
     */
    @FXML
    private void partyOnButtonSave(){

        Gson gson = new Gson();
        try{
            writer=new FileWriter(DesktopLauncher.file);
            writer.write(gson.toJson(matchconfig));
            writer.flush();
        }
        catch(IOException e){
            System.out.println(e);
        }
    }


    /**
     * triggered by close-Button
     * close the writer and chane the scene to menu without saving
     *
     * @author Jonas Frei
     */
    @FXML
    private void partyOnButtonClose(){
        try{
            writer.close();
        }
        catch(Exception e){
            //nothing to catch because there was no active writer
        }
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
    }


    /**
     * The function checks the value of the TextField
     * If the value is ok: return the value of the TextField
     * else : return the saved value in the target
     *
     * Method for Integer targets
     *
     * @param textField
     * @param target
     * @return
     */
    private Integer checkValue( TextField textField, Integer target){
        try{
            int newInt= Integer.parseInt(textField.getText()) ;
            if(newInt>=0){
                target=newInt;
                System.out.println("Target value:"+target.toString());
            }
            else{
                throw new Exception("Negative value");
            }
        }
        catch(Exception e) {
            textField.setText(target.toString());
        }
        return target;
    }


    /**
     * The function checks the value of the TextField
     * If the value is ok: return the value of the TextField
     * else : return the saved value in the target
     *
     * Method for Double targets
     *
     * @param textField
     * @param target
     * @return
     */
    private Double checkValue( TextField textField, Double target){
        try{
            double newDouble= Double.parseDouble(textField.getText()) ;
            if((newDouble>=0.0)&&(newDouble<=1.0)){
                target=newDouble;
            }
            else{
                throw new Exception("Negative value");
            }
        }
        catch(Exception e){
            textField.setText(target.toString());
        }
        return target;
    }


    /**
     * Initialise the values of the TextFields
     *
     * @author Jonas Frei
     */
    private void textFieldInitialize(){

        /////////GADGET/////////////////////////////////
        /* Gadget: Moledie Range */
        Moledie_RangeTF.setText(matchconfig.moledieRange.toString());//[0-MAX_INT]

        /* Gadget: BowlerBlade */
        BowlerBlade_RangeTF.setText(matchconfig.bowlerBladeRange.toString());//[0-MAX_INT]
        BowlerBlade_HitChanceTF.setText(matchconfig.bowlerBladeHitChance.toString());//[0.00-1.00]
        BowlerBlade_DamageTF.setText(matchconfig.bowlerBladeDamage.toString());//[0-MAX_INT]

        /* Gadget: LaserCompact */
        LaserCompact_HitChanceTF.setText(matchconfig.laserCompactHitChance.toString());//[0.00-1.00]

        /* Gadget: RocketPen */
        RocketPen_DamageTF.setText(matchconfig.rocketPenDamage.toString());//[0-MAX_INT]

        /* Gadget: GasGloss */
        GasGloss_DamageTF.setText(matchconfig.gasGlossDamage.toString());//[0-MAX_INT]

        /* Gadget: MothballPouch */
        MothballPouch_RangeTF.setText(matchconfig.mothballPouchRange.toString());//[0-MAX_INT]
        MothballPouch_DamageTF.setText(matchconfig.mothballPouchDamage.toString());//[0-MAX_INT]

        /* Gadget: FogTin */
        FogTin_RangeTF.setText(matchconfig.fogTinRange.toString());//[0-MAX_INT]

        /* Gadget: Grapple */
        Grapple_RangeTF.setText(matchconfig.grappleRange.toString());//[0-MAX_INT]
        Grapple_HitChanceTF.setText(matchconfig.grappleHitChance.toString());//[0.00-1.00]

        /* Gadget: WiretapWithEarplugs */
        WiretapWithEarplugs_FailChanceTF.setText(matchconfig.wiretapWithEarplugsFailChance.toString());//[0.00-1.00]

        /* Gadget: Mirror */
        Mirror_SwapChanceTF.setText(matchconfig.mirrorSwapChance.toString());//[0.00-1.00]

        /* Gadget: Cocktail */
        Cocktail_DodgeChanceTF.setText(matchconfig.cocktailDodgeChance.toString());//[0.00-1.00]
        Cocktail_HpTF.setText(matchconfig.cocktailHp.toString());//[0-MAX_INT]


        /* Aktionen *///////////////////////////////////////////////////
        Spy_SuccessChanceTF.setText(matchconfig.spySuccessChance.toString());//[0.00-1.00]
        Babysitter_SuccessChanceTF.setText(matchconfig.babysitterSuccessChance.toString());//[0.00-1.00]
        HoneyTrap_SuccessChanceTF.setText(matchconfig.honeyTrapSuccessChance.toString());//[0.00-1.00]
        Observation_SuccessChanceTF.setText(matchconfig.observationSuccessChance.toString());//[0.00-1.00]

        /* Spielfaktoren */////////////////////////////////////////////
        ChipsToIpFaktorTF.setText(matchconfig.chipsToIpFaktor.toString());//[0-MAX_INT]
        SecretToIpFactorTF.setText(matchconfig.secretToIpFactor.toString());
        MinChipsRouletteTF.setText(matchconfig.minChipsRoulette.toString());
        MaxChipsRouletteTF.setText(matchconfig.maxChipsRoulette.toString());
        RoundLimitTF.setText(matchconfig.roundLimit.toString());//[0-MAX_INT]
        TurnPhaseLimitTF.setText(matchconfig.turnPhaseLimit.toString());//[0-MAX_INT]
        CatIpTF.setText(matchconfig.catIp.toString());//[0-MAX_INT]
        StrikeMaximumTF.setText(matchconfig.strikeMaximum.toString());//[0-MAX_INT]
        Pause_LimitTF.setText(matchconfig.pauseLimit.toString());
        ReconnectLimitTF.setText(matchconfig.reconnectLimit.toString());

    }


    /**
     * Initialize the Listeners of the TextFields
     *
     * @author Jonas Frei
     */
    private void textFieldListenerInitialize() {
            ///////////init TextField Listeners//////////////////////////////////////////

            Moledie_RangeTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.moledieRange = checkValue(Moledie_RangeTF, matchconfig.moledieRange);
                }
            });

            BowlerBlade_RangeTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.bowlerBladeRange = checkValue(BowlerBlade_RangeTF, matchconfig.bowlerBladeRange);
                }
            });

            BowlerBlade_HitChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.bowlerBladeHitChance = checkValue(BowlerBlade_HitChanceTF, matchconfig.bowlerBladeHitChance);
                }
            });

            BowlerBlade_DamageTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.bowlerBladeDamage = checkValue(BowlerBlade_DamageTF, matchconfig.bowlerBladeDamage);
                }
            });

            LaserCompact_HitChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.laserCompactHitChance = checkValue(LaserCompact_HitChanceTF, matchconfig.laserCompactHitChance);
                }
            });

            RocketPen_DamageTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.rocketPenDamage = checkValue(RocketPen_DamageTF, matchconfig.rocketPenDamage);
                }
            });

            GasGloss_DamageTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.gasGlossDamage = checkValue(GasGloss_DamageTF, matchconfig.gasGlossDamage);
                }
            });

            MothballPouch_RangeTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.mothballPouchRange = checkValue(MothballPouch_RangeTF, matchconfig.mothballPouchRange);
                }
            });

            MothballPouch_DamageTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.mothballPouchDamage = checkValue(MothballPouch_DamageTF, matchconfig.mothballPouchDamage);
                }
            });

            FogTin_RangeTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.fogTinRange = checkValue(FogTin_RangeTF, matchconfig.fogTinRange);
                }
            });

            Grapple_RangeTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.grappleRange = checkValue(Grapple_RangeTF, matchconfig.grappleRange);
                }
            });

            Grapple_HitChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.grappleHitChance = checkValue(Grapple_HitChanceTF, matchconfig.grappleHitChance);
                }
            });

            WiretapWithEarplugs_FailChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.wiretapWithEarplugsFailChance = checkValue(WiretapWithEarplugs_FailChanceTF, matchconfig.wiretapWithEarplugsFailChance);
                }
            });

            Mirror_SwapChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.mirrorSwapChance = checkValue(Mirror_SwapChanceTF, matchconfig.mirrorSwapChance);
                }
            });

            Cocktail_DodgeChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.cocktailDodgeChance = checkValue(Cocktail_DodgeChanceTF, matchconfig.cocktailDodgeChance);
                }
            });

            Cocktail_HpTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.cocktailHp = checkValue(Cocktail_HpTF, matchconfig.cocktailHp);
                }
            });


            //////////AKTIONEN////////////////
            Spy_SuccessChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.spySuccessChance = checkValue(Spy_SuccessChanceTF, matchconfig.spySuccessChance);
                }
            });

            Babysitter_SuccessChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.babysitterSuccessChance = checkValue(Babysitter_SuccessChanceTF, matchconfig.babysitterSuccessChance);
                }
            });

            HoneyTrap_SuccessChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.honeyTrapSuccessChance = checkValue(HoneyTrap_SuccessChanceTF, matchconfig.honeyTrapSuccessChance);
                }
            });

            Observation_SuccessChanceTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.observationSuccessChance = checkValue(Observation_SuccessChanceTF, matchconfig.observationSuccessChance);
                }
            });


            ///////GAME//////////////////
            CatIpTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.catIp = checkValue(CatIpTF, matchconfig.catIp);
                }
            });

             SecretToIpFactorTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                 if (oldVal) {
                     matchconfig.secretToIpFactor = checkValue(SecretToIpFactorTF, matchconfig.secretToIpFactor);
                 }
              });

             MinChipsRouletteTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                 if (oldVal) {
                     matchconfig.minChipsRoulette = checkValue( MinChipsRouletteTF, matchconfig.minChipsRoulette);
                 }
             });

             MaxChipsRouletteTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                 if (oldVal) {
                     matchconfig.maxChipsRoulette = checkValue(MaxChipsRouletteTF, matchconfig.maxChipsRoulette);
                 }
               });


            ChipsToIpFaktorTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.chipsToIpFaktor = checkValue(ChipsToIpFaktorTF, matchconfig.chipsToIpFaktor);
                }
            });

            RoundLimitTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.roundLimit = checkValue(RoundLimitTF, matchconfig.roundLimit);
                }
            });

            TurnPhaseLimitTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.turnPhaseLimit = checkValue(TurnPhaseLimitTF, matchconfig.turnPhaseLimit);
                }
            });

            StrikeMaximumTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                if (oldVal) {
                    matchconfig.strikeMaximum = checkValue(StrikeMaximumTF, matchconfig.strikeMaximum);
                }
            });

             Pause_LimitTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                  if (oldVal) {
                        matchconfig.pauseLimit = checkValue(Pause_LimitTF, matchconfig.pauseLimit);
                    }
             });

             ReconnectLimitTF.focusedProperty().addListener((obs, oldVal, newVal) -> {
                   if (oldVal) {
                        matchconfig.reconnectLimit = checkValue(ReconnectLimitTF, matchconfig.reconnectLimit);
                    }
               });
    }
}
