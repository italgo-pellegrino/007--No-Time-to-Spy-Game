package controller.scenario;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import model.SceneEnum;

import java.io.File;
import java.io.IOException;

/**
 * @author Akin Kula
 * loading the file
 */
public class FileLoaderScenarioController {

    @FXML
    ListView<String> scenarioFileLoaderLV;

    public void initialize(){
        try {
            scenarioFileLoaderLV.setItems(FileController.getFiles(DesktopLauncher.scenarioPath));
        }
        catch(IOException e){
            //TODO: if empty then cant load
        }
    }

    @FXML
    private void onButtonBack(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_SCENARIO);
    }
    @FXML
    private void onButtonLoad(){
        DesktopLauncher.isNewFile=false;
        DesktopLauncher.file=new File(DesktopLauncher.scenarioPath+scenarioFileLoaderLV.getSelectionModel().getSelectedItem());
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.SCENARIO_EDITOR);
    }
}
