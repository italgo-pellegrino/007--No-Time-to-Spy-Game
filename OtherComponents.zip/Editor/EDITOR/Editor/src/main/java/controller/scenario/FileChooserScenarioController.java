package controller.scenario;

import controller.DesktopLauncher;
import javafx.fxml.FXML;
import model.SceneEnum;


/**
 * @author Akin Kula
 * fxml controller
 */

public class FileChooserScenarioController {

    @FXML
    private void onButtonErstellen(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECREATION_SCENARIO);
    }
    @FXML
    private void onButtonLaden(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILELOADER_SCENARIO);
    }
    @FXML
    private void onButtonZurueck(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
    }
}
