package controller.character;

import controller.DesktopLauncher;
import javafx.fxml.FXML;
import model.SceneEnum;

/**
 * Backend logic  of CharacterFileChooser.fxml
 * changes the scene by clicking on the buttons
 * @author  Akin Kula
 * @author Jonas Frei
 */
public class FileChooserCharacterController {

    @FXML
    private void onButtonErstellen(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECREATION_CHARACTER);
    }
    @FXML
    private void onButtonLaden(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILELOADER_CHARACTER);
    }
    @FXML
    private void onButtonZurueck(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
    }
}
