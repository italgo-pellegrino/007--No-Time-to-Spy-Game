package controller.party;

import controller.DesktopLauncher;
import javafx.fxml.FXML;
import model.SceneEnum;

/**
 * Back-end  logic of FileChooserParty.fxml
 *
 *
 * @author Akin Kula
 * @author Jonas Frei
 */
public class FileChooserPartyController {

    @FXML
    private void onButtonErstellen(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECREATION_PARTY);
    }
    @FXML
    private void onButtonLaden(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILELOADER_PARTY);
    }
    @FXML
    private void onButtonZurueck(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);
    }
}
