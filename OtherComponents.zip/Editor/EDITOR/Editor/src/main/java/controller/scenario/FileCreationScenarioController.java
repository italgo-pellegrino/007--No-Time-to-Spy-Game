package controller.scenario;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import model.SceneEnum;
import model.scenes.NoValidFileNameDialog;

import java.io.File;
import java.io.IOException;

/**
 * @author Akin Kula
 * for file creation
 */

public class FileCreationScenarioController {
    @FXML
    TextField filenameInput;


    @FXML
    private void onButtonBack(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_SCENARIO);
    }
    @FXML
    private void onButtonCreate(){

        File file;
        System.out.println("File Creation File:"+filenameInput.getText());
        DesktopLauncher.isNewFile=true;
        try{
            file =FileController.createFile(DesktopLauncher.scenarioPath,filenameInput.getText(),".scenario");

            DesktopLauncher.file =file;
            DesktopLauncher.isNewFile=true;
            DesktopLauncher.changeSceneBySceneEnum(SceneEnum.SCENARIO_EDITOR);
        }
        catch(IOException e){
            e.printStackTrace();
            NoValidFileNameDialog dialog = new NoValidFileNameDialog();
            dialog.showAndWait();
        }
    }
}
