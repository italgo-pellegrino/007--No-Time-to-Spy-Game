package controller.character;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.SceneEnum;

import java.io.File;
import java.io.IOException;

/**
 * Backend Logic from FileCreationCharacter.fxml
 * @author Jonas Frei
 */
public class FileCreationCharacterController {

    @FXML
    TextField filenameTF;//filename
    @FXML
    Label errorL;//shows the error Messages


    @FXML
    private void onButtonBack(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_CHARACTER);
    }


    /**
     * triggered by clicking the create Button
     *
     * check the name of the file and create it  if its possible.
     * If its not possible the method shows the reason in the errorL
     *
     * @author Jonas Frei
     */
    @FXML
    private  void onButtonCreate() {
        File file;
        System.out.println("File Creation File:" + filenameTF.getText());

        try {
            file = FileController.createFile(DesktopLauncher.characterPath, filenameTF.getText(), ".character");

            DesktopLauncher.file = file;
            DesktopLauncher.isNewFile = true;
            DesktopLauncher.changeSceneBySceneEnum(SceneEnum.CHARACTER_EDITOR);
        } catch (IOException e) {
            //print error for user
            errorL.setText(e.getMessage());
        }
    }


}
