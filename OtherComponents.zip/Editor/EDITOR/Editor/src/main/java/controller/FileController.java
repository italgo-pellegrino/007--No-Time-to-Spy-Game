package controller;

import com.google.gson.Gson;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.FieldStateEnum;
import model.Scenario;
import model.ScenarioMap;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 *
 * @author Jonas Frei
 * @author Akin Kula
 */
public class FileController{

    /**
     * Create and return a file with the name witch defined by the filename parameter.
     * The function throws a Exception if the file already exists or mismatches with the regex.
     *
     * @param path folder
     * @param filename
     * @param endung
     * @return File
     * @throws IOException contains the reason
     *
     * @author Jonas Frei
     * @author Akin Kula
     */
    public static File createFile(String path, String filename, String endung) throws IOException{

        String regex = "^[a-zA-Z0-9]{3,24}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(filename);
        if(!matcher.matches()){
            throw new IOException("Filename not valid");
        }

        File file = new File(path+filename + endung);
        System.out.println(file.getAbsolutePath());

        if(file.exists())
            throw new IOException("File already exists");

        boolean createdSuccessfully  = true;
        createdSuccessfully = file.createNewFile();
        if(!createdSuccessfully){
            throw new IOException("File cant be created");
        }

        System.out.println("File created");
        return file;
    }


    /**
     * The Method returns a ObservableList<String> with all files in the folder
     *
     * @param path folder
     * @return ObservableList<String> with all files in the folder
     * @throws IOException
     *
     * @author Jonas Frei
     */
    public static ObservableList getFiles(String path) throws IOException{

        ObservableList<String> fileList= FXCollections.observableArrayList();
        File f = new File(path);
        File[] fileArray = f.listFiles();

        for(File f2:fileArray){
            fileList.add(f2.getName());
        }

        return fileList;
    }

    public static void saveFile(ScenarioMap currentMap){
        //save on file
        Scenario scenario = new Scenario();
        scenario.scenario = new FieldStateEnum[currentMap.size_y][currentMap.size_x];
        System.out.println(currentMap);
        for(int y=0;y<currentMap.size_y;y++){
            for(int x=0;x<currentMap.size_x;x++){
                if(currentMap.matrix[y][x] != null){
                    if(currentMap.matrix[y][x].fieldStateEnum == null){
                        scenario.scenario[y][x] = FieldStateEnum.FREE;
                    }
                    else{
                        scenario.scenario[y][x] = currentMap.matrix[y][x].fieldStateEnum;
                    }
                }
                else
                    scenario.scenario[y][x] = FieldStateEnum.FREE;
            }
        }
        Gson gson = new Gson();
        System.out.println(gson.toJson(scenario));

        try{
            FileWriter writer = new FileWriter(DesktopLauncher.file);
            writer.write(gson.toJson(scenario));
            writer.flush();
        }
        catch(IOException e){
            System.out.println(e);
        }
    }

}
