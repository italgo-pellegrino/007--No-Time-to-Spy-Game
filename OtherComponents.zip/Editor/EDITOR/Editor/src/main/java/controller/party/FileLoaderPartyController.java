package controller.party;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import model.SceneEnum;

import java.io.File;
import java.io.IOException;

/**
 * Backend logic of FileLoaderParty.fxml
 * @author Jonas Frei
 */
public class FileLoaderPartyController {

    @FXML
    ListView partyFileLoaderLV;


    /**
     * This mehode shows all saved character Files
     *
     * @author Jonas Frei
     */
    public void initialize(){
        try {
            partyFileLoaderLV.setItems(FileController.getFiles(DesktopLauncher.partyPath));
        }
        catch(IOException e){

        }
    }

    @FXML
    private void onButtonBack(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_PARTY);
    }


    /**
     * This methode set the File variable from the desktopLouncher to the selected file and change the sceen.
     * @author Jonas Frei
     */
    @FXML
    private void onButtonLoad(){

        DesktopLauncher.isNewFile=false;
        DesktopLauncher.file=new File(DesktopLauncher.partyPath+partyFileLoaderLV.getSelectionModel().getSelectedItem());

        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.PARTY_EDITOR);
    }
}
