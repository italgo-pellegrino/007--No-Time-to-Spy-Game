package controller.scenario;

import com.google.gson.Gson;
import controller.DesktopLauncher;
import controller.FileController;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import model.*;

import java.io.*;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Akin Kula
 * This class makes the scenario editor working
 */
public class ScenarioEditorController {



    double scale = 1.0;
    double moveSpeed = 4;
    int offsetX = 0;
    int offsetY = 0;
    int FPS = 30;
    double dragPointingX;
    double dragPointingY;
    FileWriter writer;

    public ScenarioMap currentMap;
    public long currentMapHash;

    public Grid grid;

    public Palette palette;

    Timer refreshTimer;
    TimerTask timerTask;

    @FXML
    Label filenameLabel;

    @FXML
    Canvas canvas;

    @FXML
    Canvas paletteCanvas;

    @FXML
    TextField mapSizeTextBox;
    @FXML
    Button mapSizeApplyButton;

    @FXML
    public void initialize() {

        GraphicsContext gc = canvas.getGraphicsContext2D();

        GraphicsContext gcPalette = paletteCanvas.getGraphicsContext2D();



        FieldColor floorColor = new FieldColor(FieldStateEnum.FREE, TileImage.floorImage);
        FieldColor wallColor = new FieldColor(FieldStateEnum.WALL, TileImage.wallImage);
        FieldColor chairColor = new FieldColor(FieldStateEnum.BAR_SEAT, TileImage.chairImage);
        FieldColor fireplaceColor = new FieldColor(FieldStateEnum.FIREPLACE, TileImage.fireplaceImage);
        FieldColor safeColor = new FieldColor(FieldStateEnum.SAFE, TileImage.safeImage);
        FieldColor rouletteTableColor = new FieldColor(FieldStateEnum.ROULETTE_TABLE, TileImage.rouletteTableImage);
        FieldColor tableColor = new FieldColor(FieldStateEnum.BAR_TABLE, TileImage.tableImage);
        FieldColor emptyColor = new FieldColor(FieldStateEnum.FREE, TileImage.emptyImage);


        if(DesktopLauncher.isNewFile){
            //grid
            this.grid = new Grid(40, 8, 8);
            grid.draw(gc, scale, offsetX, offsetY);

            //map
            currentMap = new ScenarioMap(8, 8);
            mapSizeTextBox.setText("" + currentMap.size_x + "x" + currentMap.size_y);
        }
        else{

            //lade json file
            Gson gson=new Gson();
            Reader reader = null;
            try{
                reader = new FileReader(DesktopLauncher.file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            Scenario loadedMap = gson.fromJson(reader,Scenario.class);
            //convert into ScenarioMap
            int size_y = loadedMap.scenario.length;
            int size_x = loadedMap.scenario[0].length;

            this.currentMap = new ScenarioMap(size_x, size_y);

            for(int y=0;y<size_y;y++){
                for(int x=0;x<size_x;x++){
                    if(loadedMap.scenario[y][x].equals(FieldStateEnum.FREE))
                        this.currentMap.setFieldEnum(x,y, floorColor);
                    else if(loadedMap.scenario[y][x].equals(FieldStateEnum.WALL))
                        this.currentMap.setFieldEnum(x,y, wallColor);
                    else if(loadedMap.scenario[y][x].equals(FieldStateEnum.BAR_SEAT))
                        this.currentMap.setFieldEnum(x,y, chairColor);
                    else if(loadedMap.scenario[y][x].equals(FieldStateEnum.FIREPLACE))
                        this.currentMap.setFieldEnum(x,y, fireplaceColor);
                    else if(loadedMap.scenario[y][x].equals(FieldStateEnum.SAFE))
                        this.currentMap.setFieldEnum(x,y, safeColor);
                    else if(loadedMap.scenario[y][x].equals(FieldStateEnum.ROULETTE_TABLE))
                        this.currentMap.setFieldEnum(x,y, rouletteTableColor);
                    else if(loadedMap.scenario[y][x].equals(FieldStateEnum.BAR_TABLE))
                        this.currentMap.setFieldEnum(x,y, tableColor);
                    else if(loadedMap.scenario[y][x] == null)
                        this.currentMap.setFieldEnum(x,y, floorColor);

                }
            }
            mapSizeTextBox.setText("" + currentMap.size_x + "x" + currentMap.size_y);
            this.grid = new Grid(40, currentMap.size_x, currentMap.size_y);
            grid.draw(gc, scale, offsetX, offsetY);
        }

        //change filenameLable
        filenameLabel.setText(DesktopLauncher.file.getName());



        //add colors to array list
        ArrayList<FieldColor> fieldColors = new ArrayList<>();
        fieldColors.add(floorColor);
        fieldColors.add(wallColor);
        fieldColors.add(chairColor);
        fieldColors.add(fireplaceColor);
        fieldColors.add(safeColor);
        fieldColors.add(rouletteTableColor);
        fieldColors.add(tableColor);
        fieldColors.add(emptyColor);


        //field palette
        this.palette = new Palette(fieldColors, 4, 40);


        //Set timer for refreshment
        this.timerTask = new TimerTask(){
            @Override
            public void run() {
                //calc delta time
                gc.setFill(Color.WHITE);
                gc.fillRect(0,0, canvas.getWidth(), canvas.getHeight());

                currentMap.draw(gc, scale, offsetX, offsetY, grid.gridSize);
                //update grid
                grid.draw(gc, scale, offsetX, offsetY);
                //draw palette
                gcPalette.setFill(Color.WHITE);
                gcPalette.fillRect(0,0, canvas.getWidth(), canvas.getHeight());
                palette.draw(gcPalette);

            }
        };


        this.refreshTimer = new Timer();
        long time = (long)((1.0/(double)FPS) * 1000.0);
        refreshTimer.scheduleAtFixedRate(timerTask, 0, time);


        paletteCanvas.addEventFilter(MouseEvent.MOUSE_PRESSED, mouseEvent -> {
            //System.out.println("X: " + mouseEvent.getX() + " Y: " + mouseEvent.getY());
            //select color (FieldEnum)//check on which place in grid the user clicked
                if(     (mouseEvent.getX() <= (palette.width)) &&
                        (mouseEvent.getX() >= 0) &&
                        (mouseEvent.getY() <= (palette.height)) &&
                        (mouseEvent.getY() >= 0)
                )
                {
                    int xPos = (int)((mouseEvent.getX())/(double)(palette.gridSize));
                    int yPos = (int)((mouseEvent.getY())/(double)(palette.gridSize));
                    System.out.println("X: " + xPos + " Y: " + yPos);
                    palette.select(xPos, yPos);
                }
            }
        );






        //scrollable
        canvas.setOnScroll((ScrollEvent event) -> {
            double deltaY = event.getDeltaY();
            if(deltaY > 0){
                scale += 0.05;
            }
            else if(deltaY < 0){
                if (scale >= 0.05)
                    scale -= 0.05;
            }
        });
        canvas.addEventFilter(MouseEvent.MOUSE_PRESSED, mouseEvent ->
                {
                    if(mouseEvent.isMiddleButtonDown())
                        return;
                    //check on which place in grid the user clicked
                    if(     (mouseEvent.getX() <= (grid.width+offsetX)*scale) &&
                            (mouseEvent.getX() >= offsetX) &&
                            (mouseEvent.getY() <= (grid.height+offsetY)*scale) &&
                            (mouseEvent.getY() >= offsetY)
                    )
                        {
                            //clicked on grid
                            //now check which cell

                            double xPos = (double)(mouseEvent.getX()-offsetX)/(double)(grid.gridSize*scale);
                            double yPos = (double)(mouseEvent.getY()-offsetY)/(double)(grid.gridSize*scale);
                            //System.out.println("X: " + xPos + " Y: " + yPos);

                            if(mouseEvent.isPrimaryButtonDown())
                                this.currentMap.setFieldEnum((int)xPos, (int)yPos, palette.getChosenFieldColor());
                            else if (mouseEvent.isSecondaryButtonDown())
                                this.currentMap.setFieldEnum((int)xPos, (int)yPos, floorColor);



                        }



                }
        );

        canvas.addEventFilter(MouseEvent.MOUSE_DRAGGED, mouseEvent ->
            {
                if(!mouseEvent.isMiddleButtonDown())
                    return;


                System.out.println("dragged");
                double difX = mouseEvent.getX() - dragPointingX;
                double difY = mouseEvent.getY() - dragPointingY;
                double n = Math.sqrt(Math.pow(difX, 2) + Math.pow(difY, 2));

                double nDifX = difX/n;
                double nDifY = difY/n;

                //should be multiplied with delta time as well

                double deltaTime = (double)timerTask.scheduledExecutionTime()/ 1000000.0;

                System.out.println(deltaTime);
                offsetX += nDifX * moveSpeed;
                offsetY += nDifY * moveSpeed;
                //System.out.println("offset x: " + offsetX + " offset y: " + offsetY);
                dragPointingX = mouseEvent.getX();
                dragPointingY = mouseEvent.getY();
            });

    }


    @FXML
    private void onMapSizeApplyButton(){
        System.out.println("applied");
        String input = mapSizeTextBox.getText();
        Pattern p = Pattern.compile("([0-9]+)x([0-9]+)");
        Matcher m = p.matcher(input);
        if (m.find()){
            System.out.println(m.group(1));
            System.out.println(m.group(2));

            //change gridsize
            int sizeX = Integer.parseInt(m.group(1));
            int sizeY = Integer.parseInt(m.group(2));




            grid.resize(sizeX, sizeY);
            //resize currentMap
            currentMap.resize(sizeX, sizeY);
        }
        else{
            System.err.println("Only ([0-9]+)x([0-9]+) allowed");
        }
    }


    @FXML
    private void onButtonSave() {
        FileController.saveFile(this.currentMap);
    }
    @FXML
    private void onButtonClose(){
        try{
            this.writer.close();
        }
        catch(Exception e){
            //nothing to catch because there was no active writer
        }
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.MENU);

    }


}
