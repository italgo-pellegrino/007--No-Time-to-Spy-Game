package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import model.SceneEnum;

import java.io.IOException;

/**
 * Backend logic of Menu.fxml
 * @author Akin Kula
 * @author Jonas Frei
 */
public class MenuController {

    @FXML
    ImageView logoImage;

    @FXML
    public void initialize() {
        this.logoImage.setImage(new Image("images/logo.png"));
        this.logoImage.setPreserveRatio(true);
        this.logoImage.setSmooth(true);
        this.logoImage.setCache(true);
    }


    @FXML
    private void onButtonSzenario(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_SCENARIO);
    }

    @FXML
    private void onButtonPartiekonfiguration(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_PARTY);
    }

    @FXML
    private void onButtonCharakterkonfiguration(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_CHARACTER);
    }

    @FXML
    private void onButtonBeenden(){
        System.exit(0);
    }
}
