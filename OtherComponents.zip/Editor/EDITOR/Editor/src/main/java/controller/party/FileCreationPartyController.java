package controller.party;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import model.SceneEnum;
import org.w3c.dom.html.HTMLLabelElement;

import java.io.File;
import java.io.IOException;

/**
 * Backend logic of FileCreationParty.fxml
 *
 * @author Jonas Frei
 */
public class FileCreationPartyController {

    @FXML
    TextField partyFileNameTF;//filename
    @FXML
    Label errorL;//shows the error Messages


    @FXML
    private void onButtonBack(){
        DesktopLauncher.changeSceneBySceneEnum(SceneEnum.FILECHOOSER_PARTY);
    }

    /**
     * Triggered by create-Button
     *  check the name of the file and create it  if its possible.
     *  If its not possible the method shows the reason in the errorL
     *
     * @author Jonas Frei
     */
    @FXML
    private void onButtonCreate(){
        File file;

        try{
            file = FileController.createFile(DesktopLauncher.partyPath,partyFileNameTF.getText(),".party");

            DesktopLauncher.file =file;
            DesktopLauncher.isNewFile=true;
            DesktopLauncher.changeSceneBySceneEnum(SceneEnum.PARTY_EDITOR);
        }
        catch(IOException e){
            //print error for user
            errorL.setText(e.getMessage());
        }
    }
}
