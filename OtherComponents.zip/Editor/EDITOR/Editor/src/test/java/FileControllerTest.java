import static org.junit.Assert.*;

import controller.DesktopLauncher;
import controller.FileController;
import javafx.collections.ObservableList;
import org.junit.Test;

import java.io.File;
import java.io.IOException;


/**
 * @author Akin Kula
 *
 */

public class FileControllerTest {
    @Test
    public void createFileTest(){
        File file = null;
        try{
            file = FileController.createFile(DesktopLauncher.scenarioPath, "testscen123",".scenario");
        }
        catch(Exception e){

        }
        assertEquals("testscen123.scenario", file.getName());

        //delete file again
        file.delete();
    }

    @Test
    public void getFilesTest(){
        File file = null;
        try{
            file = FileController.createFile(DesktopLauncher.scenarioPath, "testscen123",".scenario");
        }
        catch(Exception e) {

        }


        ObservableList<String> fileList = null;
        try {
            fileList = FileController.getFiles(DesktopLauncher.scenarioPath);
        } catch (IOException e) {
            e.printStackTrace();
        }
        assertTrue(fileList.contains("testscen123.scenario"));




        //delete file again
        file.delete();
    }


}
